from unittest.mock import MagicMock, patch

from app.services.provisioning.base import ProvisioningError


class FakeVM:
    def __init__(self, **kw):
        self.id = "fake-id"
        self.engine = kw.get("engine", "docker")
        self.os_key = kw.get("os_key", "ubuntu-22.04")
        self.name = kw.get("name", "test")
        self.hostname = kw.get("hostname", "test")
        self.cpu = kw.get("cpu", 1)
        self.ram_mb = kw.get("ram_mb", 512)
        self.disk_gb = kw.get("disk_gb", 5)
        self.username = kw.get("username", "ubuntu")
        self.password_plain = kw.get("password_plain", "password123")
        self.container_id = kw.get("container_id", None)
        self.tmate_socket_path = None


def test_docker_provider_verify_available_raises_when_daemon_unreachable():
    from app.services.provisioning.docker_provider import DockerProvider

    provider = DockerProvider()
    with patch("app.services.provisioning.docker_provider._client") as mock_client:
        mock_client.side_effect = ProvisioningError("Could not connect to the Docker daemon: boom")
        try:
            provider.verify_available()
            assert False, "expected ProvisioningError"
        except ProvisioningError as exc:
            assert "Docker daemon" in str(exc)


def test_docker_provider_create_pulls_correct_image():
    from app.services.provisioning.docker_provider import DockerProvider

    provider = DockerProvider()
    vm = FakeVM(os_key="debian-12")

    fake_container = MagicMock(id="abc123")
    fake_client = MagicMock()
    fake_client.containers.create.return_value = fake_container

    with patch("app.services.provisioning.docker_provider._client", return_value=fake_client):
        container_id = provider.create(vm)

    fake_client.images.pull.assert_called_once_with("debian:12")
    assert container_id == "abc123"


def test_docker_provider_execute_rejects_shell_strings():
    from app.services.provisioning.docker_provider import DockerProvider

    provider = DockerProvider()
    vm = FakeVM()
    try:
        provider.execute(vm, "rm -rf /")  # not a list -> must be rejected
        assert False, "expected ProvisioningError"
    except ProvisioningError:
        pass


def test_lxc_provider_verify_available_missing_tools():
    from app.services.provisioning.lxc_provider import LXCProvider

    provider = LXCProvider()
    with patch("shutil.which", return_value=None):
        try:
            provider.verify_available()
            assert False, "expected ProvisioningError"
        except ProvisioningError as exc:
            assert "not installed" in str(exc)


def test_lxc_provider_execute_uses_lxc_attach():
    from app.services.provisioning import lxc_provider as mod

    provider = mod.LXCProvider()
    vm = FakeVM(container_id="skvm-fake-id")

    with patch.object(mod, "_run", return_value={"exit_code": 0, "stdout": "ok", "stderr": ""}) as mock_run:
        result = provider.execute(vm, ["echo", "hi"])

    called_argv = mock_run.call_args[0][0]
    assert called_argv[0] == "lxc-attach"
    assert "--" in called_argv
    assert result["stdout"] == "ok"


def test_lxc_provider_root_check_blocks_non_root():
    from app.services.provisioning import lxc_provider as mod

    provider = mod.LXCProvider()
    with patch("shutil.which", return_value="/usr/bin/lxc-create"), \
         patch("os.geteuid", return_value=1000):
        try:
            provider.verify_available()
            assert False, "expected ProvisioningError for non-root"
        except ProvisioningError as exc:
            assert "root" in str(exc).lower()


def test_lxc_provider_apt_get_sets_noninteractive_env():
    from app.services.provisioning import lxc_provider as mod

    provider = mod.LXCProvider()
    vm = FakeVM(container_id="skvm-fake-id")

    with patch.object(mod, "_run", return_value={"exit_code": 0, "stdout": "", "stderr": ""}) as mock_run:
        provider._apt_get(vm, ["install", "tmate"])

    called_argv = mock_run.call_args[0][0]
    assert "--set-var" in called_argv
    idx = called_argv.index("--set-var")
    assert called_argv[idx + 1] == "DEBIAN_FRONTEND=noninteractive"
    assert "apt-get" in called_argv
    assert "install" in called_argv
    assert "tmate" in called_argv


def test_docker_provider_apt_get_sets_noninteractive_env():
    from app.services.provisioning.docker_provider import DockerProvider

    provider = DockerProvider()
    vm = FakeVM()

    fake_client = MagicMock()
    fake_container = MagicMock()
    fake_exec_result = MagicMock(exit_code=0, output=(b"", b""))
    fake_container.exec_run.return_value = fake_exec_result
    fake_client.containers.get.return_value = fake_container

    with patch("app.services.provisioning.docker_provider._client", return_value=fake_client):
        provider._apt_get(vm, ["install", "tmate"])

    _, kwargs = fake_container.exec_run.call_args
    assert kwargs.get("environment") == {"DEBIAN_FRONTEND": "noninteractive"}
    from app.services.provisioning import get_provider
    from app.services.provisioning.docker_provider import DockerProvider
    from app.services.provisioning.lxc_provider import LXCProvider

    assert isinstance(get_provider("docker"), DockerProvider)
    assert isinstance(get_provider("lxc"), LXCProvider)
    try:
        get_provider("qemu")
        assert False
    except ValueError:
        pass
