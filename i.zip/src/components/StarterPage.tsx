import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { 
  Server, Cpu, Shield, Zap, Terminal, Globe, 
  ArrowRight, CheckCircle2, Lock, HardDrive, Layers, 
  Play, RefreshCw, Sliders, Download, Copy, Check, Disc
} from 'lucide-react';
import { OSLogo } from './OSLogo';

export const StarterPage: React.FC = () => {
  const { setCurrentView, currentUser, settings, nodes, vms, osImages } = useSKVM();
  const [copied, setCopied] = useState(false);

  const installCmd = 'curl -sSL https://raw.githubusercontent.com/skvm/panel/main/install.sh | bash';

  const copyInstall = () => {
    navigator.clipboard.writeText(installCmd);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-white">
      {/* Top Starter Navigation Bar */}
      <header className="h-16 glass-nav sticky top-0 z-30 flex items-center justify-between px-4 sm:px-8 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl overflow-hidden bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-white shadow-lg shadow-cyan-500/20">
            <img src="/logo.png" alt="SKVM" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-white text-base tracking-tight">{settings.panelName || 'SKVM'}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">v1.0</span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono hidden sm:block">Docker Container Cloud</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <a
            href="/skvm-vps-panel.zip"
            download="skvm-vps-panel.zip"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-cyan-400 hover:text-cyan-300 text-xs font-semibold border border-cyan-500/20 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download ZIP</span>
          </a>

          {currentUser ? (
            <button
              onClick={() => setCurrentView('dashboard')}
              className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center gap-1.5"
            >
              Go to Dashboard <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <>
              <button
                onClick={() => setCurrentView('login')}
                className="px-3.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 text-xs font-semibold border border-white/10 transition-all"
              >
                Sign In
              </button>
              <button
                onClick={() => setCurrentView('register')}
                className="px-4 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-md shadow-cyan-500/20"
              >
                Create Account
              </button>
            </>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-16 pb-16 px-4 sm:px-8 max-w-6xl mx-auto w-full text-center space-y-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-mono">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
          Enterprise Docker-Based VPS Management Panel
        </div>

        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight max-w-4xl mx-auto">
          High-Density Cloud VPS <br className="hidden sm:inline" />
          <span className="bg-gradient-to-r from-cyan-400 via-teal-300 to-blue-500 bg-clip-text text-transparent">
            Powered by Pure Docker
          </span>
        </h1>

        <p className="text-slate-400 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
          SKVM combines the raw performance and sub-second spin-up of containerization with accurate LXCFS hardware allocations, isolated virtual filesystems, and instant TMATE web SSH consoles.
        </p>

        {/* Primary Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
          {currentUser ? (
            <button
              onClick={() => setCurrentView('dashboard')}
              className="px-6 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm transition-all shadow-xl shadow-cyan-500/25 flex items-center gap-2 group"
            >
              Open Control Panel <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </button>
          ) : (
            <>
              <button
                onClick={() => setCurrentView('register')}
                className="px-6 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm transition-all shadow-xl shadow-cyan-500/25 flex items-center gap-2 group"
              >
                Get Started Free <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>
              <button
                onClick={() => setCurrentView('login')}
                className="px-6 py-3 rounded-xl bg-white/[0.06] hover:bg-white/10 text-white border border-white/10 font-semibold text-sm transition-all"
              >
                Sign In to Panel
              </button>
            </>
          )}

          {/* Download ZIP in Hero */}
          <a
            href="/skvm-vps-panel.zip"
            download="skvm-vps-panel.zip"
            className="px-5 py-3 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold text-sm transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/10"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            <span>Download Panel .ZIP</span>
          </a>
        </div>

        {/* One-Liner Quick Install Command */}
        <div className="max-w-xl mx-auto pt-4">
          <div className="bg-black/60 border border-white/10 rounded-2xl p-3.5 flex items-center justify-between gap-3 text-left shadow-xl">
            <div className="flex items-center gap-2.5 overflow-hidden">
              <Terminal className="w-4 h-4 text-cyan-400 shrink-0" />
              <code className="text-xs font-mono text-slate-300 truncate select-all">{installCmd}</code>
            </div>
            <button
              onClick={copyInstall}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors shrink-0"
              title="Copy one-line installer command"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
          <p className="text-[11px] text-slate-500 font-mono mt-1.5">
            Auto-detects Ubuntu, Debian, CentOS, Rocky, Alpine, Codespaces, or any VPS.
          </p>
        </div>

        {/* Floating Ambient Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none"></div>
      </section>

      {/* Supported Operating Systems Showcase */}
      <section className="px-4 sm:px-8 max-w-6xl mx-auto w-full pb-16">
        <div className="text-center space-y-2 mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-slate-400 text-xs font-mono">
            <Disc className="w-3.5 h-3.5 text-cyan-400" /> Supported OS Distribution Templates
          </div>
          <h2 className="text-2xl font-bold text-white">Pre-configured Enterprise Linux Images</h2>
          <p className="text-xs text-slate-400">Launch any Linux flavor in seconds with native SSH & TMATE tunnel ready</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
          {osImages.map(os => (
            <div 
              key={os.id}
              className="p-4 rounded-2xl glass-card border border-white/5 hover:border-cyan-500/30 transition-all flex flex-col items-center text-center space-y-2.5 group"
            >
              <div className="p-2.5 rounded-xl bg-white/[0.03] group-hover:scale-105 transition-transform">
                <OSLogo slug={os.iconSlug || os.family} name={os.name} size="lg" />
              </div>
              <div>
                <span className="font-bold text-xs text-white block">{os.name}</span>
                <span className="text-[10px] text-slate-500 font-mono block mt-0.5">{os.dockerImage}</span>
              </div>
              <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                Min {os.minRamMb} MB RAM
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Feature Highlights Grid */}
      <section className="px-4 sm:px-8 max-w-6xl mx-auto w-full pb-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-3 hover:border-cyan-500/30 transition-all">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">Sub-Second Provisioning</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              No heavy hypervisor emulation. Instances pull optimized base images and launch in under 2 seconds with native Linux kernel execution.
            </p>
          </div>

          <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-3 hover:border-cyan-500/30 transition-all">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">LXCFS & cgroups v2 Quotas</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Enforces real hardware constraints. Running <code className="text-cyan-300 font-mono">free -m</code> or <code className="text-cyan-300 font-mono">nproc</code> inside the VPS reflects the exact allocated cores and RAM.
            </p>
          </div>

          <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-3 hover:border-cyan-500/30 transition-all">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
              <Terminal className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-white">TMATE Web & SSH Access</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every provisioned instance automatically spawns an authenticated secure TMATE tunnel and OpenSSH daemon for immediate terminal access.
            </p>
          </div>
        </div>
      </section>

      {/* Architecture Comparison Table */}
      <section className="px-4 sm:px-8 max-w-5xl mx-auto w-full pb-20">
        <div className="p-6 sm:p-8 rounded-2xl glass-card border border-white/10 space-y-6">
          <div className="text-center space-y-2">
            <h2 className="text-xl font-bold text-white">Traditional KVM vs. SKVM Container VPS</h2>
            <p className="text-xs text-slate-400">Why Docker container virtualization provides higher density and lower latency</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/[0.03] border-b border-white/5 text-[11px] text-slate-400 font-mono uppercase">
                <tr>
                  <th className="px-4 py-3">Metric</th>
                  <th className="px-4 py-3 text-slate-400">Legacy KVM / QEMU</th>
                  <th className="px-4 py-3 text-cyan-400">SKVM Container Cloud</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono text-xs">
                <tr>
                  <td className="px-4 py-3 text-white font-sans font-semibold">Idle RAM Overhead</td>
                  <td className="px-4 py-3 text-rose-400">~800 MB - 1.5 GB / VM</td>
                  <td className="px-4 py-3 text-emerald-400 font-bold">&lt; 35 MB / Instance</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 text-white font-sans font-semibold">Provisioning Latency</td>
                  <td className="px-4 py-3 text-rose-400">45 - 180 seconds</td>
                  <td className="px-4 py-3 text-emerald-400 font-bold">1.8 - 4.5 seconds</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 text-white font-sans font-semibold">Hardware Virtualization</td>
                  <td className="px-4 py-3 text-slate-400">Full VT-x emulation required</td>
                  <td className="px-4 py-3 text-cyan-400">Native host kernel namespaces</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 text-white font-sans font-semibold">Density per 64GB Node</td>
                  <td className="px-4 py-3 text-slate-400">~20-30 VMs</td>
                  <td className="px-4 py-3 text-emerald-400 font-bold">~150+ Container VPS</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-white/5 py-8 px-4 sm:px-8 text-center text-xs text-slate-500 font-mono">
        <div className="flex items-center justify-center gap-4 mb-2">
          <span>{settings.panelName || 'SKVM'} Cloud</span>
          <span>&bull;</span>
          <a href="/skvm-vps-panel.zip" download="skvm-vps-panel.zip" className="text-cyan-400 hover:underline">Download Panel ZIP</a>
          <span>&bull;</span>
          <a href={settings.discordLink} target="_blank" rel="noreferrer" className="hover:text-cyan-400 transition-colors">Discord</a>
          <span>&bull;</span>
          <a href={settings.websiteLink} target="_blank" rel="noreferrer" className="hover:text-cyan-400 transition-colors">Website</a>
        </div>
        <p>&copy; {new Date().getFullYear()} SKVM Project. Enterprise Docker Container VPS Orchestrator.</p>
      </footer>
    </div>
  );
};
