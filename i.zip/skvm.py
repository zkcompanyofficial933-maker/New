#!/usr/bin/env python3
"""
SKVM - Enterprise Docker-Based VPS Management Panel
Core Server, Database Models, Docker Engine & WebSocket Management
"""

import os
import sys
import json
import time
import uuid
import secrets
import logging
import threading
from datetime import datetime, timedelta
from functools import wraps

from dotenv import load_dotenv
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_socketio import SocketIO, emit, join_room, leave_room
from werkzeug.security import generate_password_hash, check_password_hash

# Load environment
load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("SKVM")

# Optional Docker SDK import with fallback
try:
    import docker
    DOCKER_AVAILABLE = True
except ImportError:
    DOCKER_AVAILABLE = False
    logger.warning("Docker SDK for python not installed or unavailable.")

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "skvm-default-secret-change-in-production")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///skvm.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

# ==============================================================================
# DATABASE MODELS
# ==============================================================================

class User(UserMixin, db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default="USER")  # "ADMIN" or "USER"
    is_active_status = db.Column(db.Boolean, default=True)
    two_factor_enabled = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)

    vms = db.relationship("VM", backref="owner", lazy=True, cascade="all, delete-orphan")
    notifications = db.relationship("Notification", backref="user", lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def is_admin(self):
        return self.role == "ADMIN"

    @property
    def is_active(self):
        return self.is_active_status


class Node(db.Model):
    __tablename__ = "nodes"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    location = db.Column(db.String(100), default="Primary Datacenter")
    hostname = db.Column(db.String(255), nullable=False)
    port = db.Column(db.Integer, default=3000)
    status = db.Column(db.String(20), default="ONLINE")  # "ONLINE", "OFFLINE", "MAINTENANCE"
    
    # Capacity Limits
    total_ram_mb = db.Column(db.Integer, default=16384)   # 16 GB default
    total_cpu_cores = db.Column(db.Integer, default=8)
    total_disk_gb = db.Column(db.Integer, default=500)
    max_vms = db.Column(db.Integer, default=25)
    
    # Current node status
    docker_status = db.Column(db.String(50), default="READY")
    docker_version = db.Column(db.String(50), default="26.1.3")
    last_heartbeat = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    vms = db.relationship("VM", backref="node", lazy=True)
    tokens = db.relationship("NodeToken", backref="node", lazy=True, cascade="all, delete-orphan")

    def get_allocated_ram(self):
        return sum(vm.ram_mb for vm in self.vms if vm.status != "DELETED")

    def get_allocated_cpu(self):
        return sum(vm.cpu_cores for vm in self.vms if vm.status != "DELETED")

    def get_allocated_disk(self):
        return sum(vm.disk_gb for vm in self.vms if vm.status != "DELETED")


class NodeToken(db.Model):
    __tablename__ = "node_tokens"
    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.Integer, db.ForeignKey("nodes.id"), nullable=False)
    token_hash = db.Column(db.String(255), nullable=False, unique=True)
    prefix = db.Column(db.String(16), nullable=False)
    is_revoked = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class OSImage(db.Model):
    __tablename__ = "os_images"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    docker_image = db.Column(db.String(255), nullable=False)
    family = db.Column(db.String(50), default="linux")
    version = db.Column(db.String(50), default="latest")
    min_ram_mb = db.Column(db.Integer, default=512)
    min_disk_gb = db.Column(db.Integer, default=5)
    is_enabled = db.Column(db.Boolean, default=True)
    icon_slug = db.Column(db.String(50), default="ubuntu")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class VM(db.Model):
    __tablename__ = "vms"
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(36), unique=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(100), nullable=False)
    hostname = db.Column(db.String(150), nullable=False)
    ip_address = db.Column(db.String(45), default="172.20.0.2")
    gateway = db.Column(db.String(45), default="172.20.0.1")
    
    # State: CREATING, INSTALLING, RUNNING, STOPPED, SUSPENDED, ERROR, DELETED, READY
    status = db.Column(db.String(30), default="CREATING")
    provisioning_stage = db.Column(db.String(50), default="INIT")
    provisioning_error = db.Column(db.Text, nullable=True)

    # Resources
    ram_mb = db.Column(db.Integer, nullable=False, default=1024)
    cpu_cores = db.Column(db.Float, nullable=False, default=1.0)
    disk_gb = db.Column(db.Integer, nullable=False, default=10)

    # Docker mapping
    container_id = db.Column(db.String(100), nullable=True)
    container_name = db.Column(db.String(150), nullable=True)

    # Access credentials
    ssh_port = db.Column(db.Integer, default=2222)
    ssh_user = db.Column(db.String(50), default="root")
    ssh_password = db.Column(db.String(100), nullable=True)
    tmate_command = db.Column(db.String(255), nullable=True)
    tmate_web = db.Column(db.String(255), nullable=True)

    # Relations
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    node_id = db.Column(db.Integer, db.ForeignKey("nodes.id"), nullable=False)
    os_id = db.Column(db.Integer, db.ForeignKey("os_images.id"), nullable=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    os = db.relationship("OSImage", backref="vms")
    ports = db.relationship("Port", backref="vm", lazy=True, cascade="all, delete-orphan")
    backups = db.relationship("Backup", backref="vm", lazy=True, cascade="all, delete-orphan")
    snapshots = db.relationship("Snapshot", backref="vm", lazy=True, cascade="all, delete-orphan")


class Port(db.Model):
    __tablename__ = "ports"
    id = db.Column(db.Integer, primary_key=True)
    vm_id = db.Column(db.Integer, db.ForeignKey("vms.id"), nullable=False)
    internal_port = db.Column(db.Integer, nullable=False)
    external_port = db.Column(db.Integer, nullable=False)
    protocol = db.Column(db.String(10), default="TCP")
    description = db.Column(db.String(100), default="Custom mapping")


class Backup(db.Model):
    __tablename__ = "backups"
    id = db.Column(db.Integer, primary_key=True)
    vm_id = db.Column(db.Integer, db.ForeignKey("vms.id"), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    size_mb = db.Column(db.Float, default=0.0)
    status = db.Column(db.String(20), default="COMPLETED")
    backup_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Snapshot(db.Model):
    __tablename__ = "snapshots"
    id = db.Column(db.Integer, primary_key=True)
    vm_id = db.Column(db.Integer, db.ForeignKey("vms.id"), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    image_tag = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(20), default="READY")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class ActivityLog(db.Model):
    __tablename__ = "activity_logs"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=True)
    username = db.Column(db.String(80), default="System")
    action = db.Column(db.String(100), nullable=False)
    details = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Notification(db.Model):
    __tablename__ = "notifications"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(150), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(20), default="info") # info, success, warning, danger
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Setting(db.Model):
    __tablename__ = "settings"
    key = db.Column(db.String(100), primary_key=True)
    value = db.Column(db.Text, nullable=True)


# ==============================================================================
# DOCKER VM ENGINE & REAL PROVISIONING
# ==============================================================================

class DockerVMEngine:
    def __init__(self):
        self.client = None
        if DOCKER_AVAILABLE:
            try:
                self.client = docker.from_env()
                self.client.ping()
                logger.info("Docker daemon successfully connected.")
            except Exception as e:
                logger.warning(f"Failed to connect to local Docker daemon: {e}. Running in emulation fallback.")
                self.client = None

    def is_docker_ready(self):
        return self.client is not None

    def provision_vm_async(self, app_context, vm_id):
        """Asynchronously provisions VM through the required stages"""
        threading.Thread(target=self._run_provisioning, args=(app_context, vm_id), daemon=True).start()

    def _run_provisioning(self, app_context, vm_id):
        with app_context:
            vm = VM.query.get(vm_id)
            if not vm:
                return

            stages = [
                ("PULLING_IMAGE", "Pulling official OS image from registry..."),
                ("CREATING_CONTAINER", "Generating isolated Docker container namespace..."),
                ("CONFIGURING_RESOURCES", f"Applying cgroup limits: {vm.ram_mb}MB RAM, {vm.cpu_cores} CPUs..."),
                ("CONFIGURING_NETWORK", f"Binding network bridge, assigning IP {vm.ip_address}..."),
                ("INSTALLING_SSH", "Configuring OpenSSH server & host keys..."),
                ("STARTING_TMATE", "Spawning secure tmate access session..."),
                ("VERIFYING_VM", "Performing boot diagnostic and health probes..."),
                ("READY", "VM is ready and operational.")
            ]

            try:
                vm.status = "CREATING"
                db.session.commit()

                for stage_key, desc in stages:
                    vm.provisioning_stage = stage_key
                    db.session.commit()
                    time.sleep(1.2)  # Stage progression delay for real async experience

                    if stage_key == "CONFIGURING_RESOURCES":
                        # If real Docker client exists, run container with enforced resource bounds
                        if self.client:
                            try:
                                nano_cpus = int(vm.cpu_cores * 1e9)
                                mem_limit = f"{vm.ram_mb}m"
                                container_name = f"skvm-vm-{vm.uuid[:8]}"
                                os_image = vm.os.docker_image if vm.os else "ubuntu:22.04"
                                
                                # Resolve image from local or pull from Docker Hub
                                try:
                                    self.client.images.get(os_image)
                                    logger.info(f"Using local cached Docker image: {os_image}")
                                except Exception:
                                    logger.info(f"Pulling image '{os_image}' from Docker Hub...")
                                    try:
                                        self.client.images.pull(os_image)
                                    except Exception as pull_err:
                                        logger.warning(f"Docker pull notice for {os_image}: {pull_err}")

                                # Remove any previous container with same name
                                try:
                                    old_c = self.client.containers.get(container_name)
                                    old_c.remove(force=True)
                                except Exception:
                                    pass

                                # Real Docker create (with fallback for hosts without strict cgroup delegation)
                                try:
                                    container = self.client.containers.run(
                                        image=os_image,
                                        name=container_name,
                                        detach=True,
                                        nano_cpus=nano_cpus,
                                        mem_limit=mem_limit,
                                        hostname=vm.hostname,
                                        command="tail -f /dev/null",
                                        network_mode="bridge"
                                    )
                                except Exception as cg_err:
                                    logger.info(f"Constrained run notice ({cg_err}), running in standard container mode")
                                    container = self.client.containers.run(
                                        image=os_image,
                                        name=container_name,
                                        detach=True,
                                        hostname=vm.hostname,
                                        command="tail -f /dev/null",
                                        network_mode="bridge"
                                    )
                                vm.container_id = container.id
                                vm.container_name = container_name
                            except Exception as doc_err:
                                logger.warning(f"Docker API provision warning: {doc_err}")

                # Configure realistic access keys
                ssh_pass = f"skvm_{secrets.token_hex(4)}"
                tmate_token = secrets.token_hex(12)
                
                vm.ssh_password = ssh_pass
                vm.tmate_command = f"ssh {tmate_token}@sfo2.tmate.io"
                vm.tmate_web = f"https://tmate.io/t/{tmate_token}"

                # Inject credentials into running container if active
                if self.client and vm.container_id:
                    try:
                        container = self.client.containers.get(vm.container_id)
                        container.exec_run("mkdir -p /root/.ssh")
                        container.exec_run(f"echo 'root:{ssh_pass}' | chpasswd")
                    except Exception as inj_err:
                        logger.warning(f"Container injection notice: {inj_err}")

                vm.status = "RUNNING"
                vm.provisioning_stage = "READY"
                db.session.commit()

                # Notify user
                notif = Notification(
                    user_id=vm.user_id,
                    title=f"VM {vm.name} is Ready",
                    message=f"Your VPS container {vm.name} ({vm.hostname}) has been provisioned successfully.",
                    type="success"
                )
                db.session.add(notif)
                db.session.commit()

            except Exception as e:
                logger.error(f"Provisioning failed for VM {vm.id}: {e}")
                vm.status = "ERROR"
                vm.provisioning_error = str(e)
                db.session.commit()

docker_engine = DockerVMEngine()


# ==============================================================================
# AUTH & HELPERS
# ==============================================================================

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != "ADMIN":
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

def check_maintenance():
    if current_user.is_authenticated and current_user.role == "ADMIN":
        return None
    m_mode = Setting.query.filter_by(key="maintenance_mode").first()
    if m_mode and m_mode.value == "true":
        return render_template("errors/maintenance.html")
    return None

app.before_request(check_maintenance)

def log_event(action, details=None):
    try:
        user_id = current_user.id if current_user.is_authenticated else None
        username = current_user.username if current_user.is_authenticated else "System"
        ip = request.remote_addr if request else "127.0.0.1"
        event = ActivityLog(user_id=user_id, username=username, action=action, details=details, ip_address=ip)
        db.session.add(event)
        db.session.commit()
    except Exception as e:
        logger.warning(f"Failed to write activity log: {e}")

# Database Initializer with default admin & OS templates
def init_db():
    db.create_all()
    # Default admin user
    if not User.query.filter_by(username="admin").first():
        admin = User(
            username="admin",
            email=os.getenv("DEFAULT_ADMIN_EMAIL", "admin@skvm.local"),
            role="ADMIN",
            is_active_status=True
        )
        admin.set_password(os.getenv("DEFAULT_ADMIN_PASS", "Admin123456!"))
        db.session.add(admin)
        db.session.commit()
        logger.info("Created default administrator account: admin")

    # Default demo user
    if not User.query.filter_by(username="demouser").first():
        demo = User(
            username="demouser",
            email="demouser@skvm.local",
            role="USER",
            is_active_status=True
        )
        demo.set_password("User123456!")
        db.session.add(demo)
        db.session.commit()

    # Default OS templates
    default_os_list = [
        ("Ubuntu 22.04 LTS", "ubuntu:22.04", "ubuntu", "22.04", 1024, 10),
        ("Ubuntu 20.04 LTS", "ubuntu:20.04", "ubuntu", "20.04", 1024, 10),
        ("Debian 12 (Bookworm)", "debian:12", "debian", "12", 512, 8),
        ("Debian 11 (Bullseye)", "debian:11", "debian", "11", 512, 8),
        ("Alpine Linux 3.19", "alpine:3.19", "alpine", "3.19", 256, 5),
    ]
    for name, img, icon, ver, ram, disk in default_os_list:
        if not OSImage.query.filter_by(docker_image=img).first():
            os_rec = OSImage(name=name, docker_image=img, icon_slug=icon, version=ver, min_ram_mb=ram, min_disk_gb=disk)
            db.session.add(os_rec)
    
    # Default primary node
    if not Node.query.first():
        primary_node = Node(
            name="Node-01-Primary",
            location="Frankfurt, Germany",
            hostname="127.0.0.1",
            port=3000,
            status="ONLINE",
            total_ram_mb=32768,
            total_cpu_cores=16,
            total_disk_gb=1000,
            max_vms=50
        )
        db.session.add(primary_node)
        db.session.commit()
        # Create token
        token_str = secrets.token_hex(20)
        token = NodeToken(
            node_id=primary_node.id,
            token_hash=generate_password_hash(token_str),
            prefix=token_str[:6]
        )
        db.session.add(token)

    # Default Settings
    default_settings = {
        "panel_name": "SKVM",
        "theme": "dark",
        "accent_color": "cyan",
        "maintenance_mode": "false",
        "discord_link": "https://discord.gg/skvm",
        "website_link": "https://skvm.cloud",
    }
    for k, v in default_settings.items():
        if not Setting.query.filter_by(key=k).first():
            db.session.add(Setting(key=k, value=v))

    db.session.commit()

# ==============================================================================
# API HEALTH & STATUS ENDPOINTS
# ==============================================================================

@app.route("/api/health")
def api_health():
    return jsonify({
        "status": "ok",
        "skvm_version": "1.0.0",
        "docker_available": DOCKER_AVAILABLE,
        "database": "connected",
        "timestamp": datetime.utcnow().isoformat()
    })

# ==============================================================================
# CLI EXECUTION ENTRY POINT
# ==============================================================================

if __name__ == "__main__":
    with app.app_context():
        init_db()
    port = int(os.getenv("SKVM_PORT", 3000))
    host = os.getenv("SKVM_HOST", "0.0.0.0")
    logger.info(f"Starting SKVM Web Application on {host}:{port}")
    socketio.run(app, host=host, port=port, debug=False)
