import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { CONFIG } from './server/config.js';
import { apiRouter } from './server/api/router.js';
import { seedDatabase } from './server/db/seed.js';
import { wsBroker } from './server/websocket.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = http.createServer(app);

  // Body parser
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  // Cookie parser middleware
  app.use((req, res, next) => {
    const cookieHeader = req.headers.cookie;
    const cookies: Record<string, string> = {};
    if (cookieHeader) {
      cookieHeader.split(';').forEach(c => {
        const [k, ...v] = c.trim().split('=');
        if (k) cookies[k] = decodeURIComponent(v.join('='));
      });
    }
    (req as any).cookies = cookies;
    next();
  });

  // Mount API router
  app.use('/api/v1', apiRouter);

  // Initialize WebSocket Broker
  wsBroker.init(server);

  // Seed DB with Admin & Node capabilities
  await seedDatabase();

  // Development vs Production Frontend Serving
  if (CONFIG.ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(CONFIG.PORT, CONFIG.HOST, () => {
    console.log(`[VortexPanel] Server listening at http://${CONFIG.HOST}:${CONFIG.PORT}`);
    console.log(`[VortexPanel] Default Admin: ${CONFIG.DEFAULT_ADMIN_EMAIL}`);
  });
}

startServer().catch(err => {
  console.error('[VortexPanel] Fatal startup error:', err);
  process.exit(1);
});
