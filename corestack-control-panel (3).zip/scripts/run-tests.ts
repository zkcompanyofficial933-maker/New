import {
  hashPassword,
  verifyPassword,
  generateApiKey,
  generateSessionToken,
  timingSafeStringEqual,
} from '../server/auth/crypto.js';
import { validateHostCapacity, getHostMetrics } from '../server/resources/hostMetrics.js';
import { PortAllocator } from '../server/networking/portAllocator.js';
import { VMStatus } from '../server/db/schema.js';
import { LXCProvider } from '../server/providers/lxc.js';
import { sanitizeMetadata, db } from '../server/db/database.js';
import { authorizeVM, requireAuth, AuthenticatedRequest } from '../server/auth/middleware.js';
import { validateProductionConfig, INSECURE_DEFAULT_SECRET, INSECURE_DEFAULT_ADMIN_PASSWORD } from '../server/config.js';
import { validateSafeContainerPath, validateZipSlipPath } from '../server/api/router.js';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string) {
  if (condition) {
    console.log(`  ✓ PASS: ${testName}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${testName}`);
    failed++;
  }
}

async function runAllTests() {
  console.log('=== [VORTEX PANEL COMPREHENSIVE SECURITY & AUDIT TEST SUITE] ===\n');

  // ==========================================
  // Suite 1: Cryptography & Timing-Safe Checks
  // ==========================================
  console.log('[Suite 1: Cryptography & Timing-Safe Hash Verification]');
  const rawPass = 'UltraSecureVPS!#2026';
  const hashed = await hashPassword(rawPass);
  assert(hashed.includes(':') && hashed.length > 50, 'Password hash format (salt:hash)');
  const isValid = await verifyPassword(rawPass, hashed);
  assert(isValid === true, 'Verify valid password');
  const isInvalid = await verifyPassword('WrongPassword!', hashed);
  assert(isInvalid === false, 'Reject invalid password');

  const { fullKey, keyPrefix, keyHash } = generateApiKey();
  assert(fullKey.startsWith('vp_live_'), 'API key prefix format');
  assert(keyPrefix.length > 5 && keyHash.length === 64, 'SHA-256 key hash length');

  const { rawToken, tokenHash } = generateSessionToken();
  assert(rawToken.length === 64 && tokenHash.length === 64, 'Session token entropy');

  // Constant-time hash verification tests
  const tokenA = 'a8f5c3d2e1b4a7c9f0e2d4b6a8c0e2f4a6b8d0e2f4a6b8c0d2e4f6a8b0c2d4e6';
  const tokenB = 'a8f5c3d2e1b4a7c9f0e2d4b6a8c0e2f4a6b8d0e2f4a6b8c0d2e4f6a8b0c2d4e6';
  const tokenC = 'b8f5c3d2e1b4a7c9f0e2d4b6a8c0e2f4a6b8d0e2f4a6b8c0d2e4f6a8b0c2d4e7';
  assert(timingSafeStringEqual(tokenA, tokenB) === true, 'timingSafeStringEqual returns true for identical hashes');
  assert(timingSafeStringEqual(tokenA, tokenC) === false, 'timingSafeStringEqual returns false for differing hashes');
  assert(timingSafeStringEqual(tokenA, 'short') === false, 'timingSafeStringEqual handles differing length safely');

  // ==========================================
  // Suite 2: LXC Host Command Injection Prevention
  // ==========================================
  console.log('\n[Suite 2: LXC Input Validation & Command Injection Prevention]');
  const lxc = new LXCProvider();

  const testLxcValidate = (id: any): boolean => {
    try {
      (lxc as any).validateIdentifier(id, 'test_id');
      return true;
    } catch {
      return false;
    }
  };

  assert(testLxcValidate('web-container-01') === true, 'Allows valid identifier (web-container-01)');
  assert(testLxcValidate('vps_workload_99') === true, 'Allows alphanumeric with underscore and dash');
  assert(testLxcValidate('-f') === false, 'Blocks flag injection: leading dash (-f)');
  assert(testLxcValidate('--destroy') === false, 'Blocks option injection: leading double dash (--destroy)');
  assert(testLxcValidate('name; rm -rf /') === false, 'Blocks command separator (; semicolon)');
  assert(testLxcValidate('name & reboot') === false, 'Blocks command background operator (&)');
  assert(testLxcValidate('name | cat') === false, 'Blocks pipe operator (|)');
  assert(testLxcValidate('name $(reboot)') === false, 'Blocks subshell execution ($(...))');
  assert(testLxcValidate('name`id`') === false, 'Blocks backtick command substitution');
  assert(testLxcValidate('name\x00') === false, 'Blocks null byte injection');
  assert(testLxcValidate('name with spaces') === false, 'Blocks whitespace in container identifier');
  assert(testLxcValidate('') === false, 'Blocks empty identifier');

  // ==========================================
  // Suite 3: Authorization (IDOR) & Scope Checks
  // ==========================================
  console.log('\n[Suite 3: Authorization, IDOR Defense, and Scope Enforcement]');

  const testUserId = 'user-auth-test-01';
  const otherUserId = 'user-auth-test-02';
  const testVmId = 'vm-auth-test-01';

  await db.createUser({
    id: testUserId,
    email: 'normaluser@vortex.local',
    password_hash: 'dummy',
    role: 'user',
    status: 'active',
    must_change_password: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    last_login_at: null,
  });

  await db.createUser({
    id: otherUserId,
    email: 'otheruser@vortex.local',
    password_hash: 'dummy',
    role: 'user',
    status: 'active',
    must_change_password: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    last_login_at: null,
  });

  await db.createVM(
    {
      id: testVmId,
      owner_id: testUserId,
      local_node_id: 'node-local',
      name: 'auth-test-vm',
      slug: 'auth-test-vm',
      requested_os: 'ubuntu:22.04',
      provider: 'docker',
      provider_resource_id: null,
      status: 'READY',
      status_version: 0,
      failure_code: null,
      failure_message: null,
      hostname: 'auth-test-vm',
      username: 'ubuntu',
      ssh_enabled: false,
      ssh_host_port: null,
      ip_address: '10.0.0.5',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      deleted_at: null,
    },
    {
      vm_id: testVmId,
      cpu_cores: 1,
      memory_bytes: 1024 * 1024 * 512,
      disk_bytes: 1024 * 1024 * 1024 * 10,
      pids_limit: 1024,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
  );

  const testAuthMiddleware = async (
    action: 'read' | 'control' | 'delete' | 'terminal' | 'files',
    user: any,
    params: Record<string, string>,
    apiKeyScopes?: string[]
  ): Promise<{ status: number; passed: boolean }> => {
    return new Promise(resolve => {
      let resolved = false;
      const req: any = { user, params, apiKeyScopes, requestId: 'req_test' };
      const res: any = {
        status: (code: number) => {
          return {
            json: () => {
              if (!resolved) {
                resolved = true;
                resolve({ status: code, passed: false });
              }
            },
          };
        },
      };
      const next = () => {
        if (!resolved) {
          resolved = true;
          resolve({ status: 200, passed: true });
        }
      };

      authorizeVM(action)(req, res, next);
    });
  };

  const normId = await testAuthMiddleware('read', { id: testUserId, role: 'user' }, { id: testVmId });
  assert(normId.passed, 'Parameter normalization accepts req.params.id');

  const normVmId = await testAuthMiddleware('read', { id: testUserId, role: 'user' }, { vm_id: testVmId });
  assert(normVmId.passed, 'Parameter normalization accepts req.params.vm_id');

  const normTargetId = await testAuthMiddleware('read', { id: testUserId, role: 'user' }, { target_id: testVmId });
  assert(normTargetId.passed, 'Parameter normalization accepts req.params.target_id');

  const missingId = await testAuthMiddleware('read', { id: testUserId, role: 'user' }, {});
  assert(missingId.status === 403 && !missingId.passed, 'Missing identifier fails closed with 403 Forbidden');

  const idorAttempt = await testAuthMiddleware('read', { id: otherUserId, role: 'user' }, { id: testVmId });
  assert(idorAttempt.status === 403 && !idorAttempt.passed, 'IDOR blocked: Non-owner cannot access another user workload');

  const adminUser = { id: 'admin-1', role: 'admin' };
  const adminKeyWithReadScope = await testAuthMiddleware('delete', adminUser, { id: testVmId }, ['vm:read']);
  assert(
    adminKeyWithReadScope.status === 403 && !adminKeyWithReadScope.passed,
    'Scope check enforced before role: Admin API key with vm:read is blocked from delete'
  );

  const adminKeyWithControlScope = await testAuthMiddleware('terminal', adminUser, { id: testVmId }, ['vm:control']);
  assert(
    adminKeyWithControlScope.status === 403 && !adminKeyWithControlScope.passed,
    'Scope check enforced before role: Admin API key with vm:control is blocked from terminal'
  );

  const adminKeyWithFullScope = await testAuthMiddleware('delete', adminUser, { id: testVmId }, ['*']);
  assert(adminKeyWithFullScope.passed, 'Wildcard API key allowed full access');

  // ==========================================
  // Suite 4: Activity Log Sensitive Data Redaction
  // ==========================================
  console.log('\n[Suite 4: Activity Log Data Sanitization & Redaction]');
  const rawPayload = {
    email: 'admin@vortex.local',
    password: 'SuperSecretPassword123!',
    api_key: 'vp_live_998877665544332211',
    credentials: {
      private_key: '-----BEGIN RSA PRIVATE KEY-----...',
      ssh_key: 'ssh-rsa AAAAB3...',
      token: 'session_token_xyz',
    },
    nested: [
      { secret: 'very_secret', cookie: 'vortex_session=abc' },
      { non_sensitive: 'safe_value' },
    ],
    safe_param: 'ubuntu:22.04',
  };

  const sanitized = sanitizeMetadata(rawPayload);
  assert(sanitized.password === '[REDACTED]', 'Redacted password field');
  assert(sanitized.api_key === '[REDACTED]', 'Redacted api_key field');
  assert(sanitized.credentials.private_key === '[REDACTED]', 'Redacted nested private_key field');
  assert(sanitized.credentials.ssh_key === '[REDACTED]', 'Redacted nested ssh_key field');
  assert(sanitized.credentials.token === '[REDACTED]', 'Redacted nested token field');
  assert(sanitized.nested[0].secret === '[REDACTED]', 'Redacted array object secret field');
  assert(sanitized.nested[0].cookie === '[REDACTED]', 'Redacted array object cookie field');
  assert(sanitized.nested[1].non_sensitive === 'safe_value', 'Preserved non-sensitive nested data');
  assert(sanitized.safe_param === 'ubuntu:22.04', 'Preserved top-level safe data');

  const savedLog = await db.logActivity({
    actor_user_id: testUserId,
    vm_id: testVmId,
    action: 'test.sensitive_action',
    outcome: 'succeeded',
    request_id: 'req_audit_test',
    ip_hash: null,
    metadata_json: { password: 'leak_attempt_pass', normal: 'safe' },
  });
  assert(savedLog.metadata_json.password === '[REDACTED]', 'db.logActivity automatically redacts sensitive keys');

  // ==========================================
  // Suite 5: Fast Indexed Lookups & Telemetry
  // ==========================================
  console.log('\n[Suite 5: Fast Indexed Lookups & Decoupled Telemetry]');
  const { rawToken: sessToken, tokenHash: sessHash } = generateSessionToken();
  const sessionRecord = {
    id: 'sess-test-01',
    user_id: testUserId,
    token_hash: sessHash,
    expires_at: new Date(Date.now() + 3600000).toISOString(),
    created_at: new Date().toISOString(),
    revoked_at: null,
    ip_hash: null,
    user_agent_hash: null,
  };
  await db.createSession(sessionRecord);

  const foundSession = db.getSessionByTokenHash(sessHash);
  assert(foundSession?.id === 'sess-test-01', 'O(1) indexed session lookup by token hash succeeds');

  const notFoundSession = db.getSessionByTokenHash('non_existent_hash');
  assert(notFoundSession === undefined, 'Returns undefined for missing session hash');

  await db.addMonitoringSample({
    vm_id: testVmId,
    sampled_at: new Date().toISOString(),
    cpu_usage_percent: 15.5,
    memory_used_bytes: 1024 * 1024 * 128,
    memory_limit_bytes: 1024 * 1024 * 512,
    disk_used_bytes: null,
    disk_limit_bytes: null,
    net_rx_bytes: 1000,
    net_tx_bytes: 2000,
    pids: 12,
  });

  const latestSample = db.getLatestMonitoringSample(testVmId);
  assert(latestSample?.cpu_usage_percent === 15.5, 'In-memory ring buffer returns latest sample immediately');
  assert(latestSample?.pids === 12, 'Sample attributes preserved in ring buffer');

  // ==========================================
  // Suite 6: Production Secrets Validator
  // ==========================================
  console.log('\n[Suite 6: Production Secrets & Environment Enforcement]');
  let prodCheckFailed = false;
  try {
    const mockProdConfig: any = {
      ENV: 'production',
      SESSION_SECRET: INSECURE_DEFAULT_SECRET,
      DEFAULT_ADMIN_PASSWORD: 'custom_secure_password_123',
    };
    const originalExit = process.exit;
    (process as any).exit = (code: number) => {
      prodCheckFailed = true;
      throw new Error(`process.exit(${code}) called`);
    };

    try {
      validateProductionConfig(mockProdConfig);
    } catch {
      // Caught exit
    } finally {
      process.exit = originalExit;
    }
  } catch {
    prodCheckFailed = true;
  }
  assert(prodCheckFailed, 'Refuses startup when default SESSION_SECRET is used in production');

  // ==========================================
  // Suite 7: Port Allocation Ownership & Boundaries (Task 4)
  // ==========================================
  console.log('\n[Suite 7: Port Allocation IDOR & Boundary Checks]');
  let portBoundaryRejected = false;
  try {
    await db.createPortAllocation({
      id: 'port-priv-01',
      vm_id: testVmId,
      protocol: 'tcp',
      host_port: 80, // Privileged port < 1024
      container_port: 80,
      purpose: 'http',
      state: 'reserved',
      created_at: new Date().toISOString(),
      released_at: null,
    });
  } catch (err: any) {
    if (err.message.includes('INVALID_PORT_RANGE')) {
      portBoundaryRejected = true;
    }
  }
  assert(portBoundaryRejected, 'Blocks allocation of privileged system ports (< 1024)');

  let portIdorRejected = false;
  try {
    const maliciousUser: any = { id: otherUserId, role: 'user' };
    await db.createPortAllocation(
      {
        id: 'port-idor-01',
        vm_id: testVmId, // Belongs to testUserId, not otherUserId!
        protocol: 'tcp',
        host_port: 25000,
        container_port: 22,
        purpose: 'ssh',
        state: 'reserved',
        created_at: new Date().toISOString(),
        released_at: null,
      },
      maliciousUser
    );
  } catch (err: any) {
    if (err.message.includes('FORBIDDEN')) {
      portIdorRejected = true;
    }
  }
  assert(portIdorRejected, 'Blocks port allocation to unowned workload (IDOR prevented)');

  // ==========================================
  // Suite 8: Change-Password Flag Enforcement (Task 5)
  // ==========================================
  console.log('\n[Suite 8: Change-Password Flag Enforcement]');
  const tempUser: any = { id: 'temp-u1', role: 'admin', status: 'active', must_change_password: true };
  const testPasswordChangeEnforcement = async (path: string): Promise<number> => {
    return new Promise(resolve => {
      const { rawToken, tokenHash } = generateSessionToken();
      db.createSession({
        id: 'sess-temp-01',
        user_id: tempUser.id,
        token_hash: tokenHash,
        expires_at: new Date(Date.now() + 3600000).toISOString(),
        created_at: new Date().toISOString(),
        revoked_at: null,
        ip_hash: null,
        user_agent_hash: null,
      });

      // Insert tempUser into db
      db.createUser({
        ...tempUser,
        email: 'tempadmin@vortex.local',
        password_hash: 'dummy',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        last_login_at: null,
      });

      const req: any = {
        headers: { authorization: `Bearer ${rawToken}` },
        baseUrl: '/api/v1',
        path,
        method: 'GET',
      };
      const res: any = {
        status: (code: number) => ({ json: () => resolve(code) }),
      };
      const next = () => resolve(200);

      requireAuth(req, res, next);
    });
  };

  const blockedVmAccess = await testPasswordChangeEnforcement('/vms');
  assert(blockedVmAccess === 403, 'Blocks general API access when must_change_password is true (HTTP 403)');

  const allowedChangePass = await testPasswordChangeEnforcement('/auth/change-password');
  assert(allowedChangePass === 200, 'Permits access to /auth/change-password when must_change_password is true');

  // ==========================================
  // Suite 9: Anti-CSRF Header Defense (Task 6)
  // ==========================================
  console.log('\n[Suite 9: Anti-CSRF Protection for Cookie Requests]');
  const testCsrfProtection = async (hasHeader: boolean): Promise<number> => {
    return new Promise(resolve => {
      const { rawToken, tokenHash } = generateSessionToken();
      const activeUser: any = { id: 'csrf-u1', role: 'user', status: 'active', must_change_password: false };
      db.createUser({
        ...activeUser,
        email: 'csrfuser@vortex.local',
        password_hash: 'dummy',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        last_login_at: null,
      });
      db.createSession({
        id: 'sess-csrf-01',
        user_id: activeUser.id,
        token_hash: tokenHash,
        expires_at: new Date(Date.now() + 3600000).toISOString(),
        created_at: new Date().toISOString(),
        revoked_at: null,
        ip_hash: null,
        user_agent_hash: null,
      });

      const headers: Record<string, string> = {
        cookie: `vortex_session=${rawToken}`,
      };
      if (hasHeader) {
        headers['x-vortex-requested-with'] = 'XMLHttpRequest';
      }

      const req: any = {
        method: 'POST',
        headers,
        baseUrl: '/api/v1',
        path: '/vms/123/stop',
      };
      const res: any = {
        status: (code: number) => ({ json: () => resolve(code) }),
      };
      const next = () => resolve(200);

      requireAuth(req, res, next);
    });
  };

  const blockedCsrf = await testCsrfProtection(false);
  assert(blockedCsrf === 403, 'Blocks state-changing cookie request missing Anti-CSRF header (HTTP 403)');

  const allowedCsrf = await testCsrfProtection(true);
  assert(allowedCsrf === 200, 'Allows state-changing cookie request with Anti-CSRF header (HTTP 200)');

  // ==========================================
  // Suite 10: Path Traversal & Zip-Slip Defense (Task 7)
  // ==========================================
  console.log('\n[Suite 10: Path Traversal & Zip-Slip Defense]');

  const testSafePath = (p: string): boolean => {
    try {
      validateSafeContainerPath(p);
      return true;
    } catch {
      return false;
    }
  };

  assert(testSafePath('/var/log/syslog') === true, 'Allows valid absolute path (/var/log/syslog)');
  assert(testSafePath('/etc/nginx/nginx.conf') === true, 'Allows valid nested config path');
  assert(testSafePath('../../etc/shadow') === false, 'Blocks relative path traversal (../../etc/shadow)');
  assert(testSafePath('/var/www/../../etc/passwd') === false, 'Blocks embedded directory traversal (/var/www/../../etc/passwd)');
  assert(testSafePath('/var/log\x00/evil') === false, 'Blocks null byte in path');
  assert(testSafePath('/var/log; rm -rf /') === false, 'Blocks command separator in path');
  assert(testSafePath('/var/`id`') === false, 'Blocks backtick command injection in path');

  const testZipSlip = (dest: string, entry: string): boolean => {
    try {
      validateZipSlipPath(dest, entry);
      return true;
    } catch {
      return false;
    }
  };

  assert(testZipSlip('/tmp/extracted', 'file.txt') === true, 'Allows legitimate entry in archive');
  assert(testZipSlip('/tmp/extracted', 'sub/dir/app.js') === true, 'Allows legitimate sub-entry in archive');
  assert(testZipSlip('/tmp/extracted', '../../etc/cron.d/evil') === false, 'Blocks Zip-Slip traversal out of target directory');

  // ==========================================
  // Suite 11: Host Telemetry & State Machine (Existing Invariants)
  // ==========================================
  console.log('\n[Suite 11: Host Capacity & State Machine Invariants]');
  const metrics = await getHostMetrics();
  assert(metrics.cpu.cores >= 1, `Host CPU cores detected (${metrics.cpu.cores})`);
  assert(metrics.memory.total_bytes > 0, `Host RAM total detected (${metrics.memory.total_bytes} bytes)`);

  const validCap = await validateHostCapacity(1, 1024 * 1024 * 64);
  assert(validCap.valid === true, 'Capacity check approves sensible allocation (64MB)');

  const invalidCap = await validateHostCapacity(128, 1024 * 1024 * 1024 * 1000);
  assert(invalidCap.valid === false, 'Capacity check rejects impossible allocation (1TB)');

  const isPortSafe = await PortAllocator.isPortFreeOnHost(39876);
  assert(typeof isPortSafe === 'boolean', `Host port 39876 bindability test: ${isPortSafe}`);

  console.log(`\n=== RESULTS: ${passed} PASSED, ${failed} FAILED ===\n`);
  if (failed > 0) process.exit(1);
  process.exit(0);
}

runAllTests().catch(err => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
