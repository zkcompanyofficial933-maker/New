#!/usr/bin/env node

/**
 * VortexPanel - Codebase Packaging & Review Inspection Tool
 *
 * Scans the project, prints the file tree, and packages all relevant source code
 * into a single archive ('vortexpanel-review-bundle.tar.gz') while excluding
 * heavy build artifacts, dependencies, and git histories.
 *
 * Compatible with Node.js on macOS, Linux, and Windows.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import zlib from 'zlib';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

// Exclude patterns
const EXCLUDE_DIRS = new Set([
  'node_modules',
  'dist',
  'build',
  '.git',
  '.cache',
  '.temp',
  'tmp',
  'data',
  '.vscode',
  '.idea',
]);

const EXCLUDE_FILES = new Set([
  'vortexpanel-review-bundle.tar.gz',
  'vortexpanel-review-bundle.zip',
  'vortex.db.json',
  'vortex.metrics.json',
  '.DS_Store',
  'Thumbs.db',
]);

// Relevant extensions
const ALLOWED_EXTS = new Set([
  '.ts',
  '.tsx',
  '.js',
  '.jsx',
  '.mjs',
  '.cjs',
  '.json',
  '.html',
  '.css',
  '.sh',
  '.md',
  '.example',
]);

function walkDir(dir, relativeTo = ROOT_DIR) {
  const files = [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = path.relative(relativeTo, fullPath);

    if (entry.isDirectory()) {
      if (!EXCLUDE_DIRS.has(entry.name) && !entry.name.startsWith('.')) {
        files.push(...walkDir(fullPath, relativeTo));
      }
    } else if (entry.isFile()) {
      if (EXCLUDE_FILES.has(entry.name)) continue;
      const ext = path.extname(entry.name);
      if (ALLOWED_EXTS.has(ext) || entry.name.startsWith('.env') || entry.name.endsWith('.rules')) {
        files.push({ fullPath, relPath, size: fs.statSync(fullPath).size });
      }
    }
  }

  return files;
}

console.log('=== VORTEXPANEL CODEBASE INSPECTION & BUNDLER ===\n');
console.log(`Scanning root: ${ROOT_DIR}\n`);

const files = walkDir(ROOT_DIR);

console.log('Included Source Files:');
let totalBytes = 0;
for (const f of files) {
  totalBytes += f.size;
  console.log(`  [${(f.size / 1024).toFixed(1).padStart(6, ' ')} KB] ${f.relPath}`);
}

console.log(`\nTotal Files: ${files.length}`);
console.log(`Total Uncompressed Size: ${(totalBytes / 1024).toFixed(1)} KB`);

// Create simple portable tar archive
function createTar(filesList, outputFile) {
  const chunks = [];

  function pad(buf, size) {
    const padding = size - (buf.length % size);
    if (padding === size) return buf;
    return Buffer.concat([buf, Buffer.alloc(padding)]);
  }

  for (const file of filesList) {
    const content = fs.readFileSync(file.fullPath);
    const header = Buffer.alloc(512);

    // Standard UStar header format
    const name = file.relPath.replace(/\\/g, '/');
    header.write(name, 0, 100, 'utf-8'); // file name
    header.write('0000644\0', 100, 8, 'ascii'); // mode
    header.write('0000000\0', 108, 8, 'ascii'); // uid
    header.write('0000000\0', 116, 8, 'ascii'); // gid
    header.write(content.length.toString(8).padStart(11, '0') + '\0', 124, 12, 'ascii'); // size
    header.write(Math.floor(Date.now() / 1000).toString(8).padStart(11, '0') + '\0', 136, 12, 'ascii'); // mtime
    header.write('        ', 148, 8, 'ascii'); // checksum placeholder
    header.write('0', 156, 1, 'ascii'); // typeflag
    header.write('ustar\0', 257, 6, 'ascii'); // magic
    header.write('00', 263, 2, 'ascii'); // version

    // Compute checksum
    let sum = 0;
    for (let i = 0; i < 512; i++) {
      sum += header[i];
    }
    header.write(sum.toString(8).padStart(6, '0') + '\0 ', 148, 8, 'ascii');

    chunks.push(header);
    chunks.push(pad(content, 512));
  }

  // 2 null blocks at the end of tar
  chunks.push(Buffer.alloc(1024));

  const tarBuffer = Buffer.concat(chunks);
  const compressed = zlib.gzipSync(tarBuffer);
  fs.writeFileSync(outputFile, compressed);

  console.log(`\nArchive created: ${path.resolve(outputFile)}`);
  console.log(`Compressed Archive Size: ${(compressed.length / 1024).toFixed(1)} KB`);
}

const outputPath = path.join(ROOT_DIR, 'vortexpanel-review-bundle.tar.gz');
createTar(files, outputPath);

console.log('\nReady for architectural and security review!');
