#!/usr/bin/env bash
# ==============================================================================
# VortexPanel - Production Linux Installer
# Supported: Ubuntu 20.04, Ubuntu 22.04, Debian 11, Debian 12
# Idempotent: Safe to re-run; will NOT erase database, workloads, or user data.
# ==============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

# 1. Verify root privileges
if [ "$EUID" -ne 0 ]; then
    log_error "Please run this installer as root (e.g., sudo bash install.sh)."
    exit 1
fi

log_info "Starting VortexPanel production installer..."

# 2. Detect OS & Architecture
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    VERSION_ID=$VERSION_ID
else
    log_error "Cannot detect operating system. /etc/os-release not found."
    exit 1
fi

ARCH=$(uname -m)
if [ "$ARCH" != "x86_64" ] && [ "$ARCH" != "aarch64" ]; then
    log_error "Unsupported architecture: $ARCH. VortexPanel supports x86_64 and aarch64."
    exit 1
fi

log_info "Detected OS: $OS $VERSION_ID ($ARCH)"

case "$OS" in
    ubuntu)
        if [ "$VERSION_ID" != "20.04" ] && [ "$VERSION_ID" != "22.04" ] && [ "$VERSION_ID" != "24.04" ]; then
            log_warn "Ubuntu version $VERSION_ID is not officially verified. Expected 20.04 or 22.04."
        fi
        ;;
    debian)
        if [ "$VERSION_ID" != "11" ] && [ "$VERSION_ID" != "12" ]; then
            log_warn "Debian version $VERSION_ID is not officially verified. Expected 11 or 12."
        fi
        ;;
    *)
        log_error "Unsupported Linux distribution: $OS. Supported: Ubuntu, Debian."
        exit 1
        ;;
esac

# 3. Update repositories and install base utilities
log_info "Updating system packages..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y --no-install-recommends \
    curl \
    wget \
    git \
    ca-certificates \
    gnupg \
    lsb-release \
    net-tools \
    tar \
    gzip

# 4. Install Docker Engine if not present
if ! command -v docker &> /dev/null; then
    log_info "Docker not found. Installing official Docker Engine..."
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL "https://download.docker.com/linux/$OS/gpg" | gpg --dearmor --yes -o /etc/apt/keyrings/docker.gpg
    chmod a+r /etc/apt/keyrings/docker.gpg

    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/$OS \
      $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null

    apt-get update -y
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    systemctl enable --now docker
    log_success "Docker Engine installed and started."
else
    log_info "Docker is already installed. Ensuring service is active..."
    systemctl enable --now docker || true
fi

# Verify Docker socket
if [ -S /var/run/docker.sock ]; then
    log_success "Docker daemon verified at /var/run/docker.sock"
else
    log_warn "Docker socket not detected. Checking systemctl status..."
    systemctl status docker --no-pager || true
fi

# 5. Install Node.js 20 LTS if needed
if ! command -v node &> /dev/null || [ "$(node -v | cut -d'.' -f1 | tr -d 'v')" -lt 20 ]; then
    log_info "Installing Node.js 20 LTS..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
    log_success "Node.js $(node -v) and npm $(npm -v) installed."
else
    log_info "Node.js $(node -v) is already installed."
fi

# 6. Setup Directory Structure
INSTALL_DIR="/opt/vortexpanel"
DATA_DIR="/opt/vortexpanel/data"
mkdir -p "$INSTALL_DIR"
mkdir -p "$DATA_DIR"

log_info "Deploying application to $INSTALL_DIR..."
# If installer is run from within the repo, copy files
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ "$SCRIPT_DIR" != "$INSTALL_DIR" ]; then
    cp -ru "$SCRIPT_DIR"/* "$INSTALL_DIR"/ || true
fi

cd "$INSTALL_DIR"

# 7. Environment Configuration (Idempotent: preserve existing secrets!)
ENV_FILE="$INSTALL_DIR/.env"
if [ ! -f "$ENV_FILE" ]; then
    log_info "Generating production .env configuration..."
    SESSION_SECRET=$(openssl rand -hex 32)
    ADMIN_PASS=$(openssl rand -base64 12)
    cat <<EOF > "$ENV_FILE"
NODE_ENV=production
PORT=3000
HOST=0.0.0.0
DATA_DIR=$DATA_DIR
SESSION_SECRET=$SESSION_SECRET
DEFAULT_ADMIN_EMAIL=admin@vortex.local
DEFAULT_ADMIN_PASSWORD=$ADMIN_PASS
DOCKER_SOCKET=/var/run/docker.sock
CONTAINER_ENGINE=docker
PORT_RANGE_START=20000
PORT_RANGE_END=40000
EOF
    log_success "Created fresh .env configuration with secure random credentials."
    echo -e "${YELLOW}Initial Administrator Credentials:${NC}"
    echo -e "Email:    admin@vortex.local"
    echo -e "Password: $ADMIN_PASS"
else
    log_info "Existing .env found. Preserving current secrets and database."
fi

# 8. Install NPM dependencies & Build Frontend
log_info "Installing app dependencies..."
npm install --omit=dev --ignore-scripts=false || npm install
log_info "Building frontend assets..."
npx vite build

# 9. Configure systemd Service
SERVICE_FILE="/etc/systemd/system/vortexpanel.service"
log_info "Configuring systemd service ($SERVICE_FILE)..."
cat <<EOF > "$SERVICE_FILE"
[Unit]
Description=VortexPanel Linux Control Panel
After=network.target docker.service
Requires=docker.service

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=$ENV_FILE
ExecStart=$(which npx) tsx server.ts
Restart=always
RestartSec=5
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable vortexpanel
systemctl restart vortexpanel

# 10. Health check
log_info "Waiting for VortexPanel service to initialize..."
sleep 3

PUBLIC_IP=$(curl -s -4 https://ifconfig.me || hostname -I | awk '{print $1}')
log_success "=========================================================="
log_success " VortexPanel successfully installed and running!"
log_success " Access the panel at: http://$PUBLIC_IP:3000"
log_success " Health check URL:    http://$PUBLIC_IP:3000/api/v1/health"
log_success "=========================================================="
