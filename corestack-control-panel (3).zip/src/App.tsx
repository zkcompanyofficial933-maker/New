import React, { useState, useEffect } from 'react';
import { useAuth, AuthProvider } from './context/AuthContext.js';
import { LoginView } from './components/LoginView.js';
import { StatusBadge } from './components/StatusBadge.js';
import { CreateVMModal } from './components/CreateVMModal.js';
import { VMDetailsModal } from './components/VMDetailsModal.js';
import { AcceptanceTestView } from './components/AcceptanceTestView.js';
import { ApiKeysView } from './components/ApiKeysView.js';
import { AdminSettingsView } from './components/AdminSettingsView.js';
import { VM, HostMetrics } from './types/api.js';
import { api } from './lib/api.js';
import { wsClient } from './lib/ws.js';
import {
  Server,
  Plus,
  Activity,
  Key,
  Settings,
  ShieldCheck,
  LogOut,
  Cpu,
  HardDrive,
  Play,
  Square,
  Search,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
} from 'lucide-react';

type NavTab = 'dashboard' | 'vms' | 'acceptance' | 'apikeys' | 'settings';

function MainPanel() {
  const { user, logout, health } = useAuth();
  const isAdmin = user?.role === 'admin';

  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [vms, setVms] = useState<VM[]>([]);
  const [loadingVMs, setLoadingVMs] = useState(true);
  const [hostMetrics, setHostMetrics] = useState<HostMetrics | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedVM, setSelectedVM] = useState<VM | null>(null);

  const loadVMs = async () => {
    try {
      const res = await api.getVMs();
      setVms(res.items);
    } catch (err) {
      console.warn('Failed to load workloads:', err);
    } finally {
      setLoadingVMs(false);
    }
  };

  const loadHostMetrics = async () => {
    try {
      const metrics = await api.getHostDiagnostics();
      setHostMetrics(metrics);
    } catch {
      // non-fatal
    }
  };

  useEffect(() => {
    loadVMs();
    loadHostMetrics();

    // Periodic telemetry refresh
    const interval = setInterval(() => {
      loadHostMetrics();
    }, 10000);

    // WebSocket real-time subscription
    const unsubStatus = wsClient.on('vm.status_changed', (data: any) => {
      setVms(prev =>
        prev.map(v => (v.id === data.vm_id ? { ...v, status: data.status, ip_address: data.ip_address || v.ip_address } : v))
      );
      if (selectedVM && selectedVM.id === data.vm_id) {
        setSelectedVM(prev => (prev ? { ...prev, status: data.status } : null));
      }
    });

    const unsubDelete = wsClient.on('vm.deleted', (data: any) => {
      setVms(prev => prev.filter(v => v.id !== data.vm_id));
      if (selectedVM?.id === data.vm_id) {
        setSelectedVM(null);
      }
    });

    return () => {
      clearInterval(interval);
      unsubStatus();
      unsubDelete();
    };
  }, [selectedVM?.id]);

  const handleStartVM = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    try {
      await api.startVM(id);
      loadVMs();
    } catch (err: any) {
      alert(`Start failed: ${err.message}`);
    }
  };

  const handleStopVM = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    try {
      await api.stopVM(id);
      loadVMs();
    } catch (err: any) {
      alert(`Stop failed: ${err.message}`);
    }
  };

  const runningCount = vms.filter(v => v.status === 'READY').length;
  const stoppedCount = vms.filter(v => v.status === 'STOPPED').length;
  const filteredVMs = vms.filter(
    v =>
      v.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.requested_os.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (v.ip_address && v.ip_address.includes(searchQuery))
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Navbar */}
      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-600/10 border border-blue-500/20 rounded-xl text-blue-400">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-sm tracking-wide text-white block">
                VortexPanel
              </span>
              <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1.5">
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    health?.container_engine.docker.available ? 'bg-emerald-400' : 'bg-amber-400 animate-pulse'
                  }`}
                />
                Engine: {health?.container_engine.active_default.toUpperCase()} (
                {health?.container_engine.docker.available ? 'ONLINE' : 'DEGRADED/SANDBOX'})
              </span>
            </div>
          </div>

          {/* User profile & quick action */}
          <div className="flex items-center gap-3">
            {isAdmin && (
              <button
                onClick={() => setShowCreateModal(true)}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold shadow-md shadow-blue-500/20 transition"
              >
                <Plus className="w-4 h-4" /> Create Workload
              </button>
            )}

            <div className="h-6 w-px bg-slate-800 hidden sm:block" />

            <div className="text-right hidden sm:block">
              <span className="block text-xs font-medium text-white">{user?.email}</span>
              <span className="block text-[10px] font-mono uppercase text-slate-400">
                {user?.role} Access
              </span>
            </div>

            <button
              onClick={() => logout()}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex space-x-1 overflow-x-auto text-xs font-medium border-t border-slate-800/60">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-2 py-3 px-3.5 border-b-2 transition ${
              activeTab === 'dashboard'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="w-3.5 h-3.5" /> Dashboard
          </button>
          <button
            onClick={() => setActiveTab('vms')}
            className={`flex items-center gap-2 py-3 px-3.5 border-b-2 transition ${
              activeTab === 'vms'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Server className="w-3.5 h-3.5" /> Workloads ({vms.length})
          </button>
          <button
            onClick={() => setActiveTab('acceptance')}
            className={`flex items-center gap-2 py-3 px-3.5 border-b-2 transition ${
              activeTab === 'acceptance'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" /> Real VPS Acceptance Suite
          </button>
          <button
            onClick={() => setActiveTab('apikeys')}
            className={`flex items-center gap-2 py-3 px-3.5 border-b-2 transition ${
              activeTab === 'apikeys'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Key className="w-3.5 h-3.5" /> API Keys
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 py-3 px-3.5 border-b-2 transition ${
              activeTab === 'settings'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Settings className="w-3.5 h-3.5" /> Settings & Audit
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        {/* DASHBOARD TAB */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* Real Host Stats Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                <span className="text-xs text-slate-400">Total Workloads</span>
                <div className="text-2xl font-bold font-mono text-white flex items-baseline gap-2">
                  {vms.length}
                  <span className="text-xs font-normal text-emerald-400">
                    ({runningCount} online)
                  </span>
                </div>
              </div>

              <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                <span className="text-xs text-slate-400 flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-blue-400" /> Host CPU Utilization
                </span>
                <div className="text-2xl font-bold font-mono text-white">
                  {hostMetrics ? `${hostMetrics.cpu.usage_percent}%` : '---'}
                </div>
                <div className="text-[11px] text-slate-500 font-mono">
                  {hostMetrics?.cpu.cores} Cores • Load: {hostMetrics?.cpu.load_avg[0].toFixed(2)}
                </div>
              </div>

              <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                <span className="text-xs text-slate-400 flex items-center gap-1.5">
                  <Server className="w-3.5 h-3.5 text-indigo-400" /> Physical RAM Available
                </span>
                <div className="text-2xl font-bold font-mono text-white">
                  {hostMetrics ? `${Math.round(hostMetrics.memory.free_bytes / (1024 * 1024))} MB` : '---'}
                </div>
                <div className="text-[11px] text-slate-500 font-mono">
                  Total: {hostMetrics ? `${Math.round(hostMetrics.memory.total_bytes / (1024 * 1024 * 1024))} GB` : '---'}
                </div>
              </div>

              <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                <span className="text-xs text-slate-400 flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-cyan-400" /> Node Status
                </span>
                <div className="text-2xl font-bold font-mono text-white flex items-center gap-2">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      health?.container_engine.docker.available ? 'bg-emerald-400' : 'bg-amber-400'
                    }`}
                  />
                  {health?.status.toUpperCase()}
                </div>
                <div className="text-[11px] text-slate-500">
                  {health?.container_engine.docker.available ? 'Production Daemon Connected' : 'Sandbox (Socket Unattached)'}
                </div>
              </div>
            </div>

            {/* Workloads Section */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
              <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Server className="w-4 h-4 text-blue-400" />
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                    Managed Linux Workloads
                  </h2>
                </div>

                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                      placeholder="Filter by name, OS, IP..."
                      className="pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500 w-48"
                    />
                  </div>
                  {isAdmin && (
                    <button
                      onClick={() => setShowCreateModal(true)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition"
                    >
                      <Plus className="w-3.5 h-3.5" /> Create
                    </button>
                  )}
                </div>
              </div>

              {loadingVMs ? (
                <div className="p-12 text-center text-xs text-slate-500">
                  <RotateCw className="w-5 h-5 animate-spin mx-auto mb-2 text-slate-400" />
                  Loading workloads from database...
                </div>
              ) : filteredVMs.length === 0 ? (
                <div className="p-12 text-center space-y-3">
                  <Server className="w-10 h-10 mx-auto text-slate-600" />
                  <div className="text-sm font-semibold text-slate-300">No workloads found</div>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    {searchQuery
                      ? 'No workloads matching your filter query.'
                      : 'No Linux containers have been created yet. Launch your first real workload with the button below.'}
                  </p>
                  {isAdmin && !searchQuery && (
                    <button
                      onClick={() => setShowCreateModal(true)}
                      className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold shadow-md transition"
                    >
                      <Plus className="w-4 h-4" /> Provision New Container
                    </button>
                  )}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-3 font-medium">Workload Name</th>
                        <th className="p-3 font-medium">Engine / OS</th>
                        <th className="p-3 font-medium">Lifecycle Status</th>
                        <th className="p-3 font-medium">Observed IP</th>
                        <th className="p-3 font-medium">SSH Host Port</th>
                        <th className="p-3 font-medium text-right">Quick Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-slate-300">
                      {filteredVMs.map(vm => (
                        <tr
                          key={vm.id}
                          onClick={() => setSelectedVM(vm)}
                          className="hover:bg-slate-800/30 cursor-pointer transition"
                        >
                          <td className="p-3">
                            <span className="font-semibold text-white block text-sm">{vm.name}</span>
                            <span className="text-[11px] text-slate-500 font-mono">
                              {vm.hostname || vm.name}
                            </span>
                          </td>
                          <td className="p-3">
                            <span className="text-slate-200 block">{vm.requested_os}</span>
                            <span className="font-mono text-[10px] text-blue-400 uppercase">
                              {vm.provider}
                            </span>
                          </td>
                          <td className="p-3">
                            <StatusBadge status={vm.status} failureCode={vm.failure_code} />
                          </td>
                          <td className="p-3 font-mono text-slate-300">
                            {vm.ip_address || <span className="text-slate-600 italic">None</span>}
                          </td>
                          <td className="p-3 font-mono text-slate-300">
                            {vm.ssh_host_port ? (
                              <span className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                                :{vm.ssh_host_port}
                              </span>
                            ) : (
                              <span className="text-slate-600">---</span>
                            )}
                          </td>
                          <td className="p-3 text-right">
                            <div className="inline-flex items-center gap-1.5" onClick={e => e.stopPropagation()}>
                              {vm.status === 'READY' ? (
                                <button
                                  onClick={e => handleStopVM(e, vm.id)}
                                  className="p-1.5 text-amber-400 hover:text-amber-300 hover:bg-slate-800 rounded transition"
                                  title="Stop Workload"
                                >
                                  <Square className="w-3.5 h-3.5 fill-current" />
                                </button>
                              ) : (
                                <button
                                  onClick={e => handleStartVM(e, vm.id)}
                                  disabled={vm.status !== 'STOPPED'}
                                  className="p-1.5 text-emerald-400 hover:text-emerald-300 hover:bg-slate-800 rounded disabled:opacity-30 transition"
                                  title="Start Workload"
                                >
                                  <Play className="w-3.5 h-3.5 fill-current" />
                                </button>
                              )}
                              <button
                                onClick={() => setSelectedVM(vm)}
                                className="px-2.5 py-1 text-[11px] font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded transition"
                              >
                                Manage
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* WORKLOADS TAB */}
        {activeTab === 'vms' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-xl font-bold text-white flex items-center gap-2">
                  <Server className="w-5 h-5 text-blue-400" /> All Linux Workloads
                </h1>
                <p className="text-xs text-slate-400 mt-1">
                  Manage real containers, interactive terminals, files, and lifecycle operations.
                </p>
              </div>

              {isAdmin && (
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="flex items-center gap-2 px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold shadow-md transition"
                >
                  <Plus className="w-4 h-4" /> Create Workload
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredVMs.map(vm => (
                <div
                  key={vm.id}
                  onClick={() => setSelectedVM(vm)}
                  className="p-5 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl space-y-4 cursor-pointer transition shadow-lg group"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-bold text-white text-base group-hover:text-blue-400 transition">
                        {vm.name}
                      </h3>
                      <span className="text-xs text-slate-400 font-mono">
                        {vm.requested_os} • {vm.provider.toUpperCase()}
                      </span>
                    </div>
                    <StatusBadge status={vm.status} failureCode={vm.failure_code} />
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-300 font-mono py-2 border-y border-slate-800/80">
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-sans">Observed IP:</span>
                      <span className="text-emerald-400">{vm.ip_address || 'Unassigned'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-sans">SSH Host Port:</span>
                      <span>{vm.ssh_host_port ? `:${vm.ssh_host_port}` : 'Disabled'}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-slate-500">
                      Created: {new Date(vm.created_at).toLocaleDateString()}
                    </span>
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        setSelectedVM(vm);
                      }}
                      className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded text-xs font-medium transition"
                    >
                      Open Console →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* REAL VPS ACCEPTANCE & DIAGNOSTICS */}
        {activeTab === 'acceptance' && <AcceptanceTestView />}

        {/* API KEYS */}
        {activeTab === 'apikeys' && <ApiKeysView />}

        {/* SETTINGS & USERS */}
        {activeTab === 'settings' && <AdminSettingsView />}
      </main>

      {/* Modals */}
      {showCreateModal && (
        <CreateVMModal
          isOpen={showCreateModal}
          onClose={() => setShowCreateModal(false)}
          onCreated={newVM => {
            loadVMs();
            setSelectedVM(newVM);
          }}
        />
      )}

      {selectedVM && (
        <VMDetailsModal
          vm={selectedVM}
          isOpen={!!selectedVM}
          onClose={() => setSelectedVM(null)}
          onRefresh={loadVMs}
        />
      )}
    </div>
  );
}

export default function App() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-400 text-xs font-mono">
        <div className="flex items-center gap-2">
          <RotateCw className="w-4 h-4 animate-spin text-blue-500" />
          <span>Initializing VortexPanel subsystems...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginView />;
  }

  return <MainPanel />;
}
