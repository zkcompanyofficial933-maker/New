export type UserRole = 'admin' | 'user';
export type UserStatus = 'active' | 'disabled' | 'pending';
export type ContainerEngine = 'docker' | 'lxc';

export type VMStatus =
  | 'PENDING'
  | 'VALIDATING'
  | 'CREATING'
  | 'INSTALLING_OS'
  | 'CONFIGURING'
  | 'STARTING'
  | 'INSTALLING_SSH'
  | 'INSTALLING_TMATE'
  | 'READY'
  | 'STOPPED'
  | 'FAILED'
  | 'DELETING';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  must_change_password: boolean;
  created_at?: string;
  last_login_at?: string | null;
}

export interface VMResources {
  cpu_cores: number;
  memory_mb: number;
  disk_gb: number;
}

export interface PortAllocation {
  id: string;
  vm_id: string;
  protocol: 'tcp' | 'udp';
  host_port: number;
  container_port: number;
  purpose: string;
  state: 'reserved' | 'active' | 'released';
}

export interface VM {
  id: string;
  owner_id: string;
  local_node_id: string;
  name: string;
  slug: string;
  requested_os: 'ubuntu:20.04' | 'ubuntu:22.04' | 'debian:11' | 'debian:12';
  provider: ContainerEngine;
  provider_resource_id: string | null;
  status: VMStatus;
  status_version: number;
  failure_code: string | null;
  failure_message: string | null;
  hostname: string | null;
  username: string;
  ssh_enabled: boolean;
  ssh_host_port: number | null;
  ip_address: string | null;
  created_at: string;
  updated_at: string;
  resources?: VMResources;
  ports?: PortAllocation[];
}

export interface HostMetrics {
  hostname: string;
  platform: string;
  arch: string;
  uptime_seconds: number;
  cpu: {
    cores: number;
    model: string;
    load_avg: [number, number, number];
    usage_percent: number;
  };
  memory: {
    total_bytes: number;
    free_bytes: number;
    used_bytes: number;
    usage_percent: number;
  };
  disk: {
    total_bytes: number;
    free_bytes: number;
    used_bytes: number;
    usage_percent: number;
  };
}

export interface SystemHealth {
  status: 'ok' | 'degraded';
  version: string;
  timestamp: string;
  database: { status: string };
  container_engine: {
    active_default: ContainerEngine;
    docker: {
      name: 'docker';
      available: boolean;
      version?: string;
      error?: string;
    };
    lxc: {
      name: 'lxc';
      available: boolean;
      version?: string;
      error?: string;
    };
  };
  local_node: any;
}

export interface Job {
  id: string;
  type: string;
  vm_id: string | null;
  requested_by: string | null;
  state: 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled';
  current_step: string | null;
  error_code: string | null;
  error_message: string | null;
  created_at: string;
}

export interface ApiKeyItem {
  id: string;
  name: string;
  key_prefix: string;
  scopes: string[];
  created_at: string;
  last_used_at: string | null;
  revoked_at: string | null;
}

export interface FileItem {
  name: string;
  path: string;
  is_directory: boolean;
  size_bytes: number;
  modified_at: string;
  permissions: string;
}

export interface AcceptanceTestStep {
  id: number;
  name: string;
  category: 'core' | 'infrastructure' | 'lifecycle' | 'security';
  status: 'PASS' | 'FAIL' | 'UNVERIFIED' | 'SKIPPED';
  message: string;
  duration_ms: number;
}

export interface AcceptanceReport {
  timestamp: string;
  total: number;
  passed: number;
  failed: number;
  unverified: number;
  skipped: number;
  environment_summary: {
    platform: string;
    hostname: string;
    docker_available: boolean;
    lxc_available: boolean;
  };
  steps: AcceptanceTestStep[];
}
