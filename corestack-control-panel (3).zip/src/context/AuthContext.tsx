import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, SystemHealth } from '../types/api.js';
import { api } from '../lib/api.js';
import { wsClient } from '../lib/ws.js';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  health: SystemHealth | null;
  refreshHealth: () => Promise<void>;
  login: (email: string, pass: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  health: null,
  refreshHealth: async () => {},
  login: async () => {},
  logout: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [health, setHealth] = useState<SystemHealth | null>(null);

  const refreshHealth = async () => {
    try {
      const h = await api.getHealth();
      setHealth(h);
    } catch (err) {
      console.warn('Failed to load system health:', err);
    }
  };

  useEffect(() => {
    const initAuth = async () => {
      try {
        await refreshHealth();
        const me = await api.getMe();
        setUser(me.user);
        wsClient.connect(api.getToken());
      } catch {
        setUser(null);
      } finally {
        setLoading(false);
      }
    };
    initAuth();
  }, []);

  const login = async (email: string, pass: string) => {
    const res = await api.login(email, pass);
    setUser(res.user);
    wsClient.connect(res.token);
  };

  const logout = async () => {
    await api.logout();
    setUser(null);
    wsClient.disconnect();
  };

  return (
    <AuthContext.Provider value={{ user, loading, health, refreshHealth, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
