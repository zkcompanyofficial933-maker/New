import {
  User,
  VM,
  HostMetrics,
  SystemHealth,
  Job,
  ApiKeyItem,
  FileItem,
  AcceptanceReport,
} from '../types/api.js';

class ApiClient {
  private token: string | null = null;

  constructor() {
    this.token = localStorage.getItem('vortex_token');
  }

  setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem('vortex_token', token);
    } else {
      localStorage.removeItem('vortex_token');
    }
  }

  getToken(): string | null {
    return this.token;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-Vortex-Requested-With': 'XMLHttpRequest',
      ...(options.headers as Record<string, string>),
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(`/api/v1${endpoint}`, {
      ...options,
      headers,
      credentials: 'include', // Include HttpOnly cookies
    });

    if (response.status === 204) {
      return {} as T;
    }

    const data = await response.json();
    if (!response.ok) {
      const err = new Error(data.error?.message || `Request failed with status ${response.status}`);
      (err as any).code = data.error?.code || 'UNKNOWN_ERROR';
      (err as any).details = data.error?.details;
      throw err;
    }

    return data as T;
  }

  // Auth
  async login(email: string, password: string): Promise<{ token: string; user: User }> {
    const data = await this.request<{ token: string; user: User }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    this.setToken(data.token);
    return data;
  }

  async logout(): Promise<void> {
    try {
      await this.request('/auth/logout', { method: 'POST' });
    } finally {
      this.setToken(null);
    }
  }

  async getMe(): Promise<{ user: User }> {
    return this.request<{ user: User }>('/auth/me');
  }

  async changePassword(current_password: string, new_password: string): Promise<{ message: string }> {
    return this.request<{ message: string }>('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ current_password, new_password }),
    });
  }

  // System Health & Diagnostics
  async getHealth(): Promise<SystemHealth> {
    return this.request<SystemHealth>('/health');
  }

  async getHostDiagnostics(): Promise<HostMetrics> {
    return this.request<HostMetrics>('/diagnostics/host');
  }

  async runVPSAcceptance(): Promise<AcceptanceReport> {
    return this.request<AcceptanceReport>('/diagnostics/vps-acceptance/run', {
      method: 'POST',
    });
  }

  // Workloads / VMs
  async getVMs(): Promise<{ items: VM[]; total: number }> {
    return this.request<{ items: VM[]; total: number }>('/vms');
  }

  async getVM(id: string): Promise<VM & { recent_jobs?: Job[] }> {
    return this.request<VM & { recent_jobs?: Job[] }>(`/vms/${id}`);
  }

  async createVM(params: {
    name: string;
    os: string;
    ram_mb: number;
    cpu_cores: number;
    disk_gb: number;
    username?: string;
    password?: string;
    hostname?: string;
    ssh_enabled?: boolean;
    engine?: 'docker' | 'lxc';
  }): Promise<{ vm: VM; job: { id: string; status: string } }> {
    return this.request<{ vm: VM; job: { id: string; status: string } }>('/vms', {
      method: 'POST',
      headers: {
        'Idempotency-Key': `create_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      },
      body: JSON.stringify(params),
    });
  }

  async startVM(id: string): Promise<{ accepted: boolean; job_id: string }> {
    return this.request<{ accepted: boolean; job_id: string }>(`/vms/${id}/start`, { method: 'POST' });
  }

  async stopVM(id: string): Promise<{ accepted: boolean; job_id: string }> {
    return this.request<{ accepted: boolean; job_id: string }>(`/vms/${id}/stop`, { method: 'POST' });
  }

  async restartVM(id: string): Promise<{ accepted: boolean; job_id: string }> {
    return this.request<{ accepted: boolean; job_id: string }>(`/vms/${id}/restart`, { method: 'POST' });
  }

  async deleteVM(id: string): Promise<{ accepted: boolean; job_id: string }> {
    return this.request<{ accepted: boolean; job_id: string }>(`/vms/${id}`, { method: 'DELETE' });
  }

  async getVMStats(id: string): Promise<any> {
    return this.request<any>(`/vms/${id}/stats`);
  }

  async executeCommand(id: string, command: string | string[]): Promise<{ exit_code: number; stdout: string; stderr: string; duration_ms: number }> {
    return this.request<{ exit_code: number; stdout: string; stderr: string; duration_ms: number }>(`/vms/${id}/exec`, {
      method: 'POST',
      body: JSON.stringify({ command }),
    });
  }

  // File Manager
  async listFiles(id: string, path = '/'): Promise<{ current_path: string; items: FileItem[] }> {
    return this.request<{ current_path: string; items: FileItem[] }>(`/vms/${id}/files?path=${encodeURIComponent(path)}`);
  }

  async getFileContent(id: string, path: string): Promise<{ path: string; content: string }> {
    return this.request<{ path: string; content: string }>(`/vms/${id}/files/content?path=${encodeURIComponent(path)}`);
  }

  async saveFileContent(id: string, path: string, content: string): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>(`/vms/${id}/files/content`, {
      method: 'PUT',
      body: JSON.stringify({ path, content }),
    });
  }

  async makeDirectory(id: string, path: string): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>(`/vms/${id}/files/mkdir`, {
      method: 'POST',
      body: JSON.stringify({ path }),
    });
  }

  async deleteFile(id: string, path: string): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>(`/vms/${id}/files?path=${encodeURIComponent(path)}`, {
      method: 'DELETE',
    });
  }

  // Jobs
  async getJobs(): Promise<{ items: Job[] }> {
    return this.request<{ items: Job[] }>('/jobs');
  }

  async getJob(id: string): Promise<Job> {
    return this.request<Job>(`/jobs/${id}`);
  }

  // API Keys
  async getApiKeys(): Promise<{ items: ApiKeyItem[] }> {
    return this.request<{ items: ApiKeyItem[] }>('/api-keys');
  }

  async createApiKey(name: string, scopes: string[]): Promise<ApiKeyItem & { api_key: string; notice: string }> {
    return this.request<ApiKeyItem & { api_key: string; notice: string }>('/api-keys', {
      method: 'POST',
      body: JSON.stringify({ name, scopes }),
    });
  }

  async revokeApiKey(id: string): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>(`/api-keys/${id}/revoke`, { method: 'POST' });
  }

  // Admin Settings & Users
  async getAdminSettings(): Promise<any> {
    return this.request<any>('/admin/settings');
  }

  async updateAdminSettings(settings: { container_engine?: 'docker' | 'lxc'; branding?: any }): Promise<any> {
    return this.request<any>('/admin/settings', {
      method: 'PATCH',
      body: JSON.stringify(settings),
    });
  }

  async getUsers(): Promise<{ items: User[] }> {
    return this.request<{ items: User[] }>('/admin/users');
  }

  async createUser(user: { email: string; password: string; role: 'admin' | 'user' }): Promise<{ user: User }> {
    return this.request<{ user: User }>('/admin/users', {
      method: 'POST',
      body: JSON.stringify(user),
    });
  }

  async getActivityLogs(): Promise<{ items: any[] }> {
    return this.request<{ items: any[] }>('/activity-logs');
  }
}

export const api = new ApiClient();
