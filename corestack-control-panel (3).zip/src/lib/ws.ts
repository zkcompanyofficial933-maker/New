type EventHandler = (data: any) => void;

class WebSocketClient {
  private ws: WebSocket | null = null;
  private listeners: Map<string, Set<EventHandler>> = new Map();
  private reconnectTimer: any = null;
  private isConnected = false;

  connect(token?: string | null) {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const query = token ? `?token=${encodeURIComponent(token)}` : '';
    const url = `${protocol}//${window.location.host}/api/v1/ws${query}`;

    try {
      this.ws = new WebSocket(url);

      this.ws.onopen = () => {
        this.isConnected = true;
        this.emit('connection.open', {});
      };

      this.ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.event) {
            this.emit(msg.event, msg.data || msg);
          }
        } catch {
          // ignore unparsable
        }
      };

      this.ws.onclose = () => {
        this.isConnected = false;
        this.emit('connection.close', {});
        this.scheduleReconnect(token);
      };

      this.ws.onerror = () => {
        this.ws?.close();
      };
    } catch {
      this.scheduleReconnect(token);
    }
  }

  private scheduleReconnect(token?: string | null) {
    if (this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect(token);
    }, 3000);
  }

  disconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.isConnected = false;
  }

  on(event: string, handler: EventHandler) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(handler);
    return () => {
      this.listeners.get(event)?.delete(handler);
    };
  }

  emit(event: string, data: any) {
    this.listeners.get(event)?.forEach(handler => {
      try {
        handler(data);
      } catch (err) {
        console.error(`[WS] Handler error for ${event}:`, err);
      }
    });
  }

  send(msg: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(msg));
    }
  }

  subscribeVM(vmId: string) {
    this.send({ action: 'subscribe_vm', vm_id: vmId });
  }

  unsubscribeVM(vmId: string) {
    this.send({ action: 'unsubscribe_vm', vm_id: vmId });
  }

  execCommand(vmId: string, command: string | string[]) {
    this.send({ action: 'terminal.exec', vm_id: vmId, command });
  }
}

export const wsClient = new WebSocketClient();
