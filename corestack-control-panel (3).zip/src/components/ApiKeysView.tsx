import React, { useState, useEffect } from 'react';
import { api } from '../lib/api.js';
import { ApiKeyItem } from '../types/api.js';
import { Key, Plus, Trash2, Copy, Check, ShieldAlert, X } from 'lucide-react';

export const ApiKeysView: React.FC = () => {
  const [keys, setKeys] = useState<ApiKeyItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // New Key Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [keyName, setKeyName] = useState('');
  const [selectedScopes, setSelectedScopes] = useState<string[]>(['vm:read', 'vm:control']);
  const [submitting, setSubmitting] = useState(false);

  // Reveal Modal
  const [revealedKey, setRevealedKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const loadKeys = async () => {
    setLoading(true);
    try {
      const res = await api.getApiKeys();
      setKeys(res.items);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadKeys();
  }, []);

  const handleCreateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyName.trim()) return;

    setSubmitting(true);
    try {
      const res = await api.createApiKey(keyName.trim(), selectedScopes);
      setRevealedKey(res.api_key);
      setIsModalOpen(false);
      setKeyName('');
      loadKeys();
    } catch (err: any) {
      alert(`Failed to create API key: ${err.message}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleRevoke = async (id: string) => {
    if (!confirm('Are you sure you want to revoke this API key? This action is immediate and cannot be undone.')) {
      return;
    }
    try {
      await api.revokeApiKey(id);
      loadKeys();
    } catch (err: any) {
      alert(`Revocation failed: ${err.message}`);
    }
  };

  const toggleScope = (scope: string) => {
    setSelectedScopes(prev =>
      prev.includes(scope) ? prev.filter(s => s !== scope) : [...prev, scope]
    );
  };

  const copyKey = () => {
    if (revealedKey) {
      navigator.clipboard.writeText(revealedKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const availableScopes = [
    { id: 'vm:read', label: 'vm:read', desc: 'Read workloads, status, and telemetry' },
    { id: 'vm:control', label: 'vm:control', desc: 'Start, stop, and restart workloads' },
    { id: 'vm:terminal', label: 'vm:terminal', desc: 'Interactive terminal and command execution' },
    { id: 'vm:files', label: 'vm:files', desc: 'Read, write, and manage container files' },
    { id: 'admin:settings', label: 'admin:settings', desc: 'Manage system settings (Admin only)' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Key className="w-5 h-5 text-blue-400" /> API Keys & Automation Tokens
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Generate scoped API tokens for programmatic CLI, CI/CD, and Terraform integration.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold shadow-lg shadow-blue-500/20 transition"
        >
          <Plus className="w-4 h-4" /> Generate New Key
        </button>
      </div>

      {/* Keys List */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Active Programmatic Keys</span>
          <span>{keys.length} Keys Configured</span>
        </div>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-500">Loading API keys...</div>
        ) : keys.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            No API keys created yet. Generate a key above to interact with VortexPanel programmatically.
          </div>
        ) : (
          <div className="divide-y divide-slate-800/60">
            {keys.map(k => (
              <div key={k.id} className="p-4 flex items-center justify-between gap-4 hover:bg-slate-800/30 transition">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-white">{k.name}</span>
                    <span className="font-mono text-xs text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      {k.key_prefix}...
                    </span>
                    {k.revoked_at ? (
                      <span className="text-[10px] text-rose-400 bg-rose-950/60 px-1.5 py-0.5 rounded border border-rose-800">
                        Revoked
                      </span>
                    ) : (
                      <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800">
                        Active
                      </span>
                    )}
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    {k.scopes.map(s => (
                      <span key={s} className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-blue-300">
                        {s}
                      </span>
                    ))}
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Created: {new Date(k.created_at).toLocaleDateString()} • Last Used:{' '}
                    {k.last_used_at ? new Date(k.last_used_at).toLocaleDateString() : 'Never'}
                  </p>
                </div>

                {!k.revoked_at && (
                  <button
                    onClick={() => handleRevoke(k.id)}
                    className="p-2 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-lg transition"
                    title="Revoke Key"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Generate Key Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-blue-400" /> Generate Scoped API Key
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateKey} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Key Description / Name
                </label>
                <input
                  type="text"
                  required
                  value={keyName}
                  onChange={e => setKeyName(e.target.value)}
                  placeholder="e.g. github-actions-deployer"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">
                  Select Authorization Scopes
                </label>
                <div className="space-y-2">
                  {availableScopes.map(scope => (
                    <label
                      key={scope.id}
                      className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-950 border border-slate-800/80 cursor-pointer hover:border-slate-700 transition"
                    >
                      <input
                        type="checkbox"
                        checked={selectedScopes.includes(scope.id)}
                        onChange={() => toggleScope(scope.id)}
                        className="mt-0.5 rounded border-slate-700 bg-slate-900 text-blue-500 focus:ring-0"
                      />
                      <div className="text-xs">
                        <span className="font-mono text-slate-200 font-medium">{scope.label}</span>
                        <p className="text-[11px] text-slate-400">{scope.desc}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-medium transition"
                >
                  Create Key
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* One-Time Reveal Modal */}
      {revealedKey && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <ShieldAlert className="w-5 h-5" /> Copy Your API Key
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              This secret key will <strong>NEVER</strong> be displayed again. Store it securely in your secret manager or environment configuration.
            </p>

            <div className="flex items-center gap-2 p-3 bg-slate-950 border border-slate-800 rounded-lg font-mono text-xs text-blue-300 break-all">
              <span className="flex-1">{revealedKey}</span>
              <button
                onClick={copyKey}
                className="p-1.5 text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 rounded shrink-0 transition"
                title="Copy to clipboard"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setRevealedKey(null)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-semibold"
              >
                I Have Saved This Key
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
