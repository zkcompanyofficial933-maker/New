import React, { useState, useEffect } from 'react';
import { api } from '../lib/api.js';
import { AcceptanceReport, HostMetrics, SystemHealth } from '../types/api.js';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Play,
  RotateCw,
  Server,
  Cpu,
  HardDrive,
  Activity,
  AlertTriangle,
  Info,
} from 'lucide-react';

export const AcceptanceTestView: React.FC = () => {
  const [report, setReport] = useState<AcceptanceReport | null>(null);
  const [hostMetrics, setHostMetrics] = useState<HostMetrics | null>(null);
  const [health, setHealth] = useState<SystemHealth | null>(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadData = async () => {
    try {
      const [h, m] = await Promise.all([api.getHealth(), api.getHostDiagnostics()]);
      setHealth(h);
      setHostMetrics(m);
    } catch (err: any) {
      console.warn('Failed to load diagnostics:', err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRunSuite = async () => {
    setRunning(true);
    setError(null);
    try {
      const rep = await api.runVPSAcceptance();
      setReport(rep);
      await loadData();
    } catch (err: any) {
      setError(err.message || 'Suite execution failed');
    } finally {
      setRunning(false);
    }
  };

  const formatBytes = (bytes: number) => {
    const gb = bytes / (1024 * 1024 * 1024);
    if (gb >= 1) return `${gb.toFixed(1)} GB`;
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(0)} MB`;
  };

  return (
    <div className="space-y-6">
      {/* Title & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-blue-400" />
            Infrastructure Diagnostics & Real VPS Acceptance
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Authoritative 22-step verification suite adhering to strict non-mocking standards.
          </p>
        </div>

        <button
          onClick={handleRunSuite}
          disabled={running}
          className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold shadow-lg shadow-blue-500/20 transition self-start"
        >
          {running ? (
            <>
              <RotateCw className="w-4 h-4 animate-spin" /> Running Verification Suite...
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" /> Execute Acceptance Suite
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="p-3 bg-rose-950/60 border border-rose-800 rounded-lg flex items-center gap-2 text-xs text-rose-300">
          <AlertTriangle className="w-4 h-4 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Real Host Diagnostics Cards */}
      {hostMetrics && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span className="flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-blue-400" /> Host CPU
              </span>
              <span>{hostMetrics.cpu.cores} Cores</span>
            </div>
            <div className="text-xl font-bold font-mono text-white">
              {hostMetrics.cpu.usage_percent}%
            </div>
            <div className="text-[11px] text-slate-500 truncate" title={hostMetrics.cpu.model}>
              Load: {hostMetrics.cpu.load_avg.map(l => l.toFixed(2)).join(', ')}
            </div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span className="flex items-center gap-1.5">
                <Server className="w-4 h-4 text-indigo-400" /> Physical RAM
              </span>
              <span>{formatBytes(hostMetrics.memory.total_bytes)}</span>
            </div>
            <div className="text-xl font-bold font-mono text-white">
              {formatBytes(hostMetrics.memory.used_bytes)}
            </div>
            <div className="text-[11px] text-slate-500">
              Free: {formatBytes(hostMetrics.memory.free_bytes)} ({100 - hostMetrics.memory.usage_percent}% available)
            </div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span className="flex items-center gap-1.5">
                <HardDrive className="w-4 h-4 text-cyan-400" /> Host Storage
              </span>
              <span>{formatBytes(hostMetrics.disk.total_bytes)}</span>
            </div>
            <div className="text-xl font-bold font-mono text-white">
              {formatBytes(hostMetrics.disk.used_bytes)}
            </div>
            <div className="text-[11px] text-slate-500">
              Free: {formatBytes(hostMetrics.disk.free_bytes)}
            </div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-slate-400 text-xs">
              <span className="flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-emerald-400" /> Node & Engine
              </span>
              <span className="font-mono text-emerald-400 uppercase text-[10px] bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800">
                {health?.status || 'OK'}
              </span>
            </div>
            <div className="text-sm font-semibold text-white truncate">
              {hostMetrics.hostname} ({hostMetrics.platform})
            </div>
            <div className="text-[11px] text-slate-400">
              Docker: {health?.container_engine.docker.available ? 'Online' : 'Degraded (No Socket)'}
            </div>
          </div>
        </div>
      )}

      {/* Sandbox Notice Banner */}
      {health && !health.container_engine.docker.available && (
        <div className="p-4 bg-amber-950/40 border border-amber-800/80 rounded-xl flex items-start gap-3 text-xs text-amber-200">
          <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-semibold text-amber-300 block">
              Google AI Studio Sandbox Environment Note:
            </span>
            <p className="text-amber-200/90 leading-relaxed">
              The AI Studio development sandbox does not provide access to the Linux host Docker socket (
              <code className="text-amber-100 bg-amber-900/50 px-1 py-0.5 rounded font-mono">/var/run/docker.sock</code>
              ) or unprivileged LXC namespaces. As required by the engineering specification, the real provider code is implemented, but tests requiring host container daemon privileges are truthfully marked{' '}
              <strong className="text-amber-300 font-mono">UNVERIFIED</strong> instead of faking success. Deploy to a supported Linux VPS using <code className="text-amber-100 font-mono">bash install.sh</code> for 100% full infrastructure verification.
            </p>
          </div>
        </div>
      )}

      {/* Acceptance Test Report Summary */}
      {report && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg text-center">
              <span className="text-[11px] text-slate-400 block">Total Checks</span>
              <span className="text-lg font-bold font-mono text-white">{report.total}</span>
            </div>
            <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg text-center">
              <span className="text-[11px] text-emerald-400 block">Verified Passed</span>
              <span className="text-lg font-bold font-mono text-emerald-400">{report.passed}</span>
            </div>
            <div className="p-3 bg-amber-950/40 border border-amber-800/60 rounded-lg text-center">
              <span className="text-[11px] text-amber-400 block">Unverified (Sandbox)</span>
              <span className="text-lg font-bold font-mono text-amber-400">{report.unverified}</span>
            </div>
            <div className="p-3 bg-rose-950/40 border border-rose-800/60 rounded-lg text-center">
              <span className="text-[11px] text-rose-400 block">Failed</span>
              <span className="text-lg font-bold font-mono text-rose-400">{report.failed}</span>
            </div>
          </div>

          {/* Test Steps List */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
            <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Real VPS Acceptance Suite — Execution Log
              </h3>
              <span className="text-[11px] text-slate-500 font-mono">
                {new Date(report.timestamp).toLocaleTimeString()}
              </span>
            </div>

            <div className="divide-y divide-slate-800/60">
              {report.steps.map(step => (
                <div key={step.id} className="p-3.5 hover:bg-slate-800/30 transition flex items-start gap-3">
                  <div className="mt-0.5 shrink-0">
                    {step.status === 'PASS' && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    )}
                    {step.status === 'FAIL' && (
                      <XCircle className="w-4 h-4 text-rose-400" />
                    )}
                    {step.status === 'UNVERIFIED' && (
                      <HelpCircle className="w-4 h-4 text-amber-400" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold font-mono text-slate-400">
                        #{step.id}
                      </span>
                      <span className="text-xs font-semibold text-slate-200">
                        {step.name}
                      </span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 uppercase">
                        {step.category}
                      </span>
                      <span
                        className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ml-auto ${
                          step.status === 'PASS'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                            : step.status === 'UNVERIFIED'
                            ? 'bg-amber-950 text-amber-400 border border-amber-800/60'
                            : 'bg-rose-950 text-rose-400 border border-rose-800/60'
                        }`}
                      >
                        {step.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      {step.message}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
