import React, { useState, useEffect } from 'react';
import { VM, FileItem } from '../types/api.js';
import { api } from '../lib/api.js';
import { StatusBadge } from './StatusBadge.js';
import {
  X,
  Play,
  Square,
  RotateCw,
  Trash2,
  Terminal,
  Activity,
  Folder,
  FileText,
  Clock,
  Cpu,
  Server,
  Network,
  Copy,
  Check,
  AlertTriangle,
  Send,
  CornerDownLeft,
  Edit2,
  Save,
  Plus,
} from 'lucide-react';

interface VMDetailsModalProps {
  vm: VM;
  isOpen: boolean;
  onClose: () => void;
  onRefresh: () => void;
}

type TabType = 'overview' | 'metrics' | 'terminal' | 'files' | 'jobs';

export const VMDetailsModal: React.FC<VMDetailsModalProps> = ({ vm, isOpen, onClose, onRefresh }) => {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [actionLoading, setActionLoading] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Metrics state
  const [stats, setStats] = useState<any>(null);
  const [statsLoading, setStatsLoading] = useState(false);

  // Terminal state
  const [terminalInput, setTerminalInput] = useState('');
  const [terminalLogs, setTerminalLogs] = useState<Array<{ cmd: string; out?: string; err?: string; code?: number }>>([]);
  const [executing, setExecuting] = useState(false);

  // File Manager state
  const [currentPath, setCurrentPath] = useState('/');
  const [files, setFiles] = useState<FileItem[]>([]);
  const [filesLoading, setFilesLoading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [fileContent, setFileContent] = useState<string>('');
  const [fileEditing, setFileEditing] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [showNewFolderModal, setShowNewFolderModal] = useState(false);

  // Lifecycle actions
  const handleLifecycle = async (action: 'start' | 'stop' | 'restart' | 'delete') => {
    setActionLoading(true);
    setActionError(null);
    try {
      if (action === 'start') await api.startVM(vm.id);
      if (action === 'stop') await api.stopVM(vm.id);
      if (action === 'restart') await api.restartVM(vm.id);
      if (action === 'delete') {
        if (!confirm(`Are you sure you want to permanently delete workload '${vm.name}'?`)) {
          setActionLoading(false);
          return;
        }
        await api.deleteVM(vm.id);
        onClose();
        onRefresh();
        return;
      }
      onRefresh();
    } catch (err: any) {
      setActionError(err.message || `Failed to ${action} workload`);
    } finally {
      setActionLoading(false);
    }
  };

  // Fetch metrics when tab is active
  useEffect(() => {
    if (activeTab === 'metrics' && vm.status === 'READY') {
      setStatsLoading(true);
      api.getVMStats(vm.id)
        .then(s => setStats(s))
        .catch(err => console.warn('Failed to load stats:', err))
        .finally(() => setStatsLoading(false));

      const interval = setInterval(() => {
        api.getVMStats(vm.id).then(s => setStats(s)).catch(() => {});
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [activeTab, vm.id, vm.status]);

  // Fetch files when tab is active
  const loadDirectory = async (path: string) => {
    setFilesLoading(true);
    setSelectedFile(null);
    setFileEditing(false);
    try {
      const res = await api.listFiles(vm.id, path);
      setCurrentPath(res.current_path);
      setFiles(res.items);
    } catch (err: any) {
      console.warn('Failed to list files:', err);
    } finally {
      setFilesLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'files' && vm.status === 'READY') {
      loadDirectory(currentPath);
    }
  }, [activeTab, vm.id, vm.status]);

  const openFile = async (filePath: string) => {
    try {
      const res = await api.getFileContent(vm.id, filePath);
      setSelectedFile(filePath);
      setFileContent(res.content);
      setFileEditing(false);
    } catch (err: any) {
      alert(`Could not open file: ${err.message}`);
    }
  };

  const saveFile = async () => {
    if (!selectedFile) return;
    try {
      await api.saveFileContent(vm.id, selectedFile, fileContent);
      setFileEditing(false);
      alert('File saved successfully inside workload.');
    } catch (err: any) {
      alert(`Save failed: ${err.message}`);
    }
  };

  const handleCreateFolder = async () => {
    if (!newFolderName.trim()) return;
    const target = currentPath === '/' ? `/${newFolderName.trim()}` : `${currentPath}/${newFolderName.trim()}`;
    try {
      await api.makeDirectory(vm.id, target);
      setNewFolderName('');
      setShowNewFolderModal(false);
      loadDirectory(currentPath);
    } catch (err: any) {
      alert(`Failed to create directory: ${err.message}`);
    }
  };

  const handleDeleteItem = async (path: string) => {
    if (!confirm(`Delete ${path} inside the container?`)) return;
    try {
      await api.deleteFile(vm.id, path);
      if (selectedFile === path) {
        setSelectedFile(null);
      }
      loadDirectory(currentPath);
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  // Terminal execute command
  const handleExecCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!terminalInput.trim() || executing) return;

    const cmd = terminalInput.trim();
    setTerminalInput('');
    setExecuting(true);

    try {
      const res = await api.executeCommand(vm.id, cmd);
      setTerminalLogs(prev => [
        ...prev,
        { cmd, out: res.stdout, err: res.stderr, code: res.exit_code },
      ]);
    } catch (err: any) {
      setTerminalLogs(prev => [
        ...prev,
        { cmd, err: err.message, code: 1 },
      ]);
    } finally {
      setExecuting(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-950 border border-slate-800 rounded-lg">
              <Server className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white">{vm.name}</h2>
                <StatusBadge status={vm.status} failureCode={vm.failure_code} />
                <span className="px-2 py-0.5 text-[10px] font-mono font-medium uppercase bg-slate-800 text-slate-300 rounded border border-slate-700">
                  {vm.provider}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                ID: {vm.id} • Image: {vm.requested_os}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 px-5 bg-slate-950/50">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-medium border-b-2 transition ${
              activeTab === 'overview'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Server className="w-3.5 h-3.5" /> Overview & Actions
          </button>
          <button
            onClick={() => setActiveTab('metrics')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-medium border-b-2 transition ${
              activeTab === 'metrics'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="w-3.5 h-3.5" /> Live Metrics
          </button>
          <button
            onClick={() => setActiveTab('terminal')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-medium border-b-2 transition ${
              activeTab === 'terminal'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" /> Web Terminal
          </button>
          <button
            onClick={() => setActiveTab('files')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-medium border-b-2 transition ${
              activeTab === 'files'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Folder className="w-3.5 h-3.5" /> File Manager
          </button>
        </div>

        {actionError && (
          <div className="mx-5 mt-4 p-3 bg-rose-950/60 border border-rose-800 rounded-lg flex items-center justify-between text-xs text-rose-300">
            <span className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              {actionError}
            </span>
            <button onClick={() => setActionError(null)} className="text-rose-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Tab Content */}
        <div className="p-5 flex-1 overflow-y-auto">
          {/* OVERVIEW TAB */}
          {activeTab === 'overview' && (
            <div className="space-y-5">
              {/* Failure banner if any */}
              {vm.failure_code && (
                <div className="p-4 bg-rose-950/40 border border-rose-800/80 rounded-xl space-y-1">
                  <div className="flex items-center gap-2 text-rose-300 font-semibold text-xs">
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                    Infrastructure Failure: {vm.failure_code}
                  </div>
                  <p className="text-xs text-rose-400 font-mono pl-6">
                    {vm.failure_message || 'Detailed error logged to activity stream.'}
                  </p>
                </div>
              )}

              {/* Action Toolbar */}
              <div className="flex flex-wrap items-center gap-2.5 p-3.5 bg-slate-950 border border-slate-800 rounded-xl">
                <span className="text-xs font-medium text-slate-400 mr-2">Lifecycle Controls:</span>
                <button
                  onClick={() => handleLifecycle('start')}
                  disabled={actionLoading || vm.status === 'READY'}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-800/80 rounded-lg transition disabled:opacity-40"
                >
                  <Play className="w-3.5 h-3.5 fill-current" /> Start
                </button>
                <button
                  onClick={() => handleLifecycle('stop')}
                  disabled={actionLoading || vm.status !== 'READY'}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-amber-300 bg-amber-950/60 hover:bg-amber-900/60 border border-amber-800/80 rounded-lg transition disabled:opacity-40"
                >
                  <Square className="w-3.5 h-3.5 fill-current" /> Stop
                </button>
                <button
                  onClick={() => handleLifecycle('restart')}
                  disabled={actionLoading || vm.status !== 'READY'}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-300 bg-blue-950/60 hover:bg-blue-900/60 border border-blue-800/80 rounded-lg transition disabled:opacity-40"
                >
                  <RotateCw className="w-3.5 h-3.5" /> Restart
                </button>
                <button
                  onClick={() => handleLifecycle('delete')}
                  disabled={actionLoading}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-rose-300 bg-rose-950/60 hover:bg-rose-900/60 border border-rose-800/80 rounded-lg transition disabled:opacity-40 ml-auto"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete
                </button>
              </div>

              {/* Technical Specifications Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-950 border border-slate-800/80 rounded-xl space-y-3">
                  <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <Server className="w-3.5 h-3.5 text-blue-400" /> Container & Runtime Identity
                  </h3>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">Container ID:</span>
                      <span className="font-mono text-slate-200">
                        {vm.provider_resource_id ? vm.provider_resource_id.substring(0, 16) : 'Unassigned'}
                      </span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">Hostname:</span>
                      <span className="font-mono text-slate-200">{vm.hostname || vm.name}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">Engine Type:</span>
                      <span className="text-slate-200 font-medium">
                        {vm.provider === 'docker' ? 'Docker Container (OCI)' : 'LXC Container (System)'}
                      </span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">OS Template:</span>
                      <span className="text-slate-200">{vm.requested_os}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-slate-400">Default User:</span>
                      <span className="font-mono text-blue-400">{vm.username}</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-slate-950 border border-slate-800/80 rounded-xl space-y-3">
                  <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <Network className="w-3.5 h-3.5 text-emerald-400" /> Real Networking & Access
                  </h3>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">Observed IP:</span>
                      <span className="font-mono text-emerald-400 font-medium">
                        {vm.ip_address || 'No IP detected'}
                      </span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-800/60">
                      <span className="text-slate-400">SSH Host Port:</span>
                      <span className="font-mono text-slate-200">
                        {vm.ssh_host_port ? vm.ssh_host_port : 'Disabled'}
                      </span>
                    </div>
                    <div className="py-2">
                      <span className="block text-[11px] text-slate-400 mb-1">Direct SSH Command:</span>
                      {vm.ssh_host_port ? (
                        <div className="flex items-center justify-between p-2 bg-slate-900 border border-slate-800 rounded font-mono text-[11px] text-slate-300">
                          <code>ssh -p {vm.ssh_host_port} {vm.username}@{window.location.hostname}</code>
                          <button
                            onClick={() => copyToClipboard(`ssh -p ${vm.ssh_host_port} ${vm.username}@${window.location.hostname}`)}
                            className="p-1 text-slate-400 hover:text-white"
                          >
                            {copiedText?.includes(String(vm.ssh_host_port)) ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      ) : (
                        <span className="text-slate-500 italic">No external port mapped</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* METRICS TAB */}
          {activeTab === 'metrics' && (
            <div className="space-y-4">
              {vm.status !== 'READY' ? (
                <div className="p-8 text-center text-slate-500 text-xs bg-slate-950 border border-slate-800 rounded-xl">
                  Workload is currently {vm.status}. Real resource statistics are only collected while in READY status.
                </div>
              ) : statsLoading && !stats ? (
                <div className="p-8 text-center text-slate-400 text-xs">
                  Querying real Docker/LXC live stats stream...
                </div>
              ) : stats ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                    <span className="text-xs text-slate-400 flex items-center gap-1.5">
                      <Cpu className="w-4 h-4 text-blue-400" /> CPU Utilization
                    </span>
                    <div className="text-2xl font-bold font-mono text-white">
                      {stats.cpu_usage_percent?.toFixed(1) || 0}%
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-blue-500 h-full transition-all duration-500"
                        style={{ width: `${Math.min(100, stats.cpu_usage_percent || 0)}%` }}
                      />
                    </div>
                  </div>

                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                    <span className="text-xs text-slate-400 flex items-center gap-1.5">
                      <Server className="w-4 h-4 text-indigo-400" /> Memory Usage (cgroup)
                    </span>
                    <div className="text-2xl font-bold font-mono text-white">
                      {Math.round((stats.memory_used_bytes || 0) / (1024 * 1024))} MB
                      <span className="text-xs text-slate-500 font-normal ml-2">
                        / {Math.round((stats.memory_limit_bytes || 0) / (1024 * 1024))} MB
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-indigo-500 h-full transition-all duration-500"
                        style={{
                          width: `${Math.min(
                            100,
                            ((stats.memory_used_bytes || 0) / (stats.memory_limit_bytes || 1)) * 100
                          )}%`,
                        }}
                      />
                    </div>
                  </div>

                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                    <span className="text-xs text-slate-400 flex items-center gap-1.5">
                      <Network className="w-4 h-4 text-emerald-400" /> Network Traffic (I/O)
                    </span>
                    <div className="text-sm font-mono text-slate-300 space-y-1">
                      <div>Rx (Inbound): <strong>{Math.round((stats.net_rx_bytes || 0) / 1024)} KB</strong></div>
                      <div>Tx (Outbound): <strong>{Math.round((stats.net_tx_bytes || 0) / 1024)} KB</strong></div>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                    <span className="text-xs text-slate-400 flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-cyan-400" /> Active Processes (PIDs)
                    </span>
                    <div className="text-2xl font-bold font-mono text-white">
                      {stats.pids || 0}
                    </div>
                    <span className="text-[11px] text-slate-500">Tracked cgroup processes</span>
                  </div>
                </div>
              ) : (
                <div className="p-8 text-center text-slate-500 text-xs">
                  Stats collector returned empty frame. Container might be starting up.
                </div>
              )}
            </div>
          )}

          {/* TERMINAL TAB */}
          {activeTab === 'terminal' && (
            <div className="flex flex-col h-[400px] bg-slate-950 border border-slate-800 rounded-xl overflow-hidden font-mono text-xs">
              <div className="p-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-slate-400">
                <span className="flex items-center gap-2 text-slate-300">
                  <Terminal className="w-3.5 h-3.5 text-blue-400" /> In-Container Terminal ({vm.provider} exec)
                </span>
                <span className="text-[11px] text-slate-500">
                  Target: {vm.username}@{vm.name}
                </span>
              </div>

              {/* Logs output */}
              <div className="flex-1 p-3 overflow-y-auto space-y-2.5 bg-black/50">
                {terminalLogs.length === 0 ? (
                  <div className="text-slate-600 italic">
                    Type a command below to execute directly inside the authorized workload (e.g. `cat /etc/os-release`, `uname -a`, `df -h`, `top -b -n 1`).
                  </div>
                ) : (
                  terminalLogs.map((log, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex items-center gap-2 text-blue-400">
                        <span className="text-slate-500">$</span>
                        <span>{log.cmd}</span>
                        {log.code !== undefined && log.code !== 0 && (
                          <span className="text-[10px] text-rose-400 ml-auto font-sans">
                            Exit code: {log.code}
                          </span>
                        )}
                      </div>
                      {log.out && <pre className="text-slate-300 whitespace-pre-wrap pl-3">{log.out}</pre>}
                      {log.err && <pre className="text-rose-400 whitespace-pre-wrap pl-3">{log.err}</pre>}
                    </div>
                  ))
                )}
              </div>

              {/* Input bar */}
              <form onSubmit={handleExecCommand} className="p-2 border-t border-slate-800 bg-slate-900 flex items-center gap-2">
                <span className="text-blue-400 font-bold pl-2">$</span>
                <input
                  type="text"
                  value={terminalInput}
                  onChange={e => setTerminalInput(e.target.value)}
                  disabled={executing || vm.status !== 'READY'}
                  placeholder={vm.status === 'READY' ? 'Execute command inside container...' : 'Workload must be READY to execute'}
                  className="flex-1 bg-transparent text-white focus:outline-none text-xs"
                />
                <button
                  type="submit"
                  disabled={executing || !terminalInput.trim() || vm.status !== 'READY'}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white rounded text-xs font-sans font-medium flex items-center gap-1"
                >
                  <Send className="w-3 h-3" /> Run
                </button>
              </form>
            </div>
          )}

          {/* FILES TAB */}
          {activeTab === 'files' && (
            <div className="space-y-4">
              {vm.status !== 'READY' ? (
                <div className="p-8 text-center text-slate-500 text-xs bg-slate-950 border border-slate-800 rounded-xl">
                  Workload is currently {vm.status}. File system access requires a running container.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-[420px]">
                  {/* File browser */}
                  <div className="md:col-span-1 bg-slate-950 border border-slate-800 rounded-xl flex flex-col overflow-hidden">
                    <div className="p-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                      <span className="text-xs font-mono text-slate-300 truncate" title={currentPath}>
                        {currentPath}
                      </span>
                      <div className="flex items-center gap-1">
                        {currentPath !== '/' && (
                          <button
                            onClick={() => {
                              const parent = currentPath.substring(0, currentPath.lastIndexOf('/')) || '/';
                              loadDirectory(parent);
                            }}
                            className="p-1 text-slate-400 hover:text-white rounded"
                            title="Go Up"
                          >
                            <CornerDownLeft className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => setShowNewFolderModal(true)}
                          className="p-1 text-slate-400 hover:text-white rounded"
                          title="New Directory"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="flex-1 overflow-y-auto p-1.5 space-y-1 text-xs">
                      {filesLoading ? (
                        <div className="p-4 text-center text-slate-500">Reading directory...</div>
                      ) : files.length === 0 ? (
                        <div className="p-4 text-center text-slate-500">Directory is empty.</div>
                      ) : (
                        files.map(item => (
                          <div
                            key={item.path}
                            onClick={() => {
                              if (item.is_directory) {
                                loadDirectory(item.path);
                              } else {
                                openFile(item.path);
                              }
                            }}
                            className={`flex items-center justify-between p-2 rounded cursor-pointer transition ${
                              selectedFile === item.path
                                ? 'bg-blue-600/20 text-blue-300'
                                : 'hover:bg-slate-900 text-slate-300'
                            }`}
                          >
                            <div className="flex items-center gap-2 truncate">
                              {item.is_directory ? (
                                <Folder className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                              ) : (
                                <FileText className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              )}
                              <span className="truncate">{item.name}</span>
                            </div>
                            <span className="text-[10px] text-slate-500 shrink-0 font-mono">
                              {item.is_directory ? 'DIR' : `${Math.round(item.size_bytes / 1024)}K`}
                            </span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* File viewer/editor */}
                  <div className="md:col-span-2 bg-slate-950 border border-slate-800 rounded-xl flex flex-col overflow-hidden">
                    {selectedFile ? (
                      <>
                        <div className="p-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                          <span className="text-xs font-mono text-slate-300">{selectedFile}</span>
                          <div className="flex items-center gap-2">
                            {fileEditing ? (
                              <button
                                onClick={saveFile}
                                className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-emerald-300 bg-emerald-950 border border-emerald-800 rounded hover:bg-emerald-900"
                              >
                                <Save className="w-3 h-3" /> Save
                              </button>
                            ) : (
                              <button
                                onClick={() => setFileEditing(true)}
                                className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-300 bg-slate-800 border border-slate-700 rounded hover:bg-slate-700"
                              >
                                <Edit2 className="w-3 h-3" /> Edit
                              </button>
                            )}
                            <button
                              onClick={() => handleDeleteItem(selectedFile)}
                              className="p-1 text-rose-400 hover:text-white"
                              title="Delete File"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {fileEditing ? (
                          <textarea
                            value={fileContent}
                            onChange={e => setFileContent(e.target.value)}
                            className="flex-1 p-3 bg-black/60 text-slate-200 font-mono text-xs focus:outline-none resize-none"
                          />
                        ) : (
                          <pre className="flex-1 p-3 overflow-y-auto font-mono text-xs text-slate-300 whitespace-pre-wrap">
                            {fileContent}
                          </pre>
                        )}
                      </>
                    ) : (
                      <div className="flex-1 flex items-center justify-center text-slate-500 text-xs">
                        Select a file from the list to view or edit its contents.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* New Folder Modal */}
              {showNewFolderModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                  <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl max-w-sm w-full space-y-3">
                    <h3 className="text-sm font-semibold text-white">Create New Directory</h3>
                    <input
                      type="text"
                      value={newFolderName}
                      onChange={e => setNewFolderName(e.target.value)}
                      placeholder="Folder name"
                      className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs text-white focus:outline-none focus:border-blue-500"
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => setShowNewFolderModal(false)}
                        className="px-3 py-1 text-xs text-slate-400 hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleCreateFolder}
                        className="px-3 py-1 bg-blue-600 text-white rounded text-xs"
                      >
                        Create
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
