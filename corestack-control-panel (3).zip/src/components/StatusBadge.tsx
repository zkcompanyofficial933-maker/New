import React from 'react';
import { VMStatus } from '../types/api.js';

interface StatusBadgeProps {
  status: VMStatus;
  failureCode?: string | null;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, failureCode }) => {
  let color = 'bg-slate-800 text-slate-300 border-slate-700';
  let dotColor = 'bg-slate-400';
  let isPulsing = false;

  switch (status) {
    case 'READY':
      color = 'bg-emerald-950/60 text-emerald-300 border-emerald-800/60';
      dotColor = 'bg-emerald-400';
      break;
    case 'STOPPED':
      color = 'bg-slate-900 text-slate-400 border-slate-700';
      dotColor = 'bg-slate-500';
      break;
    case 'FAILED':
      color = 'bg-rose-950/60 text-rose-300 border-rose-800/60';
      dotColor = 'bg-rose-500';
      break;
    case 'DELETING':
      color = 'bg-amber-950/60 text-amber-300 border-amber-800/60';
      dotColor = 'bg-amber-500';
      isPulsing = true;
      break;
    case 'PENDING':
    case 'VALIDATING':
    case 'CREATING':
    case 'INSTALLING_OS':
    case 'CONFIGURING':
    case 'STARTING':
    case 'INSTALLING_SSH':
    case 'INSTALLING_TMATE':
      color = 'bg-blue-950/60 text-blue-300 border-blue-800/60';
      dotColor = 'bg-blue-400';
      isPulsing = true;
      break;
  }

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-mono font-medium border ${color}`}
      title={failureCode ? `Failure: ${failureCode}` : undefined}
    >
      <span
        className={`w-1.5 h-1.5 rounded-full ${dotColor} ${isPulsing ? 'animate-pulse' : ''}`}
      />
      {status}
    </span>
  );
};
