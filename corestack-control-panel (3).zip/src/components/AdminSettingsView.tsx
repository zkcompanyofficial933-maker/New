import React, { useState, useEffect } from 'react';
import { api } from '../lib/api.js';
import { User } from '../types/api.js';
import { useAuth } from '../context/AuthContext.js';
import {
  Settings,
  Users,
  Lock,
  Plus,
  Check,
  AlertTriangle,
  FileText,
} from 'lucide-react';

export const AdminSettingsView: React.FC = () => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  // Settings State
  const [engine, setEngine] = useState<'docker' | 'lxc'>('docker');
  const [brandName, setBrandName] = useState('VortexPanel');
  const [settingsLoading, setSettingsLoading] = useState(true);
  const [savingSettings, setSavingSettings] = useState(false);
  const [settingsSuccess, setSettingsSuccess] = useState(false);

  // Users State
  const [users, setUsers] = useState<User[]>([]);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPass, setNewUserPass] = useState('');
  const [newUserRole, setNewUserRole] = useState<'admin' | 'user'>('user');

  // Password Change State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passMsg, setPassMsg] = useState<string | null>(null);
  const [passError, setPassError] = useState<string | null>(null);

  // Activity Logs
  const [logs, setLogs] = useState<any[]>([]);

  useEffect(() => {
    if (isAdmin) {
      api.getAdminSettings()
        .then(s => {
          setEngine(s.container_engine || 'docker');
          setBrandName(s.branding?.name || 'VortexPanel');
        })
        .finally(() => setSettingsLoading(false));

      api.getUsers().then(u => setUsers(u.items)).catch(() => {});
      api.getActivityLogs().then(l => setLogs(l.items)).catch(() => {});
    }
  }, [isAdmin]);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    setSettingsSuccess(false);
    try {
      await api.updateAdminSettings({
        container_engine: engine,
        branding: { name: brandName, color: '#2563eb' },
      });
      setSettingsSuccess(true);
      setTimeout(() => setSettingsSuccess(false), 2500);
    } catch (err: any) {
      alert(`Failed to save settings: ${err.message}`);
    } finally {
      setSavingSettings(false);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createUser({
        email: newUserEmail.trim(),
        password: newUserPass,
        role: newUserRole,
      });
      setShowAddUserModal(false);
      setNewUserEmail('');
      setNewUserPass('');
      const u = await api.getUsers();
      setUsers(u.items);
    } catch (err: any) {
      alert(`User creation failed: ${err.message}`);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg(null);
    setPassError(null);
    try {
      const res = await api.changePassword(currentPassword, newPassword);
      setPassMsg(res.message);
      setCurrentPassword('');
      setNewPassword('');
    } catch (err: any) {
      setPassError(err.message);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-blue-400" /> System Settings & Access Control
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Configure default container infrastructure, manage administrator accounts, and review audit records.
        </p>
      </div>

      {isAdmin && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Global Container Engine Settings */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Settings className="w-4 h-4 text-blue-400" /> Default Container Engine
            </h2>
            <p className="text-xs text-slate-400">
              Select which backend runtime is used for newly provisioned workloads. Existing containers retain their original engine.
            </p>

            {settingsSuccess && (
              <div className="p-2.5 bg-emerald-950/60 border border-emerald-800 rounded text-xs text-emerald-300 flex items-center gap-2">
                <Check className="w-4 h-4" /> Settings updated successfully.
              </div>
            )}

            <form onSubmit={handleSaveSettings} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Engine Selector
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <div
                    onClick={() => setEngine('docker')}
                    className={`p-3 rounded-lg border cursor-pointer text-xs transition ${
                      engine === 'docker'
                        ? 'bg-blue-600/20 border-blue-500 text-white font-medium'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-300'
                    }`}
                  >
                    <span className="font-semibold block text-slate-200">Docker Engine</span>
                    <span className="text-[11px] text-slate-400">Standard OCI containers with cgroups isolation</span>
                  </div>
                  <div
                    onClick={() => setEngine('lxc')}
                    className={`p-3 rounded-lg border cursor-pointer text-xs transition ${
                      engine === 'lxc'
                        ? 'bg-blue-600/20 border-blue-500 text-white font-medium'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-300'
                    }`}
                  >
                    <span className="font-semibold block text-slate-200">LXC Runtime</span>
                    <span className="text-[11px] text-slate-400">Native system containers with namespaces</span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Control Panel Branding
                </label>
                <input
                  type="text"
                  value={brandName}
                  onChange={e => setBrandName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800/80 rounded-lg text-xs text-slate-400 space-y-1">
                <span className="font-medium text-slate-300 block">Host Port Range Allocation:</span>
                <span className="font-mono text-blue-400">20000 - 40000 (TCP/UDP)</span>
                <p className="text-[11px] text-slate-500">
                  Enforces atomic port checking on 0.0.0.0 before binding.
                </p>
              </div>

              <button
                type="submit"
                disabled={savingSettings || settingsLoading}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold disabled:opacity-50 transition"
              >
                {savingSettings ? 'Saving...' : 'Save Settings'}
              </button>
            </form>
          </div>

          {/* User Account Password Change */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-4">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-emerald-400" /> Account Security & Password
            </h2>
            <p className="text-xs text-slate-400">
              Change the password for your active account ({user?.email}). Uses PBKDF2 SHA-512 with 100,000 rounds.
            </p>

            {passMsg && (
              <div className="p-2.5 bg-emerald-950/60 border border-emerald-800 rounded text-xs text-emerald-300 flex items-center gap-2">
                <Check className="w-4 h-4" /> {passMsg}
              </div>
            )}
            {passError && (
              <div className="p-2.5 bg-rose-950/60 border border-rose-800 rounded text-xs text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" /> {passError}
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={e => setCurrentPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  New Password (min 8 characters)
                </label>
                <input
                  type="password"
                  required
                  minLength={8}
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <button
                type="submit"
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold transition"
              >
                Update Password
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Users Management Table (Admin) */}
      {isAdmin && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
          <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-400" />
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Panel User Accounts
              </h3>
            </div>
            <button
              onClick={() => setShowAddUserModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium transition"
            >
              <Plus className="w-3.5 h-3.5" /> Add User
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/50 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-3 font-medium">User Email</th>
                  <th className="p-3 font-medium">Role</th>
                  <th className="p-3 font-medium">Status</th>
                  <th className="p-3 font-medium">Created Date</th>
                  <th className="p-3 font-medium">Last Login</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-slate-800/20">
                    <td className="p-3 font-mono font-medium text-white">{u.email}</td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                          u.role === 'admin'
                            ? 'bg-purple-950 text-purple-300 border border-purple-800'
                            : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        {u.role}
                      </span>
                    </td>
                    <td className="p-3">
                      <span className="text-emerald-400">{u.status}</span>
                    </td>
                    <td className="p-3 text-slate-400">
                      {new Date(u.created_at || '').toLocaleDateString()}
                    </td>
                    <td className="p-3 text-slate-400">
                      {u.last_login_at ? new Date(u.last_login_at).toLocaleDateString() : 'Never'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Activity Logs Table */}
      {isAdmin && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
          <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Recent Audit & Infrastructure Activity Logs
              </h3>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">Last 100 Events</span>
          </div>

          <div className="max-h-80 overflow-y-auto divide-y divide-slate-800/60 font-mono text-xs">
            {logs.length === 0 ? (
              <div className="p-6 text-center text-slate-500">No activity logged yet.</div>
            ) : (
              logs.slice(0, 30).map(l => (
                <div key={l.id} className="p-3 flex items-center justify-between gap-4 hover:bg-slate-800/20">
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        l.outcome === 'succeeded'
                          ? 'bg-emerald-400'
                          : l.outcome === 'denied'
                          ? 'bg-amber-400'
                          : 'bg-rose-400'
                      }`}
                    />
                    <span className="text-slate-200 font-semibold">{l.action}</span>
                    <span className="text-slate-500 text-[11px]">[{l.outcome}]</span>
                  </div>
                  <div className="text-[11px] text-slate-500">
                    {new Date(l.created_at).toLocaleString()}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Add User Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl max-w-sm w-full space-y-4">
            <h3 className="text-sm font-bold text-white">Create Panel User</h3>
            <form onSubmit={handleCreateUser} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Email</label>
                <input
                  type="email"
                  required
                  value={newUserEmail}
                  onChange={e => setNewUserEmail(e.target.value)}
                  placeholder="dev@example.com"
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Temporary Password</label>
                <input
                  type="password"
                  required
                  value={newUserPass}
                  onChange={e => setNewUserPass(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Role</label>
                <select
                  value={newUserRole}
                  onChange={e => setNewUserRole(e.target.value as any)}
                  className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded text-xs text-white focus:outline-none"
                >
                  <option value="user">User (Own Workloads Only)</option>
                  <option value="admin">Administrator (Full Access)</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddUserModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded text-xs font-medium"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
