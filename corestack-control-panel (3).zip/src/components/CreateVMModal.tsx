import React, { useState, useEffect } from 'react';
import { api } from '../lib/api.js';
import { HostMetrics, VM } from '../types/api.js';
import { Server, Cpu, HardDrive, Shield, AlertTriangle, X, Check } from 'lucide-react';

interface CreateVMModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated: (vm: VM) => void;
}

export const CreateVMModal: React.FC<CreateVMModalProps> = ({ isOpen, onClose, onCreated }) => {
  const [name, setName] = useState('');
  const [hostname, setHostname] = useState('');
  const [engine, setEngine] = useState<'docker' | 'lxc'>('docker');
  const [os, setOs] = useState<'ubuntu:22.04' | 'ubuntu:20.04' | 'debian:12' | 'debian:11'>('ubuntu:22.04');
  const [ramMb, setRamMb] = useState(1024);
  const [cpuCores, setCpuCores] = useState(1);
  const [diskGb, setDiskGb] = useState(10);
  const [username, setUsername] = useState('ubuntu');
  const [password, setPassword] = useState('');
  const [sshEnabled, setSshEnabled] = useState(true);

  const [hostMetrics, setHostMetrics] = useState<HostMetrics | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      api.getHostDiagnostics()
        .then(m => setHostMetrics(m))
        .catch(err => console.warn('Failed to load host metrics:', err));
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please provide a server/workload name.');
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const res = await api.createVM({
        name: name.trim(),
        hostname: hostname.trim() || name.trim(),
        engine,
        os,
        ram_mb: ramMb,
        cpu_cores: cpuCores,
        disk_gb: diskGb,
        username: username.trim() || 'ubuntu',
        password: password || undefined,
        ssh_enabled: sshEnabled,
      });
      onCreated(res.vm);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Workload creation failed');
    } finally {
      setSubmitting(false);
    }
  };

  const freeMemMb = hostMetrics ? Math.round(hostMetrics.memory.free_bytes / (1024 * 1024)) : 2048;
  const maxCores = hostMetrics ? hostMetrics.cpu.cores : 4;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-6 my-8">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-semibold text-white">Create Linux Workload</h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 bg-rose-950/60 border border-rose-800/80 rounded-lg flex items-start gap-2.5 text-sm text-rose-300">
            <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Workload Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. web-app-01"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Hostname (optional)
              </label>
              <input
                type="text"
                value={hostname}
                onChange={e => setHostname(e.target.value)}
                placeholder="e.g. web-01.local"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Container Engine
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setEngine('docker')}
                  className={`px-3 py-2 rounded-lg text-xs font-medium border text-center transition ${
                    engine === 'docker'
                      ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Docker Container
                </button>
                <button
                  type="button"
                  onClick={() => setEngine('lxc')}
                  className={`px-3 py-2 rounded-lg text-xs font-medium border text-center transition ${
                    engine === 'lxc'
                      ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  LXC Container
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Operating System (Exact Catalog)
              </label>
              <select
                value={os}
                onChange={e => setOs(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500"
              >
                <option value="ubuntu:22.04">Ubuntu 22.04 LTS (Jammy)</option>
                <option value="ubuntu:20.04">Ubuntu 20.04 LTS (Focal)</option>
                <option value="debian:12">Debian 12 (Bookworm)</option>
                <option value="debian:11">Debian 11 (Bullseye)</option>
              </select>
            </div>
          </div>

          <div className="p-4 bg-slate-950 border border-slate-800/80 rounded-lg space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-medium text-slate-300">Resource Allocation & Boundaries</span>
              <span>Host Free RAM: <strong className="text-emerald-400">{freeMemMb} MB</strong></span>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <Cpu className="w-3.5 h-3.5 text-blue-400" /> CPU Allocation: {cpuCores} Core{cpuCores > 1 ? 's' : ''}
                </span>
                <span className="text-slate-400">Host has {maxCores} cores</span>
              </div>
              <input
                type="range"
                min="1"
                max={Math.max(1, maxCores)}
                value={cpuCores}
                onChange={e => setCpuCores(parseInt(e.target.value, 10))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <Server className="w-3.5 h-3.5 text-indigo-400" /> Memory (RAM): {ramMb} MB ({Math.round(ramMb / 1024 * 10) / 10} GB)
                </span>
                <span className="text-slate-400">Hard limit via cgroups</span>
              </div>
              <input
                type="range"
                min="256"
                max={Math.max(2048, freeMemMb)}
                step="256"
                value={ramMb}
                onChange={e => setRamMb(parseInt(e.target.value, 10))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <HardDrive className="w-3.5 h-3.5 text-cyan-400" /> Disk Capacity: {diskGb} GB
                </span>
                <span className="text-slate-400">Storage quota</span>
              </div>
              <input
                type="range"
                min="5"
                max="100"
                step="5"
                value={diskGb}
                onChange={e => setDiskGb(parseInt(e.target.value, 10))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Initial Workload User
              </label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="ubuntu"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Initial Password (optional)
              </label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-lg">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              <div>
                <span className="block text-xs font-medium text-slate-200">Expose SSH Host Port</span>
                <span className="block text-[11px] text-slate-400">
                  Dynamically assigns a free port from the 20000-40000 host pool
                </span>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={sshEnabled}
                onChange={e => setSshEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition disabled:opacity-50"
            >
              {submitting ? (
                <>Provisioning Workload...</>
              ) : (
                <>
                  <Check className="w-4 h-4" /> Create Workload
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
