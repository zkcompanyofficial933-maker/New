export interface ProviderCapabilities {
  name: 'docker' | 'lxc';
  available: boolean;
  version?: string;
  driver?: string;
  cgroups_version?: string;
  error?: string;
}

export interface ProviderValidationResult {
  valid: boolean;
  engine: 'docker' | 'lxc';
  details: Record<string, any>;
  error?: string;
}

export interface CreateContainerSpec {
  name: string;
  image: string; // 'ubuntu:20.04' | 'ubuntu:22.04' | 'debian:11' | 'debian:12'
  cpu_cores: number;
  memory_bytes: number;
  disk_bytes: number;
  pids_limit: number;
  hostname?: string;
  username: string;
  ssh_enabled: boolean;
  ssh_host_port?: number;
  labels?: Record<string, string>;
}

export interface ProviderResource {
  provider: 'docker' | 'lxc';
  resource_id: string;
  name: string;
  raw_state: any;
}

export interface ProviderStatus {
  provider: 'docker' | 'lxc';
  resource_id: string;
  state: 'running' | 'stopped' | 'paused' | 'restarting' | 'dead' | 'not_found';
  exit_code?: number;
  started_at?: string;
  finished_at?: string;
  error?: string;
}

export interface ProviderInspection {
  provider: 'docker' | 'lxc';
  resource_id: string;
  name: string;
  state: ProviderStatus['state'];
  ip_addresses: string[];
  ports: Record<string, number>;
  memory_limit_bytes: number;
  cpu_cores_configured: number;
  created_at: string;
  raw: any;
}

export interface ProviderStats {
  provider: 'docker' | 'lxc';
  resource_id: string;
  sampled_at: string;
  cpu_usage_percent: number;
  memory_used_bytes: number;
  memory_limit_bytes: number;
  net_rx_bytes: number;
  net_tx_bytes: number;
  pids: number;
}

export interface ExecuteOptions {
  working_dir?: string;
  user?: string;
  timeout_seconds?: number;
  env?: Record<string, string>;
}

export interface ExecuteResult {
  exit_code: number;
  stdout: string;
  stderr: string;
  duration_ms: number;
}

export interface HealthcheckResult {
  healthy: boolean;
  engine: 'docker' | 'lxc';
  message: string;
  details?: any;
}

export interface ContainerProvider {
  readonly name: 'docker' | 'lxc';
  capabilities(): Promise<ProviderCapabilities>;
  validate_host(): Promise<ProviderValidationResult>;
  create(spec: CreateContainerSpec): Promise<ProviderResource>;
  delete(resource_id: string): Promise<void>;
  start(resource_id: string): Promise<ProviderStatus>;
  stop(resource_id: string): Promise<ProviderStatus>;
  restart(resource_id: string): Promise<ProviderStatus>;
  status(resource_id: string): Promise<ProviderStatus>;
  inspect(resource_id: string): Promise<ProviderInspection>;
  stats(resource_id: string): Promise<ProviderStats>;
  execute(resource_id: string, command: string[], options?: ExecuteOptions): Promise<ExecuteResult>;
  get_ip(resource_id: string): Promise<string[]>;
  configure_resources(
    resource_id: string,
    resources: { cpu_cores: number; memory_bytes: number; pids_limit?: number }
  ): Promise<ProviderInspection>;
  healthcheck(resource_id?: string): Promise<HealthcheckResult>;
}

export class ProviderUnavailableError extends Error {
  constructor(public provider: 'docker' | 'lxc', message: string, public details?: any) {
    super(`[${provider.toUpperCase()}_UNAVAILABLE] ${message}`);
    this.name = 'ProviderUnavailableError';
  }
}

export class ProviderOperationError extends Error {
  constructor(public provider: 'docker' | 'lxc', public code: string, message: string, public details?: any) {
    super(`[${provider.toUpperCase()}_${code}] ${message}`);
    this.name = 'ProviderOperationError';
  }
}
