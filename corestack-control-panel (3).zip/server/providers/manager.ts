import { ContainerProvider, ProviderUnavailableError } from './types.js';
import { DockerProvider } from './docker.js';
import { LXCProvider } from './lxc.js';
import { db } from '../db/database.js';

export class ProviderManager {
  private dockerProvider: DockerProvider;
  private lxcProvider: LXCProvider;

  constructor() {
    this.dockerProvider = new DockerProvider();
    this.lxcProvider = new LXCProvider();
  }

  getProvider(engine: 'docker' | 'lxc'): ContainerProvider {
    if (engine === 'docker') return this.dockerProvider;
    if (engine === 'lxc') return this.lxcProvider;
    throw new ProviderUnavailableError(engine, `Unknown container engine: ${engine}`);
  }

  getGlobalDefaultEngine(): 'docker' | 'lxc' {
    return db.getSetting<'docker' | 'lxc'>('container_engine', 'docker');
  }

  getDocker(): DockerProvider {
    return this.dockerProvider;
  }

  getLXC(): LXCProvider {
    return this.lxcProvider;
  }
}

export const providerManager = new ProviderManager();
