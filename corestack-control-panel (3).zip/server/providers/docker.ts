import http from 'http';
import { CONFIG } from '../config.js';
import {
  ContainerProvider,
  ProviderCapabilities,
  ProviderValidationResult,
  CreateContainerSpec,
  ProviderResource,
  ProviderStatus,
  ProviderInspection,
  ProviderStats,
  ExecuteOptions,
  ExecuteResult,
  HealthcheckResult,
  ProviderUnavailableError,
  ProviderOperationError,
} from './types.js';

export class DockerProvider implements ContainerProvider {
  readonly name = 'docker' as const;

  /**
   * Scoped allowlist of permitted Docker Engine API endpoint prefixes.
   * Restricts communication over the Docker socket exclusively to authorized workload lifecycle operations.
   */
  private static readonly ALLOWED_API_PREFIXES = [
    '/version',
    '/info',
    '/images/',
    '/containers/',
    '/exec/',
  ];

  private makeRequest(
    method: string,
    apiPath: string,
    body?: any,
    timeoutMs = 30000
  ): Promise<{ statusCode: number; data: any; raw: Buffer }> {
    return new Promise((resolve, reject) => {
      // Validate path against directory traversal and null bytes
      if (!apiPath.startsWith('/') || apiPath.includes('..') || apiPath.includes('\0')) {
        return reject(
          new ProviderOperationError(
            'docker',
            'SECURITY_VIOLATION',
            `Invalid Docker API path format: ${apiPath}`
          )
        );
      }

      // If accessing a container endpoint, validate that the container ID segment is alphanumeric
      const containerMatch = apiPath.match(/^\/containers\/([^/?#]+)/);
      if (containerMatch) {
        const containerIdSegment = decodeURIComponent(containerMatch[1]);
        if (!/^[a-zA-Z0-9_-]{1,64}$/.test(containerIdSegment)) {
          return reject(
            new ProviderOperationError(
              'docker',
              'SECURITY_VIOLATION',
              `Invalid or malicious container identifier in Docker API path: ${containerIdSegment}`
            )
          );
        }
      }

      // Enforce least-privilege endpoint allowlist
      const isAllowedEndpoint = DockerProvider.ALLOWED_API_PREFIXES.some(prefix =>
        apiPath === prefix || apiPath.startsWith(prefix)
      );

      if (!isAllowedEndpoint) {
        return reject(
          new ProviderOperationError(
            'docker',
            'DISALLOWED_ENDPOINT',
            `Access to Docker API endpoint '${apiPath}' is blocked by security policy.`
          )
        );
      }

      const isTcp = CONFIG.DOCKER_HOST && CONFIG.DOCKER_HOST.startsWith('tcp://');
      let host = 'localhost';
      let port = 2375;

      if (isTcp) {
        const url = new URL(CONFIG.DOCKER_HOST.replace('tcp://', 'http://'));
        host = url.hostname;
        port = parseInt(url.port || '2375', 10);
      }

      const options: http.RequestOptions = {
        method,
        path: apiPath,
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'VortexPanel-DockerClient/1.0',
        },
        timeout: timeoutMs,
      };

      if (isTcp) {
        options.host = host;
        options.port = port;
      } else {
        options.socketPath = CONFIG.DOCKER_SOCKET;
      }

      const req = http.request(options, (res) => {
        const chunks: Buffer[] = [];
        res.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
        res.on('end', () => {
          const raw = Buffer.concat(chunks);
          let parsed: any = null;
          const text = raw.toString('utf-8');
          try {
            parsed = text ? JSON.parse(text) : null;
          } catch {
            parsed = text;
          }
          resolve({ statusCode: res.statusCode || 500, data: parsed, raw });
        });
      });

      req.on('error', (err) => {
        reject(
          new ProviderUnavailableError(
            'docker',
            `Docker daemon communication failed on ${isTcp ? CONFIG.DOCKER_HOST : CONFIG.DOCKER_SOCKET}: ${err.message}`,
            err
          )
        );
      });

      req.on('timeout', () => {
        req.destroy();
        reject(
          new ProviderOperationError(
            'docker',
            'TIMEOUT',
            `Docker request timed out after ${timeoutMs}ms for ${method} ${apiPath}`
          )
        );
      });

      if (body) {
        const payload = typeof body === 'string' ? body : JSON.stringify(body);
        req.write(payload);
      }
      req.end();
    });
  }

  async capabilities(): Promise<ProviderCapabilities> {
    try {
      const res = await this.makeRequest('GET', '/version', undefined, 5000);
      if (res.statusCode === 200 && res.data) {
        return {
          name: 'docker',
          available: true,
          version: res.data.Version || res.data.ApiVersion,
          driver: res.data.Platform?.Name,
          cgroups_version: res.data.MinAPIVersion,
        };
      }
      return {
        name: 'docker',
        available: false,
        error: `Daemon returned HTTP ${res.statusCode}: ${JSON.stringify(res.data)}`,
      };
    } catch (err: any) {
      return {
        name: 'docker',
        available: false,
        error: err.message,
      };
    }
  }

  async validate_host(): Promise<ProviderValidationResult> {
    try {
      const res = await this.makeRequest('GET', '/info', undefined, 5000);
      if (res.statusCode === 200 && res.data) {
        return {
          valid: true,
          engine: 'docker',
          details: {
            server_version: res.data.ServerVersion,
            operating_system: res.data.OperatingSystem,
            cpus: res.data.NCPU,
            total_memory_bytes: res.data.MemTotal,
            storage_driver: res.data.Driver,
            containers_total: res.data.Containers,
            containers_running: res.data.ContainersRunning,
            cgroups_mode: res.data.CgroupVersion || 'cgroupfs',
          },
        };
      }
      return {
        valid: false,
        engine: 'docker',
        details: {},
        error: `Docker /info returned status ${res.statusCode}`,
      };
    } catch (err: any) {
      return {
        valid: false,
        engine: 'docker',
        details: {},
        error: err.message,
      };
    }
  }

  async ensureImage(imageTag: string): Promise<void> {
    // Check if image already exists locally
    try {
      const inspectRes = await this.makeRequest('GET', `/images/${encodeURIComponent(imageTag)}/json`);
      if (inspectRes.statusCode === 200) {
        return; // Image is already available locally
      }
    } catch {
      // not found, proceed to pull
    }

    // Pull image
    const pullRes = await this.makeRequest('POST', `/images/create?fromImage=${encodeURIComponent(imageTag)}`, undefined, 120000);
    if (pullRes.statusCode !== 200) {
      throw new ProviderOperationError(
        'docker',
        'IMAGE_PULL_FAILED',
        `Failed to pull Docker image ${imageTag}: ${JSON.stringify(pullRes.data)}`
      );
    }
  }

  async create(spec: CreateContainerSpec): Promise<ProviderResource> {
    // Validate host daemon first
    const hostVal = await this.validate_host();
    if (!hostVal.valid) {
      throw new ProviderUnavailableError('docker', `Cannot create container: ${hostVal.error}`);
    }

    // Ensure image is downloaded
    await this.ensureImage(spec.image);

    // Compute nanoCPUs (1 CPU = 1e9 nanoCPUs)
    const nanoCpus = Math.max(1, Math.round(spec.cpu_cores * 1e9));

    // Port bindings for SSH
    const exposedPorts: Record<string, Record<string, any>> = {};
    const portBindings: Record<string, Array<{ HostPort: string }>> = {};

    if (spec.ssh_enabled && spec.ssh_host_port) {
      exposedPorts['22/tcp'] = {};
      portBindings['22/tcp'] = [{ HostPort: String(spec.ssh_host_port) }];
    }

    const payload = {
      Image: spec.image,
      Hostname: spec.hostname || spec.name,
      Cmd: ['/bin/sh', '-c', 'trap exit TERM; while :; do sleep 1; done'],
      ExposedPorts: exposedPorts,
      Volumes: {}, // Strictly strip any untrusted container volumes
      HostConfig: {
        Memory: spec.memory_bytes,
        MemorySwap: spec.memory_bytes, // Disable unbounded swap memory beyond allocated RAM limit
        NanoCPUs: nanoCpus,
        PidsLimit: spec.pids_limit || 2048,
        PortBindings: portBindings,
        RestartPolicy: { Name: 'unless-stopped' },
        Privileged: false, // Strictly unprivileged container
        NetworkMode: 'bridge', // Isolate from host network stack
        CapDrop: ['ALL'], // Drop all host capabilities
        CapAdd: ['CHOWN', 'DAC_OVERRIDE', 'FOWNER', 'SETGID', 'SETUID', 'NET_BIND_SERVICE'], // Minimal required set
        SecurityOpt: ['no-new-privileges:true'], // Prevent privilege escalation through setuid/setgid binaries
        Binds: [], // Strictly clear and block any host filesystem binds
        Mounts: [], // Strictly clear any host mounts
      },
      Labels: {
        managed_by: 'vortex-panel',
        vm_name: spec.name,
        username: spec.username,
        ...spec.labels,
      },
    };

    const res = await this.makeRequest('POST', `/containers/create?name=${encodeURIComponent(spec.name)}`, payload);

    if (res.statusCode !== 201 || !res.data?.Id) {
      throw new ProviderOperationError(
        'docker',
        'CONTAINER_CREATE_FAILED',
        `Docker container creation failed with status ${res.statusCode}: ${JSON.stringify(res.data)}`
      );
    }

    return {
      provider: 'docker',
      resource_id: res.data.Id,
      name: spec.name,
      raw_state: res.data,
    };
  }

  async start(resource_id: string): Promise<ProviderStatus> {
    const res = await this.makeRequest('POST', `/containers/${encodeURIComponent(resource_id)}/start`);
    if (res.statusCode !== 204 && res.statusCode !== 304) {
      throw new ProviderOperationError(
        'docker',
        'START_FAILED',
        `Failed to start container ${resource_id} (HTTP ${res.statusCode}): ${JSON.stringify(res.data)}`
      );
    }
    return this.status(resource_id);
  }

  async stop(resource_id: string): Promise<ProviderStatus> {
    const res = await this.makeRequest('POST', `/containers/${encodeURIComponent(resource_id)}/stop?t=10`);
    if (res.statusCode !== 204 && res.statusCode !== 304) {
      throw new ProviderOperationError(
        'docker',
        'STOP_FAILED',
        `Failed to stop container ${resource_id} (HTTP ${res.statusCode}): ${JSON.stringify(res.data)}`
      );
    }
    return this.status(resource_id);
  }

  async restart(resource_id: string): Promise<ProviderStatus> {
    const res = await this.makeRequest('POST', `/containers/${encodeURIComponent(resource_id)}/restart?t=10`);
    if (res.statusCode !== 204) {
      throw new ProviderOperationError(
        'docker',
        'RESTART_FAILED',
        `Failed to restart container ${resource_id} (HTTP ${res.statusCode}): ${JSON.stringify(res.data)}`
      );
    }
    return this.status(resource_id);
  }

  async delete(resource_id: string): Promise<void> {
    // Delete with force=1 and v=1 (remove volumes)
    const res = await this.makeRequest('DELETE', `/containers/${encodeURIComponent(resource_id)}?v=1&force=1`);
    if (res.statusCode !== 204 && res.statusCode !== 404) {
      throw new ProviderOperationError(
        'docker',
        'DELETE_FAILED',
        `Failed to delete container ${resource_id} (HTTP ${res.statusCode}): ${JSON.stringify(res.data)}`
      );
    }
  }

  async status(resource_id: string): Promise<ProviderStatus> {
    const res = await this.makeRequest('GET', `/containers/${encodeURIComponent(resource_id)}/json`);
    if (res.statusCode === 404) {
      return {
        provider: 'docker',
        resource_id,
        state: 'not_found',
      };
    }
    if (res.statusCode !== 200 || !res.data) {
      throw new ProviderOperationError('docker', 'INSPECT_FAILED', `Status inspection failed: ${res.statusCode}`);
    }

    const state = res.data.State || {};
    let mappedState: ProviderStatus['state'] = 'stopped';
    if (state.Running) mappedState = 'running';
    else if (state.Paused) mappedState = 'paused';
    else if (state.Restarting) mappedState = 'restarting';
    else if (state.Dead) mappedState = 'dead';

    return {
      provider: 'docker',
      resource_id,
      state: mappedState,
      exit_code: state.ExitCode,
      started_at: state.StartedAt,
      finished_at: state.FinishedAt,
      error: state.Error,
    };
  }

  async inspect(resource_id: string): Promise<ProviderInspection> {
    const res = await this.makeRequest('GET', `/containers/${encodeURIComponent(resource_id)}/json`);
    if (res.statusCode !== 200 || !res.data) {
      throw new ProviderOperationError(
        'docker',
        'INSPECT_FAILED',
        `Failed to inspect container ${resource_id} (HTTP ${res.statusCode})`
      );
    }

    const c = res.data;
    const ips: string[] = [];

    if (c.NetworkSettings?.IPAddress) {
      ips.push(c.NetworkSettings.IPAddress);
    }
    if (c.NetworkSettings?.Networks) {
      for (const net of Object.values(c.NetworkSettings.Networks) as any[]) {
        if (net?.IPAddress && !ips.includes(net.IPAddress)) {
          ips.push(net.IPAddress);
        }
      }
    }

    const ports: Record<string, number> = {};
    if (c.NetworkSettings?.Ports) {
      for (const [containerPort, hostBindings] of Object.entries(c.NetworkSettings.Ports) as any[]) {
        if (Array.isArray(hostBindings) && hostBindings.length > 0) {
          ports[containerPort] = parseInt(hostBindings[0].HostPort, 10);
        }
      }
    }

    const hostConfig = c.HostConfig || {};
    const cpuCores = hostConfig.NanoCPUs ? hostConfig.NanoCPUs / 1e9 : 1;

    let mappedState: ProviderStatus['state'] = 'stopped';
    if (c.State?.Running) mappedState = 'running';
    else if (c.State?.Paused) mappedState = 'paused';
    else if (c.State?.Restarting) mappedState = 'restarting';

    return {
      provider: 'docker',
      resource_id,
      name: c.Name?.replace(/^\//, '') || '',
      state: mappedState,
      ip_addresses: ips,
      ports,
      memory_limit_bytes: hostConfig.Memory || 0,
      cpu_cores_configured: cpuCores,
      created_at: c.Created,
      raw: c,
    };
  }

  async stats(resource_id: string): Promise<ProviderStats> {
    const res = await this.makeRequest('GET', `/containers/${encodeURIComponent(resource_id)}/stats?stream=false`);
    if (res.statusCode !== 200 || !res.data) {
      throw new ProviderOperationError(
        'docker',
        'STATS_FAILED',
        `Failed to retrieve stats for ${resource_id} (HTTP ${res.statusCode})`
      );
    }

    const s = res.data;
    let cpuPercent = 0.0;
    const cpuDelta = (s.cpu_stats?.cpu_usage?.total_usage || 0) - (s.precpu_stats?.cpu_usage?.total_usage || 0);
    const systemDelta = (s.cpu_stats?.system_cpu_usage || 0) - (s.precpu_stats?.system_cpu_usage || 0);
    const numCpus = s.cpu_stats?.online_cpus || s.cpu_stats?.cpu_usage?.percpu_usage?.length || 1;

    if (systemDelta > 0 && cpuDelta > 0) {
      cpuPercent = (cpuDelta / systemDelta) * numCpus * 100.0;
    }

    let rxBytes = 0;
    let txBytes = 0;
    if (s.networks) {
      for (const net of Object.values(s.networks) as any[]) {
        rxBytes += net.rx_bytes || 0;
        txBytes += net.tx_bytes || 0;
      }
    }

    const memUsage = s.memory_stats?.usage || 0;
    const memLimit = s.memory_stats?.limit || 0;
    const pids = s.pids_stats?.current || 0;

    return {
      provider: 'docker',
      resource_id,
      sampled_at: new Date().toISOString(),
      cpu_usage_percent: Math.min(100.0 * numCpus, Math.max(0, parseFloat(cpuPercent.toFixed(2)))),
      memory_used_bytes: memUsage,
      memory_limit_bytes: memLimit,
      net_rx_bytes: rxBytes,
      net_tx_bytes: txBytes,
      pids,
    };
  }

  async execute(resource_id: string, command: string[], options: ExecuteOptions = {}): Promise<ExecuteResult> {
    const startTime = Date.now();

    // 1. Create exec instance
    const execCreateRes = await this.makeRequest('POST', `/containers/${encodeURIComponent(resource_id)}/exec`, {
      AttachStdout: true,
      AttachStderr: true,
      Tty: false,
      Cmd: command,
      WorkingDir: options.working_dir,
      User: options.user,
      Env: options.env ? Object.entries(options.env).map(([k, v]) => `${k}:${v}`) : undefined,
    });

    if (execCreateRes.statusCode !== 201 || !execCreateRes.data?.Id) {
      throw new ProviderOperationError(
        'docker',
        'EXEC_CREATE_FAILED',
        `Failed to create exec instance in ${resource_id}: ${JSON.stringify(execCreateRes.data)}`
      );
    }

    const execId = execCreateRes.data.Id;

    // 2. Start exec instance and capture output
    const startRes = await this.makeRequest('POST', `/exec/${encodeURIComponent(execId)}/start`, {
      Detach: false,
      Tty: false,
    });

    // 3. Inspect exec instance for exit code
    const inspectRes = await this.makeRequest('GET', `/exec/${encodeURIComponent(execId)}/json`);
    const exitCode = inspectRes.data?.ExitCode ?? 0;

    // Docker multiplexes stdout & stderr in raw stream headers if TTY is false (8 bytes header per frame)
    const raw = startRes.raw;
    let stdout = '';
    let stderr = '';

    if (raw && raw.length > 8) {
      let offset = 0;
      while (offset < raw.length) {
        if (offset + 8 > raw.length) {
          stdout += raw.subarray(offset).toString('utf-8');
          break;
        }
        const streamType = raw.readUInt8(offset);
        const frameSize = raw.readUInt32BE(offset + 4);
        offset += 8;

        const frameData = raw.subarray(offset, offset + frameSize).toString('utf-8');
        offset += frameSize;

        if (streamType === 2) {
          stderr += frameData;
        } else {
          stdout += frameData;
        }
      }
    } else if (raw) {
      stdout = raw.toString('utf-8');
    }

    return {
      exit_code: exitCode,
      stdout: stdout.trim(),
      stderr: stderr.trim(),
      duration_ms: Date.now() - startTime,
    };
  }

  async get_ip(resource_id: string): Promise<string[]> {
    const inspection = await this.inspect(resource_id);
    return inspection.ip_addresses;
  }

  async configure_resources(
    resource_id: string,
    resources: { cpu_cores: number; memory_bytes: number; pids_limit?: number }
  ): Promise<ProviderInspection> {
    const payload: any = {
      Memory: resources.memory_bytes,
      NanoCPUs: Math.round(resources.cpu_cores * 1e9),
    };
    if (resources.pids_limit) {
      payload.PidsLimit = resources.pids_limit;
    }

    const res = await this.makeRequest('POST', `/containers/${encodeURIComponent(resource_id)}/update`, payload);
    if (res.statusCode !== 200) {
      throw new ProviderOperationError(
        'docker',
        'RESOURCE_UPDATE_FAILED',
        `Failed to update container resources: ${JSON.stringify(res.data)}`
      );
    }
    return this.inspect(resource_id);
  }

  async healthcheck(resource_id?: string): Promise<HealthcheckResult> {
    try {
      const caps = await this.capabilities();
      if (!caps.available) {
        return {
          healthy: false,
          engine: 'docker',
          message: caps.error || 'Docker daemon unreachable',
        };
      }

      if (resource_id) {
        const st = await this.status(resource_id);
        return {
          healthy: st.state === 'running',
          engine: 'docker',
          message: `Container ${resource_id} is in state: ${st.state}`,
          details: st,
        };
      }

      return {
        healthy: true,
        engine: 'docker',
        message: `Docker Engine version ${caps.version} online and responsive.`,
        details: caps,
      };
    } catch (err: any) {
      return {
        healthy: false,
        engine: 'docker',
        message: err.message,
      };
    }
  }
}
