import { execFile } from 'child_process';
import util from 'util';
import {
  ContainerProvider,
  ProviderCapabilities,
  ProviderValidationResult,
  CreateContainerSpec,
  ProviderResource,
  ProviderStatus,
  ProviderInspection,
  ProviderStats,
  ExecuteOptions,
  ExecuteResult,
  HealthcheckResult,
  ProviderUnavailableError,
  ProviderOperationError,
} from './types.js';

const execFileAsync = util.promisify(execFile);

/**
 * Strict identifier allowlist:
 * - Exactly alphanumeric, hyphen, or underscore
 * - Between 1 and 64 characters
 * - Never starts with dash (-) to eliminate CLI flag/option injection
 */
const IDENTIFIER_REGEX = /^[a-zA-Z0-9\-_]{1,64}$/;

/**
 * Forbidden shell characters that could be used in injection attempts
 */
const FORBIDDEN_SHELL_CHARS = /[;&|`$><\n\r\t\0 ]/;

/**
 * Strict image tag allowlist:
 * - alphanumeric/colon/dots/dashes only (e.g. ubuntu:22.04)
 */
const IMAGE_TAG_REGEX = /^[a-zA-Z0-9][a-zA-Z0-9_.-]*:[a-zA-Z0-9_.-]+$/;

export class LXCProvider implements ContainerProvider {
  readonly name = 'lxc' as const;

  /**
   * Validates and sanitizes a container identifier / resource ID.
   * Throws immediately if input contains invalid characters, flags, or separators.
   */
  private validateIdentifier(value: unknown, fieldName: string): string {
    if (typeof value !== 'string' || !value.trim()) {
      throw new ProviderOperationError(
        'lxc',
        'INVALID_IDENTIFIER',
        `Validation failed: ${fieldName} must be a non-empty string.`
      );
    }

    const trimmed = value.trim();

    // Prevent flag/option injection into CLI (e.g. -n, --destroy)
    if (trimmed.startsWith('-')) {
      throw new ProviderOperationError(
        'lxc',
        'COMMAND_INJECTION_DETECTED',
        `Security violation: ${fieldName} cannot start with a dash/flag character ('-').`
      );
    }

    // Block any shell control operators or command separators
    if (FORBIDDEN_SHELL_CHARS.test(trimmed)) {
      throw new ProviderOperationError(
        'lxc',
        'COMMAND_INJECTION_DETECTED',
        `Security violation: ${fieldName} contains forbidden shell characters or whitespace.`
      );
    }

    if (!IDENTIFIER_REGEX.test(trimmed)) {
      throw new ProviderOperationError(
        'lxc',
        'INVALID_IDENTIFIER',
        `Security violation: ${fieldName} contains illegal characters. Only alphanumeric, hyphen, and underscore are allowed (regex: ^[a-zA-Z0-9\\-_]{1,64}$).`
      );
    }

    return trimmed;
  }

  /**
   * Safely executes an LXC CLI command using child_process.execFile with shell=false.
   * All parameters must be passed in an explicit array.
   */
  private async safeExec(
    cmd: string,
    args: string[],
    timeoutMs = 30000
  ): Promise<{ stdout: string; stderr: string; exitCode: number }> {
    // Assert all arguments are primitive strings with no null bytes
    for (let i = 0; i < args.length; i++) {
      if (typeof args[i] !== 'string' || args[i].includes('\0')) {
        throw new ProviderOperationError(
          'lxc',
          'ILLEGAL_ARGUMENT',
          `Safe execution blocked: argument at index ${i} contains illegal null byte or is not a string.`
        );
      }
    }

    try {
      const res = await execFileAsync(cmd, args, {
        timeout: timeoutMs,
        shell: false, // Strictly disable shell context to prevent any command injection
        maxBuffer: 10 * 1024 * 1024,
      });
      return { stdout: res.stdout, stderr: res.stderr, exitCode: 0 };
    } catch (err: any) {
      return {
        stdout: err.stdout || '',
        stderr: err.stderr || err.message,
        exitCode: typeof err.code === 'number' ? err.code : 1,
      };
    }
  }

  async capabilities(): Promise<ProviderCapabilities> {
    try {
      const { exitCode, stdout, stderr } = await this.safeExec('lxc-checkconfig', [], 5000);
      if (exitCode === 0 || stdout.includes('Cgroup')) {
        const verRes = await this.safeExec('lxc-ls', ['--version'], 5000);
        return {
          name: 'lxc',
          available: true,
          version: verRes.stdout.trim() || 'LXC Installed',
          driver: 'lxc-native',
        };
      }
      return {
        name: 'lxc',
        available: false,
        error: `lxc-checkconfig failed or not found: ${stderr || stdout || 'command not available'}`,
      };
    } catch (err: any) {
      return {
        name: 'lxc',
        available: false,
        error: `LXC binary check failed: ${err.message}`,
      };
    }
  }

  async validate_host(): Promise<ProviderValidationResult> {
    const caps = await this.capabilities();
    if (!caps.available) {
      return {
        valid: false,
        engine: 'lxc',
        details: {},
        error: caps.error || 'LXC tooling is not installed or kernel namespaces are unsupported',
      };
    }

    return {
      valid: true,
      engine: 'lxc',
      details: {
        version: caps.version,
      },
    };
  }

  async create(spec: CreateContainerSpec): Promise<ProviderResource> {
    const hostVal = await this.validate_host();
    if (!hostVal.valid) {
      throw new ProviderUnavailableError('lxc', hostVal.error || 'LXC host validation failed');
    }

    // Strict input validation for spec name
    const validName = this.validateIdentifier(spec.name, 'spec.name');

    // Strict validation for image tag
    if (typeof spec.image !== 'string' || !IMAGE_TAG_REGEX.test(spec.image)) {
      throw new ProviderOperationError(
        'lxc',
        'INVALID_IMAGE_TAG',
        `Security violation: Invalid container image format: ${spec.image}`
      );
    }

    // Map image string to lxc distribution and release
    const osMap: Record<string, { dist: string; release: string }> = {
      'ubuntu:20.04': { dist: 'ubuntu', release: 'focal' },
      'ubuntu:22.04': { dist: 'ubuntu', release: 'jammy' },
      'debian:11': { dist: 'debian', release: 'bullseye' },
      'debian:12': { dist: 'debian', release: 'bookworm' },
    };

    const target = osMap[spec.image];
    if (!target) {
      throw new ProviderOperationError('lxc', 'UNSUPPORTED_OS', `Unsupported OS for LXC: ${spec.image}`);
    }

    const containerName = validName.toLowerCase();
    this.validateIdentifier(containerName, 'containerName');

    // Safe command invocation with strictly separated arguments and explicit end-of-options marker
    const createRes = await this.safeExec(
      'lxc-create',
      ['-n', containerName, '-t', 'download', '--', '-d', target.dist, '-r', target.release, '-a', 'amd64'],
      180000
    );

    if (createRes.exitCode !== 0) {
      throw new ProviderOperationError(
        'lxc',
        'CREATE_FAILED',
        `lxc-create failed for ${containerName}: ${createRes.stderr || createRes.stdout}`
      );
    }

    // Configure cgroups memory limits with strict numerical check
    if (typeof spec.memory_bytes === 'number' && Number.isSafeInteger(spec.memory_bytes) && spec.memory_bytes > 0) {
      await this.safeExec('lxc-cgroup', ['-n', containerName, '--', 'memory.limit_in_bytes', String(spec.memory_bytes)]);
    }

    return {
      provider: 'lxc',
      resource_id: containerName,
      name: spec.name,
      raw_state: { containerName, spec },
    };
  }

  async delete(resource_id: string): Promise<void> {
    const validId = this.validateIdentifier(resource_id, 'resource_id');
    await this.safeExec('lxc-stop', ['-n', validId, '-k'], 10000);
    const res = await this.safeExec('lxc-destroy', ['-n', validId, '-f'], 30000);
    if (res.exitCode !== 0 && !res.stderr.includes('does not exist')) {
      throw new ProviderOperationError('lxc', 'DELETE_FAILED', `lxc-destroy failed: ${res.stderr}`);
    }
  }

  async start(resource_id: string): Promise<ProviderStatus> {
    const validId = this.validateIdentifier(resource_id, 'resource_id');
    const res = await this.safeExec('lxc-start', ['-n', validId, '-d'], 15000);
    if (res.exitCode !== 0) {
      throw new ProviderOperationError('lxc', 'START_FAILED', `lxc-start failed: ${res.stderr}`);
    }
    return this.status(validId);
  }

  async stop(resource_id: string): Promise<ProviderStatus> {
    const validId = this.validateIdentifier(resource_id, 'resource_id');
    const res = await this.safeExec('lxc-stop', ['-n', validId, '-t', '10'], 15000);
    if (res.exitCode !== 0) {
      throw new ProviderOperationError('lxc', 'STOP_FAILED', `lxc-stop failed: ${res.stderr}`);
    }
    return this.status(validId);
  }

  async restart(resource_id: string): Promise<ProviderStatus> {
    const validId = this.validateIdentifier(resource_id, 'resource_id');
    await this.stop(validId);
    return this.start(validId);
  }

  async status(resource_id: string): Promise<ProviderStatus> {
    const validId = this.validateIdentifier(resource_id, 'resource_id');
    const res = await this.safeExec('lxc-info', ['-n', validId], 5000);
    if (res.exitCode !== 0) {
      return {
        provider: 'lxc',
        resource_id: validId,
        state: 'not_found',
        error: res.stderr,
      };
    }

    const text = res.stdout;
    let state: ProviderStatus['state'] = 'stopped';
    if (text.includes('State:          RUNNING')) {
      state = 'running';
    } else if (text.includes('State:          FROZEN')) {
      state = 'paused';
    }

    return {
      provider: 'lxc',
      resource_id: validId,
      state,
    };
  }

  async inspect(resource_id: string): Promise<ProviderInspection> {
    const validId = this.validateIdentifier(resource_id, 'resource_id');
    const res = await this.safeExec('lxc-info', ['-n', validId], 5000);
    if (res.exitCode !== 0) {
      throw new ProviderOperationError('lxc', 'INSPECT_FAILED', `lxc-info failed: ${res.stderr}`);
    }

    const text = res.stdout;
    const ips: string[] = [];
    const ipMatches = text.match(/IP:\s+([0-9.]+)/g);
    if (ipMatches) {
      for (const m of ipMatches) {
        const ip = m.replace(/IP:\s+/, '').trim();
        if (ip && !ips.includes(ip)) ips.push(ip);
      }
    }

    let state: ProviderStatus['state'] = 'stopped';
    if (text.includes('State:          RUNNING')) state = 'running';
    else if (text.includes('State:          FROZEN')) state = 'paused';

    return {
      provider: 'lxc',
      resource_id: validId,
      name: validId,
      state,
      ip_addresses: ips,
      ports: {},
      memory_limit_bytes: 0,
      cpu_cores_configured: 1,
      created_at: new Date().toISOString(),
      raw: text,
    };
  }

  async stats(resource_id: string): Promise<ProviderStats> {
    const validId = this.validateIdentifier(resource_id, 'resource_id');
    const res = await this.safeExec('lxc-info', ['-n', validId], 5000);
    let memUsed = 0;
    if (res.stdout) {
      const memMatch = res.stdout.match(/Memory use:\s+([0-9.]+)\s+(KB|MB|GB|bytes)/i);
      if (memMatch) {
        const val = parseFloat(memMatch[1]);
        const unit = memMatch[2].toUpperCase();
        if (unit === 'KB') memUsed = val * 1024;
        else if (unit === 'MB') memUsed = val * 1024 * 1024;
        else if (unit === 'GB') memUsed = val * 1024 * 1024 * 1024;
        else memUsed = val;
      }
    }

    return {
      provider: 'lxc',
      resource_id: validId,
      sampled_at: new Date().toISOString(),
      cpu_usage_percent: 0,
      memory_used_bytes: memUsed,
      memory_limit_bytes: 0,
      net_rx_bytes: 0,
      net_tx_bytes: 0,
      pids: 0,
    };
  }

  async execute(resource_id: string, command: string[], options: ExecuteOptions = {}): Promise<ExecuteResult> {
    const validId = this.validateIdentifier(resource_id, 'resource_id');
    const startTime = Date.now();

    if (!Array.isArray(command) || command.length === 0) {
      throw new ProviderOperationError(
        'lxc',
        'INVALID_COMMAND',
        'Command must be a non-empty array of strings.'
      );
    }

    // Verify all command arguments are strings and contain no null bytes
    for (const arg of command) {
      if (typeof arg !== 'string' || arg.includes('\0')) {
        throw new ProviderOperationError(
          'lxc',
          'INVALID_COMMAND',
          'All command elements must be valid strings without null bytes.'
        );
      }
    }

    // Safe execution inside container without host shell interpolation
    const args = ['-n', validId, '--', ...command];
    const res = await this.safeExec('lxc-attach', args, (options.timeout_seconds || 30) * 1000);

    return {
      exit_code: res.exitCode,
      stdout: res.stdout.trim(),
      stderr: res.stderr.trim(),
      duration_ms: Date.now() - startTime,
    };
  }

  async get_ip(resource_id: string): Promise<string[]> {
    const validId = this.validateIdentifier(resource_id, 'resource_id');
    const inspection = await this.inspect(validId);
    return inspection.ip_addresses;
  }

  async configure_resources(
    resource_id: string,
    resources: { cpu_cores: number; memory_bytes: number; pids_limit?: number }
  ): Promise<ProviderInspection> {
    const validId = this.validateIdentifier(resource_id, 'resource_id');

    if (typeof resources.memory_bytes === 'number' && Number.isSafeInteger(resources.memory_bytes) && resources.memory_bytes > 0) {
      await this.safeExec('lxc-cgroup', ['-n', validId, '--', 'memory.limit_in_bytes', String(resources.memory_bytes)]);
    }

    return this.inspect(validId);
  }

  async healthcheck(resource_id?: string): Promise<HealthcheckResult> {
    const caps = await this.capabilities();
    if (!caps.available) {
      return {
        healthy: false,
        engine: 'lxc',
        message: caps.error || 'LXC tooling unavailable on host',
      };
    }

    if (resource_id) {
      const validId = this.validateIdentifier(resource_id, 'resource_id');
      const st = await this.status(validId);
      return {
        healthy: st.state === 'running',
        engine: 'lxc',
        message: `LXC container ${validId} is ${st.state}`,
        details: st,
      };
    }

    return {
      healthy: true,
      engine: 'lxc',
      message: `LXC operational (${caps.version})`,
    };
  }
}
