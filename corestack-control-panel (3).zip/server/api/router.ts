import { Router, Request, Response } from 'express';
import { randomUUID } from 'crypto';
import path from 'path';
import { db } from '../db/database.js';
import { PortAllocator } from '../networking/portAllocator.js';
import {
  hashPassword,
  verifyPassword,
  generateSessionToken,
  generateApiKey,
  hashToken,
  hashIp,
} from '../auth/crypto.js';
import {
  requireAuth,
  requireAdmin,
  authorizeVM,
  AuthenticatedRequest,
} from '../auth/middleware.js';
import { CONFIG } from '../config.js';
import { providerManager } from '../providers/manager.js';
import { jobQueue } from '../jobs/queue.js';
import { getHostMetrics, validateHostCapacity } from '../resources/hostMetrics.js';
import { runVPSAcceptanceSuite } from '../acceptance/vpsAcceptanceRunner.js';
import { VM, VMResource } from '../db/schema.js';

export const apiRouter = Router();

// Middleware to attach request ID
apiRouter.use((req: any, res, next) => {
  req.requestId = req.headers['x-request-id'] || `req_${randomUUID().substring(0, 8)}`;
  res.setHeader('X-Request-Id', req.requestId);
  next();
});

// ==========================================
// 1. HEALTH & DIAGNOSTICS
// ==========================================

apiRouter.get('/health', async (req: Request, res: Response) => {
  const docker = providerManager.getDocker();
  const lxc = providerManager.getLXC();

  const [dockerCaps, lxcCaps] = await Promise.all([
    docker.capabilities(),
    lxc.capabilities(),
  ]);

  const defaultEngine = providerManager.getGlobalDefaultEngine();
  const primaryProviderHealthy = defaultEngine === 'docker' ? dockerCaps.available : lxcCaps.available;

  res.json({
    status: primaryProviderHealthy ? 'ok' : 'degraded',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    database: { status: 'ok' },
    container_engine: {
      active_default: defaultEngine,
      docker: dockerCaps,
      lxc: lxcCaps,
    },
    local_node: db.getLocalNode(),
  });
});

apiRouter.get('/ready', async (req: Request, res: Response) => {
  res.status(200).send('READY');
});

apiRouter.get('/diagnostics/host', async (req: Request, res: Response) => {
  const metrics = await getHostMetrics();
  res.json(metrics);
});

apiRouter.post('/diagnostics/vps-acceptance/run', requireAuth, requireAdmin, async (req: Request, res: Response) => {
  const report = await runVPSAcceptanceSuite();
  res.json(report);
});

// ==========================================
// 2. AUTHENTICATION
// ==========================================

apiRouter.post('/auth/login', async (req: Request, res: Response) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    res.status(400).json({
      error: { code: 'VALIDATION_ERROR', message: 'Email and password are required' },
    });
    return;
  }

  const user = db.getUserByEmail(email);
  if (!user || user.status !== 'active') {
    res.status(401).json({
      error: { code: 'AUTH_INVALID', message: 'Invalid email or password' },
    });
    return;
  }

  const valid = await verifyPassword(password, user.password_hash);
  if (!valid) {
    await db.logActivity({
      actor_user_id: user.id,
      vm_id: null,
      action: 'auth.login_failed',
      outcome: 'denied',
      request_id: (req as any).requestId,
      ip_hash: hashIp(req.ip || '127.0.0.1'),
      metadata_json: { email },
    });

    res.status(401).json({
      error: { code: 'AUTH_INVALID', message: 'Invalid email or password' },
    });
    return;
  }

  // Create session
  const { rawToken, tokenHash } = generateSessionToken();
  const expiresAt = new Date(Date.now() + CONFIG.SESSION_TTL_HOURS * 3600 * 1000).toISOString();

  await db.createSession({
    id: randomUUID(),
    user_id: user.id,
    token_hash: tokenHash,
    expires_at: expiresAt,
    created_at: new Date().toISOString(),
    revoked_at: null,
    ip_hash: hashIp(req.ip || '127.0.0.1'),
    user_agent_hash: req.headers['user-agent'] ? hashToken(req.headers['user-agent']) : null,
  });

  await db.updateUser(user.id, { last_login_at: new Date().toISOString() });

  // Set secure HttpOnly cookie
  res.cookie('vortex_session', rawToken, {
    httpOnly: true,
    secure: CONFIG.ENV === 'production',
    sameSite: 'strict',
    maxAge: CONFIG.SESSION_TTL_HOURS * 3600 * 1000,
    path: '/',
  });

  await db.logActivity({
    actor_user_id: user.id,
    vm_id: null,
    action: 'auth.login',
    outcome: 'succeeded',
    request_id: (req as any).requestId,
    ip_hash: hashIp(req.ip || '127.0.0.1'),
    metadata_json: { email: user.email },
  });

  res.json({
    token: rawToken,
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      status: user.status,
      must_change_password: user.must_change_password,
    },
  });
});

apiRouter.post('/auth/logout', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const token = req.headers.authorization?.replace('Bearer ', '') || req.cookies?.vortex_session;
  if (token) {
    const session = db.getSessionByTokenHash(hashToken(token));
    if (session) {
      await db.revokeSession(session.id);
    }
  }

  res.clearCookie('vortex_session', { path: '/' });
  res.status(204).send();
});

apiRouter.get('/auth/me', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  res.json({
    user: {
      id: user.id,
      email: user.email,
      role: user.role,
      status: user.status,
      must_change_password: user.must_change_password,
      created_at: user.created_at,
      last_login_at: user.last_login_at,
    },
  });
});

apiRouter.post('/auth/change-password', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const { current_password, new_password } = req.body;
  if (!current_password || !new_password || new_password.length < 8) {
    res.status(400).json({
      error: { code: 'VALIDATION_ERROR', message: 'New password must be at least 8 characters' },
    });
    return;
  }

  const valid = await verifyPassword(current_password, req.user!.password_hash);
  if (!valid) {
    res.status(400).json({
      error: { code: 'AUTH_INVALID', message: 'Current password is incorrect' },
    });
    return;
  }

  const newHash = await hashPassword(new_password);
  await db.updateUser(req.user!.id, {
    password_hash: newHash,
    must_change_password: false,
  });

  res.json({ message: 'Password updated successfully' });
});

// ==========================================
// 3. WORKLOADS (VMS)
// ==========================================

apiRouter.get('/vms', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const ownerId = req.user!.role === 'admin' ? undefined : req.user!.id;
  const vms = db.getAllVMs(ownerId);

  const detailed = vms.map((vm) => {
    const resrc = db.getVMResources(vm.id);
    return {
      ...vm,
      resources: resrc ? {
        cpu_cores: resrc.cpu_cores,
        memory_mb: Math.round(resrc.memory_bytes / (1024 * 1024)),
        disk_gb: Math.round(resrc.disk_bytes / (1024 * 1024 * 1024)),
      } : undefined,
    };
  });

  res.json({
    items: detailed,
    total: detailed.length,
    page: 1,
    page_size: detailed.length,
  });
});

apiRouter.post('/vms', requireAuth, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const {
    name,
    os,
    ram_mb = 1024,
    cpu_cores = 1,
    disk_gb = 10,
    username = 'ubuntu',
    password,
    hostname,
    ssh_enabled = true,
    engine,
  } = req.body;

  if (!name || !os) {
    res.status(400).json({
      error: { code: 'VALIDATION_ERROR', message: 'Workload name and OS are required' },
    });
    return;
  }

  // Exact OS verification per specification Section 0.5
  const supportedOS = ['ubuntu:20.04', 'ubuntu:22.04', 'debian:11', 'debian:12'];
  if (!supportedOS.includes(os)) {
    res.status(400).json({
      error: {
        code: 'UNSUPPORTED_OS',
        message: `Requested OS '${os}' is not supported. Supported: ${supportedOS.join(', ')}`,
      },
    });
    return;
  }

  const chosenEngine = engine || providerManager.getGlobalDefaultEngine();
  const memoryBytes = ram_mb * 1024 * 1024;
  const diskBytes = disk_gb * 1024 * 1024 * 1024;

  // Real capacity pre-validation
  const capCheck = await validateHostCapacity(cpu_cores, memoryBytes);
  if (!capCheck.valid) {
    res.status(400).json({
      error: { code: 'CAPACITY_INSUFFICIENT', message: capCheck.reason },
    });
    return;
  }

  // Check idempotency
  const idempotencyKey = (req.headers['idempotency-key'] as string) || null;
  if (idempotencyKey) {
    const existingJob = db.getJobByIdempotencyKey(idempotencyKey);
    if (existingJob) {
      const existingVM = existingJob.vm_id ? db.getVMById(existingJob.vm_id) : null;
      res.status(200).json({ vm: existingVM, job: existingJob });
      return;
    }
  }

  const vmId = randomUUID();
  const slug = name.toLowerCase().replace(/[^a-z0-9_-]/g, '-') + '-' + vmId.substring(0, 4);
  const localNode = db.getLocalNode();

  const newVM: VM = {
    id: vmId,
    owner_id: req.user!.id,
    local_node_id: localNode?.id || 'node-local',
    name,
    slug,
    requested_os: os,
    provider: chosenEngine,
    provider_resource_id: null,
    status: 'PENDING',
    status_version: 0,
    failure_code: null,
    failure_message: null,
    hostname: hostname || name,
    username,
    ssh_enabled: !!ssh_enabled,
    ssh_host_port: null,
    ip_address: null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    deleted_at: null,
  };

  const newResource: VMResource = {
    vm_id: vmId,
    cpu_cores,
    memory_bytes: memoryBytes,
    disk_bytes: diskBytes,
    pids_limit: 2048,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  await db.createVM(newVM, newResource);

  // Enqueue durable background job
  const job = await jobQueue.enqueue({
    type: 'vm.create',
    vm_id: vmId,
    requested_by: req.user!.id,
    idempotency_key: idempotencyKey,
    payload_json: {
      initial_password: password || undefined,
    },
    result_json: null,
    error_code: null,
    error_message: null,
  });

  res.status(202).json({
    vm: newVM,
    job: {
      id: job.id,
      status: job.state,
      current_step: job.current_step,
    },
  });
});

apiRouter.get('/vms/:id', requireAuth, authorizeVM('read'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id);
  if (!vm) {
    res.status(404).json({ error: { code: 'VM_NOT_FOUND', message: 'Workload not found' } });
    return;
  }

  const resources = db.getVMResources(vm.id);
  const ports = db.getActivePortAllocations().filter(p => p.vm_id === vm.id);
  const recentJobs = db.getJobsByVM(vm.id).slice(-5);

  res.json({
    ...vm,
    resources,
    ports,
    recent_jobs: recentJobs,
  });
});

apiRouter.post('/vms/:id/start', requireAuth, authorizeVM('control'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  if (vm.status === 'READY') {
    res.status(400).json({ error: { code: 'INVALID_VM_STATE', message: 'Workload is already running' } });
    return;
  }

  const job = await jobQueue.enqueue({
    type: 'vm.start',
    vm_id: vm.id,
    requested_by: req.user!.id,
    idempotency_key: null,
    payload_json: {},
    result_json: null,
    error_code: null,
    error_message: null,
  });

  res.status(202).json({ accepted: true, job_id: job.id, status: 'STARTING' });
});

apiRouter.post('/vms/:id/stop', requireAuth, authorizeVM('control'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  if (vm.status === 'STOPPED') {
    res.status(400).json({ error: { code: 'INVALID_VM_STATE', message: 'Workload is already stopped' } });
    return;
  }

  const job = await jobQueue.enqueue({
    type: 'vm.stop',
    vm_id: vm.id,
    requested_by: req.user!.id,
    idempotency_key: null,
    payload_json: {},
    result_json: null,
    error_code: null,
    error_message: null,
  });

  res.status(202).json({ accepted: true, job_id: job.id, status: 'STOPPING' });
});

apiRouter.post('/vms/:id/restart', requireAuth, authorizeVM('control'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;

  const job = await jobQueue.enqueue({
    type: 'vm.restart',
    vm_id: vm.id,
    requested_by: req.user!.id,
    idempotency_key: null,
    payload_json: {},
    result_json: null,
    error_code: null,
    error_message: null,
  });

  res.status(202).json({ accepted: true, job_id: job.id, status: 'RESTARTING' });
});

apiRouter.delete('/vms/:id', requireAuth, authorizeVM('delete'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;

  const job = await jobQueue.enqueue({
    type: 'vm.delete',
    vm_id: vm.id,
    requested_by: req.user!.id,
    idempotency_key: null,
    payload_json: {},
    result_json: null,
    error_code: null,
    error_message: null,
  });

  res.status(202).json({ accepted: true, job_id: job.id, status: 'DELETING' });
});

apiRouter.get('/vms/:id/stats', requireAuth, authorizeVM('read'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  if (vm.status !== 'READY' || !vm.provider_resource_id) {
    res.json({
      vm_id: vm.id,
      status: vm.status,
      available: false,
      message: `Workload metrics unavailable while in state ${vm.status}`,
    });
    return;
  }

  const provider = providerManager.getProvider(vm.provider);
  try {
    const stats = await provider.stats(vm.provider_resource_id);
    await db.addMonitoringSample({
      vm_id: vm.id,
      sampled_at: stats.sampled_at,
      cpu_usage_percent: stats.cpu_usage_percent,
      memory_used_bytes: stats.memory_used_bytes,
      memory_limit_bytes: stats.memory_limit_bytes,
      disk_used_bytes: null,
      disk_limit_bytes: null,
      net_rx_bytes: stats.net_rx_bytes,
      net_tx_bytes: stats.net_tx_bytes,
      pids: stats.pids,
    });
    res.json(stats);
  } catch (err: any) {
    res.status(503).json({
      error: { code: 'STATS_UNAVAILABLE', message: err.message },
    });
  }
});

apiRouter.post('/vms/:id/exec', requireAuth, authorizeVM('terminal'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  if (vm.status !== 'READY' || !vm.provider_resource_id) {
    res.status(400).json({
      error: { code: 'INVALID_VM_STATE', message: 'Workload must be READY to execute commands' },
    });
    return;
  }

  const { command } = req.body;
  if (!command) {
    res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Command array or string required' } });
    return;
  }

  const cmdArray = Array.isArray(command) ? command : ['/bin/sh', '-c', command];
  const provider = providerManager.getProvider(vm.provider);

  try {
    const result = await provider.execute(vm.provider_resource_id, cmdArray, {
      timeout_seconds: 30,
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: { code: 'EXEC_FAILED', message: err.message } });
  }
});

// ==========================================
// 4. IN-CONTAINER FILE MANAGER & PATH DEFENSE
// ==========================================

/**
 * Validates and canonicalizes file paths inside workloads to prevent Path Traversal attacks.
 */
export function validateSafeContainerPath(userPath: string, rootDir = '/'): string {
  if (typeof userPath !== 'string' || !userPath.trim()) {
    throw new Error('Access Denied: Path parameter is required');
  }
  if (userPath.includes('\0')) {
    throw new Error('Access Denied: Null byte detected in path');
  }

  // Explicitly block any directory traversal sequences (..)
  if (userPath.includes('..') || userPath.split(/[\/\\]/).some(s => s === '..')) {
    throw new Error('Access Denied: Path Traversal Detected');
  }

  // Canonicalize path using posix normalize
  const normalized = path.posix.normalize(userPath.trim());
  if (normalized.startsWith('../') || normalized === '..' || normalized.includes('/../')) {
    throw new Error('Access Denied: Path Traversal Detected');
  }

  const resolved = path.posix.resolve(rootDir, normalized);
  if (!resolved.startsWith(rootDir)) {
    throw new Error('Access Denied: Path Traversal Detected');
  }

  // Block shell injection characters in file paths
  if (/[;&|`$><\n\r\t]/.test(resolved)) {
    throw new Error('Access Denied: Illegal characters detected in path');
  }

  return resolved;
}

/**
 * Protects archive extractions from Zip-Slip path traversal attacks.
 */
export function validateZipSlipPath(destinationDir: string, entryPath: string): string {
  const safeDest = path.resolve(destinationDir);
  const targetPath = path.resolve(safeDest, entryPath);
  if (!targetPath.startsWith(safeDest + path.sep) && targetPath !== safeDest) {
    throw new Error('Access Denied: Zip-Slip Path Traversal Detected');
  }
  return targetPath;
}

apiRouter.get('/vms/:id/files', requireAuth, authorizeVM('files'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  if (vm.status !== 'READY' || !vm.provider_resource_id) {
    res.status(400).json({ error: { code: 'INVALID_VM_STATE', message: 'Workload must be READY for file operations' } });
    return;
  }

  let cleanPath = '/';
  try {
    cleanPath = validateSafeContainerPath((req.query.path as string) || '/');
  } catch (err: any) {
    res.status(403).json({ error: { code: 'PATH_TRAVERSAL_DETECTED', message: err.message } });
    return;
  }

  const provider = providerManager.getProvider(vm.provider);
  try {
    // List directory using ls -la with JSON or formatted output
    const result = await provider.execute(vm.provider_resource_id, [
      'ls',
      '-la',
      '--time-style=+%Y-%m-%d %H:%M:%S',
      cleanPath,
    ]);

    if (result.exit_code !== 0) {
      res.status(400).json({ error: { code: 'FILE_OPERATION_FAILED', message: result.stderr || 'Failed to list path' } });
      return;
    }

    const lines = result.stdout.split('\n').filter(l => l.trim().length > 0);
    const items = [];

    for (let i = 1; i < lines.length; i++) {
      const parts = lines[i].split(/\s+/);
      if (parts.length >= 8) {
        const perms = parts[0];
        const isDir = perms.startsWith('d');
        const size = parseInt(parts[4], 10) || 0;
        const modified = `${parts[5]} ${parts[6]}`;
        const name = parts.slice(7).join(' ');

        if (name !== '.' && name !== '..') {
          items.push({
            name,
            path: cleanPath === '/' ? `/${name}` : `${cleanPath}/${name}`,
            is_directory: isDir,
            size_bytes: size,
            modified_at: modified,
            permissions: perms,
          });
        }
      }
    }

    res.json({ current_path: cleanPath, items });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'FILE_ERROR', message: err.message } });
  }
});

apiRouter.get('/vms/:id/files/content', requireAuth, authorizeVM('files'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  let filePath = '';
  try {
    filePath = validateSafeContainerPath(req.query.path as string);
  } catch (err: any) {
    res.status(403).json({ error: { code: 'PATH_TRAVERSAL_DETECTED', message: err.message } });
    return;
  }

  const provider = providerManager.getProvider(vm.provider);
  try {
    const result = await provider.execute(vm.provider_resource_id!, ['cat', '--', filePath]);
    if (result.exit_code !== 0) {
      res.status(404).json({ error: { code: 'FILE_NOT_FOUND', message: result.stderr || 'File not found' } });
      return;
    }
    res.json({ path: filePath, content: result.stdout });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'FILE_READ_FAILED', message: err.message } });
  }
});

apiRouter.put('/vms/:id/files/content', requireAuth, authorizeVM('files'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  const { path: rawPath, content } = req.body;
  if (!rawPath || typeof content !== 'string') {
    res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Path and content string required' } });
    return;
  }

  let filePath = '';
  try {
    filePath = validateSafeContainerPath(rawPath);
  } catch (err: any) {
    res.status(403).json({ error: { code: 'PATH_TRAVERSAL_DETECTED', message: err.message } });
    return;
  }

  const provider = providerManager.getProvider(vm.provider);
  try {
    // Write via base64 decode inside container passing path as $2 argument to prevent any shell injection
    const b64 = Buffer.from(content).toString('base64');
    const result = await provider.execute(vm.provider_resource_id!, [
      '/bin/sh',
      '-c',
      'echo "$1" | base64 -d > "$2"',
      '--',
      b64,
      filePath,
    ]);

    if (result.exit_code !== 0) {
      res.status(500).json({ error: { code: 'FILE_WRITE_FAILED', message: result.stderr } });
      return;
    }

    res.json({ success: true, path: filePath });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'FILE_WRITE_FAILED', message: err.message } });
  }
});

apiRouter.post('/vms/:id/files/mkdir', requireAuth, authorizeVM('files'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  const { path: rawPath } = req.body;
  if (!rawPath) {
    res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Directory path required' } });
    return;
  }

  let dirPath = '';
  try {
    dirPath = validateSafeContainerPath(rawPath);
  } catch (err: any) {
    res.status(403).json({ error: { code: 'PATH_TRAVERSAL_DETECTED', message: err.message } });
    return;
  }

  const provider = providerManager.getProvider(vm.provider);
  try {
    const result = await provider.execute(vm.provider_resource_id!, ['mkdir', '-p', '--', dirPath]);
    if (result.exit_code !== 0) {
      res.status(500).json({ error: { code: 'MKDIR_FAILED', message: result.stderr } });
      return;
    }
    res.json({ success: true, path: dirPath });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'MKDIR_FAILED', message: err.message } });
  }
});

apiRouter.delete('/vms/:id/files', requireAuth, authorizeVM('files'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  let targetPath = '';
  try {
    targetPath = validateSafeContainerPath(req.query.path as string);
  } catch (err: any) {
    res.status(403).json({ error: { code: 'PATH_TRAVERSAL_DETECTED', message: err.message } });
    return;
  }

  const PROTECTED_ROOTS = ['/', '/etc', '/bin', '/usr', '/sbin', '/lib', '/lib64', '/root', '/var'];
  if (PROTECTED_ROOTS.includes(targetPath)) {
    res.status(403).json({ error: { code: 'PROTECTED_PATH', message: 'Cannot delete root or essential system directories' } });
    return;
  }

  const provider = providerManager.getProvider(vm.provider);
  try {
    const result = await provider.execute(vm.provider_resource_id!, ['rm', '-rf', '--', targetPath]);
    if (result.exit_code !== 0) {
      res.status(500).json({ error: { code: 'DELETE_FAILED', message: result.stderr } });
      return;
    }
    res.json({ success: true, path: targetPath });
  } catch (err: any) {
    res.status(500).json({ error: { code: 'DELETE_FAILED', message: err.message } });
  }
});

// ==========================================
// 5. PORT ALLOCATION & IDOR DEFENSE
// ==========================================

apiRouter.get('/vms/:id/ports', requireAuth, authorizeVM('read'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  const ports = db.getActivePortAllocations().filter(p => p.vm_id === vm.id);
  res.json({ vm_id: vm.id, ports });
});

apiRouter.post('/vms/:id/ports', requireAuth, authorizeVM('control'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  const { purpose = 'custom', protocol = 'tcp' } = req.body;

  if (protocol !== 'tcp' && protocol !== 'udp') {
    res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Protocol must be tcp or udp' } });
    return;
  }

  try {
    const allocation = await PortAllocator.allocatePort(vm.id, purpose, protocol, req.user);
    res.status(201).json(allocation);
  } catch (err: any) {
    res.status(400).json({ error: { code: 'PORT_ALLOCATION_FAILED', message: err.message } });
  }
});

apiRouter.delete('/vms/:id/ports/:portId', requireAuth, authorizeVM('control'), async (req: AuthenticatedRequest, res: Response) => {
  const vm = db.getVMById(req.params.id)!;
  const port = db.getPortAllocationById(req.params.portId);

  if (!port || port.vm_id !== vm.id) {
    res.status(404).json({ error: { code: 'PORT_NOT_FOUND', message: 'Port allocation not found on this workload' } });
    return;
  }

  try {
    await PortAllocator.releasePort(port.id, req.user);
    res.json({ success: true, message: `Port ${port.host_port} released successfully` });
  } catch (err: any) {
    res.status(403).json({ error: { code: 'FORBIDDEN', message: err.message } });
  }
});

// ==========================================
// 5. JOBS
// ==========================================

apiRouter.get('/jobs', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const jobs = db.getAllJobs();
  const filtered = req.user!.role === 'admin'
    ? jobs
    : jobs.filter(j => j.requested_by === req.user!.id);
  res.json({ items: filtered });
});

apiRouter.get('/jobs/:id', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const job = db.getJobById(req.params.id);
  if (!job) {
    res.status(404).json({ error: { code: 'JOB_NOT_FOUND', message: 'Job not found' } });
    return;
  }
  if (req.user!.role !== 'admin' && job.requested_by !== req.user!.id) {
    res.status(403).json({ error: { code: 'FORBIDDEN', message: 'Access denied to this job' } });
    return;
  }
  res.json(job);
});

// ==========================================
// 6. API KEYS
// ==========================================

apiRouter.get('/api-keys', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const keys = db.getApiKeysByUser(req.user!.id);
  // Never expose key_hash
  const sanitized = keys.map(k => ({
    id: k.id,
    name: k.name,
    key_prefix: k.key_prefix,
    scopes: k.scopes,
    created_at: k.created_at,
    last_used_at: k.last_used_at,
    revoked_at: k.revoked_at,
  }));
  res.json({ items: sanitized });
});

apiRouter.post('/api-keys', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const { name, scopes = ['vm:read', 'vm:control'] } = req.body;
  if (!name) {
    res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Key name is required' } });
    return;
  }

  const { fullKey, keyPrefix, keyHash } = generateApiKey();
  const apiKeyRecord = {
    id: randomUUID(),
    user_id: req.user!.id,
    name,
    key_prefix: keyPrefix,
    key_hash: keyHash,
    scopes,
    created_at: new Date().toISOString(),
    last_used_at: null,
    revoked_at: null,
  };

  await db.createApiKey(apiKeyRecord);

  // Return the full secret ONLY ONCE
  res.status(201).json({
    id: apiKeyRecord.id,
    name: apiKeyRecord.name,
    api_key: fullKey,
    key_prefix: keyPrefix,
    scopes,
    created_at: apiKeyRecord.created_at,
    notice: 'Copy this API key now. It will NEVER be shown again.',
  });
});

apiRouter.post('/api-keys/:id/revoke', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const success = await db.revokeApiKey(req.params.id, req.user!.id);
  if (!success) {
    res.status(404).json({ error: { code: 'NOT_FOUND', message: 'API key not found' } });
    return;
  }
  res.json({ success: true });
});

// ==========================================
// 7. ADMIN SETTINGS & USERS
// ==========================================

apiRouter.get('/admin/settings', requireAuth, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  res.json({
    container_engine: db.getSetting('container_engine', 'docker'),
    branding: db.getSetting('branding', { name: 'VortexPanel', color: '#3b82f6' }),
    port_range: {
      start: CONFIG.PORT_RANGE_START,
      end: CONFIG.PORT_RANGE_END,
    },
  });
});

apiRouter.patch('/admin/settings', requireAuth, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const { container_engine, branding } = req.body;

  if (container_engine) {
    if (container_engine !== 'docker' && container_engine !== 'lxc') {
      res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Container engine must be docker or lxc' } });
      return;
    }
    await db.setSetting('container_engine', container_engine, req.user!.id);
  }

  if (branding) {
    await db.setSetting('branding', branding, req.user!.id);
  }

  res.json({ success: true, settings: db.getAllSettings() });
});

apiRouter.get('/admin/users', requireAuth, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const users = db.getAllUsers().map(u => ({
    id: u.id,
    email: u.email,
    role: u.role,
    status: u.status,
    created_at: u.created_at,
    last_login_at: u.last_login_at,
  }));
  res.json({ items: users });
});

apiRouter.post('/admin/users', requireAuth, requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
  const { email, password, role = 'user' } = req.body;
  if (!email || !password) {
    res.status(400).json({ error: { code: 'VALIDATION_ERROR', message: 'Email and password required' } });
    return;
  }

  const existing = db.getUserByEmail(email);
  if (existing) {
    res.status(409).json({ error: { code: 'CONFLICT', message: 'User with this email already exists' } });
    return;
  }

  const passwordHash = await hashPassword(password);
  const newUser = {
    id: randomUUID(),
    email,
    password_hash: passwordHash,
    role: role as any,
    status: 'active' as const,
    must_change_password: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    last_login_at: null,
  };

  await db.createUser(newUser);
  res.status(201).json({
    user: {
      id: newUser.id,
      email: newUser.email,
      role: newUser.role,
      status: newUser.status,
    },
  });
});

apiRouter.get('/activity-logs', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const filter: any = { limit: 100 };
  if (req.user!.role !== 'admin') {
    filter.actorId = req.user!.id;
  }
  const logs = db.getActivityLogs(filter);
  res.json({ items: logs });
});
