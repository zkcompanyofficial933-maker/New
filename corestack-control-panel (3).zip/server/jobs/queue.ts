import { randomUUID } from 'crypto';
import { db } from '../db/database.js';
import { Job, VM, VMStatus } from '../db/schema.js';
import { providerManager } from '../providers/manager.js';
import { PortAllocator } from '../networking/portAllocator.js';
import { validateHostCapacity } from '../resources/hostMetrics.js';
import { wsBroker } from '../websocket.js';

class JobQueue {
  private processing = false;
  private queue: string[] = [];

  constructor() {
    // Process queue periodically
    setInterval(() => this.tick(), 1000);
  }

  async enqueue(job: Omit<Job, 'id' | 'created_at' | 'started_at' | 'finished_at' | 'state' | 'attempt' | 'current_step'>): Promise<Job> {
    const fullJob: Job = {
      id: randomUUID(),
      created_at: new Date().toISOString(),
      started_at: null,
      finished_at: null,
      state: 'queued',
      attempt: 0,
      current_step: null,
      ...job,
    };

    await db.createJob(fullJob);
    this.queue.push(fullJob.id);
    this.tick();
    return fullJob;
  }

  private async tick(): Promise<void> {
    if (this.processing || this.queue.length === 0) return;
    this.processing = true;

    const jobId = this.queue.shift();
    if (!jobId) {
      this.processing = false;
      return;
    }

    try {
      const job = db.getJobById(jobId);
      if (job && (job.state === 'queued' || job.state === 'running')) {
        await this.executeJob(job);
      }
    } catch (err) {
      console.error(`[Worker] Unhandled error processing job ${jobId}:`, err);
    } finally {
      this.processing = false;
      if (this.queue.length > 0) {
        setImmediate(() => this.tick());
      }
    }
  }

  private async updateJobStep(job: Job, step: string): Promise<void> {
    job.current_step = step;
    await db.updateJob(job.id, { current_step: step, state: 'running' });
    wsBroker.broadcast('job.updated', {
      job_id: job.id,
      state: 'running',
      current_step: step,
      vm_id: job.vm_id,
    }, job.vm_id || undefined);
  }

  private async updateVMStatus(vmId: string, status: VMStatus, failure?: { code: string; message: string }): Promise<void> {
    const updates: Partial<VM> = { status };
    if (failure) {
      updates.failure_code = failure.code;
      updates.failure_message = failure.message;
    } else {
      updates.failure_code = null;
      updates.failure_message = null;
    }
    const updated = await db.updateVM(vmId, updates);
    if (updated) {
      wsBroker.broadcast('vm.status_changed', {
        vm_id: vmId,
        status,
        failure_code: failure?.code,
        failure_message: failure?.message,
      }, vmId);
    }
  }

  private async executeJob(job: Job): Promise<void> {
    await db.updateJob(job.id, { state: 'running', started_at: new Date().toISOString() });

    try {
      switch (job.type) {
        case 'vm.create':
          await this.handleVMCreate(job);
          break;
        case 'vm.start':
          await this.handleVMStart(job);
          break;
        case 'vm.stop':
          await this.handleVMStop(job);
          break;
        case 'vm.restart':
          await this.handleVMRestart(job);
          break;
        case 'vm.delete':
          await this.handleVMDelete(job);
          break;
        default:
          throw new Error(`Unknown job type: ${job.type}`);
      }

      await db.updateJob(job.id, {
        state: 'succeeded',
        finished_at: new Date().toISOString(),
      });
      wsBroker.broadcast('job.updated', {
        job_id: job.id,
        state: 'succeeded',
        vm_id: job.vm_id,
      }, job.vm_id || undefined);
    } catch (err: any) {
      console.error(`[Worker] Job ${job.id} failed:`, err);
      await db.updateJob(job.id, {
        state: 'failed',
        error_code: err.code || 'JOB_FAILED',
        error_message: err.message,
        finished_at: new Date().toISOString(),
      });
      wsBroker.broadcast('job.updated', {
        job_id: job.id,
        state: 'failed',
        error_message: err.message,
        vm_id: job.vm_id,
      }, job.vm_id || undefined);
    }
  }

  // --- Workload Provisioning Flow ---
  private async handleVMCreate(job: Job): Promise<void> {
    const vmId = job.vm_id!;
    const vm = db.getVMById(vmId);
    if (!vm) throw new Error(`Workload ${vmId} not found`);

    const resources = db.getVMResources(vmId);
    if (!resources) throw new Error(`Resources for ${vmId} not found`);

    const provider = providerManager.getProvider(vm.provider);
    let allocatedPortId: string | null = null;
    let providerResourceId: string | null = null;

    try {
      // 1. VALIDATING
      await this.updateJobStep(job, 'VALIDATING');
      await this.updateVMStatus(vmId, 'VALIDATING');

      // Check host capacity
      const capCheck = await validateHostCapacity(resources.cpu_cores, resources.memory_bytes);
      if (!capCheck.valid) {
        throw new Error(capCheck.reason || 'Host capacity validation failed');
      }

      // Check provider capabilities
      const hostVal = await provider.validate_host();
      if (!hostVal.valid) {
        throw new Error(hostVal.error || `${vm.provider.toUpperCase()} host engine is not available`);
      }

      // 2. CREATING
      await this.updateJobStep(job, 'CREATING');
      await this.updateVMStatus(vmId, 'CREATING');

      let hostPort: number | undefined;
      if (vm.ssh_enabled) {
        const portAlloc = await PortAllocator.allocatePort(vmId, 'ssh', 'tcp');
        allocatedPortId = portAlloc.id;
        hostPort = portAlloc.host_port;
        await db.updateVM(vmId, { ssh_host_port: hostPort });
      }

      const res = await provider.create({
        name: vm.name,
        image: vm.requested_os,
        cpu_cores: resources.cpu_cores,
        memory_bytes: resources.memory_bytes,
        disk_bytes: resources.disk_bytes,
        pids_limit: resources.pids_limit,
        hostname: vm.hostname || vm.name,
        username: vm.username,
        ssh_enabled: vm.ssh_enabled,
        ssh_host_port: hostPort,
        labels: { vm_id: vm.id, owner_id: vm.owner_id },
      });

      providerResourceId = res.resource_id;
      await db.updateVM(vmId, { provider_resource_id: providerResourceId });

      // 3. INSTALLING_OS
      await this.updateJobStep(job, 'INSTALLING_OS');
      await this.updateVMStatus(vmId, 'INSTALLING_OS');

      // 4. CONFIGURING
      await this.updateJobStep(job, 'CONFIGURING');
      await this.updateVMStatus(vmId, 'CONFIGURING');
      await provider.configure_resources(providerResourceId, {
        cpu_cores: resources.cpu_cores,
        memory_bytes: resources.memory_bytes,
        pids_limit: resources.pids_limit,
      });

      // 5. STARTING
      await this.updateJobStep(job, 'STARTING');
      await this.updateVMStatus(vmId, 'STARTING');
      await provider.start(providerResourceId);

      // 6. INSTALLING_SSH
      if (vm.ssh_enabled) {
        await this.updateJobStep(job, 'INSTALLING_SSH');
        await this.updateVMStatus(vmId, 'INSTALLING_SSH');

        // Execute user creation inside container if required
        const initialPassword = job.payload_json?.initial_password;
        if (initialPassword && vm.username !== 'root') {
          try {
            await provider.execute(providerResourceId, [
              'useradd',
              '-m',
              '-s',
              '/bin/bash',
              vm.username,
            ]);
            // Set password safely
            await provider.execute(providerResourceId, [
              'sh',
              '-c',
              `echo "${vm.username}:${initialPassword}" | chpasswd`,
            ]);
          } catch {
            // Container might already have user, ignore non-fatal
          }
        }

        if (allocatedPortId) {
          await PortAllocator.markActive(allocatedPortId);
        }
      }

      // 7. READY
      await this.updateJobStep(job, 'READY');
      const ips = await provider.get_ip(providerResourceId);
      const ipAddress = ips.length > 0 ? ips[0] : null;

      await db.updateVM(vmId, {
        status: 'READY',
        ip_address: ipAddress,
        failure_code: null,
        failure_message: null,
      });

      wsBroker.broadcast('vm.status_changed', {
        vm_id: vmId,
        status: 'READY',
        ip_address: ipAddress,
      }, vmId);

      await db.logActivity({
        actor_user_id: job.requested_by,
        vm_id: vmId,
        action: 'vm.create',
        outcome: 'succeeded',
        request_id: job.id,
        ip_hash: null,
        metadata_json: {
          name: vm.name,
          provider: vm.provider,
          os: vm.requested_os,
          ip_address: ipAddress,
          ssh_host_port: hostPort,
        },
      });
    } catch (err: any) {
      // Failure rollback
      console.error(`[Worker] Provisioning error for VM ${vmId}:`, err);
      await this.updateVMStatus(vmId, 'FAILED', {
        code: err.code || 'PROVISIONING_FAILED',
        message: err.message,
      });

      if (allocatedPortId) {
        await PortAllocator.releasePort(allocatedPortId);
      }

      if (providerResourceId) {
        try {
          await provider.delete(providerResourceId);
        } catch (cleanupErr) {
          console.warn(`[Worker] Cleanup warning for ${providerResourceId}:`, cleanupErr);
        }
      }

      await db.logActivity({
        actor_user_id: job.requested_by,
        vm_id: vmId,
        action: 'vm.create',
        outcome: 'failed',
        request_id: job.id,
        ip_hash: null,
        metadata_json: { error: err.message },
      });

      throw err;
    }
  }

  // --- Start Flow ---
  private async handleVMStart(job: Job): Promise<void> {
    const vm = db.getVMById(job.vm_id!);
    if (!vm || !vm.provider_resource_id) throw new Error('Workload or provider resource not found');

    await this.updateVMStatus(vm.id, 'STARTING');
    const provider = providerManager.getProvider(vm.provider);

    await provider.start(vm.provider_resource_id);
    const ips = await provider.get_ip(vm.provider_resource_id);

    await db.updateVM(vm.id, {
      status: 'READY',
      ip_address: ips[0] || vm.ip_address,
      failure_code: null,
      failure_message: null,
    });

    wsBroker.broadcast('vm.status_changed', { vm_id: vm.id, status: 'READY' }, vm.id);

    await db.logActivity({
      actor_user_id: job.requested_by,
      vm_id: vm.id,
      action: 'vm.start',
      outcome: 'succeeded',
      request_id: job.id,
      ip_hash: null,
      metadata_json: {},
    });
  }

  // --- Stop Flow ---
  private async handleVMStop(job: Job): Promise<void> {
    const vm = db.getVMById(job.vm_id!);
    if (!vm || !vm.provider_resource_id) throw new Error('Workload or provider resource not found');

    const provider = providerManager.getProvider(vm.provider);
    await provider.stop(vm.provider_resource_id);

    await db.updateVM(vm.id, {
      status: 'STOPPED',
      failure_code: null,
      failure_message: null,
    });

    wsBroker.broadcast('vm.status_changed', { vm_id: vm.id, status: 'STOPPED' }, vm.id);

    await db.logActivity({
      actor_user_id: job.requested_by,
      vm_id: vm.id,
      action: 'vm.stop',
      outcome: 'succeeded',
      request_id: job.id,
      ip_hash: null,
      metadata_json: {},
    });
  }

  // --- Restart Flow ---
  private async handleVMRestart(job: Job): Promise<void> {
    const vm = db.getVMById(job.vm_id!);
    if (!vm || !vm.provider_resource_id) throw new Error('Workload or provider resource not found');

    await this.updateVMStatus(vm.id, 'STARTING');
    const provider = providerManager.getProvider(vm.provider);

    await provider.restart(vm.provider_resource_id);
    const ips = await provider.get_ip(vm.provider_resource_id);

    await db.updateVM(vm.id, {
      status: 'READY',
      ip_address: ips[0] || vm.ip_address,
      failure_code: null,
      failure_message: null,
    });

    wsBroker.broadcast('vm.status_changed', { vm_id: vm.id, status: 'READY' }, vm.id);

    await db.logActivity({
      actor_user_id: job.requested_by,
      vm_id: vm.id,
      action: 'vm.restart',
      outcome: 'succeeded',
      request_id: job.id,
      ip_hash: null,
      metadata_json: {},
    });
  }

  // --- Delete Flow ---
  private async handleVMDelete(job: Job): Promise<void> {
    const vm = db.getVMById(job.vm_id!);
    if (!vm) throw new Error('Workload not found');

    await this.updateVMStatus(vm.id, 'DELETING');

    if (vm.provider_resource_id) {
      try {
        const provider = providerManager.getProvider(vm.provider);
        await provider.delete(vm.provider_resource_id);
      } catch (err: any) {
        console.warn(`[Worker] Notice during provider delete for ${vm.provider_resource_id}: ${err.message}`);
      }
    }

    // Release allocated ports
    await PortAllocator.releaseAllForVM(vm.id);

    // Soft delete in DB
    await db.softDeleteVM(vm.id);

    wsBroker.broadcast('vm.deleted', { vm_id: vm.id }, vm.id);

    await db.logActivity({
      actor_user_id: job.requested_by,
      vm_id: vm.id,
      action: 'vm.delete',
      outcome: 'succeeded',
      request_id: job.id,
      ip_hash: null,
      metadata_json: {},
    });
  }
}

export const jobQueue = new JobQueue();
