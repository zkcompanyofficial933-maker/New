import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const INSECURE_DEFAULT_SECRET = 'vortex-panel-secret-key-change-in-production-min32chars';
export const INSECURE_DEFAULT_ADMIN_PASSWORD = 'VortexAdmin2026!#';

export const CONFIG = {
  PORT: parseInt(process.env.PORT || '3000', 10),
  HOST: process.env.HOST || '0.0.0.0',
  ENV: process.env.NODE_ENV || 'development',
  DATA_DIR: process.env.DATA_DIR || path.join(__dirname, '../data'),
  
  // Security & Auth
  SESSION_SECRET: process.env.SESSION_SECRET || INSECURE_DEFAULT_SECRET,
  SESSION_TTL_HOURS: 24,
  PASSWORD_SALT_ROUNDS: 100000,
  
  // Infrastructure
  DEFAULT_CONTAINER_ENGINE: (process.env.CONTAINER_ENGINE as 'docker' | 'lxc') || 'docker',
  DOCKER_SOCKET: process.env.DOCKER_SOCKET || '/var/run/docker.sock',
  DOCKER_HOST: process.env.DOCKER_HOST || '',
  PORT_RANGE_START: parseInt(process.env.PORT_RANGE_START || '20000', 10),
  PORT_RANGE_END: parseInt(process.env.PORT_RANGE_END || '40000', 10),
  
  // Default Admin bootstrap credentials
  DEFAULT_ADMIN_EMAIL: process.env.DEFAULT_ADMIN_EMAIL || 'admin@vortex.local',
  DEFAULT_ADMIN_PASSWORD: process.env.DEFAULT_ADMIN_PASSWORD || '',
};

/**
 * Validates configuration against strict production security standards.
 * Refuses startup if default or weak secrets are detected in production mode.
 */
export function validateProductionConfig(config: typeof CONFIG = CONFIG): void {
  if (config.ENV === 'production') {
    const errors: string[] = [];

    if (!process.env.SESSION_SECRET || config.SESSION_SECRET === INSECURE_DEFAULT_SECRET) {
      errors.push('SESSION_SECRET must not use the hardcoded default fallback in production.');
    }

    if (config.SESSION_SECRET.length < 32) {
      errors.push(
        `SESSION_SECRET must meet the minimum strength threshold of 32 characters in production (provided length: ${config.SESSION_SECRET.length}).`
      );
    }

    if (!process.env.DEFAULT_ADMIN_PASSWORD || config.DEFAULT_ADMIN_PASSWORD === INSECURE_DEFAULT_ADMIN_PASSWORD) {
      errors.push('DEFAULT_ADMIN_PASSWORD must not match the hardcoded default in production.');
    }

    if (errors.length > 0) {
      console.error('================================================================');
      console.error('CRITICAL SECURITY VIOLATION - INSECURE PRODUCTION CONFIGURATION:');
      errors.forEach(err => console.error(` [FAIL] ${err}`));
      console.error('VortexPanel startup halted to protect host infrastructure.');
      console.error('================================================================');
      process.exit(1);
    }
  } else {
    // Log development security advisory if defaults are detected
    if (config.SESSION_SECRET === INSECURE_DEFAULT_SECRET) {
      console.warn('[SECURITY WARNING] Running with development fallback SESSION_SECRET. Set SESSION_SECRET in production.');
    }
    if (config.DEFAULT_ADMIN_PASSWORD === INSECURE_DEFAULT_ADMIN_PASSWORD) {
      console.warn('[SECURITY WARNING] Running with default development admin password. Override DEFAULT_ADMIN_PASSWORD in production.');
    }
  }
}

// Run validation immediately on module load
validateProductionConfig(CONFIG);

