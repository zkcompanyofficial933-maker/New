import { randomUUID, randomBytes } from 'crypto';
import os from 'os';
import { db } from './database.js';
import { hashPassword } from '../auth/crypto.js';
import { CONFIG } from '../config.js';
import { providerManager } from '../providers/manager.js';
import { getHostMetrics } from '../resources/hostMetrics.js';

export async function seedDatabase(): Promise<void> {
  // 1. Dynamic Admin User Initialization
  const allUsers = db.getAllUsers();
  const existingAdmin = allUsers.find(u => u.role === 'admin');

  if (!existingAdmin) {
    const adminEmail = CONFIG.DEFAULT_ADMIN_EMAIL;
    let initialPassword = CONFIG.DEFAULT_ADMIN_PASSWORD;
    let mustChangePassword = false;

    if (!initialPassword) {
      // Generate a cryptographically strong 32-character initial password
      initialPassword = randomBytes(16).toString('hex');
      mustChangePassword = true;
    }

    console.log(`[Seed] Initializing administrator account: ${adminEmail}`);
    const adminHash = await hashPassword(initialPassword);
    await db.createUser({
      id: randomUUID(),
      email: adminEmail,
      password_hash: adminHash,
      role: 'admin',
      status: 'active',
      must_change_password: mustChangePassword,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      last_login_at: null,
    });

    console.log('================================================================');
    console.log('INITIAL ADMINISTRATIVE CREDENTIALS PROVISIONED (Printed strictly once):');
    console.log(`  Email:    ${adminEmail}`);
    console.log(`  Password: ${initialPassword}`);
    if (mustChangePassword) {
      console.log('  Security Flag: must_change_password is TRUE. Password must be changed upon first login.');
    }
    console.log('================================================================');
  }

  // 2. Discover and register Local Node
  const docker = providerManager.getDocker();
  const lxc = providerManager.getLXC();

  const [dockerCaps, lxcCaps, hostMetrics] = await Promise.all([
    docker.capabilities(),
    lxc.capabilities(),
    getHostMetrics(),
  ]);

  const existingNode = db.getLocalNode();
  const nodeId = existingNode?.id || `node-${randomUUID().substring(0, 8)}`;

  await db.upsertLocalNode({
    id: nodeId,
    name: 'Primary-Node',
    hostname: os.hostname(),
    status: dockerCaps.available || lxcCaps.available ? 'online' : 'degraded',
    engine_capabilities: {
      docker_available: dockerCaps.available,
      docker_version: dockerCaps.version,
      docker_error: dockerCaps.error,
      lxc_available: lxcCaps.available,
      lxc_version: lxcCaps.version,
      lxc_error: lxcCaps.error,
      cgroups_v2: true,
      kvm_virtualization: false,
    },
    cpu_total: hostMetrics.cpu.cores,
    memory_total_bytes: hostMetrics.memory.total_bytes,
    disk_total_bytes: hostMetrics.disk.total_bytes,
    last_heartbeat_at: new Date().toISOString(),
    created_at: existingNode?.created_at || new Date().toISOString(),
    updated_at: new Date().toISOString(),
  });

  // 3. Default Settings
  if (!db.getSetting('container_engine', null)) {
    await db.setSetting('container_engine', CONFIG.DEFAULT_CONTAINER_ENGINE);
  }
  if (!db.getSetting('branding', null)) {
    await db.setSetting('branding', { name: 'VortexPanel', color: '#2563eb' });
  }

  console.log(`[Seed] Node & settings verified. Docker available: ${dockerCaps.available}, LXC available: ${lxcCaps.available}`);
}
