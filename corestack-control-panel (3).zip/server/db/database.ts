import fs from 'fs';
import path from 'path';
import { randomUUID } from 'crypto';
import { CONFIG } from '../config.js';
import { timingSafeStringEqual } from '../auth/crypto.js';
import {
  User,
  Session,
  ApiKey,
  LocalNode,
  Setting,
  VM,
  VMResource,
  VMNetwork,
  PortAllocation,
  PortState,
  Job,
  ActivityLog,
  MonitoringSample,
} from './schema.js';

interface DatabaseData {
  users: User[];
  sessions: Session[];
  api_keys: ApiKey[];
  local_nodes: LocalNode[];
  settings: Setting[];
  vms: VM[];
  vm_resources: VMResource[];
  vm_networks: VMNetwork[];
  port_allocations: PortAllocation[];
  jobs: Job[];
  activity_logs: ActivityLog[];
}

/**
 * Case-insensitive sensitive key pattern matcher for recursive activity log sanitization.
 */
const SENSITIVE_KEY_PATTERN = /password|token|secret|authorization|private_key|ssh_key|session|cookie|credentials|api_key|apikey|auth_header/i;

/**
 * Recursively sanitizes object payloads to redact credentials, tokens, and private keys.
 */
export function sanitizeMetadata(data: any, seen = new WeakSet()): any {
  if (data === null || data === undefined) {
    return data;
  }

  if (typeof data !== 'object') {
    if (typeof data === 'string') {
      if (data.startsWith('Bearer ') || data.startsWith('vp_live_')) {
        return '[REDACTED]';
      }
    }
    return data;
  }

  // Prevent infinite loops on circular references
  if (seen.has(data)) {
    return '[CIRCULAR]';
  }
  seen.add(data);

  if (Array.isArray(data)) {
    return data.map(item => sanitizeMetadata(item, seen));
  }

  const sanitized: Record<string, any> = {};
  for (const [key, value] of Object.entries(data)) {
    if (SENSITIVE_KEY_PATTERN.test(key)) {
      if (typeof value === 'object' && value !== null) {
        // Recursively inspect and redact inside sensitive container objects
        sanitized[key] = sanitizeMetadata(value, seen);
      } else {
        sanitized[key] = '[REDACTED]';
      }
    } else {
      sanitized[key] = sanitizeMetadata(value, seen);
    }
  }

  return sanitized;
}

export class Database {
  private filePath: string;
  private metricsFilePath: string;
  private data: DatabaseData;

  // In-memory constant-time / O(1) indexed lookups
  private sessionIndexByTokenHash: Map<string, Session> = new Map();
  private apiKeyIndexByHash: Map<string, ApiKey> = new Map();
  private userIndexById: Map<string, User> = new Map();
  private userIndexByEmail: Map<string, User> = new Map();
  private vmIndexById: Map<string, VM> = new Map();
  private vmIndexByResourceId: Map<string, VM> = new Map();

  // In-memory decoupled telemetry ring-buffer (eliminates write amplification on metrics)
  private monitoringSamplesByVM: Map<string, MonitoringSample[]> = new Map();
  private allMonitoringSamples: MonitoringSample[] = [];

  // Write serialization & debouncing
  private writeLock: Promise<void> = Promise.resolve();
  private metricsWriteLock: Promise<void> = Promise.resolve();
  private metricsFlushTimer: NodeJS.Timeout | null = null;
  private coreDbDirty = false;

  constructor() {
    if (!fs.existsSync(CONFIG.DATA_DIR)) {
      fs.mkdirSync(CONFIG.DATA_DIR, { recursive: true });
    }
    this.filePath = path.join(CONFIG.DATA_DIR, 'vortex.db.json');
    this.metricsFilePath = path.join(CONFIG.DATA_DIR, 'vortex.metrics.json');
    this.data = this.load();
    this.loadMetrics();
    this.rebuildIndexes();

    // Register process exit flush handler
    process.on('beforeExit', () => {
      this.flushSync();
    });
  }

  private load(): DatabaseData {
    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, 'utf-8');
        const parsed = JSON.parse(raw);
        return {
          users: parsed.users || [],
          sessions: parsed.sessions || [],
          api_keys: parsed.api_keys || [],
          local_nodes: parsed.local_nodes || [],
          settings: parsed.settings || [],
          vms: parsed.vms || [],
          vm_resources: parsed.vm_resources || [],
          vm_networks: parsed.vm_networks || [],
          port_allocations: parsed.port_allocations || [],
          jobs: parsed.jobs || [],
          activity_logs: parsed.activity_logs || [],
        };
      }
    } catch (err) {
      console.error('[DB] Failed to load database file, initializing fresh:', err);
    }

    return {
      users: [],
      sessions: [],
      api_keys: [],
      local_nodes: [],
      settings: [],
      vms: [],
      vm_resources: [],
      vm_networks: [],
      port_allocations: [],
      jobs: [],
      activity_logs: [],
    };
  }

  private loadMetrics(): void {
    try {
      if (fs.existsSync(this.metricsFilePath)) {
        const raw = fs.readFileSync(this.metricsFilePath, 'utf-8');
        const samples: MonitoringSample[] = JSON.parse(raw);
        if (Array.isArray(samples)) {
          this.allMonitoringSamples = samples.slice(-5000);
          for (const s of this.allMonitoringSamples) {
            if (!this.monitoringSamplesByVM.has(s.vm_id)) {
              this.monitoringSamplesByVM.set(s.vm_id, []);
            }
            this.monitoringSamplesByVM.get(s.vm_id)!.push(s);
          }
        }
      }
    } catch {
      this.allMonitoringSamples = [];
    }
  }

  /**
   * Rebuilds fast in-memory lookup indexes for O(1) query performance
   */
  private rebuildIndexes(): void {
    this.sessionIndexByTokenHash.clear();
    for (const s of this.data.sessions) {
      if (!s.revoked_at) {
        this.sessionIndexByTokenHash.set(s.token_hash, s);
      }
    }

    this.apiKeyIndexByHash.clear();
    for (const k of this.data.api_keys) {
      if (!k.revoked_at) {
        this.apiKeyIndexByHash.set(k.key_hash, k);
      }
    }

    this.userIndexById.clear();
    this.userIndexByEmail.clear();
    for (const u of this.data.users) {
      this.userIndexById.set(u.id, u);
      this.userIndexByEmail.set(u.email.toLowerCase(), u);
    }

    this.vmIndexById.clear();
    this.vmIndexByResourceId.clear();
    for (const v of this.data.vms) {
      if (!v.deleted_at) {
        this.vmIndexById.set(v.id, v);
        if (v.provider_resource_id) {
          this.vmIndexByResourceId.set(v.provider_resource_id, v);
        }
      }
    }
  }

  /**
   * Atomic file persistence with temporary file write and atomic rename
   */
  private async persist(): Promise<void> {
    this.writeLock = this.writeLock.then(async () => {
      const tempPath = `${this.filePath}.${randomUUID()}.tmp`;
      const serialized = JSON.stringify(this.data, null, 2);
      await fs.promises.writeFile(tempPath, serialized, 'utf-8');
      await fs.promises.rename(tempPath, this.filePath);
      this.coreDbDirty = false;
    });
    return this.writeLock;
  }

  /**
   * Flushes any pending memory data to disk synchronously upon shutdown
   */
  public flushSync(): void {
    try {
      if (this.coreDbDirty) {
        const tempPath = `${this.filePath}.${randomUUID()}.tmp`;
        fs.writeFileSync(tempPath, JSON.stringify(this.data, null, 2), 'utf-8');
        fs.renameSync(tempPath, this.filePath);
        this.coreDbDirty = false;
      }
      if (this.allMonitoringSamples.length > 0) {
        const tempMetrics = `${this.metricsFilePath}.${randomUUID()}.tmp`;
        fs.writeFileSync(tempMetrics, JSON.stringify(this.allMonitoringSamples.slice(-2000)), 'utf-8');
        fs.renameSync(tempMetrics, this.metricsFilePath);
      }
    } catch (err) {
      console.error('[DB] Synchronous flush error on shutdown:', err);
    }
  }

  // --- Users ---
  getUserById(id: string): User | undefined {
    return this.userIndexById.get(id);
  }

  getUserByEmail(email: string): User | undefined {
    return this.userIndexByEmail.get(email.toLowerCase());
  }

  getAllUsers(): User[] {
    return [...this.data.users];
  }

  async createUser(user: User): Promise<User> {
    this.data.users.push(user);
    this.userIndexById.set(user.id, user);
    this.userIndexByEmail.set(user.email.toLowerCase(), user);
    await this.persist();
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const idx = this.data.users.findIndex(u => u.id === id);
    if (idx === -1) return undefined;
    this.data.users[idx] = { ...this.data.users[idx], ...updates, updated_at: new Date().toISOString() };
    const updated = this.data.users[idx];
    this.userIndexById.set(updated.id, updated);
    this.userIndexByEmail.set(updated.email.toLowerCase(), updated);
    await this.persist();
    return updated;
  }

  // --- Sessions ---
  async createSession(session: Session): Promise<Session> {
    this.data.sessions.push(session);
    this.sessionIndexByTokenHash.set(session.token_hash, session);
    await this.persist();
    return session;
  }

  /**
   * Constant-time session hash verification against indexed map
   */
  getSessionByTokenHash(tokenHash: string): Session | undefined {
    const candidate = this.sessionIndexByTokenHash.get(tokenHash);
    if (!candidate || candidate.revoked_at) {
      return undefined;
    }

    // Verify token hash equality in constant time to prevent side-channel timing leaks
    if (!timingSafeStringEqual(candidate.token_hash, tokenHash)) {
      return undefined;
    }

    return candidate;
  }

  async revokeSession(id: string): Promise<void> {
    const s = this.data.sessions.find(x => x.id === id);
    if (s) {
      s.revoked_at = new Date().toISOString();
      this.sessionIndexByTokenHash.delete(s.token_hash);
      await this.persist();
    }
  }

  async revokeAllUserSessions(userId: string): Promise<void> {
    const now = new Date().toISOString();
    for (const s of this.data.sessions) {
      if (s.user_id === userId && !s.revoked_at) {
        s.revoked_at = now;
        this.sessionIndexByTokenHash.delete(s.token_hash);
      }
    }
    await this.persist();
  }

  // --- API Keys ---
  async createApiKey(key: ApiKey): Promise<ApiKey> {
    this.data.api_keys.push(key);
    this.apiKeyIndexByHash.set(key.key_hash, key);
    await this.persist();
    return key;
  }

  /**
   * Constant-time API key hash verification against indexed map
   */
  getApiKeyByHash(hash: string): ApiKey | undefined {
    const candidate = this.apiKeyIndexByHash.get(hash);
    if (!candidate || candidate.revoked_at) {
      return undefined;
    }

    // Constant-time comparison
    if (!timingSafeStringEqual(candidate.key_hash, hash)) {
      return undefined;
    }

    return candidate;
  }

  getApiKeysByUser(userId: string): ApiKey[] {
    return this.data.api_keys.filter(k => k.user_id === userId);
  }

  async revokeApiKey(id: string, userId: string): Promise<boolean> {
    const k = this.data.api_keys.find(x => x.id === id && x.user_id === userId);
    if (k) {
      k.revoked_at = new Date().toISOString();
      this.apiKeyIndexByHash.delete(k.key_hash);
      await this.persist();
      return true;
    }
    return false;
  }

  async touchApiKey(id: string): Promise<void> {
    const k = this.data.api_keys.find(x => x.id === id);
    if (k) {
      k.last_used_at = new Date().toISOString();
      await this.persist();
    }
  }

  // --- Local Node ---
  getLocalNode(): LocalNode | undefined {
    return this.data.local_nodes[0];
  }

  async upsertLocalNode(node: LocalNode): Promise<LocalNode> {
    const idx = this.data.local_nodes.findIndex(n => n.id === node.id || n.name === node.name);
    if (idx >= 0) {
      this.data.local_nodes[idx] = { ...this.data.local_nodes[idx], ...node, updated_at: new Date().toISOString() };
    } else {
      this.data.local_nodes.push(node);
    }
    await this.persist();
    return this.data.local_nodes[0];
  }

  // --- Settings ---
  getSetting<T>(key: string, defaultValue: T): T {
    const s = this.data.settings.find(x => x.key === key);
    return s ? (s.value_json as T) : defaultValue;
  }

  getAllSettings(): Record<string, any> {
    const res: Record<string, any> = {};
    for (const s of this.data.settings) {
      res[s.key] = s.value_json;
    }
    return res;
  }

  async setSetting(key: string, value: any, updatedBy: string | null = null): Promise<Setting> {
    let s = this.data.settings.find(x => x.key === key);
    const now = new Date().toISOString();
    if (s) {
      s.value_json = value;
      s.updated_by = updatedBy;
      s.updated_at = now;
    } else {
      s = {
        id: randomUUID(),
        key,
        value_json: value,
        updated_by: updatedBy,
        updated_at: now,
      };
      this.data.settings.push(s);
    }
    await this.persist();
    return s;
  }

  // --- VMs ---
  getVMById(id: string): VM | undefined {
    const cached = this.vmIndexById.get(id);
    if (cached && !cached.deleted_at) return cached;
    return this.data.vms.find(v => v.id === id && !v.deleted_at);
  }

  getVMByIdIncludeDeleted(id: string): VM | undefined {
    return this.data.vms.find(v => v.id === id);
  }

  getVMBySlug(slug: string): VM | undefined {
    return this.data.vms.find(v => v.slug === slug && !v.deleted_at);
  }

  getVMByProviderResourceId(resId: string): VM | undefined {
    const cached = this.vmIndexByResourceId.get(resId);
    if (cached && !cached.deleted_at) return cached;
    return this.data.vms.find(v => v.provider_resource_id === resId && !v.deleted_at);
  }

  getAllVMs(ownerId?: string): VM[] {
    return this.data.vms.filter(v => !v.deleted_at && (!ownerId || v.owner_id === ownerId));
  }

  async createVM(vm: VM, resources: VMResource): Promise<VM> {
    this.data.vms.push(vm);
    this.data.vm_resources.push(resources);
    this.vmIndexById.set(vm.id, vm);
    if (vm.provider_resource_id) {
      this.vmIndexByResourceId.set(vm.provider_resource_id, vm);
    }
    await this.persist();
    return vm;
  }

  async updateVM(id: string, updates: Partial<VM>): Promise<VM | undefined> {
    const idx = this.data.vms.findIndex(v => v.id === id);
    if (idx === -1) return undefined;
    const current = this.data.vms[idx];
    const statusChanged = updates.status && updates.status !== current.status;
    const newVersion = statusChanged ? current.status_version + 1 : current.status_version;

    this.data.vms[idx] = {
      ...current,
      ...updates,
      status_version: newVersion,
      updated_at: new Date().toISOString(),
    };

    const updated = this.data.vms[idx];
    this.vmIndexById.set(updated.id, updated);
    if (updated.provider_resource_id) {
      this.vmIndexByResourceId.set(updated.provider_resource_id, updated);
    }

    await this.persist();
    return updated;
  }

  async softDeleteVM(id: string): Promise<boolean> {
    const v = this.data.vms.find(x => x.id === id);
    if (v) {
      v.deleted_at = new Date().toISOString();
      v.updated_at = new Date().toISOString();
      this.vmIndexById.delete(id);
      if (v.provider_resource_id) {
        this.vmIndexByResourceId.delete(v.provider_resource_id);
      }
      await this.persist();
      return true;
    }
    return false;
  }

  getVMResources(vmId: string): VMResource | undefined {
    return this.data.vm_resources.find(r => r.vm_id === vmId);
  }

  async updateVMResources(vmId: string, updates: Partial<VMResource>): Promise<VMResource | undefined> {
    const idx = this.data.vm_resources.findIndex(r => r.vm_id === vmId);
    if (idx === -1) return undefined;
    this.data.vm_resources[idx] = {
      ...this.data.vm_resources[idx],
      ...updates,
      updated_at: new Date().toISOString(),
    };
    await this.persist();
    return this.data.vm_resources[idx];
  }

  // --- Port Allocations ---
  getPortAllocations(): PortAllocation[] {
    return [...this.data.port_allocations];
  }

  getActivePortAllocations(): PortAllocation[] {
    return this.data.port_allocations.filter(p => p.state !== 'released');
  }

  getPortAllocationById(id: string): PortAllocation | undefined {
    return this.data.port_allocations.find(p => p.id === id);
  }

  getPortAllocationByPort(protocol: 'tcp' | 'udp', hostPort: number): PortAllocation | undefined {
    return this.data.port_allocations.find(
      p => p.protocol === protocol && p.host_port === hostPort && p.state !== 'released'
    );
  }

  async createPortAllocation(allocation: PortAllocation, requestingUser?: User): Promise<PortAllocation> {
    // Enforce port boundary: prohibit binding to privileged/system ports (< 1024)
    if (allocation.host_port < 1024 || allocation.host_port > 65535) {
      throw new Error(`[INVALID_PORT_RANGE] Port ${allocation.host_port} is outside valid unprivileged port boundaries (1024-65535)`);
    }

    // Enforce ownership: non-admin users cannot allocate ports to workloads they do not own
    if (requestingUser && requestingUser.role !== 'admin') {
      const vm = this.getVMById(allocation.vm_id);
      if (!vm || vm.owner_id !== requestingUser.id) {
        throw new Error(`[FORBIDDEN] Cannot allocate port for unowned workload ${allocation.vm_id}`);
      }
    }

    this.data.port_allocations.push(allocation);
    await this.persist();
    return allocation;
  }

  async updatePortAllocationState(id: string, state: PortState, requestingUser?: User): Promise<void> {
    const p = this.data.port_allocations.find(x => x.id === id);
    if (!p) {
      throw new Error(`[PORT_NOT_FOUND] Port allocation ${id} not found`);
    }

    // Enforce ownership: non-admin users cannot modify port allocations for unowned workloads
    if (requestingUser && requestingUser.role !== 'admin') {
      const vm = this.getVMById(p.vm_id);
      if (!vm || vm.owner_id !== requestingUser.id) {
        throw new Error(`[FORBIDDEN] Cannot modify port allocation for unowned workload`);
      }
    }

    p.state = state;
    if (state === 'released') {
      p.released_at = new Date().toISOString();
    }
    await this.persist();
  }

  async releaseVMPorts(vmId: string): Promise<void> {
    const now = new Date().toISOString();
    for (const p of this.data.port_allocations) {
      if (p.vm_id === vmId && p.state !== 'released') {
        p.state = 'released';
        p.released_at = now;
      }
    }
    await this.persist();
  }

  // --- Jobs ---
  getJobById(id: string): Job | undefined {
    return this.data.jobs.find(j => j.id === id);
  }

  getJobByIdempotencyKey(key: string): Job | undefined {
    return this.data.jobs.find(j => j.idempotency_key === key);
  }

  getJobsByVM(vmId: string): Job[] {
    return this.data.jobs.filter(j => j.vm_id === vmId);
  }

  getAllJobs(): Job[] {
    return [...this.data.jobs].reverse();
  }

  async createJob(job: Job): Promise<Job> {
    this.data.jobs.push(job);
    await this.persist();
    return job;
  }

  async updateJob(id: string, updates: Partial<Job>): Promise<Job | undefined> {
    const idx = this.data.jobs.findIndex(j => j.id === id);
    if (idx === -1) return undefined;
    this.data.jobs[idx] = { ...this.data.jobs[idx], ...updates };
    await this.persist();
    return this.data.jobs[idx];
  }

  // --- Activity Logs ---
  async logActivity(entry: Omit<ActivityLog, 'id' | 'created_at'>): Promise<ActivityLog> {
    // Recursively sanitize metadata to redact sensitive values before persistence
    const sanitizedMetadata = sanitizeMetadata(entry.metadata_json);

    const log: ActivityLog = {
      id: randomUUID(),
      created_at: new Date().toISOString(),
      ...entry,
      metadata_json: sanitizedMetadata,
    };

    this.data.activity_logs.push(log);

    // Keep at most 1,000 logs in memory/disk
    if (this.data.activity_logs.length > 1000) {
      this.data.activity_logs.splice(0, this.data.activity_logs.length - 1000);
    }

    await this.persist();
    return log;
  }

  getActivityLogs(filter?: { vmId?: string; actorId?: string; limit?: number }): ActivityLog[] {
    let logs = [...this.data.activity_logs];
    if (filter?.vmId) {
      logs = logs.filter(l => l.vm_id === filter.vmId);
    }
    if (filter?.actorId) {
      logs = logs.filter(l => l.actor_user_id === filter.actorId);
    }
    logs.reverse();
    if (filter?.limit) {
      logs = logs.slice(0, filter.limit);
    }
    return logs;
  }

  // --- Monitoring Samples (Decoupled Telemetry Ring Buffer) ---

  /**
   * Adds telemetry metric sample to in-memory ring-buffer.
   * Debounces asynchronous disk persistence to prevent write amplification.
   */
  async addMonitoringSample(sample: Omit<MonitoringSample, 'id'>): Promise<void> {
    const fullSample: MonitoringSample = {
      id: randomUUID(),
      ...sample,
    };

    // Update in-memory VM ring-buffer
    if (!this.monitoringSamplesByVM.has(sample.vm_id)) {
      this.monitoringSamplesByVM.set(sample.vm_id, []);
    }
    const vmBuffer = this.monitoringSamplesByVM.get(sample.vm_id)!;
    vmBuffer.push(fullSample);
    if (vmBuffer.length > 100) {
      vmBuffer.splice(0, vmBuffer.length - 100);
    }

    // Update global collection
    this.allMonitoringSamples.push(fullSample);
    if (this.allMonitoringSamples.length > 5000) {
      this.allMonitoringSamples.splice(0, this.allMonitoringSamples.length - 5000);
    }

    // Schedule debounced batch write to avoid disk thrashing and event-loop stalls
    if (!this.metricsFlushTimer) {
      this.metricsFlushTimer = setTimeout(() => {
        this.metricsFlushTimer = null;
        this.flushMetricsToDisk().catch(err => {
          console.error('[DB] Telemetry batch flush error:', err);
        });
      }, 5000);
      if (typeof this.metricsFlushTimer.unref === 'function') {
        this.metricsFlushTimer.unref();
      }
    }
  }

  private async flushMetricsToDisk(): Promise<void> {
    this.metricsWriteLock = this.metricsWriteLock.then(async () => {
      const tempPath = `${this.metricsFilePath}.${randomUUID()}.tmp`;
      const serialized = JSON.stringify(this.allMonitoringSamples.slice(-2000));
      await fs.promises.writeFile(tempPath, serialized, 'utf-8');
      await fs.promises.rename(tempPath, this.metricsFilePath);
    });
    return this.metricsWriteLock;
  }

  getLatestMonitoringSample(vmId: string): MonitoringSample | undefined {
    const buffer = this.monitoringSamplesByVM.get(vmId);
    if (buffer && buffer.length > 0) {
      return buffer[buffer.length - 1];
    }
    return undefined;
  }

  getMonitoringHistory(vmId: string, limit = 50): MonitoringSample[] {
    const buffer = this.monitoringSamplesByVM.get(vmId);
    if (buffer) {
      return buffer.slice(-limit);
    }
    return [];
  }
}

export const db = new Database();
