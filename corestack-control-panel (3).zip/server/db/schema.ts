export type UserRole = 'admin' | 'user';
export type UserStatus = 'active' | 'disabled' | 'pending';
export type ContainerEngine = 'docker' | 'lxc';

export type VMStatus =
  | 'PENDING'
  | 'VALIDATING'
  | 'CREATING'
  | 'INSTALLING_OS'
  | 'CONFIGURING'
  | 'STARTING'
  | 'INSTALLING_SSH'
  | 'INSTALLING_TMATE'
  | 'READY'
  | 'STOPPED'
  | 'FAILED'
  | 'DELETING';

export type JobState = 'queued' | 'running' | 'succeeded' | 'failed' | 'cancelled';
export type PortState = 'reserved' | 'active' | 'released';
export type ActionOutcome = 'started' | 'succeeded' | 'failed' | 'denied';

export interface User {
  id: string;
  email: string;
  password_hash: string;
  role: UserRole;
  status: UserStatus;
  must_change_password: boolean;
  created_at: string;
  updated_at: string;
  last_login_at: string | null;
}

export interface Session {
  id: string;
  user_id: string;
  token_hash: string;
  expires_at: string;
  created_at: string;
  revoked_at: string | null;
  ip_hash: string | null;
  user_agent_hash: string | null;
}

export interface ApiKey {
  id: string;
  user_id: string;
  name: string;
  key_prefix: string;
  key_hash: string;
  scopes: string[];
  created_at: string;
  last_used_at: string | null;
  revoked_at: string | null;
}

export interface LocalNode {
  id: string;
  name: string;
  hostname: string;
  status: 'online' | 'degraded' | 'offline' | 'unknown';
  engine_capabilities: {
    docker_available: boolean;
    docker_version?: string;
    docker_error?: string;
    lxc_available: boolean;
    lxc_version?: string;
    lxc_error?: string;
    cgroups_v2: boolean;
    kvm_virtualization: boolean;
  };
  cpu_total: number;
  memory_total_bytes: number;
  disk_total_bytes: number;
  last_heartbeat_at: string;
  created_at: string;
  updated_at: string;
}

export interface Setting {
  id: string;
  key: string;
  value_json: any;
  updated_by: string | null;
  updated_at: string;
}

export interface VM {
  id: string;
  owner_id: string;
  local_node_id: string;
  name: string;
  slug: string;
  requested_os: 'ubuntu:20.04' | 'ubuntu:22.04' | 'debian:11' | 'debian:12';
  provider: ContainerEngine;
  provider_resource_id: string | null;
  status: VMStatus;
  status_version: number;
  failure_code: string | null;
  failure_message: string | null;
  hostname: string | null;
  username: string;
  ssh_enabled: boolean;
  ssh_host_port: number | null;
  ip_address: string | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
}

export interface VMResource {
  vm_id: string;
  cpu_cores: number;
  memory_bytes: number;
  disk_bytes: number;
  pids_limit: number;
  created_at: string;
  updated_at: string;
}

export interface VMNetwork {
  id: string;
  vm_id: string;
  network_name: string;
  ipv4_address: string | null;
  ipv6_address: string | null;
  interface_name: string | null;
  created_at: string;
}

export interface PortAllocation {
  id: string;
  vm_id: string;
  protocol: 'tcp' | 'udp';
  host_port: number;
  container_port: number;
  purpose: string;
  state: PortState;
  created_at: string;
  released_at: string | null;
}

export interface Job {
  id: string;
  type: string;
  vm_id: string | null;
  requested_by: string | null;
  state: JobState;
  idempotency_key: string | null;
  current_step: string | null;
  attempt: number;
  error_code: string | null;
  error_message: string | null;
  payload_json: any;
  result_json: any;
  created_at: string;
  started_at: string | null;
  finished_at: string | null;
}

export interface ActivityLog {
  id: string;
  actor_user_id: string | null;
  vm_id: string | null;
  action: string;
  outcome: ActionOutcome;
  request_id: string;
  ip_hash: string | null;
  metadata_json: any;
  created_at: string;
}

export interface MonitoringSample {
  id: string;
  vm_id: string;
  sampled_at: string;
  cpu_usage_percent: number | null;
  memory_used_bytes: number | null;
  memory_limit_bytes: number | null;
  disk_used_bytes: number | null;
  disk_limit_bytes: number | null;
  net_rx_bytes: number | null;
  net_tx_bytes: number | null;
  pids: number | null;
}
