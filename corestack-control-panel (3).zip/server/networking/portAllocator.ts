import net from 'net';
import { randomUUID } from 'crypto';
import { db } from '../db/database.js';
import { CONFIG } from '../config.js';
import { PortAllocation, User } from '../db/schema.js';

export class PortAllocator {
  private static allocationLock: Promise<void> = Promise.resolve();

  /**
   * Tests if a host port is actually bindable on 0.0.0.0
   */
  static isPortFreeOnHost(port: number): Promise<boolean> {
    return new Promise((resolve) => {
      const server = net.createServer();
      server.once('error', () => {
        resolve(false);
      });
      server.once('listening', () => {
        server.close(() => resolve(true));
      });
      server.listen(port, '0.0.0.0');
    });
  }

  /**
   * Atomically allocates an available port from the configured range
   */
  static async allocatePort(
    vmId: string,
    purpose: string = 'ssh',
    protocol: 'tcp' | 'udp' = 'tcp',
    requestingUser?: User
  ): Promise<PortAllocation> {
    return new Promise((resolve, reject) => {
      this.allocationLock = this.allocationLock.then(async () => {
        try {
          const activeAllocations = db.getActivePortAllocations();
          const usedPorts = new Set(
            activeAllocations
              .filter(p => p.protocol === protocol)
              .map(p => p.host_port)
          );

          const start = Math.max(1024, CONFIG.PORT_RANGE_START);
          const end = Math.min(65535, CONFIG.PORT_RANGE_END);

          let chosenPort: number | null = null;

          for (let port = start; port <= end; port++) {
            if (!usedPorts.has(port)) {
              // Check if free on host
              const isFree = await this.isPortFreeOnHost(port);
              if (isFree) {
                chosenPort = port;
                break;
              }
            }
          }

          if (!chosenPort) {
            throw new Error(`[PORT_EXHAUSTED] No free ports available in range ${start}-${end}`);
          }

          const allocation: PortAllocation = {
            id: randomUUID(),
            vm_id: vmId,
            protocol,
            host_port: chosenPort,
            container_port: 22,
            purpose,
            state: 'reserved',
            created_at: new Date().toISOString(),
            released_at: null,
          };

          await db.createPortAllocation(allocation, requestingUser);
          resolve(allocation);
        } catch (err) {
          reject(err);
        }
      });
    });
  }

  static async markActive(allocationId: string, requestingUser?: User): Promise<void> {
    await db.updatePortAllocationState(allocationId, 'active', requestingUser);
  }

  static async releasePort(allocationId: string, requestingUser?: User): Promise<void> {
    await db.updatePortAllocationState(allocationId, 'released', requestingUser);
  }

  static async releaseAllForVM(vmId: string): Promise<void> {
    await db.releaseVMPorts(vmId);
  }
}

