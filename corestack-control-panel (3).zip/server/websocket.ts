import { WebSocketServer, WebSocket } from 'ws';
import { Server, IncomingMessage } from 'http';
import { db } from './db/database.js';
import { hashToken } from './auth/crypto.js';
import { User } from './db/schema.js';
import { providerManager } from './providers/manager.js';

interface ClientConnection {
  ws: WebSocket;
  user: User;
  apiKeyScopes?: string[];
  subscribedVmIds: Set<string>;
  activeTerminal?: {
    vmId: string;
    process?: any;
  };
}

export class WebSocketBroker {
  private wss: WebSocketServer | null = null;
  private clients: Set<ClientConnection> = new Set();
  private sequence = 1;

  init(server: Server): void {
    // Use noServer mode so we can explicitly intercept and authorize the HTTP upgrade handshake
    this.wss = new WebSocketServer({ noServer: true });

    // Intercept HTTP upgrade requests before establishing WebSocket connection
    server.on('upgrade', (request: IncomingMessage, socket, head) => {
      const url = new URL(request.url || '', `http://${request.headers.host || 'localhost'}`);
      if (url.pathname !== '/api/v1/ws') {
        return; // Ignore other upgrade requests
      }

      let token = url.searchParams.get('token');

      // Check cookie if not in query
      if (!token && request.headers.cookie) {
        const cookies = request.headers.cookie.split(';').map(c => c.trim());
        const sessionCookie = cookies.find(c => c.startsWith('vortex_session='));
        if (sessionCookie) {
          token = sessionCookie.substring('vortex_session='.length);
        }
      }

      // Check Authorization header
      if (!token && request.headers.authorization && request.headers.authorization.startsWith('Bearer ')) {
        token = request.headers.authorization.substring(7).trim();
      }

      // Fail-closed handshake authorization: reject unauthenticated upgrades immediately
      if (!token) {
        socket.write('HTTP/1.1 401 Unauthorized\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n{"error":{"code":"AUTH_REQUIRED","message":"Authentication required for WebSocket connection"}}\r\n');
        socket.destroy();
        return;
      }

      const tokenHash = hashToken(token);
      let user: User | undefined;
      let apiKeyScopes: string[] | undefined;

      const session = db.getSessionByTokenHash(tokenHash);
      if (session && new Date(session.expires_at) >= new Date()) {
        user = db.getUserById(session.user_id);
      } else {
        const apiKey = db.getApiKeyByHash(tokenHash);
        if (apiKey) {
          user = db.getUserById(apiKey.user_id);
          apiKeyScopes = apiKey.scopes;
          db.touchApiKey(apiKey.id).catch(() => {});
        }
      }

      if (!user || user.status !== 'active') {
        socket.write('HTTP/1.1 401 Unauthorized\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n{"error":{"code":"AUTH_INVALID","message":"Invalid or expired session credentials"}}\r\n');
        socket.destroy();
        return;
      }

      // Enforce change-password requirement: block active operations if change is required
      if (user.must_change_password) {
        socket.write('HTTP/1.1 403 Forbidden\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n{"error":{"code":"PASSWORD_CHANGE_REQUIRED","message":"Password change required before connecting to terminal"}}\r\n');
        socket.destroy();
        return;
      }

      // Authentication verified: proceed with WebSocket upgrade
      this.wss!.handleUpgrade(request, socket, head, (ws) => {
        this.wss!.emit('connection', ws, request, user, apiKeyScopes);
      });
    });

    this.wss.on('connection', (ws: WebSocket, req: IncomingMessage, user: User, apiKeyScopes?: string[]) => {
      const client: ClientConnection = {
        ws,
        user,
        apiKeyScopes,
        subscribedVmIds: new Set(),
      };
      this.clients.add(client);

      // Welcome handshake confirmation
      ws.send(
        JSON.stringify({
          event: 'system.connected',
          data: {
            user_id: user.id,
            email: user.email,
            role: user.role,
            timestamp: new Date().toISOString(),
          },
        })
      );

      ws.on('message', async (raw) => {
        try {
          const msg = JSON.parse(raw.toString());
          await this.handleClientMessage(client, msg);
        } catch (err: any) {
          ws.send(JSON.stringify({ event: 'error', message: err.message }));
        }
      });

      ws.on('close', () => {
        this.clients.delete(client);
      });
    });
  }

  private async handleClientMessage(client: ClientConnection, msg: any): Promise<void> {
    const { action, vm_id, command } = msg;

    if (action === 'subscribe_vm' && vm_id) {
      const vm = db.getVMById(vm_id);
      if (vm && (client.user.role === 'admin' || vm.owner_id === client.user.id)) {
        client.subscribedVmIds.add(vm_id);
        client.ws.send(JSON.stringify({ event: 'vm.subscribed', vm_id }));
      } else {
        client.ws.send(JSON.stringify({ event: 'error', message: 'Access denied: not authorized to subscribe to this workload' }));
      }
      return;
    }

    if (action === 'unsubscribe_vm' && vm_id) {
      client.subscribedVmIds.delete(vm_id);
      client.ws.send(JSON.stringify({ event: 'vm.unsubscribed', vm_id }));
      return;
    }

    // Strict Terminal Command Execution Authorization Check
    if (action === 'terminal.exec' && vm_id && command) {
      const vm = db.getVMById(vm_id);
      if (!vm) {
        client.ws.send(JSON.stringify({ event: 'terminal.error', error: 'Workload not found' }));
        return;
      }

      // Check API Key Scopes if connecting using an API token
      if (client.apiKeyScopes) {
        const hasScope = client.apiKeyScopes.includes('vm:terminal') || client.apiKeyScopes.includes('*');
        if (!hasScope) {
          client.ws.send(
            JSON.stringify({
              event: 'terminal.error',
              error: 'Forbidden: API token lacks required scope vm:terminal',
            })
          );
          client.ws.close(4003, 'Scope unauthorized');
          return;
        }
      }

      // Enforce strict VM ownership: non-admin users can ONLY execute inside workloads they own
      if (client.user.role !== 'admin' && vm.owner_id !== client.user.id) {
        client.ws.send(
          JSON.stringify({
            event: 'terminal.error',
            error: 'Forbidden: Access denied to workload terminal. You do not own this workload.',
          })
        );
        // Terminate socket connection immediately to prevent unauthorized probing
        client.ws.close(4003, 'Unauthorized VM terminal access');
        return;
      }

      if (vm.status !== 'READY') {
        client.ws.send(
          JSON.stringify({
            event: 'terminal.error',
            error: `Workload cannot execute terminal commands in status: ${vm.status}. It must be READY.`,
          })
        );
        return;
      }

      const provider = providerManager.getProvider(vm.provider);
      try {
        const cmdArray = Array.isArray(command) ? command : ['/bin/sh', '-c', command];
        client.ws.send(
          JSON.stringify({
            event: 'terminal.started',
            vm_id,
            command: cmdArray.join(' '),
          })
        );

        const result = await provider.execute(vm.provider_resource_id!, cmdArray, {
          timeout_seconds: 60,
        });

        client.ws.send(
          JSON.stringify({
            event: 'terminal.output',
            vm_id,
            stdout: result.stdout,
            stderr: result.stderr,
            exit_code: result.exit_code,
            duration_ms: result.duration_ms,
          })
        );
      } catch (err: any) {
        client.ws.send(
          JSON.stringify({
            event: 'terminal.error',
            vm_id,
            error: err.message,
          })
        );
      }
    }
  }

  broadcast(event: string, data: any, targetVmId?: string): void {
    const envelope = {
      event,
      event_id: `evt_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      sequence: this.sequence++,
      occurred_at: new Date().toISOString(),
      resource: targetVmId ? { type: 'vm', id: targetVmId } : undefined,
      data,
    };

    const payload = JSON.stringify(envelope);

    for (const client of this.clients) {
      if (client.ws.readyState === WebSocket.OPEN) {
        // If target VM is specified, check authorization
        if (targetVmId) {
          const vm = db.getVMByIdIncludeDeleted(targetVmId);
          if (vm) {
            const isOwner = vm.owner_id === client.user.id;
            const isAdmin = client.user.role === 'admin';
            if (!isOwner && !isAdmin) {
              continue; // Do not leak other users' events
            }
          }
        }
        client.ws.send(payload);
      }
    }
  }
}

export const wsBroker = new WebSocketBroker();
