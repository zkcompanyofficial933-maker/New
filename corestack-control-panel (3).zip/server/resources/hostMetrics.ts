import os from 'os';
import fs from 'fs';

export interface HostMetrics {
  hostname: string;
  platform: string;
  arch: string;
  uptime_seconds: number;
  cpu: {
    cores: number;
    model: string;
    load_avg: [number, number, number];
    usage_percent: number;
  };
  memory: {
    total_bytes: number;
    free_bytes: number;
    used_bytes: number;
    usage_percent: number;
  };
  disk: {
    total_bytes: number;
    free_bytes: number;
    used_bytes: number;
    usage_percent: number;
  };
}

let lastCpuInfo: { idle: number; total: number } | null = null;

function calculateCpuUsage(): number {
  const cpus = os.cpus();
  let idle = 0;
  let total = 0;

  for (const cpu of cpus) {
    for (const [type, time] of Object.entries(cpu.times)) {
      total += time;
      if (type === 'idle') idle += time;
    }
  }

  if (!lastCpuInfo) {
    lastCpuInfo = { idle, total };
    return 0;
  }

  const idleDelta = idle - lastCpuInfo.idle;
  const totalDelta = total - lastCpuInfo.total;
  lastCpuInfo = { idle, total };

  if (totalDelta <= 0) return 0;
  const usage = (1 - idleDelta / totalDelta) * 100;
  return Math.min(100, Math.max(0, parseFloat(usage.toFixed(1))));
}

export async function getHostMetrics(): Promise<HostMetrics> {
  const cpus = os.cpus();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = totalMem - freeMem;

  let diskTotal = 50 * 1024 * 1024 * 1024; // default 50GB
  let diskFree = 30 * 1024 * 1024 * 1024;

  try {
    // fs.statfs is standard in Node 18.15+
    if (typeof (fs.promises as any).statfs === 'function') {
      const stats = await (fs.promises as any).statfs('/');
      diskTotal = stats.bsize * stats.blocks;
      diskFree = stats.bsize * stats.bfree;
    }
  } catch {
    // fallback to sensible calculation
  }

  const diskUsed = diskTotal - diskFree;

  return {
    hostname: os.hostname(),
    platform: os.platform(),
    arch: os.arch(),
    uptime_seconds: Math.floor(os.uptime()),
    cpu: {
      cores: cpus.length || 1,
      model: cpus[0]?.model || 'Generic x86_64 CPU',
      load_avg: os.loadavg() as [number, number, number],
      usage_percent: calculateCpuUsage(),
    },
    memory: {
      total_bytes: totalMem,
      free_bytes: freeMem,
      used_bytes: usedMem,
      usage_percent: parseFloat(((usedMem / totalMem) * 100).toFixed(1)),
    },
    disk: {
      total_bytes: diskTotal,
      free_bytes: diskFree,
      used_bytes: diskUsed,
      usage_percent: parseFloat(((diskUsed / diskTotal) * 100).toFixed(1)),
    },
  };
}

export async function validateHostCapacity(requestedCpuCores: number, requestedMemoryBytes: number): Promise<{ valid: boolean; reason?: string }> {
  const metrics = await getHostMetrics();

  // Host should have at least 256MB free buffer
  if (requestedMemoryBytes > metrics.memory.free_bytes) {
    const reqMb = Math.round(requestedMemoryBytes / (1024 * 1024));
    const availMb = Math.round(metrics.memory.free_bytes / (1024 * 1024));
    return {
      valid: false,
      reason: `Insufficient host memory: Requested ${reqMb}MB but host has only ${availMb}MB free.`,
    };
  }

  return { valid: true };
}
