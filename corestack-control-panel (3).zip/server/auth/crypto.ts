import crypto from 'crypto';
import { CONFIG } from '../config.js';

export async function hashPassword(password: string): Promise<string> {
  const salt = crypto.randomBytes(16).toString('hex');
  return new Promise((resolve, reject) => {
    crypto.pbkdf2(
      password,
      salt,
      CONFIG.PASSWORD_SALT_ROUNDS,
      64,
      'sha512',
      (err, derivedKey) => {
        if (err) return reject(err);
        resolve(`${salt}:${derivedKey.toString('hex')}`);
      }
    );
  });
}

export async function verifyPassword(password: string, combinedHash: string): Promise<boolean> {
  const parts = combinedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const originalKey = Buffer.from(keyHex, 'hex');

  return new Promise((resolve) => {
    crypto.pbkdf2(
      password,
      salt,
      CONFIG.PASSWORD_SALT_ROUNDS,
      64,
      'sha512',
      (err, derivedKey) => {
        if (err) return resolve(false);
        try {
          resolve(crypto.timingSafeEqual(originalKey, derivedKey));
        } catch {
          resolve(false);
        }
      }
    );
  });
}

export function generateSessionToken(): { rawToken: string; tokenHash: string } {
  const rawToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  return { rawToken, tokenHash };
}

export function hashToken(rawToken: string): string {
  return crypto.createHash('sha256').update(rawToken).digest('hex');
}

export function generateApiKey(): { fullKey: string; keyPrefix: string; keyHash: string } {
  const keyPrefix = 'vp_live_' + crypto.randomBytes(4).toString('hex');
  const secretPart = crypto.randomBytes(24).toString('hex');
  const fullKey = `${keyPrefix}.${secretPart}`;
  const keyHash = crypto.createHash('sha256').update(fullKey).digest('hex');
  return { fullKey, keyPrefix, keyHash };
}

export function hashIp(ip: string): string {
  return crypto.createHash('sha256').update(ip + CONFIG.SESSION_SECRET).digest('hex').substring(0, 16);
}

/**
 * Constant-time string comparison utility using crypto.timingSafeEqual.
 * Computes fixed-length SHA-256 digests prior to timingSafeEqual to avoid leaking string length.
 */
export function timingSafeStringEqual(a: string, b: string): boolean {
  if (typeof a !== 'string' || typeof b !== 'string') {
    return false;
  }
  const digestA = crypto.createHash('sha256').update(a).digest();
  const digestB = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(digestA, digestB);
}
