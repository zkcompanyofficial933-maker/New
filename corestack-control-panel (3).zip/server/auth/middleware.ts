import { Request, Response, NextFunction } from 'express';
import { db } from '../db/database.js';
import { hashToken } from './crypto.js';
import { User } from '../db/schema.js';

export interface AuthenticatedRequest extends Request {
  user?: User;
  apiKeyScopes?: string[];
  requestId?: string;
}

export function extractAuthToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7).trim();
  }

  // Check cookie
  const cookieHeader = req.headers.cookie;
  if (cookieHeader) {
    const cookies = cookieHeader.split(';').map(c => c.trim());
    const sessionCookie = cookies.find(c => c.startsWith('vortex_session='));
    if (sessionCookie) {
      return sessionCookie.substring('vortex_session='.length);
    }
  }

  return null;
}

export async function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
  const token = extractAuthToken(req);
  if (!token) {
    res.status(401).json({
      error: {
        code: 'AUTH_REQUIRED',
        message: 'Authentication is required to access this endpoint',
        details: {},
        request_id: req.requestId || '',
      },
    });
    return;
  }

  const tokenHash = hashToken(token);

  // 1. Try session
  const session = db.getSessionByTokenHash(tokenHash);
  if (session) {
    if (new Date(session.expires_at) < new Date()) {
      res.status(401).json({
        error: {
          code: 'AUTH_INVALID',
          message: 'Session has expired',
          details: {},
          request_id: req.requestId || '',
        },
      });
      return;
    }

    const user = db.getUserById(session.user_id);
    if (!user || user.status !== 'active') {
      res.status(401).json({
        error: {
          code: 'AUTH_INVALID',
          message: 'User account is inactive or not found',
          details: {},
          request_id: req.requestId || '',
        },
      });
      return;
    }

    req.user = user;

    // Task 6: Anti-CSRF defense for cookie-based state-changing requests
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
      const isCookieAuth = !req.headers.authorization && !!req.headers.cookie?.includes('vortex_session=');
      if (isCookieAuth) {
        const antiCsrf = req.headers['x-vortex-requested-with'] || req.headers['x-requested-with'];
        if (antiCsrf !== 'XMLHttpRequest') {
          res.status(403).json({
            error: {
              code: 'CSRF_BLOCKED',
              message: 'State-changing request blocked: missing Anti-CSRF header (X-Vortex-Requested-With: XMLHttpRequest)',
              details: {},
              request_id: req.requestId || '',
            },
          });
          return;
        }
      }
    }

    // Task 5: Enforce password change requirement
    if (user.must_change_password) {
      const allowedEndpoints = ['/auth/change-password', '/auth/logout', '/auth/me'];
      const reqPath = (req.baseUrl || '') + (req.path || '');
      const isAllowed = allowedEndpoints.some(endpoint => reqPath.endsWith(endpoint));
      if (!isAllowed) {
        res.status(403).json({
          error: {
            code: 'PASSWORD_CHANGE_REQUIRED',
            message: 'Password change required before accessing other endpoints',
            details: { must_change_password: true },
            request_id: req.requestId || '',
          },
        });
        return;
      }
    }

    return next();
  }

  // 2. Try API Key
  const apiKey = db.getApiKeyByHash(tokenHash);
  if (apiKey) {
    const user = db.getUserById(apiKey.user_id);
    if (!user || user.status !== 'active') {
      res.status(401).json({
        error: {
          code: 'AUTH_INVALID',
          message: 'API Key owner is inactive or not found',
          details: {},
          request_id: req.requestId || '',
        },
      });
      return;
    }

    await db.touchApiKey(apiKey.id);
    req.user = user;
    req.apiKeyScopes = apiKey.scopes;
    return next();
  }

  res.status(401).json({
    error: {
      code: 'AUTH_INVALID',
      message: 'Invalid session or API key',
      details: {},
      request_id: req.requestId || '',
    },
  });
}

export function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.user) {
    res.status(401).json({
      error: { code: 'AUTH_REQUIRED', message: 'Authentication required' },
    });
    return;
  }

  if (req.user.role !== 'admin') {
    res.status(403).json({
      error: {
        code: 'FORBIDDEN',
        message: 'Administrator privilege is required for this action',
        details: { user_role: req.user.role },
        request_id: req.requestId || '',
      },
    });
    return;
  }

  next();
}

export function requireScope(scope: string) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (req.apiKeyScopes) {
      if (!req.apiKeyScopes.includes(scope) && !req.apiKeyScopes.includes('*')) {
        res.status(403).json({
          error: {
            code: 'FORBIDDEN',
            message: `API Key lacks required scope: ${scope}`,
            details: { required_scope: scope, available_scopes: req.apiKeyScopes },
            request_id: req.requestId || '',
          },
        });
        return;
      }
    }
    next();
  };
}

export function authorizeVM(action: 'read' | 'control' | 'delete' | 'terminal' | 'files') {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: { code: 'AUTH_REQUIRED', message: 'Authentication required' } });
      return;
    }

    // Standardize target identifier extraction across all route parameter variants
    const rawVmId = req.params.id || req.params.vm_id || req.params.target_id;
    
    // Fail-closed security rule: refuse execution if target identifier cannot be determined
    if (!rawVmId || typeof rawVmId !== 'string' || !rawVmId.trim()) {
      res.status(403).json({
        error: {
          code: 'FORBIDDEN',
          message: 'Access denied: Workload identifier is required for access verification',
          details: {},
          request_id: req.requestId || '',
        },
      });
      return;
    }

    const vmId = rawVmId.trim();

    // Enforce API key scope verification explicitly BEFORE role overrides
    // Prevents scoped API keys belonging to admins from bypassing granted scope restrictions
    if (req.apiKeyScopes) {
      const scopeMap: Record<string, string> = {
        read: 'vm:read',
        control: 'vm:control',
        delete: 'vm:delete',
        terminal: 'vm:terminal',
        files: 'vm:files',
      };
      const reqScope = scopeMap[action];
      if (reqScope && !req.apiKeyScopes.includes(reqScope) && !req.apiKeyScopes.includes('*')) {
        res.status(403).json({
          error: {
            code: 'FORBIDDEN',
            message: `API Key lacks required scope: ${reqScope}`,
            details: { required_scope: reqScope, available_scopes: req.apiKeyScopes },
            request_id: req.requestId || '',
          },
        });
        return;
      }
    }

    // Verify workload exists and is accessible
    const vm = db.getVMById(vmId);
    if (!vm) {
      res.status(404).json({
        error: {
          code: 'VM_NOT_FOUND',
          message: `Workload with ID ${vmId} not found`,
          details: { vm_id: vmId },
          request_id: req.requestId || '',
        },
      });
      return;
    }

    // Admins can access any workload only if their token/key scope allows the action
    if (req.user.role === 'admin') {
      return next();
    }

    // Normal users can only access workloads they own
    if (vm.owner_id !== req.user.id) {
      res.status(403).json({
        error: {
          code: 'FORBIDDEN',
          message: 'You do not own this workload',
          details: { vm_id: vmId },
          request_id: req.requestId || '',
        },
      });
      return;
    }

    next();
  };
}
