/**
 * Custom server entrypoint.
 *
 * Next.js's App Router route handlers cannot hold a persistent WebSocket
 * upgrade, so the panel runs its own HTTP server: Next handles normal
 * HTTP requests, and a Socket.io server attached to the SAME server
 * handles the live terminal + log streaming. This keeps one process,
 * one port, and lets Socket.io ride the initial HTTP upgrade request.
 */
const { createServer } = require("http");
const { parse } = require("url");
const next = require("next");

const dev = process.env.NODE_ENV !== "production";
const port = parseInt(process.env.PORT || "3000", 10);

const app = next({ dev });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  const httpServer = createServer((req, res) => {
    const parsedUrl = parse(req.url, true);
    handle(req, res, parsedUrl);
  });

  // Registered after transpilation is available; see src/server/socket.ts
  require("./src/server/socket-bootstrap").attachSocketServer(httpServer);

  httpServer.listen(port, () => {
    console.log(`> Bot Hosting Panel ready on http://localhost:${port}`);
  });
});
