/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    serverComponentsExternalPackages: ["dockerode", "simple-git"],
  },
};

module.exports = nextConfig;
