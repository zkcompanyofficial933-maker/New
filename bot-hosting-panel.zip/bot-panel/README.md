# Bot Hosting Panel

A self-hosted panel for running Discord/Telegram/WhatsApp (and generic) bots
written in Python, Node.js or Java — each bot isolated in its own Docker
container with enforced CPU/RAM limits, a live web terminal, log streaming,
an in-browser file manager, environment variable management, and one-click
GitHub deploys.

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│ Host machine (Docker Engine)                              │
│                                                             │
│  ┌───────────────┐        ┌────────────────────────────┐  │
│  │  postgres      │        │  panel (Next.js + Socket.io)│  │
│  │  (metadata)    │◄──────►│                              │  │
│  └───────────────┘        │  - REST API (bot lifecycle,  │  │
│                            │    files, env vars, git)     │  │
│                            │  - /terminal, /logs, /stats  │  │
│                            │    websocket namespaces      │  │
│                            │  - talks to the HOST Docker  │  │
│                            │    daemon via bind-mounted   │  │
│                            │    /var/run/docker.sock      │  │
│                            └───────────┬──────────────────┘  │
│                                        │ creates/controls     │
│                                        ▼                      │
│                     ┌─────────────────────────────────┐      │
│                     │ bot-panel-<botId>  (sibling       │      │
│                     │ container per bot, one of the     │      │
│                     │ python/nodejs/java runtime images)│      │
│                     │  - NanoCPUs / Memory limits        │      │
│                     │  - workspace bind-mounted from     │      │
│                     │    /workspaces/<botId>             │      │
│                     └─────────────────────────────────┘      │
└──────────────────────────────────────────────────────────┘
```

The panel does **not** run bots inside itself — it uses the Docker Engine
API (`dockerode`) to create sibling containers on the host daemon. This is
"Docker-out-of-Docker" via the bind-mounted socket, which is simpler and
more reliable than Docker-in-Docker for this use case.

## Prerequisites

- Docker Engine 24+ and Docker Compose v2, on a Linux host (recommended).
  Bind-mounting `/var/run/docker.sock` requires a real Docker daemon on the
  host; this does not work unmodified on Docker Desktop's isolated VM for
  bot workspace bind mounts unless you adjust the volume paths accordingly.
- Ports available: `3000` (panel), `5432` (Postgres, optional to expose).
- A Git-accessible network if you plan to use the GitHub deploy feature.

## 1. Build the runtime images

Each supported language has its own minimal runtime image (`docker/runtimes/*`).
Build them once before starting the panel:

```bash
docker build -t bot-panel-runtime-python:3.11 ./docker/runtimes/python
docker build -t bot-panel-runtime-nodejs:18   ./docker/runtimes/nodejs
docker build -t bot-panel-runtime-java:17     ./docker/runtimes/java
```

(The panel will also attempt to `docker pull` a missing image by name at
bot-start time — pre-building locally is faster and works offline.)

## 2. Configure environment variables

```bash
cp .env.example .env
```

Edit `.env` and set, at minimum:

- `JWT_SECRET` — a long random string (`openssl rand -hex 32`)
- `ENV_ENCRYPTION_KEY` — **exactly 32 bytes**, used to encrypt bot env vars
  at rest (`openssl rand -hex 16` gives 32 hex chars = 32 bytes if you take
  it as raw bytes — simplest is `openssl rand -base64 24 | cut -c1-32`)
- `POSTGRES_PASSWORD` — change from the default

## 3. Start the stack

```bash
docker compose up -d --build
```

This starts Postgres, runs Prisma migrations are applied automatically via
the panel's build step is generate-only — run migrations once:

```bash
docker compose exec panel npx prisma migrate deploy
```

(For local development without Docker for the panel itself, see "Local
development" below.)

Visit `http://localhost:3000`. **The first account you register becomes the
panel administrator.**

## 4. Create your first bot

1. Dashboard → **New bot** → choose a name, language (Python/Node.js/Java),
   and a start command (e.g. `node index.js`, `python bot.py`,
   `java -jar bot.jar`).
2. Open the bot → **Settings** tab → set CPU/RAM limits, and optionally a
   Git repository URL + branch to deploy from.
3. Either:
   - Use the **Files** tab to upload your bot's source directly, or
   - Set a Git repo URL in Settings and click **Pull latest & redeploy**.
4. Add secrets in **Settings → Environment variables** (e.g. `DISCORD_TOKEN`,
   `TELEGRAM_BOT_TOKEN`). These are encrypted at rest (AES-256-GCM) and
   injected into the container's environment at start time.
5. Click **Start**. Use the **Console** tab for an interactive shell inside
   the running container, or **Logs** for a live stdout/stderr tail.

## Local development (without building the panel image)

```bash
npm install
cp .env.example .env   # point DATABASE_URL at a local/dockerized Postgres
npx prisma generate
npx prisma migrate dev
npm run dev             # runs server.js -> Next.js dev + Socket.io on :3000
```

This still needs Docker Engine reachable at `/var/run/docker.sock` (or set
`DOCKER_HOST` and adjust `src/lib/docker.ts` / `src/server/socket-bootstrap.js`
accordingly if the daemon is remote/TCP).

## Security notes

- Every container runs with `CapDrop: ALL`, `no-new-privileges`, a
  `PidsLimit`, and hard CPU/memory ceilings — a compromised bot cannot
  escalate privileges or exhaust the host.
- File manager and Git deploy operations are sandboxed to
  `BOT_WORKSPACES_ROOT/<botId>` with path-traversal checks
  (`src/lib/file-manager.ts::resolveSafePath`) — no request can read or
  write outside a bot's own workspace.
- Env var values are encrypted at rest and never re-sent to the browser
  after initial save; only key names are returned by `GET /api/bots/:id/env`.
- The panel container needs access to the Docker socket, which is
  effectively root-equivalent on the host. Run the panel on a host you
  trust, behind your own reverse proxy/TLS, and restrict who can register
  accounts (the first registered user becomes ADMIN; consider disabling
  `/register` after initial setup by removing the route or adding an
  invite-code check).

## What's included vs. left as an exercise

Included and functional end-to-end: auth, bot CRUD, container lifecycle
(start/stop/restart/delete), resource limits, auto-restart policy, live
terminal (xterm.js ↔ Docker exec pty), live log streaming, live CPU/RAM
polling, a sandboxed file manager (browse/read/write/upload/download/
delete/rename), encrypted env vars, and Git clone/pull-based deploys with
automatic dependency install (`pip install` / `npm install` / `mvn package`)
before each (re)start.

Reasonable next steps for a larger production rollout: multi-node scheduling
(this panel targets a single Docker host), per-user resource quotas across
bots, audit logging, 2FA, and a queue for long-running installs so the UI
can show granular build progress instead of a single "Building" state.

## Tech stack

- **Frontend:** Next.js 14 (App Router), Tailwind CSS, Lucide icons,
  xterm.js + xterm-addon-fit
- **Backend:** Next.js Route Handlers + a custom Node server
  (`server.js`) running Socket.io alongside Next for WebSocket support
- **Database:** PostgreSQL + Prisma ORM
- **Containerization:** `dockerode` against the host Docker Engine API
