export type Language = "PYTHON" | "NODEJS" | "JAVA";
export type BotStatus = "CREATED" | "BUILDING" | "RUNNING" | "STOPPED" | "CRASHED" | "DELETING";
export type BotKind = "DISCORD" | "TELEGRAM" | "WHATSAPP" | "GENERIC";
export type RestartPolicyName = "no" | "on-failure" | "unless-stopped" | "always";

export interface BotSummary {
  id: string;
  name: string;
  slug: string;
  kind: BotKind;
  language: Language;
  status: BotStatus;
  cpuLimit: number;
  ramLimit: number;
  autoRestart: boolean;
  gitRepoUrl: string | null;
  gitBranch: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateBotInput {
  name: string;
  language: Language;
  kind?: BotKind;
  entrypoint: string;
  cpuLimit?: number;
  ramLimit?: number;
  gitRepoUrl?: string;
  gitBranch?: string;
  autoRestart?: boolean;
}

export interface EnvVarInput {
  key: string;
  value: string;
}

export interface FileNode {
  name: string;
  path: string; // path relative to the bot workspace root
  type: "file" | "directory";
  size: number;
  modifiedAt: string;
}

export interface ContainerStats {
  cpuPercent: number;
  memUsageMB: number;
  memLimitMB: number;
  memPercent: number;
  netRxKB: number;
  netTxKB: number;
  pids: number;
}
