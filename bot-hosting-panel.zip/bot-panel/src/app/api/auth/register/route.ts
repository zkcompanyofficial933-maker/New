import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { hashPassword, signSession, sessionCookieOptions } from "@/lib/auth";

const schema = z.object({
  email: z.string().email(),
  username: z.string().min(3).max(32),
  password: z.string().min(8, "Password must be at least 8 characters."),
});

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input." }, { status: 400 });
  }

  const { email, username, password } = parsed.data;

  const existing = await prisma.user.findFirst({ where: { OR: [{ email }, { username }] } });
  if (existing) {
    return NextResponse.json({ error: "Email or username already in use." }, { status: 409 });
  }

  // First user ever created becomes ADMIN; everyone after is USER.
  const userCount = await prisma.user.count();
  const role = userCount === 0 ? "ADMIN" : "USER";

  const user = await prisma.user.create({
    data: { email, username, passwordHash: await hashPassword(password), role },
  });

  const token = signSession({ userId: user.id, role: user.role });
  const res = NextResponse.json({
    user: { id: user.id, email: user.email, username: user.username, role: user.role },
  });
  res.cookies.set(sessionCookieOptions().name, token, sessionCookieOptions());
  return res;
}
