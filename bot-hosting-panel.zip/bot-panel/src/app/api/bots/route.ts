import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUser, handleApiError } from "@/lib/api-helpers";
import { ensureWorkspace, workspacePathFor } from "@/lib/docker";
import slugify from "@/lib/slugify";

const createSchema = z.object({
  name: z.string().min(2).max(64),
  language: z.enum(["PYTHON", "NODEJS", "JAVA"]),
  kind: z.enum(["DISCORD", "TELEGRAM", "WHATSAPP", "GENERIC"]).default("GENERIC"),
  entrypoint: z.string().min(1, "An entrypoint command is required, e.g. 'node index.js'."),
  cpuLimit: z.number().min(0.1).max(8).default(1),
  ramLimit: z.number().min(128).max(16384).default(512),
  gitRepoUrl: z.string().url().optional().or(z.literal("")),
  gitBranch: z.string().default("main"),
  autoRestart: z.boolean().default(true),
});

export async function GET() {
  try {
    const user = await requireUser();
    const bots = await prisma.bot.findMany({
      where: user.role === "ADMIN" ? {} : { ownerId: user.id },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ bots });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await req.json().catch(() => null);
    const parsed = createSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message }, { status: 400 });
    }
    const data = parsed.data;

    const baseSlug = slugify(data.name);
    let slug = baseSlug;
    let suffix = 1;
    while (await prisma.bot.findUnique({ where: { slug } })) {
      slug = `${baseSlug}-${++suffix}`;
    }

    const bot = await prisma.bot.create({
      data: {
        name: data.name,
        slug,
        kind: data.kind,
        language: data.language,
        entrypoint: data.entrypoint,
        cpuLimit: data.cpuLimit,
        ramLimit: data.ramLimit,
        gitRepoUrl: data.gitRepoUrl || null,
        gitBranch: data.gitBranch,
        autoRestart: data.autoRestart,
        restartPolicy: data.autoRestart ? "unless-stopped" : "no",
        ownerId: user.id,
        workspacePath: workspacePathFor("__pending__"), // placeholder, fixed below
        status: "CREATED",
      },
    });

    const workspacePath = await ensureWorkspace(bot.id);
    await prisma.bot.update({ where: { id: bot.id }, data: { workspacePath } });

    return NextResponse.json({ bot: { ...bot, workspacePath } }, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
