import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireOwnedBot, handleApiError, ApiError } from "@/lib/api-helpers";
import { deployFromGit } from "@/lib/git-deploy";
import { createBotContainer, startContainer, pullImageIfMissing } from "@/lib/docker";
import { decryptSecret } from "@/lib/crypto";

const RUNTIME_IMAGES: Record<string, string> = {
  PYTHON: process.env.RUNTIME_IMAGE_PYTHON || "bot-panel-runtime-python:3.11",
  NODEJS: process.env.RUNTIME_IMAGE_NODEJS || "bot-panel-runtime-nodejs:18",
  JAVA: process.env.RUNTIME_IMAGE_JAVA || "bot-panel-runtime-java:17",
};

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    if (!bot.gitRepoUrl) {
      throw new ApiError("This bot has no Git repository configured.", 400);
    }

    await prisma.bot.update({ where: { id: bot.id }, data: { status: "BUILDING" } });

    try {
      const result = await deployFromGit(bot.id, bot.gitRepoUrl, bot.gitBranch);

      await pullImageIfMissing(RUNTIME_IMAGES[bot.language]);
      const envVars = await prisma.envVar.findMany({ where: { botId: bot.id } });
      const env = Object.fromEntries(envVars.map((e) => [e.key, decryptSecret(e.value)]));

      // Re-create the container so the install step re-runs against the
      // freshly pulled code, then start it.
      const container = await createBotContainer({
        botId: bot.id,
        language: bot.language,
        entrypoint: bot.entrypoint,
        cpuLimit: bot.cpuLimit,
        ramLimit: bot.ramLimit,
        env,
        restartPolicy: bot.autoRestart ? (bot.restartPolicy as any) : "no",
        runInstallStep: true,
      });
      await startContainer(container.id);

      const updated = await prisma.bot.update({
        where: { id: bot.id },
        data: {
          status: "RUNNING",
          dockerContainerId: container.id,
          lastCommit: result.commit,
        },
      });

      return NextResponse.json({ bot: updated, deploy: result });
    } catch (innerErr) {
      await prisma.bot.update({ where: { id: bot.id }, data: { status: "CRASHED" } });
      throw innerErr;
    }
  } catch (err) {
    return handleApiError(err);
  }
}
