import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireOwnedBot, handleApiError } from "@/lib/api-helpers";
import { removeContainer } from "@/lib/docker";
import fs from "fs/promises";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    return NextResponse.json({ bot });
  } catch (err) {
    return handleApiError(err);
  }
}

const updateSchema = z.object({
  name: z.string().min(2).max(64).optional(),
  entrypoint: z.string().min(1).optional(),
  cpuLimit: z.number().min(0.1).max(8).optional(),
  ramLimit: z.number().min(128).max(16384).optional(),
  gitRepoUrl: z.string().url().or(z.literal("")).optional(),
  gitBranch: z.string().optional(),
  autoRestart: z.boolean().optional(),
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    const body = await req.json().catch(() => null);
    const parsed = updateSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message }, { status: 400 });
    }

    const data = parsed.data;
    const updated = await prisma.bot.update({
      where: { id: bot.id },
      data: {
        ...data,
        gitRepoUrl: data.gitRepoUrl === "" ? null : data.gitRepoUrl,
        restartPolicy:
          data.autoRestart === undefined ? undefined : data.autoRestart ? "unless-stopped" : "no",
      },
    });

    // Resource / restart-policy changes only take effect on next
    // start/restart since Docker cannot hot-patch NanoCPUs on a running
    // container's HostConfig via a simple update in all engine versions
    // reliably for every field — we surface that in the UI.
    return NextResponse.json({ bot: updated });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);

    if (bot.dockerContainerId) {
      await removeContainer(bot.dockerContainerId).catch(() => void 0);
    }
    await fs.rm(bot.workspacePath, { recursive: true, force: true }).catch(() => void 0);
    await prisma.bot.delete({ where: { id: bot.id } });

    return NextResponse.json({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
