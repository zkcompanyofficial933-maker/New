import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireOwnedBot, handleApiError } from "@/lib/api-helpers";
import { encryptSecret } from "@/lib/crypto";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    const vars = await prisma.envVar.findMany({
      where: { botId: bot.id },
      select: { id: true, key: true, createdAt: true, updatedAt: true },
      orderBy: { key: "asc" },
    });
    // Values are never returned to the client after creation — only keys.
    return NextResponse.json({ envVars: vars });
  } catch (err) {
    return handleApiError(err);
  }
}

const bulkSchema = z.object({
  vars: z.array(
    z.object({
      key: z
        .string()
        .regex(/^[A-Za-z_][A-Za-z0-9_]*$/, "Keys must be valid env var names (A-Z, 0-9, _)."),
      value: z.string(),
    })
  ),
});

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    const body = await req.json().catch(() => null);
    const parsed = bulkSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message }, { status: 400 });
    }

    await prisma.$transaction([
      prisma.envVar.deleteMany({ where: { botId: bot.id } }),
      ...parsed.data.vars.map((v) =>
        prisma.envVar.create({
          data: { botId: bot.id, key: v.key, value: encryptSecret(v.value) },
        })
      ),
    ]);

    return NextResponse.json({ ok: true, count: parsed.data.vars.length });
  } catch (err) {
    return handleApiError(err);
  }
}
