import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireOwnedBot, handleApiError, ApiError } from "@/lib/api-helpers";
import { restartContainer } from "@/lib/docker";

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    if (!bot.dockerContainerId) {
      throw new ApiError("Bot has never been started — nothing to restart.", 409);
    }

    await prisma.bot.update({ where: { id: bot.id }, data: { status: "BUILDING" } });
    await restartContainer(bot.dockerContainerId);
    const updated = await prisma.bot.update({ where: { id: bot.id }, data: { status: "RUNNING" } });

    return NextResponse.json({ bot: updated });
  } catch (err) {
    return handleApiError(err);
  }
}
