import { NextRequest, NextResponse } from "next/server";
import { requireOwnedBot, handleApiError } from "@/lib/api-helpers";
import { getContainerStats } from "@/lib/docker";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    if (!bot.dockerContainerId || bot.status !== "RUNNING") {
      return NextResponse.json({ stats: null });
    }
    const stats = await getContainerStats(bot.dockerContainerId);
    return NextResponse.json({ stats });
  } catch (err) {
    return handleApiError(err);
  }
}
