import { NextRequest, NextResponse } from "next/server";
import { requireOwnedBot, handleApiError, ApiError } from "@/lib/api-helpers";
import { saveUploadedFile } from "@/lib/file-manager";

const MAX_UPLOAD_BYTES = 50 * 1024 * 1024; // 50MB per file

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    const formData = await req.formData();
    const targetDir = (formData.get("path") as string) || ".";
    const file = formData.get("file");

    if (!file || !(file instanceof File)) {
      throw new ApiError("No file provided.", 400);
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      throw new ApiError("File exceeds the 50MB upload limit.", 413);
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const destination = targetDir === "." ? file.name : `${targetDir}/${file.name}`;
    await saveUploadedFile(bot.id, destination, buffer);

    return NextResponse.json({ ok: true, path: destination });
  } catch (err) {
    return handleApiError(err);
  }
}
