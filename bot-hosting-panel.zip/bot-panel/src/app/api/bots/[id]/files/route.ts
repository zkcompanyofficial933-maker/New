import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireOwnedBot, handleApiError } from "@/lib/api-helpers";
import {
  listDirectory,
  readFile,
  writeFile,
  createDirectory,
  deletePath,
  renamePath,
} from "@/lib/file-manager";

// GET /api/bots/:id/files?path=some/dir            -> directory listing
// GET /api/bots/:id/files?path=some/file.py&read=1  -> file contents
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    const url = new URL(req.url);
    const relPath = url.searchParams.get("path") ?? ".";
    const wantsRead = url.searchParams.get("read") === "1";

    if (wantsRead) {
      const content = await readFile(bot.id, relPath);
      return NextResponse.json({ path: relPath, content });
    }

    const nodes = await listDirectory(bot.id, relPath);
    return NextResponse.json({ path: relPath, nodes });
  } catch (err) {
    return handleApiError(err);
  }
}

const writeSchema = z.object({
  action: z.enum(["write-file", "create-dir", "delete", "rename"]),
  path: z.string(),
  content: z.string().optional(),
  newPath: z.string().optional(),
});

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    const body = await req.json().catch(() => null);
    const parsed = writeSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message }, { status: 400 });
    }
    const { action, path: relPath, content, newPath } = parsed.data;

    switch (action) {
      case "write-file":
        await writeFile(bot.id, relPath, content ?? "");
        break;
      case "create-dir":
        await createDirectory(bot.id, relPath);
        break;
      case "delete":
        await deletePath(bot.id, relPath);
        break;
      case "rename":
        if (!newPath) throw new Error("newPath is required for rename.");
        await renamePath(bot.id, relPath, newPath);
        break;
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    return handleApiError(err);
  }
}
