import { NextRequest, NextResponse } from "next/server";
import fs from "fs/promises";
import path from "path";
import { requireOwnedBot, handleApiError, ApiError } from "@/lib/api-helpers";
import { resolveSafePath } from "@/lib/file-manager";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    const url = new URL(req.url);
    const relPath = url.searchParams.get("path");
    if (!relPath) throw new ApiError("Missing path query parameter.", 400);

    const filePath = resolveSafePath(bot.id, relPath);
    const stat = await fs.stat(filePath);
    if (!stat.isFile()) throw new ApiError("Path is not a file.", 400);

    const data = await fs.readFile(filePath);
    return new NextResponse(data, {
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": `attachment; filename="${path.basename(filePath)}"`,
        "Content-Length": String(stat.size),
      },
    });
  } catch (err) {
    return handleApiError(err);
  }
}
