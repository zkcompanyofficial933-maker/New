import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireOwnedBot, handleApiError, ApiError } from "@/lib/api-helpers";
import { createBotContainer, startContainer, pullImageIfMissing } from "@/lib/docker";
import { decryptSecret } from "@/lib/crypto";

const RUNTIME_IMAGES: Record<string, string> = {
  PYTHON: process.env.RUNTIME_IMAGE_PYTHON || "bot-panel-runtime-python:3.11",
  NODEJS: process.env.RUNTIME_IMAGE_NODEJS || "bot-panel-runtime-nodejs:18",
  JAVA: process.env.RUNTIME_IMAGE_JAVA || "bot-panel-runtime-java:17",
};

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);

    if (bot.status === "RUNNING") {
      throw new ApiError("Bot is already running.", 409);
    }

    await prisma.bot.update({ where: { id: bot.id }, data: { status: "BUILDING" } });

    try {
      await pullImageIfMissing(RUNTIME_IMAGES[bot.language]);

      const envVars = await prisma.envVar.findMany({ where: { botId: bot.id } });
      const env = Object.fromEntries(envVars.map((e) => [e.key, decryptSecret(e.value)]));

      // Run the install step only the first time a container is created for
      // this bot's current code, so restarts are fast; deploy/route.ts also
      // triggers a rebuild with the install step after a fresh git pull.
      const container = await createBotContainer({
        botId: bot.id,
        language: bot.language,
        entrypoint: bot.entrypoint,
        cpuLimit: bot.cpuLimit,
        ramLimit: bot.ramLimit,
        env,
        restartPolicy: bot.autoRestart ? (bot.restartPolicy as any) : "no",
        runInstallStep: true,
      });

      await startContainer(container.id);

      const updated = await prisma.bot.update({
        where: { id: bot.id },
        data: { status: "RUNNING", dockerContainerId: container.id },
      });

      return NextResponse.json({ bot: updated });
    } catch (innerErr) {
      await prisma.bot.update({ where: { id: bot.id }, data: { status: "CRASHED" } });
      throw innerErr;
    }
  } catch (err) {
    return handleApiError(err);
  }
}
