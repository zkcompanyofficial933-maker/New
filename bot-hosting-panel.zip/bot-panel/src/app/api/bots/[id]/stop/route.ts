import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireOwnedBot, handleApiError, ApiError } from "@/lib/api-helpers";
import { stopContainer } from "@/lib/docker";

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { bot } = await requireOwnedBot(params.id);
    if (!bot.dockerContainerId) {
      throw new ApiError("Bot has no running container.", 409);
    }

    await stopContainer(bot.dockerContainerId);
    const updated = await prisma.bot.update({ where: { id: bot.id }, data: { status: "STOPPED" } });

    return NextResponse.json({ bot: updated });
  } catch (err) {
    return handleApiError(err);
  }
}
