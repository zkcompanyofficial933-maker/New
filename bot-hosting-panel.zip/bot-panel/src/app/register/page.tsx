"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Server } from "lucide-react";

export default function RegisterPage() {
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, username, password }),
    });
    setSubmitting(false);
    if (res.ok) {
      router.push("/dashboard");
    } else {
      const d = await res.json();
      setError(d.error ?? "Registration failed.");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <form onSubmit={submit} className="w-full max-w-sm flex flex-col gap-4">
        <div className="flex items-center gap-2 justify-center mb-2">
          <Server size={20} className="text-accent" />
          <span className="font-medium">Panel</span>
        </div>
        <p className="text-xs text-neutral-500 text-center -mt-2 mb-1">
          The first account created becomes the panel administrator.
        </p>

        <label className="flex flex-col gap-1.5 text-xs text-neutral-500">
          Username
          <input
            required
            minLength={3}
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="rounded-md border border-base-700 bg-base-900 px-3 py-2 text-sm text-neutral-200"
          />
        </label>
        <label className="flex flex-col gap-1.5 text-xs text-neutral-500">
          Email
          <input
            required
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="rounded-md border border-base-700 bg-base-900 px-3 py-2 text-sm text-neutral-200"
          />
        </label>
        <label className="flex flex-col gap-1.5 text-xs text-neutral-500">
          Password
          <input
            required
            minLength={8}
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="rounded-md border border-base-700 bg-base-900 px-3 py-2 text-sm text-neutral-200"
          />
        </label>

        {error && <p className="text-xs text-danger">{error}</p>}

        <button
          type="submit"
          disabled={submitting}
          className="rounded-md bg-accent text-base-950 font-medium px-4 py-2 text-sm hover:bg-accent/90 disabled:opacity-50"
        >
          {submitting ? "Creating account…" : "Create account"}
        </button>

        <p className="text-xs text-neutral-500 text-center">
          Already have an account?{" "}
          <Link href="/login" className="text-accent hover:underline">
            Sign in
          </Link>
        </p>
      </form>
    </div>
  );
}
