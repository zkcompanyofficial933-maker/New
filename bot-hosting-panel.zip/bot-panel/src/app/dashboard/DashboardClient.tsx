"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, LogOut, Server } from "lucide-react";
import { BotCard } from "@/components/BotCard";
import { CreateBotForm } from "@/components/CreateBotForm";
import type { BotSummary } from "@/types";

export function DashboardClient({ username, role }: { username: string; role: string }) {
  const [bots, setBots] = useState<BotSummary[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const router = useRouter();

  const load = useCallback(async () => {
    const res = await fetch("/api/bots");
    const data = await res.json();
    if (res.ok) setBots(data.bots);
  }, []);

  useEffect(() => {
    load();
    const interval = setInterval(load, 5000);
    return () => clearInterval(interval);
  }, [load]);

  async function act(id: string, action: "start" | "stop" | "restart") {
    setBusyId(id);
    await fetch(`/api/bots/${id}/${action}`, { method: "POST" });
    await load();
    setBusyId(null);
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  }

  return (
    <div className="min-h-screen">
      <header className="border-b border-base-700">
        <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 font-medium">
            <Server size={18} className="text-accent" />
            Panel
          </div>
          <div className="flex items-center gap-4 text-sm text-neutral-400">
            <span className="font-data">{username}{role === "ADMIN" ? " · admin" : ""}</span>
            <button onClick={logout} className="flex items-center gap-1.5 hover:text-neutral-100">
              <LogOut size={14} /> Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-lg font-medium">Your bots</h1>
            <p className="text-sm text-neutral-500 mt-1">
              {bots.length} bot{bots.length === 1 ? "" : "s"} · isolated in Docker containers
            </p>
          </div>
          <button
            onClick={() => setShowCreate(true)}
            className="inline-flex items-center gap-1.5 rounded-md bg-accent text-base-950 font-medium px-4 py-2 text-sm hover:bg-accent/90"
          >
            <Plus size={15} /> New bot
          </button>
        </div>

        {bots.length === 0 ? (
          <div className="border border-dashed border-base-700 rounded-md p-12 text-center text-neutral-500">
            No bots yet. Create one to get started — pick a language, a start command, and
            optionally connect a Git repo.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {bots.map((bot) => (
              <BotCard
                key={bot.id}
                bot={bot}
                busy={busyId === bot.id}
                onStart={(id) => act(id, "start")}
                onStop={(id) => act(id, "stop")}
                onRestart={(id) => act(id, "restart")}
              />
            ))}
          </div>
        )}
      </main>

      {showCreate && (
        <CreateBotForm
          onClose={() => setShowCreate(false)}
          onCreated={() => {
            setShowCreate(false);
            load();
          }}
        />
      )}
    </div>
  );
}
