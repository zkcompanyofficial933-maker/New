"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, Play, Square, RotateCw, Trash2 } from "lucide-react";
import { StatusBadge } from "@/components/StatusBadge";
import { BotTerminal } from "@/components/BotTerminal";
import { LogViewer } from "@/components/LogViewer";
import { FileManager } from "@/components/FileManager";
import { SettingsPanel } from "@/components/SettingsPanel";
import { ResourceGauges } from "@/components/ResourceGauges";
import type { BotSummary } from "@/types";

type Tab = "console" | "logs" | "files" | "settings";

export function BotDetailClient({ initialBot }: { initialBot: BotSummary }) {
  const [bot, setBot] = useState<BotSummary>(initialBot);
  const [tab, setTab] = useState<Tab>("console");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function refresh() {
    const res = await fetch(`/api/bots/${bot.id}`);
    const d = await res.json();
    if (res.ok) setBot(d.bot);
  }

  async function act(action: "start" | "stop" | "restart") {
    setBusy(true);
    const res = await fetch(`/api/bots/${bot.id}/${action}`, { method: "POST" });
    const d = await res.json();
    setBusy(false);
    if (res.ok) setBot(d.bot);
  }

  async function remove() {
    if (!confirm(`Delete "${bot.name}" and all of its files? This cannot be undone.`)) return;
    await fetch(`/api/bots/${bot.id}`, { method: "DELETE" });
    router.push("/dashboard");
  }

  const isRunning = bot.status === "RUNNING";
  const isBusy = busy || bot.status === "BUILDING" || bot.status === "DELETING";

  return (
    <div className="min-h-screen">
      <header className="border-b border-base-700">
        <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/dashboard" className="text-neutral-500 hover:text-neutral-200">
              <ArrowLeft size={18} />
            </Link>
            <div>
              <h1 className="text-[15px] font-medium leading-tight">{bot.name}</h1>
              <div className="flex items-center gap-2 text-xs text-neutral-500 font-data">
                <span>{bot.language}</span>
                <span>·</span>
                <StatusBadge status={bot.status} />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!isRunning ? (
              <button
                onClick={() => act("start")}
                disabled={isBusy}
                className="inline-flex items-center gap-1.5 rounded-md bg-accent/10 text-accent px-3 py-1.5 text-sm hover:bg-accent/20 disabled:opacity-50"
              >
                <Play size={14} /> Start
              </button>
            ) : (
              <button
                onClick={() => act("stop")}
                disabled={isBusy}
                className="inline-flex items-center gap-1.5 rounded-md bg-danger/10 text-danger px-3 py-1.5 text-sm hover:bg-danger/20 disabled:opacity-50"
              >
                <Square size={14} /> Stop
              </button>
            )}
            <button
              onClick={() => act("restart")}
              disabled={isBusy || bot.status === "CREATED"}
              className="inline-flex items-center gap-1.5 rounded-md bg-base-800 px-3 py-1.5 text-sm text-neutral-300 hover:bg-base-700 disabled:opacity-40"
            >
              <RotateCw size={14} /> Restart
            </button>
            <button
              onClick={remove}
              className="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm text-neutral-500 hover:text-danger"
            >
              <Trash2 size={14} />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-6">
        <div className="mb-5">
          <ResourceGauges botId={bot.id} running={isRunning} />
        </div>

        <div className="flex items-center gap-1 border-b border-base-700 mb-5">
          {(["console", "logs", "files", "settings"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-3 py-2 text-sm capitalize border-b-2 -mb-px ${
                tab === t
                  ? "border-accent text-neutral-100"
                  : "border-transparent text-neutral-500 hover:text-neutral-300"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {tab === "console" && <BotTerminal botId={bot.id} />}
        {tab === "logs" && <LogViewer botId={bot.id} />}
        {tab === "files" && <FileManager botId={bot.id} />}
        {tab === "settings" && <SettingsPanel bot={bot} onUpdated={refresh} />}
      </main>
    </div>
  );
}
