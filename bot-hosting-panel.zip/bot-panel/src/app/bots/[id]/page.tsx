import { redirect, notFound } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { BotDetailClient } from "./BotDetailClient";

export default async function BotDetailPage({ params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const bot = await prisma.bot.findUnique({ where: { id: params.id } });
  if (!bot) notFound();
  if (bot.ownerId !== user.id && user.role !== "ADMIN") notFound();

  return (
    <BotDetailClient
      initialBot={{
        ...bot,
        createdAt: bot.createdAt.toISOString(),
        updatedAt: bot.updatedAt.toISOString(),
      }}
    />
  );
}
