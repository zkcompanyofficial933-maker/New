"use client";

import Link from "next/link";
import { Play, Square, RotateCw, Terminal as TerminalIcon } from "lucide-react";
import { StatusBadge } from "./StatusBadge";
import { cn } from "@/lib/utils";
import type { BotSummary } from "@/types";

const LANGUAGE_LABEL: Record<string, string> = {
  PYTHON: "Python",
  NODEJS: "Node.js",
  JAVA: "Java",
};

const STATUS_BORDER: Record<string, string> = {
  RUNNING: "border-l-accent",
  STOPPED: "border-l-base-600",
  BUILDING: "border-l-warn",
  CRASHED: "border-l-danger",
  CREATED: "border-l-base-600",
  DELETING: "border-l-danger",
};

export function BotCard({
  bot,
  onStart,
  onStop,
  onRestart,
  busy,
}: {
  bot: BotSummary;
  onStart: (id: string) => void;
  onStop: (id: string) => void;
  onRestart: (id: string) => void;
  busy: boolean;
}) {
  const isRunning = bot.status === "RUNNING";
  const isBusy = bot.status === "BUILDING" || bot.status === "DELETING" || busy;

  return (
    <div
      className={cn(
        "border-l-2 border border-base-700 bg-base-900 rounded-r-md p-4 flex flex-col gap-3",
        STATUS_BORDER[bot.status]
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div>
          <Link href={`/bots/${bot.id}`} className="text-[15px] font-medium hover:text-accent">
            {bot.name}
          </Link>
          <div className="mt-1 flex items-center gap-3 text-xs text-neutral-500 font-data">
            <span>{LANGUAGE_LABEL[bot.language]}</span>
            <span>·</span>
            <span>{bot.cpuLimit} vCPU</span>
            <span>·</span>
            <span>{bot.ramLimit} MB</span>
          </div>
        </div>
        <StatusBadge status={bot.status} />
      </div>

      <div className="flex items-center gap-2 pt-1">
        {!isRunning ? (
          <button
            onClick={() => onStart(bot.id)}
            disabled={isBusy}
            className="inline-flex items-center gap-1.5 rounded-md bg-accent/10 text-accent px-3 py-1.5 text-sm hover:bg-accent/20 disabled:opacity-50"
          >
            <Play size={14} /> Start
          </button>
        ) : (
          <button
            onClick={() => onStop(bot.id)}
            disabled={isBusy}
            className="inline-flex items-center gap-1.5 rounded-md bg-danger/10 text-danger px-3 py-1.5 text-sm hover:bg-danger/20 disabled:opacity-50"
          >
            <Square size={14} /> Stop
          </button>
        )}
        <button
          onClick={() => onRestart(bot.id)}
          disabled={isBusy || bot.status === "CREATED"}
          className="inline-flex items-center gap-1.5 rounded-md bg-base-800 px-3 py-1.5 text-sm text-neutral-300 hover:bg-base-700 disabled:opacity-40"
        >
          <RotateCw size={14} /> Restart
        </button>
        <Link
          href={`/bots/${bot.id}`}
          className="ml-auto inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm text-neutral-400 hover:text-neutral-100"
        >
          <TerminalIcon size={14} /> Console
        </Link>
      </div>
    </div>
  );
}
