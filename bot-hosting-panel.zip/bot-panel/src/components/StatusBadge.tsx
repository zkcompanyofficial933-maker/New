import { cn } from "@/lib/utils";
import type { BotStatus } from "@/types";

const STATUS_META: Record<BotStatus, { label: string; dot: string; text: string }> = {
  RUNNING: { label: "Running", dot: "bg-accent", text: "text-accent" },
  STOPPED: { label: "Stopped", dot: "bg-base-600", text: "text-neutral-400" },
  BUILDING: { label: "Building", dot: "bg-warn animate-pulse", text: "text-warn" },
  CRASHED: { label: "Crashed", dot: "bg-danger", text: "text-danger" },
  CREATED: { label: "Not deployed", dot: "bg-base-600", text: "text-neutral-500" },
  DELETING: { label: "Deleting", dot: "bg-danger animate-pulse", text: "text-danger" },
};

export function StatusBadge({ status }: { status: BotStatus }) {
  const meta = STATUS_META[status];
  return (
    <span className="inline-flex items-center gap-2 font-data text-xs">
      <span className={cn("h-2 w-2 rounded-full", meta.dot)} />
      <span className={meta.text}>{meta.label}</span>
    </span>
  );
}
