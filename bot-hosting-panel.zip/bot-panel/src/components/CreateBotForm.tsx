"use client";

import { useState } from "react";
import { X } from "lucide-react";

const ENTRYPOINT_HINTS: Record<string, string> = {
  PYTHON: "python bot.py",
  NODEJS: "node index.js",
  JAVA: "java -jar bot.jar",
};

export function CreateBotForm({ onCreated, onClose }: { onCreated: () => void; onClose: () => void }) {
  const [name, setName] = useState("");
  const [language, setLanguage] = useState<"PYTHON" | "NODEJS" | "JAVA">("NODEJS");
  const [kind, setKind] = useState<"DISCORD" | "TELEGRAM" | "WHATSAPP" | "GENERIC">("DISCORD");
  const [entrypoint, setEntrypoint] = useState(ENTRYPOINT_HINTS.NODEJS);
  const [gitRepoUrl, setGitRepoUrl] = useState("");
  const [gitBranch, setGitBranch] = useState("main");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    const res = await fetch("/api/bots", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        language,
        kind,
        entrypoint,
        gitRepoUrl: gitRepoUrl || undefined,
        gitBranch,
      }),
    });
    setSubmitting(false);
    if (res.ok) {
      onCreated();
    } else {
      const d = await res.json();
      setError(d.error ?? "Failed to create bot.");
    }
  }

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <form
        onSubmit={submit}
        className="w-full max-w-lg border border-base-700 bg-base-900 rounded-md p-5 flex flex-col gap-4"
      >
        <div className="flex items-center justify-between">
          <h2 className="text-base font-medium">New bot</h2>
          <button type="button" onClick={onClose} className="text-neutral-500 hover:text-neutral-200">
            <X size={18} />
          </button>
        </div>

        <label className="flex flex-col gap-1.5 text-xs text-neutral-500">
          Name
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="My Discord Bot"
            className="rounded-md border border-base-700 bg-base-950 px-3 py-2 text-sm text-neutral-200"
          />
        </label>

        <div className="grid grid-cols-2 gap-3">
          <label className="flex flex-col gap-1.5 text-xs text-neutral-500">
            Language
            <select
              value={language}
              onChange={(e) => {
                const lang = e.target.value as typeof language;
                setLanguage(lang);
                setEntrypoint(ENTRYPOINT_HINTS[lang]);
              }}
              className="rounded-md border border-base-700 bg-base-950 px-3 py-2 text-sm text-neutral-200"
            >
              <option value="PYTHON">Python</option>
              <option value="NODEJS">Node.js</option>
              <option value="JAVA">Java</option>
            </select>
          </label>
          <label className="flex flex-col gap-1.5 text-xs text-neutral-500">
            Platform
            <select
              value={kind}
              onChange={(e) => setKind(e.target.value as typeof kind)}
              className="rounded-md border border-base-700 bg-base-950 px-3 py-2 text-sm text-neutral-200"
            >
              <option value="DISCORD">Discord</option>
              <option value="TELEGRAM">Telegram</option>
              <option value="WHATSAPP">WhatsApp</option>
              <option value="GENERIC">Generic</option>
            </select>
          </label>
        </div>

        <label className="flex flex-col gap-1.5 text-xs text-neutral-500">
          Start command
          <input
            required
            value={entrypoint}
            onChange={(e) => setEntrypoint(e.target.value)}
            className="rounded-md border border-base-700 bg-base-950 px-3 py-2 text-sm font-data text-neutral-200"
          />
        </label>

        <div className="grid grid-cols-[1fr_120px] gap-3">
          <label className="flex flex-col gap-1.5 text-xs text-neutral-500">
            Git repository (optional)
            <input
              value={gitRepoUrl}
              onChange={(e) => setGitRepoUrl(e.target.value)}
              placeholder="https://github.com/you/bot.git"
              className="rounded-md border border-base-700 bg-base-950 px-3 py-2 text-sm font-data text-neutral-200"
            />
          </label>
          <label className="flex flex-col gap-1.5 text-xs text-neutral-500">
            Branch
            <input
              value={gitBranch}
              onChange={(e) => setGitBranch(e.target.value)}
              className="rounded-md border border-base-700 bg-base-950 px-3 py-2 text-sm font-data text-neutral-200"
            />
          </label>
        </div>

        {error && <p className="text-xs text-danger">{error}</p>}

        <div className="flex justify-end gap-2 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="rounded-md px-3 py-2 text-sm text-neutral-400 hover:text-neutral-100"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="rounded-md bg-accent text-base-950 font-medium px-4 py-2 text-sm hover:bg-accent/90 disabled:opacity-50"
          >
            {submitting ? "Creating…" : "Create bot"}
          </button>
        </div>
      </form>
    </div>
  );
}
