"use client";

import { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import { Search, Trash2, ArrowDownToLine } from "lucide-react";

export function LogViewer({ botId }: { botId: string }) {
  const [lines, setLines] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const [autoScroll, setAutoScroll] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    const socket = io("/logs", { path: "/socket.io" });
    socketRef.current = socket;

    socket.on("connect", () => socket.emit("subscribe", { botId }));
    socket.on("log", (chunk: string) => {
      setLines((prev) => {
        const next = [...prev, ...chunk.split(/\r?\n/).filter(Boolean)];
        return next.length > 2000 ? next.slice(next.length - 2000) : next;
      });
    });
    socket.on("error", (msg: string) => setLines((prev) => [...prev, `[error] ${msg}`]));

    return () => socket.disconnect();
  }, [botId]);

  useEffect(() => {
    if (autoScroll && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [lines, autoScroll]);

  const filtered = query ? lines.filter((l) => l.toLowerCase().includes(query.toLowerCase())) : lines;

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-2.5 top-2.5 text-neutral-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter logs..."
            className="w-full rounded-md border border-base-700 bg-base-900 pl-8 pr-3 py-1.5 text-sm font-data placeholder:text-neutral-600 focus:outline-none focus:border-accent"
          />
        </div>
        <label className="flex items-center gap-1.5 text-xs text-neutral-400 select-none">
          <input
            type="checkbox"
            checked={autoScroll}
            onChange={(e) => setAutoScroll(e.target.checked)}
          />
          Auto-scroll
        </label>
        <button
          onClick={() => scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight })}
          className="rounded-md p-1.5 text-neutral-400 hover:bg-base-800"
          title="Jump to latest"
        >
          <ArrowDownToLine size={14} />
        </button>
        <button
          onClick={() => setLines([])}
          className="rounded-md p-1.5 text-neutral-400 hover:bg-base-800"
          title="Clear"
        >
          <Trash2 size={14} />
        </button>
      </div>

      <div
        ref={scrollRef}
        className="h-[420px] overflow-y-auto scroll-thin rounded-md border border-base-700 bg-[#0b0e14] p-3 font-data text-[13px] leading-relaxed"
      >
        {filtered.length === 0 ? (
          <p className="text-neutral-600">Waiting for output…</p>
        ) : (
          filtered.map((line, i) => (
            <div
              key={i}
              className={line.toLowerCase().includes("error") ? "text-danger" : "text-neutral-300"}
            >
              {line}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
