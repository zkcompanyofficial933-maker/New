"use client";

import { useEffect, useState } from "react";
import { GitBranch, Plus, Trash2, Save } from "lucide-react";
import type { BotSummary } from "@/types";

export function SettingsPanel({ bot, onUpdated }: { bot: BotSummary; onUpdated: () => void }) {
  const [cpuLimit, setCpuLimit] = useState(bot.cpuLimit);
  const [ramLimit, setRamLimit] = useState(bot.ramLimit);
  const [gitRepoUrl, setGitRepoUrl] = useState(bot.gitRepoUrl ?? "");
  const [gitBranch, setGitBranch] = useState(bot.gitBranch);
  const [autoRestart, setAutoRestart] = useState(bot.autoRestart);
  const [saving, setSaving] = useState(false);
  const [deploying, setDeploying] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const [envKeys, setEnvKeys] = useState<{ id: string; key: string }[]>([]);
  const [envDraft, setEnvDraft] = useState<{ key: string; value: string }[]>([]);

  useEffect(() => {
    fetch(`/api/bots/${bot.id}/env`)
      .then((r) => r.json())
      .then((d) => {
        setEnvKeys(d.envVars);
        setEnvDraft(d.envVars.map((v: any) => ({ key: v.key, value: "" })));
      });
  }, [bot.id]);

  async function saveSettings() {
    setSaving(true);
    setMessage(null);
    const res = await fetch(`/api/bots/${bot.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ cpuLimit, ramLimit, gitRepoUrl, gitBranch, autoRestart }),
    });
    setSaving(false);
    if (res.ok) {
      setMessage("Saved. Resource changes apply on next start/restart.");
      onUpdated();
    } else {
      const d = await res.json();
      setMessage(d.error ?? "Failed to save.");
    }
  }

  async function saveEnvVars() {
    const vars = envDraft.filter((v) => v.key.trim() !== "");
    const res = await fetch(`/api/bots/${bot.id}/env`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ vars }),
    });
    if (res.ok) {
      setMessage("Environment variables updated. Restart the bot to apply them.");
      const d = await fetch(`/api/bots/${bot.id}/env`).then((r) => r.json());
      setEnvKeys(d.envVars);
    }
  }

  async function deployNow() {
    setDeploying(true);
    setMessage(null);
    const res = await fetch(`/api/bots/${bot.id}/deploy`, { method: "POST" });
    const d = await res.json();
    setDeploying(false);
    setMessage(res.ok ? `Deployed commit ${d.deploy?.commit?.slice(0, 7)}.` : d.error);
    onUpdated();
  }

  return (
    <div className="grid grid-cols-2 gap-6 max-w-3xl">
      <section className="col-span-2 border border-base-700 rounded-md bg-base-900 p-4">
        <h3 className="text-sm font-medium mb-3">Resource limits</h3>
        <div className="grid grid-cols-2 gap-4">
          <label className="text-xs text-neutral-500 flex flex-col gap-1.5">
            CPU limit (cores)
            <input
              type="number"
              min={0.1}
              max={8}
              step={0.1}
              value={cpuLimit}
              onChange={(e) => setCpuLimit(parseFloat(e.target.value))}
              className="rounded-md border border-base-700 bg-base-950 px-3 py-1.5 text-sm font-data text-neutral-200"
            />
          </label>
          <label className="text-xs text-neutral-500 flex flex-col gap-1.5">
            RAM limit (MB)
            <input
              type="number"
              min={128}
              max={16384}
              step={64}
              value={ramLimit}
              onChange={(e) => setRamLimit(parseInt(e.target.value, 10))}
              className="rounded-md border border-base-700 bg-base-950 px-3 py-1.5 text-sm font-data text-neutral-200"
            />
          </label>
        </div>
        <label className="mt-4 flex items-center gap-2 text-sm text-neutral-300">
          <input type="checkbox" checked={autoRestart} onChange={(e) => setAutoRestart(e.target.checked)} />
          Automatically restart if the bot crashes
        </label>
      </section>

      <section className="col-span-2 border border-base-700 rounded-md bg-base-900 p-4">
        <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
          <GitBranch size={14} /> Git deployment
        </h3>
        <div className="flex flex-col gap-3">
          <input
            placeholder="https://github.com/you/your-bot.git"
            value={gitRepoUrl}
            onChange={(e) => setGitRepoUrl(e.target.value)}
            className="rounded-md border border-base-700 bg-base-950 px-3 py-1.5 text-sm font-data text-neutral-200"
          />
          <input
            placeholder="branch (default: main)"
            value={gitBranch}
            onChange={(e) => setGitBranch(e.target.value)}
            className="rounded-md border border-base-700 bg-base-950 px-3 py-1.5 text-sm font-data text-neutral-200 w-48"
          />
          <button
            onClick={deployNow}
            disabled={!bot.gitRepoUrl || deploying}
            className="self-start rounded-md bg-accent/10 text-accent px-3 py-1.5 text-sm hover:bg-accent/20 disabled:opacity-40"
          >
            {deploying ? "Deploying…" : "Pull latest & redeploy"}
          </button>
          {bot.lastCommit && (
            <p className="text-xs text-neutral-500 font-data">last deployed: {bot.lastCommit.slice(0, 7)}</p>
          )}
        </div>
      </section>

      <section className="col-span-2 border border-base-700 rounded-md bg-base-900 p-4">
        <h3 className="text-sm font-medium mb-3">Environment variables</h3>
        <p className="text-xs text-neutral-500 mb-3">
          Values are encrypted at rest and not shown again after saving — leave a row's value blank
          to keep its current value unchanged.
        </p>
        <div className="flex flex-col gap-2">
          {envDraft.map((v, i) => (
            <div key={i} className="flex items-center gap-2">
              <input
                placeholder="KEY"
                value={v.key}
                onChange={(e) => {
                  const next = [...envDraft];
                  next[i] = { ...next[i], key: e.target.value.toUpperCase() };
                  setEnvDraft(next);
                }}
                className="w-1/3 rounded-md border border-base-700 bg-base-950 px-3 py-1.5 text-sm font-data"
              />
              <input
                placeholder="value"
                type="password"
                value={v.value}
                onChange={(e) => {
                  const next = [...envDraft];
                  next[i] = { ...next[i], value: e.target.value };
                  setEnvDraft(next);
                }}
                className="flex-1 rounded-md border border-base-700 bg-base-950 px-3 py-1.5 text-sm font-data"
              />
              <button
                onClick={() => setEnvDraft(envDraft.filter((_, j) => j !== i))}
                className="p-1.5 text-neutral-500 hover:text-danger"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
          <button
            onClick={() => setEnvDraft([...envDraft, { key: "", value: "" }])}
            className="self-start inline-flex items-center gap-1.5 text-sm text-neutral-400 hover:text-neutral-100"
          >
            <Plus size={14} /> Add variable
          </button>
          <button
            onClick={saveEnvVars}
            className="self-start mt-2 rounded-md bg-base-800 px-3 py-1.5 text-sm text-neutral-200 hover:bg-base-700"
          >
            Save environment variables
          </button>
        </div>
      </section>

      <div className="col-span-2 flex items-center gap-3">
        <button
          onClick={saveSettings}
          disabled={saving}
          className="inline-flex items-center gap-1.5 rounded-md bg-accent text-base-950 font-medium px-4 py-2 text-sm hover:bg-accent/90 disabled:opacity-50"
        >
          <Save size={14} /> {saving ? "Saving…" : "Save settings"}
        </button>
        {message && <p className="text-xs text-neutral-400">{message}</p>}
      </div>
    </div>
  );
}
