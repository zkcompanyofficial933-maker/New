"use client";

import { useEffect, useRef } from "react";
import { Terminal } from "xterm";
import { FitAddon } from "xterm-addon-fit";
import { io, Socket } from "socket.io-client";
import "xterm/css/xterm.css";

export function BotTerminal({ botId }: { botId: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const term = new Terminal({
      convertEol: true,
      fontFamily: "'JetBrains Mono', monospace",
      fontSize: 13,
      theme: {
        background: "#0b0e14",
        foreground: "#e7ebf3",
        cursor: "#4fd1a5",
      },
    });
    const fitAddon = new FitAddon();
    term.loadAddon(fitAddon);
    term.open(containerRef.current);
    fitAddon.fit();
    term.writeln("Connecting to container shell...");

    const socket = io("/terminal", { path: "/socket.io" });
    socketRef.current = socket;

    socket.on("connect", () => {
      socket.emit("start", { botId, cols: term.cols, rows: term.rows });
    });

    socket.on("ready", () => term.writeln("\r\n[connected]\r\n"));
    socket.on("data", (chunk: string) => term.write(chunk));
    socket.on("exit", () => term.writeln("\r\n[session ended]"));
    socket.on("error", (msg: string) => term.writeln(`\r\n[error] ${msg}`));

    term.onData((data) => socket.emit("input", data));

    const resizeObserver = new ResizeObserver(() => {
      fitAddon.fit();
      socket.emit("resize", { cols: term.cols, rows: term.rows });
    });
    resizeObserver.observe(containerRef.current);

    return () => {
      resizeObserver.disconnect();
      socket.disconnect();
      term.dispose();
    };
  }, [botId]);

  return (
    <div className="rounded-md border border-base-700 bg-[#0b0e14] overflow-hidden">
      <div ref={containerRef} className="h-[420px]" />
    </div>
  );
}
