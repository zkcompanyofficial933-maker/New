"use client";

import { useEffect, useState } from "react";
import { io, Socket } from "socket.io-client";
import { Cpu, MemoryStick, Activity } from "lucide-react";

interface Stats {
  cpuPercent: number;
  memUsageMB: number;
  memLimitMB: number;
  memPercent: number;
  pids: number;
}

export function ResourceGauges({ botId, running }: { botId: string; running: boolean }) {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    if (!running) {
      setStats(null);
      return;
    }
    const socket: Socket = io("/stats", { path: "/socket.io" });
    socket.on("connect", () => socket.emit("subscribe", { botId }));
    socket.on("stats", (s: Stats) => setStats(s));
    return () => socket.disconnect();
  }, [botId, running]);

  if (!running) {
    return (
      <div className="text-xs text-neutral-600 border border-base-700 rounded-md p-4 bg-base-900">
        Start the bot to see live resource usage.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-3 gap-3">
      <Gauge icon={<Cpu size={14} />} label="CPU" value={`${stats?.cpuPercent ?? 0}%`} />
      <Gauge
        icon={<MemoryStick size={14} />}
        label="Memory"
        value={`${stats?.memUsageMB ?? 0} / ${stats?.memLimitMB ?? 0} MB`}
        sub={`${stats?.memPercent ?? 0}%`}
      />
      <Gauge icon={<Activity size={14} />} label="Processes" value={`${stats?.pids ?? 0}`} />
    </div>
  );
}

function Gauge({
  icon,
  label,
  value,
  sub,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
}) {
  return (
    <div className="border border-base-700 rounded-md bg-base-900 p-3">
      <div className="flex items-center gap-1.5 text-xs text-neutral-500">
        {icon}
        {label}
      </div>
      <div className="mt-1.5 font-data text-lg text-neutral-100">{value}</div>
      {sub && <div className="text-[11px] text-neutral-600 font-data">{sub}</div>}
    </div>
  );
}
