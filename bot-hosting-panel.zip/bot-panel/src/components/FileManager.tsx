"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Folder,
  File as FileIcon,
  ChevronRight,
  Upload,
  FilePlus,
  FolderPlus,
  Trash2,
  Download,
  Save,
} from "lucide-react";
import type { FileNode } from "@/types";

export function FileManager({ botId }: { botId: string }) {
  const [path, setPath] = useState(".");
  const [nodes, setNodes] = useState<FileNode[]>([]);
  const [openFile, setOpenFile] = useState<string | null>(null);
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (dir: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/bots/${botId}/files?path=${encodeURIComponent(dir)}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setNodes(data.nodes);
      setPath(dir);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [botId]);

  useEffect(() => {
    load(".");
  }, [load]);

  async function openFileForEdit(relPath: string) {
    setError(null);
    try {
      const res = await fetch(
        `/api/bots/${botId}/files?path=${encodeURIComponent(relPath)}&read=1`
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setOpenFile(relPath);
      setContent(data.content);
    } catch (e: any) {
      setError(e.message);
    }
  }

  async function saveFile() {
    if (!openFile) return;
    const res = await fetch(`/api/bots/${botId}/files`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "write-file", path: openFile, content }),
    });
    if (!res.ok) {
      const data = await res.json();
      setError(data.error);
    }
  }

  async function createNode(type: "file" | "directory") {
    const name = prompt(type === "file" ? "New file name:" : "New folder name:");
    if (!name) return;
    const target = path === "." ? name : `${path}/${name}`;
    await fetch(`/api/bots/${botId}/files`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: type === "file" ? "write-file" : "create-dir",
        path: target,
        content: "",
      }),
    });
    load(path);
  }

  async function removeNode(relPath: string) {
    if (!confirm(`Delete ${relPath}? This cannot be undone.`)) return;
    await fetch(`/api/bots/${botId}/files`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "delete", path: relPath }),
    });
    load(path);
  }

  async function uploadFile(file: File) {
    const form = new FormData();
    form.append("file", file);
    form.append("path", path);
    await fetch(`/api/bots/${botId}/files/upload`, { method: "POST", body: form });
    load(path);
  }

  const crumbs = path === "." ? [] : path.split("/");

  return (
    <div className="grid grid-cols-[280px_1fr] gap-4 h-[480px]">
      <div className="border border-base-700 rounded-md bg-base-900 flex flex-col">
        <div className="flex items-center gap-1 p-2 border-b border-base-700">
          <button onClick={() => createNode("file")} title="New file" className="p-1.5 rounded hover:bg-base-800 text-neutral-400">
            <FilePlus size={15} />
          </button>
          <button onClick={() => createNode("directory")} title="New folder" className="p-1.5 rounded hover:bg-base-800 text-neutral-400">
            <FolderPlus size={15} />
          </button>
          <label className="p-1.5 rounded hover:bg-base-800 text-neutral-400 cursor-pointer" title="Upload">
            <Upload size={15} />
            <input
              type="file"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && uploadFile(e.target.files[0])}
            />
          </label>
        </div>

        <div className="flex items-center gap-1 px-2 py-1.5 text-xs text-neutral-500 font-data border-b border-base-700 overflow-x-auto">
          <button onClick={() => load(".")} className="hover:text-accent">workspace</button>
          {crumbs.map((c, i) => (
            <span key={i} className="flex items-center gap-1">
              <ChevronRight size={12} />
              <button onClick={() => load(crumbs.slice(0, i + 1).join("/"))} className="hover:text-accent">
                {c}
              </button>
            </span>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto scroll-thin">
          {loading && <p className="p-3 text-sm text-neutral-500">Loading…</p>}
          {!loading && nodes.length === 0 && (
            <p className="p-3 text-sm text-neutral-600">Empty directory.</p>
          )}
          {nodes.map((node) => (
            <div
              key={node.path}
              className="group flex items-center justify-between px-3 py-1.5 hover:bg-base-800 cursor-pointer text-sm"
              onClick={() => (node.type === "directory" ? load(node.path) : openFileForEdit(node.path))}
            >
              <span className="flex items-center gap-2 truncate">
                {node.type === "directory" ? (
                  <Folder size={14} className="text-accent shrink-0" />
                ) : (
                  <FileIcon size={14} className="text-neutral-500 shrink-0" />
                )}
                <span className="truncate">{node.name}</span>
              </span>
              <span className="hidden group-hover:flex items-center gap-1">
                {node.type === "file" && (
                  <a
                    href={`/api/bots/${botId}/files/download?path=${encodeURIComponent(node.path)}`}
                    onClick={(e) => e.stopPropagation()}
                    className="p-1 text-neutral-400 hover:text-neutral-100"
                  >
                    <Download size={13} />
                  </a>
                )}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    removeNode(node.path);
                  }}
                  className="p-1 text-neutral-400 hover:text-danger"
                >
                  <Trash2 size={13} />
                </button>
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="border border-base-700 rounded-md bg-base-900 flex flex-col">
        {openFile ? (
          <>
            <div className="flex items-center justify-between px-3 py-2 border-b border-base-700">
              <span className="font-data text-sm text-neutral-300">{openFile}</span>
              <button
                onClick={saveFile}
                className="inline-flex items-center gap-1.5 rounded-md bg-accent/10 text-accent px-3 py-1 text-sm hover:bg-accent/20"
              >
                <Save size={13} /> Save
              </button>
            </div>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              spellCheck={false}
              className="flex-1 resize-none bg-transparent p-3 font-data text-[13px] leading-relaxed text-neutral-200 focus:outline-none"
            />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-sm text-neutral-600">
            Select a file to view or edit it.
          </div>
        )}
      </div>

      {error && (
        <div className="col-span-2 text-xs text-danger">{error}</div>
      )}
    </div>
  );
}
