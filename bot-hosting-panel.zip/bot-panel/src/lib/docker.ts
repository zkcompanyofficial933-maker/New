import Docker from "dockerode";
import type { Container } from "dockerode";
import path from "path";
import fs from "fs/promises";
import type { ContainerStats, Language, RestartPolicyName } from "@/types";

// ------------------------------------------------------------------
// Docker client
// Connects to the host daemon via the bind-mounted socket
// (see docker-compose.yml -> /var/run/docker.sock).
// ------------------------------------------------------------------
export const docker = new Docker({ socketPath: "/var/run/docker.sock" });

const WORKSPACES_ROOT = process.env.BOT_WORKSPACES_ROOT || "/workspaces";

const RUNTIME_IMAGES: Record<Language, string> = {
  PYTHON: process.env.RUNTIME_IMAGE_PYTHON || "bot-panel-runtime-python:3.11",
  NODEJS: process.env.RUNTIME_IMAGE_NODEJS || "bot-panel-runtime-nodejs:18",
  JAVA: process.env.RUNTIME_IMAGE_JAVA || "bot-panel-runtime-java:17",
};

const DEFAULT_INSTALL_COMMAND: Record<Language, string | null> = {
  PYTHON: "if [ -f requirements.txt ]; then pip install --no-cache-dir --user -r requirements.txt; fi",
  NODEJS: "if [ -f package.json ]; then npm install --no-audit --no-fund; fi",
  JAVA: "if [ -f pom.xml ]; then mvn -q -DskipTests package; fi",
};

export function workspacePathFor(botId: string): string {
  return path.join(WORKSPACES_ROOT, botId);
}

export async function ensureWorkspace(botId: string): Promise<string> {
  const dir = workspacePathFor(botId);
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

function containerNameFor(botId: string) {
  return `bot-panel-${botId}`;
}

function toRestartPolicy(name: RestartPolicyName) {
  // Docker's "on-failure" supports a MaximumRetryCount; we cap it to avoid
  // infinite crash loops burning CPU when autoRestart is enabled.
  if (name === "on-failure") return { Name: "on-failure", MaximumRetryCount: 5 };
  return { Name: name };
}

export interface CreateContainerOptions {
  botId: string;
  language: Language;
  entrypoint: string; // e.g. "python bot.py"
  cpuLimit: number; // cores
  ramLimit: number; // MB
  env: Record<string, string>;
  restartPolicy: RestartPolicyName;
  runInstallStep?: boolean;
}

/**
 * Creates (but does not start) a container for a bot. Any previous container
 * with the same name is removed first so re-deploys behave predictably.
 */
export async function createBotContainer(opts: CreateContainerOptions): Promise<Container> {
  const { botId, language, entrypoint, cpuLimit, ramLimit, env, restartPolicy } = opts;
  const image = RUNTIME_IMAGES[language];
  const workspace = await ensureWorkspace(botId);
  const name = containerNameFor(botId);

  await removeContainerIfExists(name);

  const installCmd = opts.runInstallStep ? DEFAULT_INSTALL_COMMAND[language] : null;
  const shellCommand = [installCmd, entrypoint].filter(Boolean).join(" && ");

  const envList = Object.entries(env).map(([k, v]) => `${k}=${v}`);

  const container = await docker.createContainer({
    name,
    Image: image,
    Cmd: [shellCommand],
    Tty: true, // enables a real pty for the interactive terminal
    OpenStdin: true,
    Env: envList,
    WorkingDir: "/workspace",
    HostConfig: {
      Binds: [`${workspace}:/workspace:rw`],
      NanoCpus: Math.max(0.1, cpuLimit) * 1_000_000_000,
      Memory: Math.max(64, ramLimit) * 1024 * 1024,
      MemorySwap: Math.max(64, ramLimit) * 1024 * 1024, // disable swap beyond limit
      PidsLimit: 256, // fork-bomb protection
      RestartPolicy: toRestartPolicy(restartPolicy),
      // Drop unneeded privileges — bots never need host device/network access
      CapDrop: ["ALL"],
      SecurityOpt: ["no-new-privileges"],
      ReadonlyRootfs: false, // workspace bind mount needs write access
      NetworkMode: "bridge",
    },
    Labels: {
      "bot-panel.bot-id": botId,
      "bot-panel.managed": "true",
    },
  });

  return container;
}

async function removeContainerIfExists(name: string) {
  try {
    const existing = docker.getContainer(name);
    const info = await existing.inspect();
    if (info.State.Running) {
      await existing.stop({ t: 5 }).catch(() => void 0);
    }
    await existing.remove({ force: true });
  } catch {
    // Container didn't exist — nothing to do.
  }
}

export function getContainer(containerId: string): Container {
  return docker.getContainer(containerId);
}

export async function startContainer(containerId: string): Promise<void> {
  await docker.getContainer(containerId).start();
}

export async function stopContainer(containerId: string, timeoutSec = 10): Promise<void> {
  await docker.getContainer(containerId).stop({ t: timeoutSec });
}

export async function restartContainer(containerId: string, timeoutSec = 10): Promise<void> {
  await docker.getContainer(containerId).restart({ t: timeoutSec });
}

export async function removeContainer(containerId: string): Promise<void> {
  const c = docker.getContainer(containerId);
  try {
    await c.stop({ t: 5 });
  } catch {
    /* already stopped */
  }
  await c.remove({ force: true });
}

export async function inspectContainer(containerId: string) {
  return docker.getContainer(containerId).inspect();
}

/**
 * Streams stdout/stderr from a running (or exited, for history) container.
 * `onChunk` is invoked for every buffer received; caller wires this to a
 * WebSocket. Returns a function to detach/stop the stream.
 */
export async function streamContainerLogs(
  containerId: string,
  onChunk: (data: string) => void
): Promise<() => void> {
  const container = docker.getContainer(containerId);
  const stream = await container.logs({
    follow: true,
    stdout: true,
    stderr: true,
    tail: 200,
  });

  stream.on("data", (chunk: Buffer) => onChunk(demuxLogChunk(chunk)));
  stream.on("error", () => void 0);

  return () => {
    // dockerode's log stream is a plain Duplex; destroying it ends `follow`.
    // @ts-expect-error - destroy exists on the underlying stream
    stream.destroy?.();
  };
}

/**
 * Docker multiplexes stdout/stderr with an 8-byte header per frame when Tty
 * is false. Since we run containers with Tty: true for the interactive
 * terminal, log frames are NOT multiplexed — this passthrough is kept for
 * safety in case Tty is ever disabled for a given bot.
 */
function demuxLogChunk(chunk: Buffer): string {
  return chunk.toString("utf8");
}

/**
 * Attaches an interactive exec session (real pty) to a running container,
 * for the xterm.js terminal. Returns the duplex stream plus a resize fn.
 */
export async function attachInteractiveShell(containerId: string) {
  const container = docker.getContainer(containerId);
  const exec = await container.exec({
    Cmd: ["/bin/sh"],
    AttachStdin: true,
    AttachStdout: true,
    AttachStderr: true,
    Tty: true,
  });

  const stream = await exec.start({ hijack: true, stdin: true, Tty: true });

  const resize = (cols: number, rows: number) =>
    exec.resize({ w: cols, h: rows }).catch(() => void 0);

  return { stream, resize, exec };
}

/** Polls container stats once (not a live stream) and normalizes the numbers. */
export async function getContainerStats(containerId: string): Promise<ContainerStats> {
  const container = docker.getContainer(containerId);
  const raw: any = await container.stats({ stream: false });

  const cpuDelta = raw.cpu_stats.cpu_usage.total_usage - raw.precpu_stats.cpu_usage.total_usage;
  const systemDelta = raw.cpu_stats.system_cpu_usage - raw.precpu_stats.system_cpu_usage;
  const cpuCount = raw.cpu_stats.online_cpus || raw.cpu_stats.cpu_usage.percpu_usage?.length || 1;
  const cpuPercent =
    systemDelta > 0 && cpuDelta > 0 ? (cpuDelta / systemDelta) * cpuCount * 100 : 0;

  const memUsage = raw.memory_stats.usage ?? 0;
  const memLimit = raw.memory_stats.limit ?? 1;
  const memCache = raw.memory_stats.stats?.cache ?? 0;

  let netRx = 0;
  let netTx = 0;
  if (raw.networks) {
    for (const iface of Object.values<any>(raw.networks)) {
      netRx += iface.rx_bytes ?? 0;
      netTx += iface.tx_bytes ?? 0;
    }
  }

  return {
    cpuPercent: round2(cpuPercent),
    memUsageMB: round2((memUsage - memCache) / (1024 * 1024)),
    memLimitMB: round2(memLimit / (1024 * 1024)),
    memPercent: round2(((memUsage - memCache) / memLimit) * 100),
    netRxKB: round2(netRx / 1024),
    netTxKB: round2(netTx / 1024),
    pids: raw.pids_stats?.current ?? 0,
  };
}

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

export async function pullImageIfMissing(image: string): Promise<void> {
  const images = await docker.listImages({ filters: { reference: [image] } });
  if (images.length > 0) return;

  await new Promise<void>((resolve, reject) => {
    docker.pull(image, (err: Error | null, stream: NodeJS.ReadableStream) => {
      if (err) return reject(err);
      docker.modem.followProgress(stream, (err2: Error | null) => {
        if (err2) reject(err2);
        else resolve();
      });
    });
  });
}
