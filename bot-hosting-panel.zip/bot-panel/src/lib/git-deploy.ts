import simpleGit from "simple-git";
import fs from "fs/promises";
import path from "path";
import { ensureWorkspace } from "./docker";

export interface DeployResult {
  commit: string;
  message: string;
}

/**
 * Clones the repo on first deploy, or fetches + hard-resets on subsequent
 * deploys, into the bot's isolated workspace directory. This runs on the
 * HOST filesystem (the panel process), not inside the bot's container —
 * the container only ever sees the resulting files via the bind mount.
 */
export async function deployFromGit(
  botId: string,
  repoUrl: string,
  branch: string
): Promise<DeployResult> {
  const dir = await ensureWorkspace(botId);
  const gitDirExists = await fs
    .stat(path.join(dir, ".git"))
    .then(() => true)
    .catch(() => false);

  const git = simpleGit({ baseDir: dir });

  if (!gitDirExists) {
    // Workspace may already contain files (e.g. re-deploy of a bot that
    // previously used the file manager) — clone into a temp dir then move,
    // so an existing non-empty directory doesn't break `git clone`.
    const entries = await fs.readdir(dir);
    if (entries.length > 0) {
      throw new Error(
        "Workspace is not empty and not a git repo. Clear the bot's files before connecting a repo, or use a fresh bot."
      );
    }
    await git.clone(repoUrl, dir, ["--branch", branch, "--single-branch", "--depth", "1"]);
  } else {
    await git.fetch(["origin", branch]);
    await git.checkout(branch);
    await git.reset(["--hard", `origin/${branch}`]);
  }

  const log = await git.log({ maxCount: 1 });
  const latest = log.latest;
  return {
    commit: latest?.hash ?? "unknown",
    message: latest?.message ?? "",
  };
}
