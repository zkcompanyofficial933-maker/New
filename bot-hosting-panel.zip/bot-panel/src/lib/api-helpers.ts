import { NextResponse } from "next/server";
import { getCurrentUser } from "./auth";
import { prisma } from "./prisma";

export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw new ApiError("Not authenticated.", 401);
  return user;
}

/** Loads a bot and enforces that the current user owns it (or is an ADMIN). */
export async function requireOwnedBot(botId: string) {
  const user = await requireUser();
  const bot = await prisma.bot.findUnique({ where: { id: botId } });
  if (!bot) throw new ApiError("Bot not found.", 404);
  if (bot.ownerId !== user.id && user.role !== "ADMIN") {
    throw new ApiError("You do not have access to this bot.", 403);
  }
  return { user, bot };
}

export function handleApiError(err: unknown) {
  if (err instanceof ApiError) {
    return NextResponse.json({ error: err.message }, { status: err.status });
  }
  console.error(err);
  return NextResponse.json({ error: "Internal server error." }, { status: 500 });
}
