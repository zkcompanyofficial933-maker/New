import fs from "fs/promises";
import path from "path";
import { workspacePathFor } from "./docker";
import type { FileNode } from "@/types";

export class PathEscapeError extends Error {
  constructor() {
    super("Resolved path escapes the bot workspace — request rejected.");
  }
}

/**
 * Resolves a user-supplied relative path against a bot's workspace root and
 * guarantees the result cannot escape it (blocks `../../etc/passwd` style
 * traversal). Every file-manager operation MUST go through this.
 */
export function resolveSafePath(botId: string, relativePath: string): string {
  const root = workspacePathFor(botId);
  const target = path.normalize(path.join(root, relativePath || "."));
  if (!target.startsWith(root)) {
    throw new PathEscapeError();
  }
  return target;
}

export async function listDirectory(botId: string, relativePath = "."): Promise<FileNode[]> {
  const dirPath = resolveSafePath(botId, relativePath);
  const entries = await fs.readdir(dirPath, { withFileTypes: true });

  const nodes = await Promise.all(
    entries.map(async (entry) => {
      const fullPath = path.join(dirPath, entry.name);
      const stat = await fs.stat(fullPath);
      return {
        name: entry.name,
        path: path.join(relativePath, entry.name).replace(/^\.\//, ""),
        type: entry.isDirectory() ? "directory" : "file",
        size: stat.size,
        modifiedAt: stat.mtime.toISOString(),
      } satisfies FileNode;
    })
  );

  // Directories first, then alphabetical
  return nodes.sort((a, b) =>
    a.type === b.type ? a.name.localeCompare(b.name) : a.type === "directory" ? -1 : 1
  );
}

const MAX_EDITABLE_FILE_BYTES = 2 * 1024 * 1024; // 2 MB — guard against loading huge binaries into the editor

export async function readFile(botId: string, relativePath: string): Promise<string> {
  const filePath = resolveSafePath(botId, relativePath);
  const stat = await fs.stat(filePath);
  if (stat.size > MAX_EDITABLE_FILE_BYTES) {
    throw new Error("File is too large to open in the editor (2MB limit). Download it instead.");
  }
  return fs.readFile(filePath, "utf8");
}

export async function writeFile(botId: string, relativePath: string, content: string) {
  const filePath = resolveSafePath(botId, relativePath);
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, content, "utf8");
}

export async function createDirectory(botId: string, relativePath: string) {
  const dirPath = resolveSafePath(botId, relativePath);
  await fs.mkdir(dirPath, { recursive: true });
}

export async function deletePath(botId: string, relativePath: string) {
  const targetPath = resolveSafePath(botId, relativePath);
  if (targetPath === workspacePathFor(botId)) {
    throw new Error("Refusing to delete the workspace root.");
  }
  await fs.rm(targetPath, { recursive: true, force: true });
}

export async function renamePath(botId: string, fromRelative: string, toRelative: string) {
  const from = resolveSafePath(botId, fromRelative);
  const to = resolveSafePath(botId, toRelative);
  await fs.rename(from, to);
}

export async function saveUploadedFile(
  botId: string,
  relativePath: string,
  buffer: Buffer
): Promise<void> {
  const filePath = resolveSafePath(botId, relativePath);
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, buffer);
}
