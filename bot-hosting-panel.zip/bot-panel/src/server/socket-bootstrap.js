/**
 * Socket.io server for:
 *   - "terminal" namespace: interactive pty attached to a bot's container
 *   - "logs" namespace: live stdout/stderr tail
 *
 * This file is loaded directly by server.js via `require(...)`, BEFORE
 * Next.js's build pipeline is involved, so it intentionally does NOT import
 * from src/lib/*.ts (which rely on TS path aliases resolved by Next/webpack).
 * It duplicates the minimal Docker/Prisma/JWT logic it needs in plain JS.
 * Keep this file's Docker semantics (limits, labels, mounts) in sync with
 * src/lib/docker.ts if you change container creation there.
 */
const { Server } = require("socket.io");
const Docker = require("dockerode");
const jwt = require("jsonwebtoken");
const { PrismaClient } = require("@prisma/client");

const docker = new Docker({ socketPath: "/var/run/docker.sock" });
const prisma = new PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-do-not-use-in-prod";
const COOKIE_NAME = "bot_panel_session";

function parseCookies(header) {
  const out = {};
  (header || "").split(";").forEach((pair) => {
    const idx = pair.indexOf("=");
    if (idx === -1) return;
    const key = pair.slice(0, idx).trim();
    const val = decodeURIComponent(pair.slice(idx + 1).trim());
    out[key] = val;
  });
  return out;
}

async function authenticateSocket(socket) {
  const cookies = parseCookies(socket.handshake.headers.cookie);
  const token = cookies[COOKIE_NAME];
  if (!token) throw new Error("Not authenticated");

  const payload = jwt.verify(token, JWT_SECRET);
  const user = await prisma.user.findUnique({ where: { id: payload.userId } });
  if (!user) throw new Error("Not authenticated");
  return user;
}

async function loadOwnedBot(user, botId) {
  const bot = await prisma.bot.findUnique({ where: { id: botId } });
  if (!bot) throw new Error("Bot not found");
  if (bot.ownerId !== user.id && user.role !== "ADMIN") throw new Error("Forbidden");
  return bot;
}

function attachSocketServer(httpServer) {
  const io = new Server(httpServer, {
    path: "/socket.io",
    cors: { origin: false },
  });

  // ---------------- Live logs ----------------
  const logsNs = io.of("/logs");
  logsNs.use(async (socket, next) => {
    try {
      socket.data.user = await authenticateSocket(socket);
      next();
    } catch (err) {
      next(new Error("unauthorized"));
    }
  });

  logsNs.on("connection", (socket) => {
    let detach = null;

    socket.on("subscribe", async ({ botId }) => {
      try {
        const bot = await loadOwnedBot(socket.data.user, botId);
        if (!bot.dockerContainerId) {
          socket.emit("error", "Bot has no container yet.");
          return;
        }
        const container = docker.getContainer(bot.dockerContainerId);
        const stream = await container.logs({ follow: true, stdout: true, stderr: true, tail: 200 });

        stream.on("data", (chunk) => socket.emit("log", chunk.toString("utf8")));
        stream.on("error", () => void 0);

        detach = () => stream.destroy && stream.destroy();
      } catch (err) {
        socket.emit("error", err.message || "Failed to subscribe to logs.");
      }
    });

    socket.on("disconnect", () => detach && detach());
  });

  // ---------------- Interactive terminal ----------------
  const termNs = io.of("/terminal");
  termNs.use(async (socket, next) => {
    try {
      socket.data.user = await authenticateSocket(socket);
      next();
    } catch (err) {
      next(new Error("unauthorized"));
    }
  });

  termNs.on("connection", (socket) => {
    let execStream = null;
    let execInstance = null;

    socket.on("start", async ({ botId, cols, rows }) => {
      try {
        const bot = await loadOwnedBot(socket.data.user, botId);
        if (!bot.dockerContainerId) {
          socket.emit("error", "Bot has no container yet — start the bot first.");
          return;
        }

        const container = docker.getContainer(bot.dockerContainerId);
        const info = await container.inspect().catch(() => null);
        if (!info || !info.State.Running) {
          socket.emit("error", "Container is not running.");
          return;
        }

        execInstance = await container.exec({
          Cmd: ["/bin/sh"],
          AttachStdin: true,
          AttachStdout: true,
          AttachStderr: true,
          Tty: true,
        });

        execStream = await execInstance.start({ hijack: true, stdin: true, Tty: true });
        if (cols && rows) await execInstance.resize({ w: cols, h: rows }).catch(() => void 0);

        execStream.on("data", (chunk) => socket.emit("data", chunk.toString("utf8")));
        execStream.on("end", () => socket.emit("exit"));

        socket.emit("ready");
      } catch (err) {
        socket.emit("error", err.message || "Failed to attach terminal.");
      }
    });

    socket.on("input", (data) => {
      if (execStream) execStream.write(data);
    });

    socket.on("resize", ({ cols, rows }) => {
      if (execInstance) execInstance.resize({ w: cols, h: rows }).catch(() => void 0);
    });

    socket.on("disconnect", () => {
      if (execStream) execStream.end();
    });
  });

  // ---------------- Live resource stats ----------------
  const statsNs = io.of("/stats");
  statsNs.use(async (socket, next) => {
    try {
      socket.data.user = await authenticateSocket(socket);
      next();
    } catch (err) {
      next(new Error("unauthorized"));
    }
  });

  statsNs.on("connection", (socket) => {
    let interval = null;

    socket.on("subscribe", async ({ botId }) => {
      const bot = await loadOwnedBot(socket.data.user, botId).catch(() => null);
      if (!bot || !bot.dockerContainerId) return;

      interval = setInterval(async () => {
        try {
          const container = docker.getContainer(bot.dockerContainerId);
          const raw = await container.stats({ stream: false });
          socket.emit("stats", summarizeStats(raw));
        } catch {
          // container likely stopped — stop polling silently
          if (interval) clearInterval(interval);
        }
      }, 2000);
    });

    socket.on("disconnect", () => interval && clearInterval(interval));
  });

  return io;
}

function summarizeStats(raw) {
  const cpuDelta = raw.cpu_stats.cpu_usage.total_usage - raw.precpu_stats.cpu_usage.total_usage;
  const systemDelta = raw.cpu_stats.system_cpu_usage - raw.precpu_stats.system_cpu_usage;
  const cpuCount = raw.cpu_stats.online_cpus || (raw.cpu_stats.cpu_usage.percpu_usage || []).length || 1;
  const cpuPercent = systemDelta > 0 && cpuDelta > 0 ? (cpuDelta / systemDelta) * cpuCount * 100 : 0;

  const memUsage = raw.memory_stats.usage || 0;
  const memLimit = raw.memory_stats.limit || 1;
  const memCache = (raw.memory_stats.stats && raw.memory_stats.stats.cache) || 0;

  return {
    cpuPercent: Math.round(cpuPercent * 100) / 100,
    memUsageMB: Math.round(((memUsage - memCache) / (1024 * 1024)) * 100) / 100,
    memLimitMB: Math.round((memLimit / (1024 * 1024)) * 100) / 100,
    memPercent: Math.round(((memUsage - memCache) / memLimit) * 100 * 100) / 100,
    pids: (raw.pids_stats && raw.pids_stats.current) || 0,
  };
}

module.exports = { attachSocketServer };
