import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        base: {
          950: "#0B0E14",
          900: "#111623",
          800: "#161C2C",
          700: "#1F2738",
          600: "#2A3348",
        },
        accent: {
          DEFAULT: "#4FD1A5", // terminal-green accent, fits an ops/console tool
          dim: "#2E7D5C",
        },
        warn: "#E5A93D",
        danger: "#E5586B",
      },
      fontFamily: {
        mono: ["JetBrains Mono", "ui-monospace", "SFMono-Regular", "monospace"],
        sans: ["Inter", "ui-sans-serif", "system-ui"],
      },
    },
  },
  plugins: [],
};

export default config;
