/**
 * SKVM Live Statistics Client Engine
 * Connects to WebSocket stream and renders real-time CPU/RAM/Disk sparklines & counters
 */

class SKVMLiveStats {
  constructor(vmId, options = {}) {
    this.vmId = vmId;
    this.socket = null;
    this.callbacks = options.onUpdate || [];
  }

  connect(serverUrl = window.location.origin) {
    if (typeof io !== 'undefined') {
      this.socket = io(serverUrl);
      this.socket.emit('subscribe_vm_stats', { vm_id: this.vmId });
      this.socket.on('vm_stats_update', (data) => {
        if (data && data.vm_id === this.vmId) {
          this.callbacks.forEach((cb) => cb(data));
        }
      });
    } else {
      console.warn('Socket.IO client library not loaded, using fallback polling.');
      this.startPolling();
    }
  }

  startPolling(intervalMs = 2500) {
    setInterval(async () => {
      try {
        const res = await fetch(`/api/v1/vms/${this.vmId}/stats`);
        if (res.ok) {
          const data = await res.json();
          this.callbacks.forEach((cb) => cb(data));
        }
      } catch (err) {
        // Silent fail on polling error
      }
    }, intervalMs);
  }

  onUpdate(callback) {
    this.callbacks.push(callback);
  }
}

window.SKVMLiveStats = SKVMLiveStats;
