/**
 * SKVM Ecosystem Process File for PM2
 * Automatically restarts and keeps SKVM online on Linux VPS
 */

module.exports = {
  apps: [
    {
      name: 'skvm-panel',
      script: 'skvm.py',
      interpreter: 'python3',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production',
        PYTHONUNBUFFERED: '1',
        SKVM_PORT: '3000',
        SKVM_HOST: '0.0.0.0'
      }
    }
  ]
};
