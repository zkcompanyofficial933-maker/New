#!/usr/bin/env python3
"""
SKVM Live Statistics Manager
Streams live CPU, Memory, Disk, and Network I/O metrics for Docker containers over Socket.IO
"""

import time
import logging

logger = logging.getLogger("SKVM-LiveStats")

class LiveStatsManager:
    def __init__(self, docker_client=None, socketio=None):
        self.docker_client = docker_client
        self.socketio = socketio
        self.active_streams = {}

    def get_container_stats(self, container_id):
        """Fetches raw or calculated metrics from Docker container"""
        if not self.docker_client:
            return None

        try:
            container = self.docker_client.containers.get(container_id)
            stats = container.stats(stream=False)
            
            # Compute CPU percent
            cpu_delta = stats["cpu_stats"]["cpu_usage"]["total_usage"] - stats["precpu_stats"]["cpu_usage"]["total_usage"]
            system_delta = stats["cpu_stats"]["system_cpu_usage"] - stats["precpu_stats"]["system_cpu_usage"]
            cpu_percent = 0.0
            if system_delta > 0 and cpu_delta > 0:
                cpu_percent = (cpu_delta / system_delta) * len(stats["cpu_stats"]["cpu_usage"].get("percpu_usage", [1])) * 100.0

            # Compute RAM
            mem_usage = stats["memory_stats"].get("usage", 0)
            mem_limit = stats["memory_stats"].get("limit", 1)
            mem_percent = (mem_usage / mem_limit) * 100.0

            # Network I/O
            net = stats.get("networks", {})
            rx_bytes = sum(v.get("rx_bytes", 0) for v in net.values())
            tx_bytes = sum(v.get("tx_bytes", 0) for v in net.values())

            return {
                "container_id": container_id,
                "status": container.status,
                "cpu_percent": round(cpu_percent, 2),
                "ram_usage_bytes": mem_usage,
                "ram_limit_bytes": mem_limit,
                "ram_percent": round(mem_percent, 2),
                "net_rx_bytes": rx_bytes,
                "net_tx_bytes": tx_bytes,
                "timestamp": time.time()
            }
        except Exception as e:
            logger.warning(f"Error reading Docker container stats for {container_id}: {e}")
            return None
