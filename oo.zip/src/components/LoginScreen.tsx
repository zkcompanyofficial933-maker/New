import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { Lock, User, ArrowRight, ShieldCheck, Server } from 'lucide-react';

export const LoginScreen: React.FC = () => {
  const { login, register, setCurrentView, settings } = useSKVM();
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [username, setUsername] = useState('admin');
  const [email, setEmail] = useState('admin@skvm.cloud');
  const [password, setPassword] = useState('admin');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      setError('Please enter your username');
      return;
    }
    if (isRegisterMode) {
      register(username.trim(), email.trim());
    } else {
      login(username.trim());
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-3xl glass-card border border-white/10 p-8 shadow-2xl relative overflow-hidden space-y-6">
        {/* Glow */}
        <div className="absolute -right-16 -top-16 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Brand */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-white shadow-lg shadow-cyan-500/20 mx-auto text-lg">
            SK
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">
            {settings.panelName || 'SKVM'} Cloud Portal
          </h2>
          <p className="text-xs text-slate-400">
            {isRegisterMode ? 'Create your VPS client account' : 'Sign in to access your Docker containers'}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300">
              {error}
            </div>
          )}

          <div>
            <label className="text-slate-300 block mb-1 font-medium">Username</label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="admin or demouser"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-black/50 border border-white/10 text-white font-medium focus:outline-none focus:border-cyan-500/50"
                required
              />
            </div>
          </div>

          {isRegisterMode && (
            <div>
              <label className="text-slate-300 block mb-1 font-medium">Email Address</label>
              <input
                type="email"
                placeholder="user@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-white font-medium focus:outline-none focus:border-cyan-500/50"
                required
              />
            </div>
          )}

          <div>
            <label className="text-slate-300 block mb-1 font-medium">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-black/50 border border-white/10 text-white font-medium focus:outline-none focus:border-cyan-500/50"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2 mt-2"
          >
            <span>{isRegisterMode ? 'Complete Registration' : 'Sign In'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>

        {/* Switch mode */}
        <div className="text-center pt-2 border-t border-white/5 text-xs text-slate-400">
          {isRegisterMode ? (
            <span>Already have an account? <button onClick={() => setIsRegisterMode(false)} className="text-cyan-400 hover:underline font-bold">Sign In</button></span>
          ) : (
            <span>Need a client account? <button onClick={() => setIsRegisterMode(true)} className="text-cyan-400 hover:underline font-bold">Create Account</button></span>
          )}
        </div>

        {/* Quick Demo Credentials Footer */}
        <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 text-[11px] font-mono text-slate-400 space-y-1">
          <div className="text-slate-500 text-[10px] uppercase font-bold">Quick Access:</div>
          <div>Admin: <span className="text-cyan-400">admin</span> / <span className="text-slate-300">admin</span></div>
          <div>Client: <span className="text-cyan-400">demouser</span> / <span className="text-slate-300">demouser</span></div>
        </div>
      </div>
    </div>
  );
};
