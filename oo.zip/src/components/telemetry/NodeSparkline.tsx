import React from 'react';
import { ResponsiveContainer, AreaChart, Area } from 'recharts';

interface NodeSparklineProps {
  nodeId: number;
  activePct: number;
  isOnline: boolean;
  color?: string;
}

export const NodeSparkline: React.FC<NodeSparklineProps> = ({
  nodeId,
  activePct,
  isOnline,
  color = '#06b6d4'
}) => {
  // Deterministic 8-point sparkline curve based on nodeId and current active load
  const data = React.useMemo(() => {
    if (!isOnline) {
      return Array.from({ length: 8 }, (_, i) => ({ i, val: 0 }));
    }
    const points = [];
    const base = Math.max(5, Math.min(95, activePct));
    for (let i = 0; i < 8; i++) {
      const wobble = Math.sin(i * 0.9 + nodeId) * 6 + Math.cos(i * 0.5) * 4;
      points.push({
        i,
        val: Math.max(2, Math.min(99, Math.round(base + wobble)))
      });
    }
    return points;
  }, [nodeId, activePct, isOnline]);

  const gradId = `sparkline-grad-${nodeId}`;

  return (
    <div className="w-full h-8 overflow-hidden rounded">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 2, right: 0, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.4} />
              <stop offset="100%" stopColor={color} stopOpacity={0.0} />
            </linearGradient>
          </defs>
          <Area
            type="monotone"
            dataKey="val"
            stroke={color}
            strokeWidth={1.5}
            fill={`url(#${gradId})`}
            dot={false}
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};
