import React, { useState } from 'react';
import { useSKVM } from '../../context/SKVMContext';
import { 
  Bell, Mail, AlertTriangle, ShieldCheck, Check, 
  Cpu, Zap, RefreshCw, Send, CheckCircle2, Sliders, 
  Clock, Server, Trash2, ArrowUpRight, Flame, Volume2, VolumeX
} from 'lucide-react';

export const ResourceThresholdsPanel: React.FC = () => {
  const { 
    thresholdConfig, 
    updateThresholdConfig, 
    triggerThresholdAlert, 
    clearAlertHistory,
    nodes,
    vms,
    currentUser
  } = useSKVM();

  // Local draft form state
  const [cpuThreshold, setCpuThreshold] = useState<number>(thresholdConfig.cpuThresholdPercent);
  const [ramThreshold, setRamThreshold] = useState<number>(thresholdConfig.ramThresholdPercent);
  const [enableEmail, setEnableEmail] = useState<boolean>(thresholdConfig.enableEmailAlerts);
  const [emailAddress, setEmailAddress] = useState<string>(thresholdConfig.alertEmail || currentUser?.email || 'admin@skvm.cloud');
  const [enableSystem, setEnableSystem] = useState<boolean>(thresholdConfig.enableSystemAlerts);
  const [notifyCluster, setNotifyCluster] = useState<boolean>(thresholdConfig.notifyOnClusterSpike);
  const [notifyNode, setNotifyNode] = useState<boolean>(thresholdConfig.notifyOnNodeSpike);
  const [notifyVm, setNotifyVm] = useState<boolean>(thresholdConfig.notifyOnVmSpike);
  const [cooldown, setCooldown] = useState<number>(thresholdConfig.cooldownMinutes);
  const [autoResolve, setAutoResolve] = useState<boolean>(thresholdConfig.autoResolveNotification);

  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);
  const [testingMetric, setTestingMetric] = useState<'cpu' | 'ram' | null>(null);

  // Handle Save
  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    updateThresholdConfig({
      cpuThresholdPercent: Number(cpuThreshold),
      ramThresholdPercent: Number(ramThreshold),
      enableEmailAlerts: enableEmail,
      alertEmail: emailAddress.trim() || 'admin@skvm.cloud',
      enableSystemAlerts: enableSystem,
      notifyOnClusterSpike: notifyCluster,
      notifyOnNodeSpike: notifyNode,
      notifyOnVmSpike: notifyVm,
      cooldownMinutes: Number(cooldown),
      autoResolveNotification: autoResolve,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  // Handle Test Simulation
  const handleTestAlert = (metric: 'CPU' | 'RAM') => {
    setTestingMetric(metric.toLowerCase() as 'cpu' | 'ram');
    
    // Choose a realistic target
    const targetName = nodes.length > 0 ? nodes[0].name : vms.length > 0 ? vms[0].name : 'Cluster-Node-01';
    const thresholdVal = metric === 'CPU' ? cpuThreshold : ramThreshold;
    const currentVal = thresholdVal + Math.round((Math.random() * 8 + 3) * 10) / 10;

    triggerThresholdAlert(targetName, metric, currentVal, thresholdVal);

    setTimeout(() => {
      setTestingMetric(null);
    }, 1200);
  };

  // Reset to default recommendations
  const handleResetDefaults = () => {
    setCpuThreshold(80);
    setRamThreshold(85);
    setEnableEmail(true);
    setEmailAddress(currentUser?.email || 'admin@skvm.cloud');
    setEnableSystem(true);
    setNotifyCluster(true);
    setNotifyNode(true);
    setNotifyVm(true);
    setCooldown(5);
    setAutoResolve(true);
  };

  // Color helper for CPU threshold
  const getCpuBadgeColor = (val: number) => {
    if (val >= 90) return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
    if (val >= 75) return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
    return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30';
  };

  // Color helper for RAM threshold
  const getRamBadgeColor = (val: number) => {
    if (val >= 90) return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
    if (val >= 80) return 'text-purple-400 bg-purple-500/10 border-purple-500/30';
    return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30';
  };

  return (
    <div className="p-6 rounded-2xl glass-card border border-white/10 space-y-6 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none -mt-20"></div>
      <div className="absolute bottom-0 right-10 w-80 h-80 bg-purple-500/5 rounded-full blur-3xl pointer-events-none -mb-20"></div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10 border-b border-white/5 pb-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Sliders className="w-4 h-4" />
            </span>
            <h3 className="text-base sm:text-lg font-extrabold text-white tracking-tight flex items-center gap-2">
              Resource Thresholds & Incident Alerts
            </h3>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              ENGINE ACTIVE
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
            Configure dynamic saturation limits for CPU cgroups and RAM allocations. Automatically dispatches system notifications and email incident alerts when hypervisors or containers exceed thresholds.
          </p>
        </div>

        {/* Quick status pill */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.03] border border-white/10 text-xs font-mono text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Alerts: {enableEmail || enableSystem ? 'ENABLED' : 'MUTED'}</span>
          </div>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6 relative z-10">
        {/* THRESHOLD SLIDERS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* CPU Threshold Card */}
          <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-4 hover:border-cyan-500/30 transition-all">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  <Cpu className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">CPU Usage Threshold</h4>
                  <p className="text-[11px] text-slate-400">Trigger alert on sustained core saturation</p>
                </div>
              </div>
              <div className={`px-2.5 py-1 rounded-lg border font-mono font-bold text-sm ${getCpuBadgeColor(cpuThreshold)}`}>
                {cpuThreshold}%
              </div>
            </div>

            {/* Slider */}
            <div className="space-y-2 pt-1">
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Sensitivity: 50%</span>
                <span className="text-cyan-400 font-semibold">{cpuThreshold}% trigger point</span>
                <span>Critical: 99%</span>
              </div>
              <input
                type="range"
                min="50"
                max="99"
                step="1"
                value={cpuThreshold}
                onChange={(e) => setCpuThreshold(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
              {/* Visual Meter Bar */}
              <div className="w-full bg-black/40 h-1.5 rounded-full overflow-hidden flex">
                <div 
                  className="bg-cyan-500 h-full transition-all"
                  style={{ width: `${cpuThreshold}%` }}
                ></div>
                <div className="bg-rose-500/50 h-full flex-1"></div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-white/5 font-mono">
              <span>Docker nano-cpus cgroup limit</span>
              <span className="text-slate-300">
                {cpuThreshold >= 90 ? '🔥 Severe Threshold' : cpuThreshold >= 75 ? '⚡ Standard Warning' : '🛡️ High Sensitivity'}
              </span>
            </div>
          </div>

          {/* RAM Threshold Card */}
          <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-4 hover:border-purple-500/30 transition-all">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">RAM Usage Threshold</h4>
                  <p className="text-[11px] text-slate-400">Trigger alert before OOM-killer fires</p>
                </div>
              </div>
              <div className={`px-2.5 py-1 rounded-lg border font-mono font-bold text-sm ${getRamBadgeColor(ramThreshold)}`}>
                {ramThreshold}%
              </div>
            </div>

            {/* Slider */}
            <div className="space-y-2 pt-1">
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>Sensitivity: 50%</span>
                <span className="text-purple-400 font-semibold">{ramThreshold}% trigger point</span>
                <span>Critical: 99%</span>
              </div>
              <input
                type="range"
                min="50"
                max="99"
                step="1"
                value={ramThreshold}
                onChange={(e) => setRamThreshold(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-400"
              />
              {/* Visual Meter Bar */}
              <div className="w-full bg-black/40 h-1.5 rounded-full overflow-hidden flex">
                <div 
                  className="bg-purple-500 h-full transition-all"
                  style={{ width: `${ramThreshold}%` }}
                ></div>
                <div className="bg-rose-500/50 h-full flex-1"></div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-white/5 font-mono">
              <span>Docker -m memory RSS quota</span>
              <span className="text-slate-300">
                {ramThreshold >= 90 ? '🚨 Immediate Action Required' : '🛡️ Proactive Warning'}
              </span>
            </div>
          </div>
        </div>

        {/* NOTIFICATION CHANNELS & DESTINATIONS */}
        <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-5">
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-cyan-400" />
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Alert Notification Channels</h4>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">Multi-channel routing</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* System In-Panel Notification */}
            <div className={`p-4 rounded-xl border transition-all flex items-start justify-between gap-3 ${
              enableSystem ? 'bg-cyan-500/[0.04] border-cyan-500/30' : 'bg-black/20 border-white/5 opacity-70'
            }`}>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-white">System In-Panel Notifications</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Sends instant alerts to the notification bell, header badge counter, and cluster activity log.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEnableSystem(!enableSystem)}
                className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  enableSystem ? 'bg-cyan-500' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-slate-950 shadow ring-0 transition duration-200 ease-in-out ${
                    enableSystem ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Email Notifications */}
            <div className={`p-4 rounded-xl border transition-all space-y-3 ${
              enableEmail ? 'bg-purple-500/[0.04] border-purple-500/30' : 'bg-black/20 border-white/5 opacity-70'
            }`}>
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-purple-400" />
                    <span className="text-xs font-bold text-white">Email Incident Dispatch</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Sends automated incident alert emails with node diagnostics and recommended remediations.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setEnableEmail(!enableEmail)}
                  className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    enableEmail ? 'bg-purple-500' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-slate-950 shadow ring-0 transition duration-200 ease-in-out ${
                      enableEmail ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Email Input Field */}
              {enableEmail && (
                <div className="pt-1">
                  <label className="text-[10px] text-slate-400 font-mono block mb-1">
                    Destination Alert Recipient Email:
                  </label>
                  <div className="relative">
                    <Mail className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-3" />
                    <input
                      type="email"
                      value={emailAddress}
                      onChange={(e) => setEmailAddress(e.target.value)}
                      placeholder="alerts@company.com"
                      className="w-full pl-9 pr-3 py-2 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder-slate-600 focus:outline-none focus:border-purple-400 font-mono"
                    />
                  </div>
                  <span className="text-[10px] text-purple-400/80 font-mono mt-1 block">
                    Supported: individual sysadmin email or Opsgenie/PagerDuty incoming email alias
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* MONITORING SCOPES & SUPPRESSION CONTROLS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Scope Checkboxes */}
          <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3.5">
            <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Server className="w-3.5 h-3.5 text-cyan-400" /> Monitored Scopes
              </span>
              <span className="text-[10px] text-slate-400 font-mono">Scope Filters</span>
            </div>

            <div className="space-y-2.5 text-xs">
              <label className="flex items-center gap-2.5 cursor-pointer text-slate-300 hover:text-white">
                <input
                  type="checkbox"
                  checked={notifyCluster}
                  onChange={(e) => setNotifyCluster(e.target.checked)}
                  className="rounded border-white/10 bg-slate-800 text-cyan-500 focus:ring-0 w-4 h-4 cursor-pointer"
                />
                <div>
                  <span className="font-semibold block">Cluster Aggregate Overload</span>
                  <span className="text-[11px] text-slate-500">Alerts when overall cluster capacity surpasses limit</span>
                </div>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer text-slate-300 hover:text-white">
                <input
                  type="checkbox"
                  checked={notifyNode}
                  onChange={(e) => setNotifyNode(e.target.checked)}
                  className="rounded border-white/10 bg-slate-800 text-cyan-500 focus:ring-0 w-4 h-4 cursor-pointer"
                />
                <div>
                  <span className="font-semibold block">Individual Hypervisor Node Spikes</span>
                  <span className="text-[11px] text-slate-500">Alerts when any connected host runner exceeds threshold</span>
                </div>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer text-slate-300 hover:text-white">
                <input
                  type="checkbox"
                  checked={notifyVm}
                  onChange={(e) => setNotifyVm(e.target.checked)}
                  className="rounded border-white/10 bg-slate-800 text-cyan-500 focus:ring-0 w-4 h-4 cursor-pointer"
                />
                <div>
                  <span className="font-semibold block">Individual Container VPS Saturation</span>
                  <span className="text-[11px] text-slate-500">Alerts when a user container maxes out its assigned cgroup</span>
                </div>
              </label>
            </div>
          </div>

          {/* Cooldown & Auto-Resolve Controls */}
          <div className="p-5 rounded-2xl bg-white/[0.02] border border-white/10 space-y-3.5">
            <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-purple-400" /> Alert Timing & Recovery
              </span>
              <span className="text-[10px] text-slate-400 font-mono">Deduplication</span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1.5 font-medium">
                  Incident Deduplication Cooldown:
                </label>
                <select
                  value={cooldown}
                  onChange={(e) => setCooldown(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-black/40 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-400 cursor-pointer font-mono"
                >
                  <option value={1} className="bg-slate-900">1 minute (High sensitivity testing)</option>
                  <option value={5} className="bg-slate-900">5 minutes (Recommended standard)</option>
                  <option value={15} className="bg-slate-900">15 minutes (Conservative)</option>
                  <option value={30} className="bg-slate-900">30 minutes (Minimal alerts)</option>
                  <option value={60} className="bg-slate-900">60 minutes (Hourly digest)</option>
                </select>
                <p className="text-[10px] text-slate-500 mt-1">
                  Prevents multiple notifications for the same ongoing resource spike.
                </p>
              </div>

              <label className="flex items-center gap-2.5 cursor-pointer text-slate-300 hover:text-white pt-1">
                <input
                  type="checkbox"
                  checked={autoResolve}
                  onChange={(e) => setAutoResolve(e.target.checked)}
                  className="rounded border-white/10 bg-slate-800 text-emerald-500 focus:ring-0 w-4 h-4 cursor-pointer"
                />
                <div>
                  <span className="font-semibold block">Send Auto-Recovery Resolution Notice</span>
                  <span className="text-[11px] text-slate-500">Notifies admins when usage cools down below threshold</span>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* BUTTON BAR & TEST CONTROLS */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
          {/* Test buttons */}
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => handleTestAlert('CPU')}
              disabled={testingMetric !== null}
              className="px-3.5 py-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-semibold transition-all flex items-center gap-1.5"
            >
              <Cpu className={`w-3.5 h-3.5 ${testingMetric === 'cpu' ? 'animate-spin' : ''}`} />
              Test CPU Alert Trigger
            </button>

            <button
              type="button"
              onClick={() => handleTestAlert('RAM')}
              disabled={testingMetric !== null}
              className="px-3.5 py-2 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-semibold transition-all flex items-center gap-1.5"
            >
              <Zap className={`w-3.5 h-3.5 ${testingMetric === 'ram' ? 'animate-spin' : ''}`} />
              Test RAM Alert Trigger
            </button>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={handleResetDefaults}
              className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white text-xs font-medium transition-all"
            >
              Reset Defaults
            </button>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center gap-1.5"
            >
              {savedSuccess ? (
                <>
                  <Check className="w-4 h-4 text-emerald-950" />
                  Saved Successfully!
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  Save Alert Configuration
                </>
              )}
            </button>
          </div>
        </div>
      </form>

      {/* RECENT THRESHOLD INCIDENTS LOG */}
      <div className="pt-4 border-t border-white/5 space-y-3 relative z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Recent Threshold Incidents & Alert Dispatches
            </h4>
            <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2 py-0.5 rounded">
              {thresholdConfig.alertHistory?.length || 0} events
            </span>
          </div>
          {thresholdConfig.alertHistory && thresholdConfig.alertHistory.length > 0 && (
            <button
              onClick={clearAlertHistory}
              className="text-[11px] text-slate-400 hover:text-rose-400 flex items-center gap-1 transition-colors"
            >
              <Trash2 className="w-3 h-3" /> Clear History
            </button>
          )}
        </div>

        {(!thresholdConfig.alertHistory || thresholdConfig.alertHistory.length === 0) ? (
          <div className="p-4 rounded-xl bg-white/[0.01] border border-dashed border-white/10 text-center text-xs text-slate-500">
            No threshold breach incidents recorded. System running within optimal limits.
          </div>
        ) : (
          <div className="space-y-2">
            {thresholdConfig.alertHistory.slice(0, 5).map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-between text-xs font-mono group hover:bg-white/[0.04] transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    item.metric === 'CPU' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                  }`}>
                    {item.metric} {item.value}%
                  </span>
                  <div>
                    <span className="text-white font-medium">{item.target}</span>
                    <span className="text-slate-500 text-[11px] ml-2">
                      (Limit: {item.threshold}%) &bull; {item.message}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-[11px]">
                  <span className="text-slate-400">
                    Channel: <span className="text-cyan-300 font-semibold">{item.channel}</span>
                  </span>
                  <span className="text-slate-500">
                    {new Date(item.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
