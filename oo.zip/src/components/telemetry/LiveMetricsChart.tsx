import React, { useState, useEffect, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';
import { 
  Activity, Cpu, Zap, ArrowDownUp, RefreshCw, 
  Play, Pause, Maximize2, Sparkles, Server, CheckCircle2 
} from 'lucide-react';

export interface TelemetryPoint {
  time: string;
  timestamp: number;
  cpu: number;        // percentage 0 - 100
  ramPercent: number; // percentage 0 - 100
  ramUsedMb: number;  // MB
  netRx: number;      // KB/s
  netTx: number;      // KB/s
}

interface LiveMetricsChartProps {
  title: string;
  subtitle?: string;
  targetType: 'user_vms' | 'admin_nodes';
  targetOptions: Array<{ id: string | number; label: string; sublabel?: string }>;
  selectedTargetId: string | number;
  onSelectTarget: (id: string | number) => void;
  // Live seed values based on real container/node states
  baseCpu?: number;
  baseRamMb?: number;
  totalRamMb?: number;
  isRunning?: boolean;
}

export const LiveMetricsChart: React.FC<LiveMetricsChartProps> = ({
  title,
  subtitle,
  targetType,
  targetOptions,
  selectedTargetId,
  onSelectTarget,
  baseCpu = 15,
  baseRamMb = 512,
  totalRamMb = 2048,
  isRunning = true
}) => {
  const [activeMetricTab, setActiveMetricTab] = useState<'all' | 'cpu' | 'ram' | 'network'>('all');
  const [isPaused, setIsPaused] = useState(false);
  const [chartType, setChartType] = useState<'area' | 'line'>('area');
  const [timeWindow, setTimeWindow] = useState<'30s' | '60s' | '3m'>('60s');

  // Buffer length based on time window (ticking every 2s)
  const maxPoints = timeWindow === '30s' ? 15 : timeWindow === '60s' ? 30 : 60;

  // Initialize historical data
  const [dataPoints, setDataPoints] = useState<TelemetryPoint[]>(() => {
    const points: TelemetryPoint[] = [];
    const now = Date.now();
    const count = 25;
    for (let i = count - 1; i >= 0; i--) {
      const t = new Date(now - i * 2000);
      const timeStr = t.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
      
      const cpuJitter = isRunning ? Math.sin(i * 0.4) * 8 + (Math.random() * 6 - 3) : 0;
      const ramJitter = isRunning ? Math.cos(i * 0.3) * 4 + (Math.random() * 3 - 1.5) : 0;
      const rxJitter = isRunning ? Math.abs(Math.sin(i * 0.5) * 120 + 80 + Math.random() * 40) : 0;
      const txJitter = isRunning ? Math.abs(Math.cos(i * 0.4) * 70 + 45 + Math.random() * 30) : 0;

      const calcCpu = Math.max(0.5, Math.min(100, Math.round((baseCpu + cpuJitter) * 10) / 10));
      const calcRamPct = Math.max(1, Math.min(100, Math.round(((baseRamMb / totalRamMb) * 100 + ramJitter) * 10) / 10));
      const calcRamMb = Math.round((calcRamPct / 100) * totalRamMb);

      points.push({
        time: timeStr,
        timestamp: t.getTime(),
        cpu: isRunning ? calcCpu : 0,
        ramPercent: isRunning ? calcRamPct : 0,
        ramUsedMb: isRunning ? calcRamMb : 0,
        netRx: isRunning ? Math.round(rxJitter * 10) / 10 : 0,
        netTx: isRunning ? Math.round(txJitter * 10) / 10 : 0
      });
    }
    return points;
  });

  // Ticking effect to append new live telemetry points
  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setDataPoints((prev) => {
        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
        
        // Realistic continuous variation based on seed values
        const last = prev[prev.length - 1];
        const lastCpu = last ? last.cpu : baseCpu;
        const lastRx = last ? last.netRx : 100;
        const lastTx = last ? last.netTx : 60;

        // Random walk with mean reversion toward baseCpu
        const cpuDelta = (Math.random() - 0.48) * 6 - (lastCpu - baseCpu) * 0.15;
        const newCpu = isRunning ? Math.max(0.8, Math.min(99.4, Math.round((lastCpu + cpuDelta) * 10) / 10)) : 0;

        const ramPctBase = totalRamMb > 0 ? (baseRamMb / totalRamMb) * 100 : 25;
        const ramDelta = (Math.random() - 0.5) * 2;
        const newRamPct = isRunning ? Math.max(1.0, Math.min(99.0, Math.round((ramPctBase + ramDelta) * 10) / 10)) : 0;
        const newRamMb = Math.round((newRamPct / 100) * totalRamMb);

        const newRx = isRunning ? Math.max(5, Math.round((lastRx * 0.7 + (Math.random() * 220 + 40) * 0.3) * 10) / 10) : 0;
        const newTx = isRunning ? Math.max(2, Math.round((lastTx * 0.7 + (Math.random() * 140 + 20) * 0.3) * 10) / 10) : 0;

        const newPoint: TelemetryPoint = {
          time: timeStr,
          timestamp: now.getTime(),
          cpu: newCpu,
          ramPercent: newRamPct,
          ramUsedMb: newRamMb,
          netRx: newRx,
          netTx: newTx
        };

        const updated = [...prev, newPoint];
        return updated.slice(-maxPoints);
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [isPaused, isRunning, baseCpu, baseRamMb, totalRamMb, maxPoints]);

  // Current Latest Stats
  const latestPoint = dataPoints[dataPoints.length - 1] || {
    cpu: 0,
    ramPercent: 0,
    ramUsedMb: 0,
    netRx: 0,
    netTx: 0
  };

  // Peak calculations over active buffer
  const peakCpu = useMemo(() => Math.max(...dataPoints.map(p => p.cpu), 0), [dataPoints]);
  const avgCpu = useMemo(() => {
    if (!dataPoints.length) return 0;
    const sum = dataPoints.reduce((acc, p) => acc + p.cpu, 0);
    return Math.round((sum / dataPoints.length) * 10) / 10;
  }, [dataPoints]);
  const peakRx = useMemo(() => Math.max(...dataPoints.map(p => p.netRx), 0), [dataPoints]);

  // Custom Glassmorphic Tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="p-3 rounded-xl bg-slate-950/95 backdrop-blur-md border border-white/10 shadow-2xl space-y-2 text-xs font-mono min-w-[180px]">
          <div className="text-[11px] font-bold text-slate-400 pb-1 border-b border-white/10 flex items-center justify-between">
            <span>TIMESTAMP</span>
            <span className="text-white">{label}</span>
          </div>
          <div className="space-y-1.5">
            {payload.map((entry: any, index: number) => {
              const color = entry.color || entry.stroke || '#fff';
              let unit = '%';
              let val = entry.value;
              if (entry.dataKey === 'netRx' || entry.dataKey === 'netTx') {
                unit = ' KB/s';
              } else if (entry.dataKey === 'ramUsedMb') {
                unit = ' MB';
              }
              return (
                <div key={`tooltip-${index}`} className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: color }}></span>
                    <span className="text-slate-300 capitalize">{entry.name}</span>
                  </div>
                  <span className="font-bold text-white">
                    {val}
                    <span className="text-[10px] text-slate-400 font-normal">{unit}</span>
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-5 sm:p-6 rounded-2xl glass-card border border-white/10 space-y-5 relative overflow-hidden">
      {/* Background ambient glow */}
      <div className="absolute top-0 right-1/4 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none -mt-20"></div>
      <div className="absolute bottom-0 left-1/4 w-80 h-80 bg-purple-500/5 rounded-full blur-3xl pointer-events-none -mb-20"></div>

      {/* Header with Title, Target Selector, and Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Activity className="w-4 h-4 animate-pulse" />
            </span>
            <h3 className="text-base sm:text-lg font-extrabold text-white tracking-tight flex items-center gap-2">
              {title}
            </h3>
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase ${
              isPaused 
                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' 
                : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${isPaused ? 'bg-amber-400' : 'bg-emerald-400 animate-ping'}`}></span>
              {isPaused ? 'PAUSED' : 'LIVE TELEMETRY'}
            </span>
          </div>
          {subtitle && <p className="text-xs text-slate-400">{subtitle}</p>}
        </div>

        {/* Controls: Target Selector + Time Range + Pause/Play */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Target Selector Dropdown */}
          {targetOptions.length > 0 && (
            <div className="flex items-center gap-1.5 bg-black/40 border border-white/10 rounded-xl px-2.5 py-1.5">
              <Server className="w-3.5 h-3.5 text-cyan-400" />
              <select
                value={selectedTargetId}
                onChange={(e) => onSelectTarget(e.target.value)}
                className="bg-transparent text-xs text-white font-medium focus:outline-none cursor-pointer pr-2"
              >
                {targetOptions.map((opt) => (
                  <option key={opt.id} value={opt.id} className="bg-slate-900 text-white">
                    {opt.label} {opt.sublabel ? `(${opt.sublabel})` : ''}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Time Window Selector */}
          <div className="flex items-center bg-black/40 border border-white/10 rounded-xl p-0.5 text-xs font-mono">
            {(['30s', '60s', '3m'] as const).map((win) => (
              <button
                key={win}
                onClick={() => setTimeWindow(win)}
                className={`px-2.5 py-1 rounded-lg transition-all ${
                  timeWindow === win
                    ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {win}
              </button>
            ))}
          </div>

          {/* Pause / Resume Button */}
          <button
            onClick={() => setIsPaused(!isPaused)}
            title={isPaused ? 'Resume live streaming' : 'Pause live streaming'}
            className={`p-1.5 rounded-xl border transition-all flex items-center gap-1 text-xs font-mono px-2.5 ${
              isPaused
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20'
                : 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
            }`}
          >
            {isPaused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isPaused ? 'Resume' : 'Pause'}</span>
          </button>
        </div>
      </div>

      {/* Real-time KPI Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 relative z-10">
        {/* CPU Badge */}
        <div 
          onClick={() => setActiveMetricTab(activeMetricTab === 'cpu' ? 'all' : 'cpu')}
          className={`p-3.5 rounded-xl border transition-all cursor-pointer space-y-1 ${
            activeMetricTab === 'cpu' || activeMetricTab === 'all'
              ? 'bg-cyan-500/10 border-cyan-500/30'
              : 'bg-white/[0.02] border-white/5 opacity-60 hover:opacity-100'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-cyan-400">
            <span className="font-semibold flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5" /> CPU Load
            </span>
            <span className="text-[10px] font-mono text-slate-400">Peak: {peakCpu}%</span>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-white font-mono flex items-baseline gap-1">
            {latestPoint.cpu}
            <span className="text-xs font-normal text-cyan-400">%</span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono">
            Avg: {avgCpu}% &bull; {isRunning ? 'Active cgroup' : 'Inactive'}
          </div>
        </div>

        {/* RAM Badge */}
        <div 
          onClick={() => setActiveMetricTab(activeMetricTab === 'ram' ? 'all' : 'ram')}
          className={`p-3.5 rounded-xl border transition-all cursor-pointer space-y-1 ${
            activeMetricTab === 'ram' || activeMetricTab === 'all'
              ? 'bg-purple-500/10 border-purple-500/30'
              : 'bg-white/[0.02] border-white/5 opacity-60 hover:opacity-100'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-purple-400">
            <span className="font-semibold flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5" /> RAM Usage
            </span>
            <span className="text-[10px] font-mono text-slate-400">{latestPoint.ramPercent}%</span>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-white font-mono flex items-baseline gap-1">
            {latestPoint.ramUsedMb}
            <span className="text-xs font-normal text-purple-400">MB</span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono">
            Limit: {(totalRamMb / 1024).toFixed(1)} GB &bull; RSS Memory
          </div>
        </div>

        {/* Network Inbound Rx */}
        <div 
          onClick={() => setActiveMetricTab(activeMetricTab === 'network' ? 'all' : 'network')}
          className={`p-3.5 rounded-xl border transition-all cursor-pointer space-y-1 ${
            activeMetricTab === 'network' || activeMetricTab === 'all'
              ? 'bg-emerald-500/10 border-emerald-500/30'
              : 'bg-white/[0.02] border-white/5 opacity-60 hover:opacity-100'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-emerald-400">
            <span className="font-semibold flex items-center gap-1.5">
              <ArrowDownUp className="w-3.5 h-3.5" /> Net Inbound (Rx)
            </span>
            <span className="text-[10px] font-mono text-slate-400">Peak {peakRx} KB/s</span>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-400 font-mono flex items-baseline gap-1">
            {latestPoint.netRx}
            <span className="text-xs font-normal text-emerald-300">KB/s</span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono">
            Virtual eth0 / bridge rx
          </div>
        </div>

        {/* Network Outbound Tx */}
        <div 
          onClick={() => setActiveMetricTab(activeMetricTab === 'network' ? 'all' : 'network')}
          className={`p-3.5 rounded-xl border transition-all cursor-pointer space-y-1 ${
            activeMetricTab === 'network' || activeMetricTab === 'all'
              ? 'bg-amber-500/10 border-amber-500/30'
              : 'bg-white/[0.02] border-white/5 opacity-60 hover:opacity-100'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-amber-400">
            <span className="font-semibold flex items-center gap-1.5">
              <ArrowDownUp className="w-3.5 h-3.5 rotate-180" /> Net Outbound (Tx)
            </span>
            <span className="text-[10px] font-mono text-slate-400">Packets OK</span>
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-amber-400 font-mono flex items-baseline gap-1">
            {latestPoint.netTx}
            <span className="text-xs font-normal text-amber-300">KB/s</span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono">
            Egress bandwidth rate
          </div>
        </div>
      </div>

      {/* Metric Filter Tabs */}
      <div className="flex items-center justify-between gap-2 border-b border-white/5 pb-2 relative z-10">
        <div className="flex items-center gap-1 text-xs">
          <button
            onClick={() => setActiveMetricTab('all')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeMetricTab === 'all'
                ? 'bg-white/10 text-white font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Combined Metrics
          </button>
          <button
            onClick={() => setActiveMetricTab('cpu')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeMetricTab === 'cpu'
                ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
                : 'text-slate-400 hover:text-cyan-300'
            }`}
          >
            CPU Trend
          </button>
          <button
            onClick={() => setActiveMetricTab('ram')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeMetricTab === 'ram'
                ? 'bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30'
                : 'text-slate-400 hover:text-purple-300'
            }`}
          >
            RAM Trend
          </button>
          <button
            onClick={() => setActiveMetricTab('network')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeMetricTab === 'network'
                ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30'
                : 'text-slate-400 hover:text-emerald-300'
            }`}
          >
            Network Traffic (Rx / Tx)
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-1 text-xs font-mono text-slate-400">
          <span>Chart:</span>
          <button
            onClick={() => setChartType('area')}
            className={`px-2 py-0.5 rounded text-[11px] ${chartType === 'area' ? 'bg-white/10 text-white font-bold' : 'hover:text-white'}`}
          >
            Area
          </button>
          <button
            onClick={() => setChartType('line')}
            className={`px-2 py-0.5 rounded text-[11px] ${chartType === 'line' ? 'bg-white/10 text-white font-bold' : 'hover:text-white'}`}
          >
            Line
          </button>
        </div>
      </div>

      {/* Main Recharts Telemetry Graph */}
      <div className="w-full h-72 sm:h-80 relative z-10">
        <ResponsiveContainer width="100%" height="100%">
          {chartType === 'area' ? (
            <AreaChart data={dataPoints} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                {/* CPU Gradient */}
                <linearGradient id="cpuGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                </linearGradient>
                {/* RAM Gradient */}
                <linearGradient id="ramGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#a855f7" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#a855f7" stopOpacity={0.0} />
                </linearGradient>
                {/* Network Rx Gradient */}
                <linearGradient id="rxGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
                {/* Network Tx Gradient */}
                <linearGradient id="txGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                </linearGradient>
              </defs>

              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis 
                dataKey="time" 
                tick={{ fill: '#64748b', fontSize: 10, fontFamily: 'monospace' }}
                tickLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
              />
              <YAxis 
                tick={{ fill: '#64748b', fontSize: 10, fontFamily: 'monospace' }}
                tickLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                domain={[0, activeMetricTab === 'network' ? 'auto' : 100]}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                wrapperStyle={{ paddingTop: 10, fontSize: '11px', fontFamily: 'monospace' }} 
              />

              {(activeMetricTab === 'all' || activeMetricTab === 'cpu') && (
                <Area
                  type="monotone"
                  dataKey="cpu"
                  name="CPU Load (%)"
                  stroke="#06b6d4"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#cpuGradient)"
                  isAnimationActive={false}
                />
              )}

              {(activeMetricTab === 'all' || activeMetricTab === 'ram') && (
                <Area
                  type="monotone"
                  dataKey="ramPercent"
                  name="RAM Usage (%)"
                  stroke="#a855f7"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#ramGradient)"
                  isAnimationActive={false}
                />
              )}

              {(activeMetricTab === 'all' || activeMetricTab === 'network') && (
                <>
                  <Area
                    type="monotone"
                    dataKey="netRx"
                    name="Net Inbound (KB/s)"
                    stroke="#10b981"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#rxGradient)"
                    isAnimationActive={false}
                  />
                  <Area
                    type="monotone"
                    dataKey="netTx"
                    name="Net Outbound (KB/s)"
                    stroke="#f59e0b"
                    strokeWidth={1.5}
                    strokeDasharray={activeMetricTab === 'all' ? '4 4' : undefined}
                    fillOpacity={1}
                    fill="url(#txGradient)"
                    isAnimationActive={false}
                  />
                </>
              )}
            </AreaChart>
          ) : (
            <LineChart data={dataPoints} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis 
                dataKey="time" 
                tick={{ fill: '#64748b', fontSize: 10, fontFamily: 'monospace' }}
                tickLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
              />
              <YAxis 
                tick={{ fill: '#64748b', fontSize: 10, fontFamily: 'monospace' }}
                tickLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                domain={[0, activeMetricTab === 'network' ? 'auto' : 100]}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                wrapperStyle={{ paddingTop: 10, fontSize: '11px', fontFamily: 'monospace' }} 
              />

              {(activeMetricTab === 'all' || activeMetricTab === 'cpu') && (
                <Line
                  type="monotone"
                  dataKey="cpu"
                  name="CPU Load (%)"
                  stroke="#06b6d4"
                  strokeWidth={2}
                  dot={false}
                  isAnimationActive={false}
                />
              )}

              {(activeMetricTab === 'all' || activeMetricTab === 'ram') && (
                <Line
                  type="monotone"
                  dataKey="ramPercent"
                  name="RAM Usage (%)"
                  stroke="#a855f7"
                  strokeWidth={2}
                  dot={false}
                  isAnimationActive={false}
                />
              )}

              {(activeMetricTab === 'all' || activeMetricTab === 'network') && (
                <>
                  <Line
                    type="monotone"
                    dataKey="netRx"
                    name="Net Inbound (KB/s)"
                    stroke="#10b981"
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="netTx"
                    name="Net Outbound (KB/s)"
                    stroke="#f59e0b"
                    strokeWidth={1.5}
                    strokeDasharray="4 4"
                    dot={false}
                    isAnimationActive={false}
                  />
                </>
              )}
            </LineChart>
          )}
        </ResponsiveContainer>
      </div>

      {/* Footer Info / Status Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-3 border-t border-white/5 text-[11px] text-slate-400 font-mono">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400"></span> CPU: cgroup quota
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-purple-400"></span> RAM: docker -m limit
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span> Net: virtual veth pairs
          </span>
        </div>
        <div className="text-slate-500">
          Rolling frequency: 2000ms &bull; Telemetry Engine v2.4
        </div>
      </div>
    </div>
  );
};
