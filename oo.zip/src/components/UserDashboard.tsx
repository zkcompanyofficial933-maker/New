import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { 
  Cpu, HardDrive, Zap, CheckCircle, PowerOff, 
  AlertCircle, ArrowRight, ShieldCheck, Terminal, 
  ExternalLink, Server, Clock, Plus
} from 'lucide-react';
import { LiveMetricsChart } from './telemetry/LiveMetricsChart';

export const UserDashboard: React.FC = () => {
  const { currentUser, vms, setCurrentView, setActiveVmId } = useSKVM();
  const [selectedVmId, setSelectedVmId] = useState<string | number>('all');

  // Filter VMs belonging strictly to this user
  const userVMs = vms.filter(v => v.userId === currentUser?.id);

  const runningCount = userVMs.filter(v => v.status === 'RUNNING').length;
  const stoppedCount = userVMs.filter(v => v.status === 'STOPPED').length;
  const suspendedCount = userVMs.filter(v => v.status === 'SUSPENDED').length;

  const totalAllocatedRam = userVMs.reduce((acc, v) => acc + v.ramMb, 0);
  const totalAllocatedCpu = userVMs.reduce((acc, v) => acc + v.cpuCores, 0);
  const totalAllocatedDisk = userVMs.reduce((acc, v) => acc + v.diskGb, 0);

  const handleOpenVm = (vmId: number) => {
    setActiveVmId(vmId);
    setCurrentView('vm_detail');
  };

  // Compute telemetry target options
  const targetOptions = userVMs.length === 0 
    ? [{ id: 'none', label: 'No Instances Assigned' }]
    : [
        ...(userVMs.length > 1 ? [{ id: 'all', label: 'All Instances (Aggregate)', sublabel: `${runningCount} Running` }] : []),
        ...userVMs.map(vm => ({
          id: vm.id,
          label: vm.name,
          sublabel: `${vm.osName} • ${vm.status}`
        }))
      ];

  const activeSelectedVm = userVMs.find(v => v.id.toString() === selectedVmId.toString());
  const isAll = selectedVmId === 'all' || (userVMs.length <= 1 && userVMs.length > 0);

  const chartIsRunning = isAll ? runningCount > 0 : activeSelectedVm?.status === 'RUNNING';
  const chartTotalRamMb = isAll ? (totalAllocatedRam || 2048) : (activeSelectedVm?.ramMb || 1024);
  const chartBaseCpu = isAll 
    ? (runningCount > 0 ? 12 + runningCount * 3.5 : 0)
    : (chartIsRunning ? 16.5 : 0);
  const chartBaseRamMb = isAll
    ? (runningCount > 0 ? Math.round(totalAllocatedRam * 0.36) : 0)
    : (chartIsRunning ? Math.round((activeSelectedVm?.ramMb || 1024) * 0.42) : 0);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Welcome Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl glass-card border border-white/10 relative overflow-hidden">
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-medium mb-2">
            <ShieldCheck className="w-3.5 h-3.5" /> Account Verified & Active
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Welcome back, {currentUser?.username}
          </h2>
          <p className="text-slate-400 text-sm mt-1 max-w-xl leading-relaxed">
            Manage your high-performance Docker VPS instances, monitor real-time utilization, and connect via SSH or web terminal.
          </p>
        </div>
        <div className="relative z-10 flex gap-3">
          <button
            onClick={() => setCurrentView('vms')}
            className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs font-semibold transition-all flex items-center gap-2"
          >
            My Instances ({userVMs.length})
          </button>
        </div>
        <div className="absolute right-0 top-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
      </div>

      {/* VM Status Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>Total Assigned VMs</span>
            <Cpu className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-extrabold text-white font-mono">{userVMs.length}</div>
          <div className="text-[11px] text-slate-400 flex items-center gap-1">
            <Server className="w-3 h-3 text-slate-400" /> Across active nodes
          </div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>Running Containers</span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold text-emerald-400 font-mono">{runningCount}</div>
          <div className="text-[11px] text-emerald-400/80 font-medium">Operational & accessible</div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>Stopped Containers</span>
            <PowerOff className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl font-extrabold text-slate-300 font-mono">{stoppedCount}</div>
          <div className="text-[11px] text-slate-400">Can be booted instantly</div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs font-medium">
            <span>Suspended VMs</span>
            <AlertCircle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-extrabold text-amber-400 font-mono">{suspendedCount}</div>
          <div className="text-[11px] text-slate-400">Zero active penalties</div>
        </div>
      </div>

      {/* Resource Allocation Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl glass-card border border-white/5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300">Allocated RAM</span>
            <Zap className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {(totalAllocatedRam / 1024).toFixed(1)} <span className="text-sm font-normal text-slate-400">GB</span>
          </div>
          <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-cyan-500 h-full rounded-full"
              style={{ width: `${Math.min(100, (totalAllocatedRam / 16384) * 100)}%` }}
            ></div>
          </div>
          <p className="text-[11px] text-slate-400 font-mono">Enforced via Docker -m cgroups</p>
        </div>

        <div className="p-5 rounded-2xl glass-card border border-white/5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300">Allocated CPU</span>
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {totalAllocatedCpu.toFixed(1)} <span className="text-sm font-normal text-slate-400">Cores</span>
          </div>
          <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-purple-500 h-full rounded-full"
              style={{ width: `${Math.min(100, (totalAllocatedCpu / 8) * 100)}%` }}
            ></div>
          </div>
          <p className="text-[11px] text-slate-400 font-mono">Real nano-cpus quota</p>
        </div>

        <div className="p-5 rounded-2xl glass-card border border-white/5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300">Allocated NVMe Storage</span>
            <HardDrive className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">
            {totalAllocatedDisk} <span className="text-sm font-normal text-slate-400">GB</span>
          </div>
          <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-emerald-500 h-full rounded-full"
              style={{ width: `${Math.min(100, (totalAllocatedDisk / 200) * 100)}%` }}
            ></div>
          </div>
          <p className="text-[11px] text-slate-400 font-mono">Overlay2 disk volume</p>
        </div>
      </div>

      {/* Real-time Telemetry Trend Visualization powered by Recharts */}
      <LiveMetricsChart
        title="Live Container Telemetry Trends"
        subtitle={
          userVMs.length === 0
            ? "Connect or request your first VPS container to start monitoring live CPU, RAM, and Network cgroups."
            : "Real-time rolling metrics streaming from Docker container cgroups and virtual network interfaces."
        }
        targetType="user_vms"
        targetOptions={targetOptions}
        selectedTargetId={selectedVmId}
        onSelectTarget={(id) => setSelectedVmId(id)}
        baseCpu={chartBaseCpu}
        baseRamMb={chartBaseRamMb}
        totalRamMb={chartTotalRamMb}
        isRunning={chartIsRunning}
      />

      {/* Your Virtual Machines Quick Access Table */}
      <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white">Assigned VPS Instances</h3>
            <p className="text-xs text-slate-400">Directly isolated Docker containers assigned to your account</p>
          </div>
          <button
            onClick={() => setCurrentView('vms')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
          >
            View All <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {userVMs.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-white/10 rounded-xl space-y-3">
            <Cpu className="w-10 h-10 text-slate-600 mx-auto" />
            <p className="text-sm font-semibold text-slate-300">No VPS Instances Assigned Yet</p>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Your administrator has not assigned a container VPS to your account. Contact your SKVM admin or check back shortly.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-[11px] text-slate-400 font-mono uppercase bg-white/[0.02] border-b border-white/5">
                <tr>
                  <th className="px-4 py-3">VM Name</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">OS / Template</th>
                  <th className="px-4 py-3">Resources</th>
                  <th className="px-4 py-3">Node / IP</th>
                  <th className="px-4 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {userVMs.map((vm) => (
                  <tr key={vm.id} className="hover:bg-white/[0.02] transition-colors group">
                    <td className="px-4 py-3.5">
                      <div className="font-semibold text-white group-hover:text-cyan-300 transition-colors">
                        {vm.name}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">{vm.hostname}</div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold font-mono uppercase ${
                        vm.status === 'RUNNING'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : vm.status === 'CREATING'
                          ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 animate-pulse'
                          : 'bg-slate-800 text-slate-400 border border-white/5'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          vm.status === 'RUNNING' ? 'bg-emerald-400' : vm.status === 'CREATING' ? 'bg-cyan-400' : 'bg-slate-400'
                        }`}></span>
                        {vm.status}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-slate-300 font-medium">
                      {vm.osName}
                    </td>
                    <td className="px-4 py-3.5 font-mono text-[11px] text-slate-300">
                      {vm.cpuCores} CPU / {(vm.ramMb / 1024).toFixed(1)} GB / {vm.diskGb} GB
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="text-slate-300 font-medium">{vm.nodeName}</div>
                      <div className="text-[10px] text-cyan-400 font-mono">{vm.ipAddress}</div>
                    </td>
                    <td className="px-4 py-3.5 text-right">
                      <button
                        onClick={() => handleOpenVm(vm.id)}
                        className="px-3 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500 text-cyan-300 hover:text-slate-950 font-semibold text-xs transition-all border border-cyan-500/20 inline-flex items-center gap-1"
                      >
                        Access VM <ArrowRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
