import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { 
  Cpu, HardDrive, Zap, Server, Users, CheckCircle2, 
  AlertTriangle, PowerOff, RefreshCw, PlusCircle, ArrowUpRight, 
  Activity, ShieldCheck, Terminal, Disc, Sliders, Bell
} from 'lucide-react';
import { LiveMetricsChart } from './telemetry/LiveMetricsChart';
import { NodeSparkline } from './telemetry/NodeSparkline';
import { ResourceThresholdsPanel } from './telemetry/ResourceThresholdsPanel';

export const AdminDashboard: React.FC = () => {
  const { vms, nodes, users, setCurrentView, setActiveVmId, setActiveNodeId, thresholdConfig } = useSKVM();
  const [selectedNodeId, setSelectedNodeId] = useState<string | number>('cluster');

  // VM Statistics
  const totalVMs = vms.length;
  const runningVMs = vms.filter(v => v.status === 'RUNNING').length;
  const stoppedVMs = vms.filter(v => v.status === 'STOPPED').length;
  const suspendedVMs = vms.filter(v => v.status === 'SUSPENDED').length;
  const creatingVMs = vms.filter(v => v.status === 'CREATING').length;
  const failedVMs = vms.filter(v => v.status === 'ERROR').length;

  // User Statistics
  const totalUsers = users.length;
  const activeUsers = users.filter(u => u.isActive).length;
  const suspendedUsers = users.filter(u => !u.isActive).length;

  // Node Statistics
  const totalNodes = nodes.length;
  const onlineNodes = nodes.filter(n => n.status === 'ONLINE').length;
  const offlineNodes = nodes.filter(n => n.status === 'OFFLINE').length;

  // Real Aggregate Resource Calculations across all cluster nodes
  const totalClusterRamMb = nodes.reduce((acc, n) => acc + n.totalRamMb, 0);
  const allocatedClusterRamMb = vms.reduce((acc, v) => acc + v.ramMb, 0);
  const availableClusterRamMb = Math.max(0, totalClusterRamMb - allocatedClusterRamMb);

  const totalClusterCpu = nodes.reduce((acc, n) => acc + n.totalCpuCores, 0);
  const allocatedClusterCpu = vms.reduce((acc, v) => acc + v.cpuCores, 0);
  const availableClusterCpu = Math.max(0, totalClusterCpu - allocatedClusterCpu);

  const totalClusterDiskGb = nodes.reduce((acc, n) => acc + n.totalDiskGb, 0);
  const allocatedClusterDiskGb = vms.reduce((acc, v) => acc + v.diskGb, 0);
  const availableClusterDiskGb = Math.max(0, totalClusterDiskGb - allocatedClusterDiskGb);

  const ramUsagePercent = totalClusterRamMb > 0 ? ((allocatedClusterRamMb / totalClusterRamMb) * 100).toFixed(1) : '0';
  const cpuUsagePercent = totalClusterCpu > 0 ? ((allocatedClusterCpu / totalClusterCpu) * 100).toFixed(1) : '0';
  const diskUsagePercent = totalClusterDiskGb > 0 ? ((allocatedClusterDiskGb / totalClusterDiskGb) * 100).toFixed(1) : '0';

  // Node / Cluster Telemetry target options
  const targetOptions = [
    { 
      id: 'cluster', 
      label: 'Cluster Aggregate (All Nodes)', 
      sublabel: `${onlineNodes}/${totalNodes} Online` 
    },
    ...nodes.map(n => {
      const nodeVMs = vms.filter(v => v.nodeId === n.id);
      return {
        id: n.id,
        label: n.name,
        sublabel: `${n.location} • ${nodeVMs.length} VMs • ${n.status}`
      };
    })
  ];

  const isCluster = selectedNodeId === 'cluster';
  const selectedNode = nodes.find(n => n.id.toString() === selectedNodeId.toString());

  let chartTotalRamMb = totalClusterRamMb || 32768;
  let chartBaseRamMb = allocatedClusterRamMb > 0 ? Math.round(allocatedClusterRamMb * 0.42) : 2048;
  let chartBaseCpu = Math.max(8, Math.min(85, Number(cpuUsagePercent) || 22));
  let chartIsRunning = onlineNodes > 0;

  if (!isCluster && selectedNode) {
    const nodeVMs = vms.filter(v => v.nodeId === selectedNode.id);
    const nodeAllocRam = nodeVMs.reduce((a, b) => a + b.ramMb, 0);
    const nodeRunningVMs = nodeVMs.filter(v => v.status === 'RUNNING').length;

    chartTotalRamMb = selectedNode.totalRamMb || 16384;
    chartBaseRamMb = nodeAllocRam > 0 ? Math.round(nodeAllocRam * 0.45) : 1024;
    chartBaseCpu = selectedNode.status === 'ONLINE' ? Math.min(95, 12 + nodeRunningVMs * 5.5) : 0;
    chartIsRunning = selectedNode.status === 'ONLINE';
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Cluster Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl glass-card border border-white/10 relative overflow-hidden">
        <div>
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-mono mb-2">
            <Server className="w-3.5 h-3.5 text-purple-400" /> MASTER CONTROLLER ORCHESTRATOR
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Cluster Infrastructure Overview
          </h2>
          <p className="text-slate-400 text-sm mt-1 max-w-xl">
            Live telemetry aggregated across {totalNodes} Docker nodes and {totalVMs} container instances.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => {
              const el = document.getElementById('threshold-config-section');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-4 py-2.5 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-semibold transition-all flex items-center gap-2"
          >
            <Sliders className="w-4 h-4 text-purple-400" />
            <span>Thresholds (CPU: {thresholdConfig.cpuThresholdPercent}% &bull; RAM: {thresholdConfig.ramThresholdPercent}%)</span>
          </button>
          <button
            onClick={() => setCurrentView('create_vm')}
            className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" /> Provision New VM
          </button>
        </div>
      </div>

      {/* High-Level Stat Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <div className="text-[11px] text-slate-400 font-medium">Total VMs</div>
          <div className="text-2xl font-extrabold text-white font-mono">{totalVMs}</div>
          <div className="text-[10px] text-emerald-400 font-semibold">{runningVMs} active</div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <div className="text-[11px] text-slate-400 font-medium">Running VMs</div>
          <div className="text-2xl font-extrabold text-emerald-400 font-mono">{runningVMs}</div>
          <div className="text-[10px] text-slate-500 font-mono">{stoppedVMs} stopped</div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <div className="text-[11px] text-slate-400 font-medium">Creating / Pending</div>
          <div className="text-2xl font-extrabold text-cyan-400 font-mono">{creatingVMs}</div>
          <div className="text-[10px] text-slate-400">{failedVMs} errors</div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <div className="text-[11px] text-slate-400 font-medium">Cluster Nodes</div>
          <div className="text-2xl font-extrabold text-purple-400 font-mono">{onlineNodes}/{totalNodes}</div>
          <div className="text-[10px] text-purple-300 font-semibold">Online & Heartbeat OK</div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <div className="text-[11px] text-slate-400 font-medium">Platform Users</div>
          <div className="text-2xl font-extrabold text-amber-400 font-mono">{totalUsers}</div>
          <div className="text-[10px] text-slate-400 font-mono">{activeUsers} active</div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <div className="text-[11px] text-slate-400 font-medium">Docker Daemons</div>
          <div className="text-2xl font-extrabold text-emerald-400 font-mono">26.1</div>
          <div className="text-[10px] text-emerald-400 font-semibold">Socket Ready</div>
        </div>
      </div>

      {/* Real-time Infrastructure Telemetry Trends powered by Recharts */}
      <LiveMetricsChart
        title={isCluster ? "Cluster-Wide Real-Time Telemetry Trends" : `Node Telemetry: ${selectedNode?.name || 'Hypervisor'}`}
        subtitle={
          isCluster
            ? `Aggregated live utilization across ${onlineNodes} online Docker nodes and ${runningVMs} active containers.`
            : `Live resource metrics streaming from agent on host ${selectedNode?.hostname || ''} (${selectedNode?.location || ''}).`
        }
        targetType="admin_nodes"
        targetOptions={targetOptions}
        selectedTargetId={selectedNodeId}
        onSelectTarget={(id) => setSelectedNodeId(id)}
        baseCpu={chartBaseCpu}
        baseRamMb={chartBaseRamMb}
        totalRamMb={chartTotalRamMb}
        isRunning={chartIsRunning}
      />

      {/* Cluster Hardware Allocation Cards (RAM, CPU, DISK) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* RAM */}
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Cluster RAM Capacity</h3>
                <p className="text-[11px] text-slate-400">Across all host hypervisors</p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-cyan-400">{ramUsagePercent}%</span>
          </div>

          <div className="w-full bg-black/50 h-2.5 rounded-full overflow-hidden p-0.5 border border-white/5">
            <div 
              className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, Number(ramUsagePercent))}%` }}
            ></div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/5 text-center text-xs">
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-mono">Total</p>
              <p className="font-bold text-white font-mono">{(totalClusterRamMb / 1024).toFixed(0)} GB</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-mono">Allocated</p>
              <p className="font-bold text-cyan-400 font-mono">{(allocatedClusterRamMb / 1024).toFixed(1)} GB</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-mono">Available</p>
              <p className="font-bold text-emerald-400 font-mono">{(availableClusterRamMb / 1024).toFixed(1)} GB</p>
            </div>
          </div>
        </div>

        {/* CPU */}
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
                <Cpu className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Cluster CPU Cores</h3>
                <p className="text-[11px] text-slate-400">Cgroup hardware limits</p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-purple-400">{cpuUsagePercent}%</span>
          </div>

          <div className="w-full bg-black/50 h-2.5 rounded-full overflow-hidden p-0.5 border border-white/5">
            <div 
              className="bg-gradient-to-r from-purple-500 to-indigo-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, Number(cpuUsagePercent))}%` }}
            ></div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/5 text-center text-xs">
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-mono">Total</p>
              <p className="font-bold text-white font-mono">{totalClusterCpu} Cores</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-mono">Allocated</p>
              <p className="font-bold text-purple-400 font-mono">{allocatedClusterCpu.toFixed(1)}</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-mono">Available</p>
              <p className="font-bold text-emerald-400 font-mono">{availableClusterCpu.toFixed(1)}</p>
            </div>
          </div>
        </div>

        {/* DISK */}
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                <HardDrive className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">NVMe Storage Quota</h3>
                <p className="text-[11px] text-slate-400">Docker overlay2 volumes</p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400">{diskUsagePercent}%</span>
          </div>

          <div className="w-full bg-black/50 h-2.5 rounded-full overflow-hidden p-0.5 border border-white/5">
            <div 
              className="bg-gradient-to-r from-emerald-500 to-teal-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, Number(diskUsagePercent))}%` }}
            ></div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/5 text-center text-xs">
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-mono">Total</p>
              <p className="font-bold text-white font-mono">{totalClusterDiskGb} GB</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-mono">Allocated</p>
              <p className="font-bold text-emerald-400 font-mono">{allocatedClusterDiskGb} GB</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-mono">Available</p>
              <p className="font-bold text-teal-400 font-mono">{availableClusterDiskGb} GB</p>
            </div>
          </div>
        </div>
      </div>

      {/* Resource Thresholds & Notification Configuration Engine */}
      <div id="threshold-config-section">
        <ResourceThresholdsPanel />
      </div>

      {/* Cluster Nodes Quick Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Nodes List */}
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Connected Nodes</h3>
              <p className="text-xs text-slate-400">Docker host runners executing node.py</p>
            </div>
            <button
              onClick={() => setCurrentView('nodes')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
            >
              Manage Nodes <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {nodes.map(node => {
              const nodeVMs = vms.filter(v => v.nodeId === node.id);
              const nodeRamAlloc = nodeVMs.reduce((a, b) => a + b.ramMb, 0);
              const ramPct = Math.round((nodeRamAlloc / node.totalRamMb) * 100);

              return (
                <div 
                  key={node.id} 
                  onClick={() => { setActiveNodeId(node.id); setCurrentView('nodes'); }}
                  className="p-4 rounded-xl bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 transition-all cursor-pointer space-y-2 group"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span className="font-bold text-white text-xs group-hover:text-cyan-300 transition-colors">{node.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono bg-white/5 px-2 py-0.5 rounded">{node.location}</span>
                    </div>
                    <span className="text-[11px] font-mono text-cyan-400">{nodeVMs.length} / {node.maxVms} VMs</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                    <span>RAM: {(nodeRamAlloc / 1024).toFixed(1)} / {(node.totalRamMb / 1024).toFixed(0)} GB ({ramPct}%)</span>
                    <span>Docker: {node.dockerVersion}</span>
                  </div>
                  <div className="pt-1">
                    <NodeSparkline nodeId={node.id} activePct={ramPct} isOnline={node.status === 'ONLINE'} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Cluster VM Provisioning Feed */}
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Active VPS Containers</h3>
              <p className="text-xs text-slate-400">Real-time status across tenants</p>
            </div>
            <button
              onClick={() => setCurrentView('vms')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
            >
              All Instances <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {vms.slice(0, 4).map(vm => (
              <div 
                key={vm.id}
                onClick={() => { setActiveVmId(vm.id); setCurrentView('vm_detail'); }}
                className="p-3.5 rounded-xl bg-white/[0.02] hover:bg-white/[0.04] border border-white/5 transition-all cursor-pointer flex items-center justify-between text-xs group"
              >
                <div>
                  <div className="font-semibold text-white group-hover:text-cyan-300 transition-colors">{vm.name}</div>
                  <div className="text-[10px] text-slate-400 font-mono">Owner: {vm.userName} &bull; {vm.nodeName}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[10px] font-mono text-slate-300">{vm.cpuCores} CPU / {vm.ramMb} MB</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase ${
                    vm.status === 'RUNNING' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {vm.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
