import React from 'react';
import { useSKVM } from '../context/SKVMContext';
import { ShieldAlert, Server, ArrowLeft } from 'lucide-react';

export const MaintenanceScreen: React.FC = () => {
  const { switchRole } = useSKVM();

  return (
    <div className="min-h-[85vh] flex items-center justify-center p-4">
      <div className="w-full max-w-lg rounded-3xl glass-card border border-amber-500/20 p-8 shadow-2xl text-center space-y-5">
        <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">System Under Scheduled Maintenance</h2>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            The SKVM cluster hypervisors are currently undergoing core kernel updates and storage optimization. Client panel access will resume shortly.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-black/40 border border-white/5 font-mono text-xs text-slate-300">
          Estimated completion window: &lt; 15 minutes
        </div>

        <div className="pt-2">
          <button
            onClick={() => switchRole('ADMIN')}
            className="text-xs text-amber-400 hover:underline font-mono"
          >
            Switch to Administrator Override &rarr;
          </button>
        </div>
      </div>
    </div>
  );
};
