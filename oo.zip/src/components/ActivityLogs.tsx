import React from 'react';
import { useSKVM } from '../context/SKVMContext';
import { FileText, Shield, Clock } from 'lucide-react';

export const ActivityLogs: React.FC = () => {
  const { activityLogs } = useSKVM();

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      <div>
        <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <FileText className="w-6 h-6 text-cyan-400" />
          Audit & Activity Trails
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Historical log of container lifecycle events, node heartbeats, and administrative mutations.
        </p>
      </div>

      <div className="rounded-2xl glass-card border border-white/5 overflow-hidden">
        <table className="w-full text-left text-xs font-mono">
          <thead className="bg-white/[0.02] border-b border-white/5 text-[11px] text-slate-400 uppercase">
            <tr>
              <th className="px-5 py-3">Timestamp</th>
              <th className="px-5 py-3">User</th>
              <th className="px-5 py-3">Action Event</th>
              <th className="px-5 py-3">Payload Details</th>
              <th className="px-5 py-3">IP Origin</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {activityLogs.map((log) => (
              <tr key={log.id} className="hover:bg-white/[0.02] transition-colors">
                <td className="px-5 py-3.5 text-slate-400 text-[11px]">
                  {new Date(log.createdAt).toLocaleTimeString()}
                </td>
                <td className="px-5 py-3.5 text-white font-bold">
                  {log.username}
                </td>
                <td className="px-5 py-3.5">
                  <span className="px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 text-[10px] font-bold">
                    {log.action}
                  </span>
                </td>
                <td className="px-5 py-3.5 text-slate-300 text-[11px] max-w-xs truncate">
                  {log.details}
                </td>
                <td className="px-5 py-3.5 text-slate-500 text-[11px]">
                  {log.ipAddress}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
