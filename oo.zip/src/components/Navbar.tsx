import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { 
  Server, Shield, Bell, Terminal, RefreshCw, 
  ExternalLink, UserCheck, LogOut, CheckCircle2, 
  AlertTriangle, Sliders, ChevronDown, Menu
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { 
    currentUser, 
    switchRole, 
    logout, 
    notifications, 
    markNotificationsAsRead, 
    settings, 
    setCurrentView,
    nodes,
    toggleSidebar,
    isSidebarOpen
  } = useSKVM();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const onlineNodes = nodes.filter(n => n.status === 'ONLINE').length;
  const unreadNotifs = notifications.filter(n => !n.isRead).length;

  return (
    <header className="h-16 glass-nav sticky top-0 z-30 flex items-center justify-between px-4 sm:px-6">
      {/* Left: Brand & Node Status Badge */}
      <div className="flex items-center gap-3 sm:gap-4">
        <button
          id="btn-toggle-sidemenu"
          onClick={toggleSidebar}
          className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 transition-all flex items-center justify-center active:scale-95 group"
          title="Toggle Sidemenu"
          aria-label="Toggle Sidemenu"
        >
          <Menu className="w-5 h-5 text-cyan-400 group-hover:rotate-12 transition-transform" />
        </button>

        <div 
          onClick={() => setCurrentView('dashboard')}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-xl overflow-hidden bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-white shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform relative">
            <img src="/logo.png" alt="SKVM" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-white tracking-tight text-base">
                {settings.panelName || 'SKVM'}
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
                v1.0
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono hidden sm:block">Docker Container Cloud</p>
          </div>
        </div>

        {/* Cluster Cluster Health Pill */}
        <div className="hidden lg:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/60 border border-white/5 text-xs text-slate-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Nodes: <strong className="text-white font-medium">{onlineNodes}/{nodes.length} Online</strong></span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400 font-mono text-[11px]">Docker Ready</span>
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Quick Role Switcher for Test & Review */}
        <div className="flex items-center bg-black/40 p-1 rounded-lg border border-white/10 text-xs">
          <button
            onClick={() => switchRole('USER')}
            className={`px-2.5 py-1 rounded-md transition-all font-medium flex items-center gap-1 ${
              currentUser?.role === 'USER'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <UserCheck className="w-3 h-3" /> User
          </button>
          <button
            onClick={() => switchRole('ADMIN')}
            className={`px-2.5 py-1 rounded-md transition-all font-medium flex items-center gap-1 ${
              currentUser?.role === 'ADMIN'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Shield className="w-3 h-3" /> Admin
          </button>
        </div>

        {/* Notifications Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-all border border-white/5"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadNotifs > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-cyan-500 text-slate-950 font-bold rounded-full text-[9px] flex items-center justify-center">
                {unreadNotifs}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 rounded-2xl glass-card border border-white/10 shadow-2xl p-3 z-50">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-white/5">
                <span className="text-xs font-bold text-white">Cluster Notifications</span>
                {unreadNotifs > 0 && (
                  <button 
                    onClick={markNotificationsAsRead}
                    className="text-[10px] text-cyan-400 hover:underline"
                  >
                    Mark all read
                  </button>
                )}
              </div>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {notifications.length === 0 ? (
                  <p className="text-xs text-slate-400 py-3 text-center">No notifications</p>
                ) : (
                  notifications.map(n => {
                    const typeColor = 
                      n.type === 'danger' ? (n.isRead ? 'border-rose-500/20 bg-rose-500/5 text-slate-400' : 'border-rose-500/40 bg-rose-500/15 text-rose-200')
                      : n.type === 'warning' ? (n.isRead ? 'border-amber-500/20 bg-amber-500/5 text-slate-400' : 'border-amber-500/40 bg-amber-500/15 text-amber-200')
                      : n.type === 'success' ? (n.isRead ? 'border-emerald-500/20 bg-emerald-500/5 text-slate-400' : 'border-emerald-500/40 bg-emerald-500/15 text-emerald-200')
                      : (n.isRead ? 'bg-black/20 border-white/5 text-slate-400' : 'bg-cyan-500/10 border-cyan-500/20 text-slate-200');

                    return (
                      <div key={n.id} className={`p-2.5 rounded-xl text-xs border transition-colors ${typeColor}`}>
                        <div className="flex items-center justify-between mb-1">
                          <p className="font-semibold text-white truncate">{n.title}</p>
                          <span className="text-[9px] font-mono text-slate-500 uppercase">{n.type}</span>
                        </div>
                        <p className="text-[11px] leading-relaxed">{n.message}</p>
                        <span className="text-[9px] text-slate-500 font-mono block mt-1">
                          {new Date(n.createdAt).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Account Menu */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 p-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 transition-all"
          >
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-cyan-600 to-teal-500 text-white flex items-center justify-center font-bold text-xs uppercase">
              {currentUser ? currentUser.username.substring(0, 2) : 'U'}
            </div>
            <span className="text-xs font-medium text-slate-200 hidden md:block max-w-[90px] truncate">
              {currentUser ? currentUser.username : 'User'}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden md:block" />
          </button>

          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-48 rounded-xl glass-card border border-white/10 shadow-2xl p-1.5 z-50 text-xs">
              <div className="px-3 py-2 border-b border-white/5 mb-1">
                <p className="font-semibold text-white truncate">{currentUser?.username}</p>
                <p className="text-[10px] text-cyan-400 font-mono">{currentUser?.role}</p>
              </div>
              <button
                onClick={() => { setCurrentView('profile'); setShowUserMenu(false); }}
                className="w-full text-left px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/5 transition-colors"
              >
                Account Profile
              </button>
              <button
                onClick={() => { setCurrentView('health'); setShowUserMenu(false); }}
                className="w-full text-left px-3 py-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/5 transition-colors"
              >
                System Health
              </button>
              <button
                onClick={() => { logout(); setShowUserMenu(false); }}
                className="w-full text-left px-3 py-2 rounded-lg text-rose-400 hover:bg-rose-500/10 transition-colors flex items-center gap-2"
              >
                <LogOut className="w-3.5 h-3.5" /> Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
