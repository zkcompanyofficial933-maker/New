import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { Users, PlusCircle, ShieldCheck, ShieldAlert, UserX, UserCheck } from 'lucide-react';

export const UsersManager: React.FC = () => {
  const { users, vms, createUser, toggleUserStatus } = useSKVM();
  const [showAddModal, setShowAddModal] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<'ADMIN' | 'USER'>('USER');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !email.trim()) return;
    createUser(username.trim(), email.trim(), role);
    setUsername('');
    setEmail('');
    setShowAddModal(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Users className="w-6 h-6 text-cyan-400" />
            User Account Management
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Manage client accounts, roles, permissions, and assigned VPS quotas.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" /> Create User
        </button>
      </div>

      <div className="rounded-2xl glass-card border border-white/5 overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="bg-white/[0.02] border-b border-white/5 text-[11px] text-slate-400 font-mono uppercase">
            <tr>
              <th className="px-5 py-3.5">User</th>
              <th className="px-5 py-3.5">Role</th>
              <th className="px-5 py-3.5">Assigned VMs</th>
              <th className="px-5 py-3.5">Status</th>
              <th className="px-5 py-3.5">Joined Date</th>
              <th className="px-5 py-3.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {users.map((u) => {
              const assignedVms = vms.filter(v => v.userId === u.id);
              return (
                <tr key={u.id} className="hover:bg-white/[0.02] transition-colors">
                  <td className="px-5 py-4">
                    <div className="font-bold text-white">{u.username}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{u.email}</div>
                  </td>
                  <td className="px-5 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold font-mono uppercase ${
                      u.role === 'ADMIN'
                        ? 'bg-purple-500/15 text-purple-300 border border-purple-500/30'
                        : 'bg-white/5 text-slate-300 border border-white/5'
                    }`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-5 py-4 font-mono font-bold text-cyan-400">
                    {assignedVms.length} Instances
                  </td>
                  <td className="px-5 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${
                      u.isActive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${u.isActive ? 'bg-emerald-400' : 'bg-rose-400'}`}></span>
                      {u.isActive ? 'Active' : 'Suspended'}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-slate-400 font-mono text-[11px]">
                    {new Date(u.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-5 py-4 text-right">
                    <button
                      onClick={() => toggleUserStatus(u.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                        u.isActive
                          ? 'border-rose-500/30 text-rose-300 hover:bg-rose-500/10'
                          : 'border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/10'
                      }`}
                    >
                      {u.isActive ? 'Suspend' : 'Reactivate'}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <form onSubmit={handleCreate} className="w-full max-w-md rounded-2xl glass-card border border-white/10 p-6 space-y-4 text-xs">
            <h3 className="text-base font-bold text-white">Create New Tenant User</h3>
            <div>
              <label className="text-slate-400 block mb-1">Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                required
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                required
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Role Permission</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as 'ADMIN' | 'USER')}
                className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
              >
                <option value="USER">Regular User (Access own VMs only)</option>
                <option value="ADMIN">Cluster Administrator (Full Cluster Control)</option>
              </select>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 text-slate-400">Cancel</button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold">Create Account</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
