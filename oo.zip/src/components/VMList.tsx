import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { 
  Cpu, Server, ArrowRight, PlusCircle, Search, 
  Filter, Play, Square, RotateCw, Terminal, CheckCircle2, 
  AlertTriangle, PowerOff, Shield
} from 'lucide-react';
import { OSLogo } from './OSLogo';

export const VMList: React.FC = () => {
  const { currentUser, vms, setCurrentView, setActiveVmId, startVM, stopVM, restartVM } = useSKVM();
  const isAdmin = currentUser?.role === 'ADMIN';

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // If user, filter only assigned VMs; if admin, show all
  const filteredVMs = vms.filter(vm => {
    if (!isAdmin && vm.userId !== currentUser?.id) return false;
    if (statusFilter !== 'ALL' && vm.status !== statusFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        vm.name.toLowerCase().includes(q) ||
        vm.hostname.toLowerCase().includes(q) ||
        vm.ipAddress.includes(q) ||
        vm.userName.toLowerCase().includes(q) ||
        vm.osName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleAccess = (id: number) => {
    setActiveVmId(id);
    setCurrentView('vm_detail');
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Cpu className="w-6 h-6 text-cyan-400" />
            {isAdmin ? 'Cluster Virtual Machines' : 'My Virtual Machines'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isAdmin 
              ? `Manage all ${vms.length} container instances provisioned across cluster nodes`
              : 'Container instances assigned to your account with real Docker isolation and SSH keys'}
          </p>
        </div>

        {isAdmin && (
          <button
            onClick={() => setCurrentView('create_vm')}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" /> Create VM
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3 rounded-xl glass-card border border-white/5">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by name, IP, OS, or user..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
            <Filter className="w-3 h-3" /> Status:
          </span>
          <div className="flex bg-black/40 p-0.5 rounded-lg border border-white/10 text-xs">
            {['ALL', 'RUNNING', 'STOPPED'].map(status => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
                  statusFilter === status 
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {status}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* VM List Table & Cards */}
      {filteredVMs.length === 0 ? (
        <div className="text-center py-16 rounded-2xl glass-card border border-white/5 space-y-3">
          <Cpu className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-sm font-bold text-white">No VMs found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            {searchQuery ? 'Try adjusting your search query or filters.' : 'No instances are active on this cluster.'}
          </p>
          {isAdmin && (
            <button
              onClick={() => setCurrentView('create_vm')}
              className="mt-2 px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 text-xs font-bold hover:bg-cyan-400 inline-flex items-center gap-1"
            >
              <PlusCircle className="w-3.5 h-3.5" /> Launch First VM
            </button>
          )}
        </div>
      ) : (
        <div className="rounded-2xl glass-card border border-white/5 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/[0.02] border-b border-white/5 text-[11px] text-slate-400 font-mono uppercase">
                <tr>
                  <th className="px-5 py-3.5">Instance Name</th>
                  <th className="px-5 py-3.5">Status</th>
                  <th className="px-5 py-3.5">OS Template</th>
                  <th className="px-5 py-3.5">Hardware Limits</th>
                  <th className="px-5 py-3.5">Node & Network</th>
                  {isAdmin && <th className="px-5 py-3.5">Owner</th>}
                  <th className="px-5 py-3.5 text-right">Operations</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredVMs.map((vm) => (
                  <tr key={vm.id} className="hover:bg-white/[0.02] transition-colors group">
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-bold">
                          <Cpu className="w-4 h-4" />
                        </div>
                        <div>
                          <div 
                            onClick={() => handleAccess(vm.id)}
                            className="font-bold text-white group-hover:text-cyan-300 transition-colors cursor-pointer text-sm"
                          >
                            {vm.name}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">{vm.hostname}</div>
                        </div>
                      </div>
                    </td>

                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold font-mono uppercase ${
                        vm.status === 'RUNNING'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : vm.status === 'CREATING'
                          ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 animate-pulse'
                          : 'bg-slate-800 text-slate-400 border border-white/5'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          vm.status === 'RUNNING' ? 'bg-emerald-400' : vm.status === 'CREATING' ? 'bg-cyan-400' : 'bg-slate-400'
                        }`}></span>
                        {vm.status}
                      </span>
                    </td>

                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2.5">
                        <OSLogo slug={vm.osIcon || vm.osName} name={vm.osName} size="sm" />
                        <div>
                          <div className="font-semibold text-slate-200">{vm.osName}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{vm.osImage}</div>
                        </div>
                      </div>
                    </td>

                    <td className="px-5 py-4 font-mono text-[11px] text-slate-300">
                      <div><strong className="text-white">{vm.cpuCores}</strong> vCPU</div>
                      <div className="text-slate-400">{(vm.ramMb / 1024).toFixed(1)} GB RAM &bull; {vm.diskGb} GB Disk</div>
                    </td>

                    <td className="px-5 py-4">
                      <div className="text-slate-200 font-medium">{vm.nodeName}</div>
                      <div className="text-[10px] text-cyan-400 font-mono">{vm.ipAddress}</div>
                    </td>

                    {isAdmin && (
                      <td className="px-5 py-4">
                        <span className="px-2 py-0.5 rounded bg-white/5 text-slate-300 font-medium font-mono text-[11px]">
                          {vm.userName}
                        </span>
                      </td>
                    )}

                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {vm.status === 'RUNNING' ? (
                          <>
                            <button
                              onClick={() => restartVM(vm.id)}
                              title="Restart Container"
                              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-amber-400 transition-colors"
                            >
                              <RotateCw className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => stopVM(vm.id)}
                              title="Stop Container"
                              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-rose-400 transition-colors"
                            >
                              <Square className="w-3.5 h-3.5" />
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => startVM(vm.id)}
                            title="Start Container"
                            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-emerald-400 transition-colors"
                          >
                            <Play className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => handleAccess(vm.id)}
                          className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-md shadow-cyan-500/10 flex items-center gap-1"
                        >
                          Access VM <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
