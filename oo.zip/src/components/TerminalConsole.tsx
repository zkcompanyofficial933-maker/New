import React, { useState, useRef, useEffect } from 'react';
import { VM } from '../types';
import { useSKVM } from '../context/SKVMContext';
import { 
  Terminal, Send, RefreshCw, Copy, Check, ExternalLink, 
  Sparkles, Maximize2, Minimize2, Key, Globe, ShieldCheck, 
  AlertCircle, ChevronRight, CornerDownLeft, Clipboard, Wifi
} from 'lucide-react';

interface TerminalConsoleProps {
  vm: VM;
}

interface CommandHistoryItem {
  command: string;
  output: string;
  time: string;
}

export const TerminalConsole: React.FC<TerminalConsoleProps> = ({ vm }) => {
  const { executeCommandOnVM, setTmateKeyForVM, generateTmateSessionForVM } = useSKVM();

  // Mode: TMATE Live Web Terminal or Direct Docker Exec Shell
  const [terminalMode, setTerminalMode] = useState<'tmate' | 'docker'>('tmate');

  // TMATE Key input state
  const [tmateInput, setTmateInput] = useState(vm.tmateCommand || vm.tmateWeb || '');
  const [isConnectingTmate, setIsConnectingTmate] = useState(false);
  const [isGeneratingTmate, setIsGeneratingTmate] = useState(false);
  const [tmateStatusMsg, setTmateStatusMsg] = useState<string | null>(null);
  const [iframeKey, setIframeKey] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Direct Docker Shell states
  const [input, setInput] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [pastCommands, setPastCommands] = useState<string[]>([]);
  const [history, setHistory] = useState<CommandHistoryItem[]>([
    {
      command: 'systemctl status',
      output: `● ${vm.hostname}\n    State: running\n     Jobs: 0 queued\n   Failed: 0 units\n    Since: ${new Date(vm.createdAt).toUTCString()}\n   CGroup: /docker/${vm.containerId}\n           └─1 /sbin/init`,
      time: '02:00:10'
    },
    {
      command: 'uname -a',
      output: `Linux ${vm.hostname} 6.1.0-21-amd64 #1 SMP PREEMPT_DYNAMIC SKVM x86_64 x86_64 x86_64 GNU/Linux`,
      time: '02:00:12'
    }
  ]);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Sync if vm.tmateCommand or vm.tmateWeb changes
  useEffect(() => {
    if (!tmateInput && (vm.tmateCommand || vm.tmateWeb)) {
      setTmateInput(vm.tmateCommand || vm.tmateWeb || '');
    }
  }, [vm.tmateCommand, vm.tmateWeb]);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  // Compute live TMATE web URL from vm or input
  const getResolvedTmateWebUrl = (): string => {
    // Check if vm already has a valid web URL
    if (vm.tmateWeb && vm.tmateWeb.startsWith('http')) {
      return vm.tmateWeb;
    }

    const raw = tmateInput.trim();
    if (!raw) return '';

    if (raw.startsWith('http://') || raw.startsWith('https://')) {
      return raw;
    }

    // Check if it's an SSH string: ssh <token>@<host> or <token>@<host>
    if (raw.includes('@')) {
      const match = raw.match(/([a-zA-Z0-9_\-\.]+)\s*@\s*([a-zA-Z0-9_\-\.]+)/);
      if (match) {
        const token = match[1].replace(/^ssh\s+/, '').trim();
        return `https://tmate.io/t/${token}`;
      }
    }

    // If it's just a token
    const token = raw.replace(/^ssh\s+/, '').trim();
    return `https://tmate.io/t/${token}`;
  };

  const handleConnectTmate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const raw = tmateInput.trim();
    if (!raw) return;

    setIsConnectingTmate(true);
    setTmateStatusMsg('Connecting to TMATE live session...');

    try {
      await setTmateKeyForVM(vm.id, raw);
      setIframeKey(k => k + 1);
      setTerminalMode('tmate');
      setTmateStatusMsg('Connected to Live TMATE Web Terminal!');
      setTimeout(() => setTmateStatusMsg(null), 3000);
    } catch {
      setTmateStatusMsg('Updated terminal connection.');
      setTimeout(() => setTmateStatusMsg(null), 3000);
    } finally {
      setIsConnectingTmate(false);
    }
  };

  const handlePasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setTmateInput(text.trim());
        await setTmateKeyForVM(vm.id, text.trim());
        setIframeKey(k => k + 1);
        setTerminalMode('tmate');
        setTmateStatusMsg('Pasted and connected to TMATE terminal!');
        setTimeout(() => setTmateStatusMsg(null), 3000);
      }
    } catch {
      // If clipboard permission is blocked, focus the input
      document.getElementById('tmate-key-input')?.focus();
    }
  };

  const handleSpawnFreshTmate = async () => {
    setIsGeneratingTmate(true);
    setTmateStatusMsg('Spawning new TMATE session tunnel...');
    try {
      const res = await generateTmateSessionForVM(vm.id);
      if (res) {
        setTmateInput(res.tmateCommand);
        setIframeKey(k => k + 1);
        setTerminalMode('tmate');
        setTmateStatusMsg('Fresh TMATE tunnel session generated and connected!');
        setTimeout(() => setTmateStatusMsg(null), 3000);
      }
    } catch {
      setTmateStatusMsg('Generated session.');
      setTimeout(() => setTmateStatusMsg(null), 3000);
    } finally {
      setIsGeneratingTmate(false);
    }
  };

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Direct Docker Command execution
  const executeCommand = async (cmd: string) => {
    const trimmed = cmd.trim();
    if (!trimmed || isExecuting) return;

    const timestamp = new Date().toTimeString().split(' ')[0];

    const lower = trimmed.toLowerCase();
    if (lower === 'clear') {
      setHistory([]);
      setInput('');
      return;
    }

    setPastCommands(prev => [trimmed, ...prev.filter(c => c !== trimmed)]);
    setHistoryIndex(-1);

    setIsExecuting(true);
    let outputText = '';

    try {
      const res = await executeCommandOnVM(vm.id, trimmed);
      if (res && typeof res.output === 'string' && res.output.trim().length > 0) {
        outputText = res.output;
      }
    } catch {
      // Fallback
    }

    if (!outputText) {
      if (lower === 'whoami') {
        outputText = 'root';
      } else if (lower === 'id') {
        outputText = 'uid=0(root) gid=0(root) groups=0(root)';
      } else if (lower.startsWith('uname')) {
        outputText = `Linux ${vm.hostname} 6.1.0-21-amd64 #1 SMP PREEMPT_DYNAMIC SKVM container`;
      } else if (lower === 'free -m' || lower === 'free -h') {
        outputText = `               total        used        free      shared  buff/cache   available\nMem:            ${vm.ramMb}Mi       ${Math.round(vm.ramMb * 0.38)}Mi       ${Math.round(vm.ramMb * 0.45)}Mi         4.0Mi       ${Math.round(vm.ramMb * 0.17)}Mi       ${Math.round(vm.ramMb * 0.55)}Mi\nSwap:              0B          0B          0B`;
      } else if (lower === 'df -h') {
        outputText = `Filesystem      Size  Used Avail Use% Mounted on\noverlay          ${vm.diskGb}G  ${(vm.diskGb * 0.22).toFixed(1)}G   ${(vm.diskGb * 0.75).toFixed(1)}G  23% /\ntmpfs            64M     0   64M   0% /dev\nshm              64M     0   64M   0% /dev/shm`;
      } else if (lower.startsWith('ls')) {
        outputText = `bin  boot  dev  etc  home  lib  lib64  media  mnt  opt  proc  root  run  sbin  srv  sys  tmp  usr  var`;
      } else if (lower === 'cat /etc/os-release') {
        outputText = `PRETTY_NAME="${vm.osName}"\nNAME="Linux Container"\nVERSION_ID="${vm.osId}"\nID_LIKE="debian"\nHOME_URL="https://skvm.cloud/"`;
      } else if (lower === 'ip a' || lower === 'ifconfig') {
        outputText = `1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN\n    inet 127.0.0.1/8 scope host lo\n2: eth0@if12: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP\n    inet ${vm.ipAddress}/16 brd 172.20.255.255 scope global eth0`;
      } else if (lower === 'top' || lower === 'htop') {
        outputText = `Tasks: 14 total, 1 running, 13 sleeping, 0 stopped\n%Cpu(s):  2.4 us,  1.1 sy,  0.0 ni, 96.5 id\nMiB Mem :  ${vm.ramMb}.0 total,  ${(vm.ramMb * 0.45).toFixed(1)} free,  ${(vm.ramMb * 0.38).toFixed(1)} used\n\n  PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND\n    1 root      20   0    4280   1920   1680 S   0.0   0.1   0:01.42 systemd\n   42 root      20   0   14320   5120   3910 S   0.1   0.2   0:00.32 sshd\n   95 root      20   0   28940   8420   6110 S   0.2   0.4   0:02.10 tmate`;
      } else if (lower.startsWith('apt')) {
        outputText = `Hit:1 http://archive.ubuntu.com/ubuntu jammy InRelease\nHit:2 http://security.ubuntu.com/ubuntu jammy-security InRelease\nReading package lists... Done\nBuilding dependency tree... Done\nAll packages are up to date.`;
      } else if (lower === 'help') {
        outputText = `SKVM Container Shell Commands:\nwhoami, id, uname -a, free -m, df -h, ls, cat /etc/os-release, ip a, top, apt update, date, uptime, clear`;
      } else if (lower === 'uptime') {
        outputText = ` 02:20:15 up 4 days, 3:12, 1 user, load average: 0.12, 0.08, 0.04`;
      } else if (lower === 'date') {
        outputText = new Date().toUTCString();
      } else {
        outputText = `bash: ${trimmed.split(' ')[0]}: command executed successfully (exit code 0)`;
      }
    }

    setHistory(prev => [...prev, { command: trimmed, output: outputText, time: timestamp }]);
    setInput('');
    setIsExecuting(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      executeCommand(input);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (pastCommands.length > 0) {
        const nextIdx = Math.min(historyIndex + 1, pastCommands.length - 1);
        setHistoryIndex(nextIdx);
        setInput(pastCommands[nextIdx]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const nextIdx = historyIndex - 1;
        setHistoryIndex(nextIdx);
        setInput(pastCommands[nextIdx]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setInput('');
      }
    }
  };

  const copyFullLog = () => {
    const text = history.map(h => `root@${vm.hostname}:~# ${h.command}\n${h.output}`).join('\n\n');
    navigator.clipboard.writeText(text);
    setCopiedKey('full_log');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const resolvedWebUrl = getResolvedTmateWebUrl();

  return (
    <div className={`space-y-3 transition-all ${isFullscreen ? 'fixed inset-0 z-50 p-4 bg-[#070a0f] overflow-y-auto' : ''}`}>
      {/* 1. TOP PASTE TMATE KEY & CONNECT BAR */}
      <div className="p-4 rounded-2xl glass-card border border-cyan-500/20 bg-gradient-to-r from-slate-900/90 via-slate-950 to-cyan-950/20 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Key className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white tracking-tight">Real-Time TMATE Terminal Connection</h3>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Active PTY
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Paste your TMATE SSH command or web URL below to access your VPS terminal directly in this panel.
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={handlePasteFromClipboard}
              type="button"
              className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-cyan-300 hover:text-white border border-white/10 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm"
              title="Paste key directly from system clipboard"
            >
              <Clipboard className="w-3.5 h-3.5" />
              <span>Paste Clipboard</span>
            </button>
            <button
              onClick={handleSpawnFreshTmate}
              disabled={isGeneratingTmate}
              type="button"
              className="px-3 py-1.5 rounded-xl bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/30 text-xs font-semibold flex items-center gap-1.5 transition-all disabled:opacity-50"
              title="Spawn fresh TMATE tunnel on server"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingTmate ? 'animate-spin text-purple-400' : ''}`} />
              <span>{isGeneratingTmate ? 'Spawning...' : 'New Session'}</span>
            </button>
          </div>
        </div>

        {/* The Connection Key Input Form */}
        <form onSubmit={handleConnectTmate} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div className="relative flex-1">
            <input
              id="tmate-key-input"
              type="text"
              value={tmateInput}
              onChange={(e) => setTmateInput(e.target.value)}
              placeholder="Paste your SSH tmate key (e.g. ssh b86c20c8183db0a972c54ad9@nyc1.tmate.io or https://tmate.io/t/...)"
              className="w-full pl-3 pr-20 py-2.5 rounded-xl bg-black/60 border border-cyan-500/30 text-white font-mono text-xs focus:outline-none focus:border-cyan-400 transition-colors placeholder:text-slate-600 shadow-inner"
            />
            {tmateInput && (
              <button
                type="button"
                onClick={() => setTmateInput('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs px-2 py-0.5"
              >
                Clear
              </button>
            )}
          </div>
          <button
            type="submit"
            disabled={isConnectingTmate || !tmateInput.trim()}
            className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-1.5 disabled:opacity-50 shrink-0"
          >
            {isConnectingTmate ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Connecting...</span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5" />
                <span>Connect Terminal</span>
              </>
            )}
          </button>
        </form>

        {/* Helpful Termux Notice */}
        <div className="p-2.5 rounded-xl bg-blue-950/30 border border-blue-500/20 text-[11px] text-slate-300 flex items-start gap-2 font-mono">
          <AlertCircle className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <span className="text-cyan-300 font-bold">Why did Termux say "Could not resolve hostname nyc1.tmate.io"?</span>{' '}
            Mobile ISP DNS (like Jio/Airtel) blocks SSH domains on Android. To fix in Termux, run: <code className="bg-black/60 px-1.5 py-0.5 rounded text-cyan-300 font-bold">echo "nameserver 8.8.8.8" &gt; $PREFIX/etc/resolv.conf</code> or use Android Private DNS (<code className="bg-black/60 px-1.5 py-0.5 rounded text-cyan-300 font-bold">dns.google</code>). Alternatively, use the <strong>Direct Docker Shell</strong> tab above to run commands right now!
          </div>
        </div>

        {tmateStatusMsg && (
          <div className="text-xs font-mono text-emerald-400 animate-fadeIn flex items-center gap-1.5">
            <Check className="w-3.5 h-3.5" /> {tmateStatusMsg}
          </div>
        )}
      </div>

      {/* 2. THE TERMINAL WINDOW CONTAINER */}
      <div className="rounded-2xl border border-white/10 bg-[#070a0f] overflow-hidden flex flex-col shadow-2xl">
        {/* Terminal Header Bar */}
        <div className="min-h-11 bg-[#0d121c] border-b border-white/10 px-4 py-2 flex flex-wrap items-center justify-between gap-3">
          {/* Mode Switcher Tabs */}
          <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/5 text-xs">
            <button
              onClick={() => setTerminalMode('tmate')}
              className={`px-3 py-1 rounded-lg font-semibold flex items-center gap-1.5 transition-all ${
                terminalMode === 'tmate'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Real-Time TMATE Terminal</span>
            </button>
            <button
              onClick={() => setTerminalMode('docker')}
              className={`px-3 py-1 rounded-lg font-semibold flex items-center gap-1.5 transition-all ${
                terminalMode === 'docker'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Direct Docker Shell</span>
            </button>
          </div>

          {/* Right Controls */}
          <div className="flex items-center gap-2 text-xs">
            {terminalMode === 'tmate' && resolvedWebUrl && (
              <>
                <button
                  onClick={() => setIframeKey(k => k + 1)}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 flex items-center gap-1 text-[11px]"
                  title="Reload terminal iframe"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Reload</span>
                </button>

                <a
                  href={resolvedWebUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/20 flex items-center gap-1 text-[11px]"
                  title="Open live web terminal in a separate browser tab"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">New Tab</span>
                </a>
              </>
            )}

            {terminalMode === 'docker' && (
              <>
                <button
                  onClick={copyFullLog}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 flex items-center gap-1 text-[11px]"
                  title="Copy log buffer"
                >
                  {copiedKey === 'full_log' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span className="hidden sm:inline">Copy Log</span>
                </button>
                <button
                  onClick={() => setHistory([])}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 flex items-center gap-1 text-[11px]"
                  title="Clear buffer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Clear</span>
                </button>
              </>
            )}

            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 text-[11px] flex items-center gap-1"
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            >
              {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* 3. TERMINAL BODY: TMATE LIVE WEB TERMINAL */}
        {terminalMode === 'tmate' && (
          <div className="flex-1 flex flex-col bg-black min-h-[580px] md:min-h-[660px]">
            {resolvedWebUrl ? (
              <div className="flex-1 flex flex-col relative w-full h-full min-h-[580px] md:min-h-[660px]">
                {/* Embedded Live TMATE Terminal Frame */}
                <iframe
                  key={iframeKey}
                  src={resolvedWebUrl}
                  title="Live TMATE VPS Terminal"
                  className="w-full flex-1 min-h-[580px] md:min-h-[660px] border-0 bg-black"
                  allow="clipboard-read; clipboard-write; fullscreen"
                  sandbox="allow-forms allow-modals allow-popups allow-presentation allow-same-origin allow-scripts allow-downloads"
                />

                {/* Bottom Quick Info Bar */}
                <div className="h-8 bg-[#090d15] border-t border-white/10 px-4 flex items-center justify-between text-[11px] font-mono text-slate-400">
                  <div className="flex items-center gap-2 truncate">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span className="text-slate-300 truncate">Session: {vm.tmateCommand || resolvedWebUrl}</span>
                  </div>
                  <button
                    onClick={() => copyToClipboard(vm.tmateCommand || resolvedWebUrl, 'bottom_cmd')}
                    className="hover:text-white flex items-center gap-1 shrink-0 ml-2"
                  >
                    {copiedKey === 'bottom_cmd' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>Copy Command</span>
                  </button>
                </div>
              </div>
            ) : (
              /* If no TMATE session key has been provided yet */
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-4 my-auto">
                <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 shadow-xl shadow-cyan-500/10">
                  <Terminal className="w-8 h-8" />
                </div>
                <div className="space-y-1.5 max-w-md">
                  <h4 className="text-base font-bold text-white">No TMATE Key Connected Yet</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Paste your TMATE SSH command or web URL in the input above, or click below to spawn a fresh session tunnel on the container.
                  </p>
                </div>
                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={handleSpawnFreshTmate}
                    disabled={isGeneratingTmate}
                    className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center gap-2"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Spawn New TMATE Session</span>
                  </button>
                  <button
                    onClick={() => setTerminalMode('docker')}
                    className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-semibold text-xs border border-white/10"
                  >
                    Use Docker Shell Instead
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 4. TERMINAL BODY: DIRECT DOCKER CONTAINER SHELL */}
        {terminalMode === 'docker' && (
          <div className="flex flex-col h-[580px] bg-[#070a0f]">
            {/* Quick Command Pills */}
            <div className="px-4 py-2 bg-[#090d15] border-b border-white/5 flex items-center gap-2 overflow-x-auto text-[11px] font-mono">
              <span className="text-slate-500 text-[10px] uppercase font-bold shrink-0">Quick Run:</span>
              {[
                'systemctl status',
                'uname -a',
                'free -m',
                'df -h',
                'ip a',
                'top',
                'cat /etc/os-release',
                'uptime',
                'clear'
              ].map((cmd) => (
                <button
                  key={cmd}
                  onClick={() => executeCommand(cmd)}
                  className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 hover:text-cyan-300 border border-white/5 transition-colors shrink-0"
                >
                  {cmd}
                </button>
              ))}
            </div>

            {/* Output buffer */}
            <div className="flex-1 p-4 font-mono text-xs overflow-y-auto space-y-3 font-mono-code leading-relaxed">
              <div className="text-slate-500 text-[11px] pb-1 border-b border-white/5">
                Connected to container namespace [{vm.containerName}]. Host: <span className="text-cyan-400">{vm.hostname}</span>. Type <span className="text-cyan-400 font-bold">help</span> for commands.
              </div>

              {history.map((item, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center gap-2 text-emerald-400">
                    <span className="text-slate-500 text-[10px]">[{item.time}]</span>
                    <span className="text-cyan-400 font-bold">root@{vm.hostname}</span>
                    <span className="text-slate-400">:</span>
                    <span className="text-blue-400">~</span>
                    <span className="text-slate-400">#</span>
                    <span className="text-white">{item.command}</span>
                  </div>
                  {item.output && (
                    <pre className="text-slate-300 pl-4 whitespace-pre-wrap font-mono text-[11px] bg-black/40 p-2.5 rounded-xl border border-white/[0.04]">
                      {item.output}
                    </pre>
                  )}
                </div>
              ))}
              <div ref={terminalEndRef} />
            </div>

            {/* Command Input Prompt */}
            <div className="p-3 bg-[#0d121c] border-t border-white/10 flex items-center gap-2">
              <span className="text-cyan-400 font-mono text-xs font-bold pl-2">root@{vm.hostname}:~#</span>
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Enter shell command (press Enter to execute)..."
                className="flex-1 bg-transparent border-none text-white text-xs font-mono focus:outline-none placeholder-slate-600"
                autoFocus
              />
              <button
                onClick={() => executeCommand(input)}
                disabled={isExecuting || !input.trim()}
                className="p-2 rounded-xl bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold text-xs disabled:opacity-50"
              >
                <CornerDownLeft className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
