import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { UserCheck, Shield, Key, Check, CheckCircle2, Lock } from 'lucide-react';

export const UserSettings: React.FC = () => {
  const { currentUser } = useSKVM();
  const [twoFactor, setTwoFactor] = useState(currentUser?.twoFactorEnabled || false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handlePasswordUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMsg('Password successfully changed.');
    setCurrentPassword('');
    setNewPassword('');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-4xl mx-auto">
      <div>
        <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <UserCheck className="w-6 h-6 text-cyan-400" />
          Account & Security Preferences
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Manage your credentials, SSH key authorization, and two-factor authentication.
        </p>
      </div>

      <div className="space-y-6">
        {/* Account Details Card */}
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4 text-xs font-mono">
          <h3 className="text-sm font-bold text-white font-sans">Profile Information</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-black/40 p-3 rounded-xl border border-white/5">
              <span className="text-slate-500 text-[10px] block">Username</span>
              <span className="text-white font-bold">{currentUser?.username}</span>
            </div>
            <div className="bg-black/40 p-3 rounded-xl border border-white/5">
              <span className="text-slate-500 text-[10px] block">Email Address</span>
              <span className="text-white font-bold">{currentUser?.email}</span>
            </div>
            <div className="bg-black/40 p-3 rounded-xl border border-white/5">
              <span className="text-slate-500 text-[10px] block">Account Role</span>
              <span className="text-cyan-400 font-bold">{currentUser?.role}</span>
            </div>
            <div className="bg-black/40 p-3 rounded-xl border border-white/5">
              <span className="text-slate-500 text-[10px] block">Account Status</span>
              <span className="text-emerald-400 font-bold">Active & Verified</span>
            </div>
          </div>
        </div>

        {/* Change Password Form */}
        <form onSubmit={handlePasswordUpdate} className="p-6 rounded-2xl glass-card border border-white/5 space-y-4 text-xs">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Lock className="w-4 h-4 text-cyan-400" /> Update Password
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-400 block mb-1">Current Password</label>
              <input
                type="password"
                placeholder="••••••••"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white"
                required
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">New Password</label>
              <input
                type="password"
                placeholder="••••••••"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white"
                required
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            {successMsg && (
              <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                <CheckCircle2 className="w-4 h-4" /> {successMsg}
              </span>
            )}
            <div className="ml-auto">
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400"
              >
                Update Credentials
              </button>
            </div>
          </div>
        </form>

        {/* 2FA Card */}
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-3 text-xs flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-purple-400" /> Two-Factor Authentication (2FA)
            </h3>
            <p className="text-slate-400 mt-1">
              Require a TOTP verification code from an authenticator app when logging in.
            </p>
          </div>
          <button
            onClick={() => setTwoFactor(!twoFactor)}
            className={`px-3 py-1.5 rounded-xl font-bold font-mono text-xs border transition-all ${
              twoFactor
                ? 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                : 'bg-white/5 text-slate-400 border-white/10 hover:text-white'
            }`}
          >
            {twoFactor ? 'ENABLED' : 'DISABLED'}
          </button>
        </div>
      </div>
    </div>
  );
};
