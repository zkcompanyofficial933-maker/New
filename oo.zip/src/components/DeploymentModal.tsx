import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { X, Copy, Check, Terminal, FileCode, CheckCircle2, Download, ExternalLink } from 'lucide-react';

export const DeploymentModal: React.FC = () => {
  const { isInstallModalOpen, setIsInstallModalOpen } = useSKVM();
  const [activeTab, setActiveTab] = useState<'installer' | 'node' | 'instructions'>('installer');
  const [copied, setCopied] = useState(false);

  if (!isInstallModalOpen) return null;

  const installCommand = `curl -fsSL https://skvm.cloud/install.sh | sudo bash`;

  const installScriptContent = `#!/usr/bin/env bash
# ==============================================================================
# SKVM - Enterprise Docker-Based VPS Management Panel
# Automated Linux VPS Production Installer
# Supported OS: Ubuntu 20.04+, 22.04+, 24.04+ / Debian 11, 12
# ==============================================================================
set -e

echo "=== [1/6] Validating Root Privileges & System Compatibility ==="
if [ "$EUID" -ne 0 ]; then
  echo "Error: Please run as root (sudo bash install.sh)"
  exit 1
fi

echo "=== [2/6] Updating APT Repositories & Installing Prerequisites ==="
apt-get update -y
apt-get install -y curl wget git python3 python3-pip python3-venv docker.io tmate htop net-tools ufw

echo "=== [3/6] Configuring Docker Engine & Daemon UNIX Socket ==="
systemctl enable --now docker
usermod -aG docker $USER

echo "=== [4/6] Setting Up Python Virtualenv & Installing Dependencies ==="
mkdir -p /opt/skvm
cd /opt/skvm
python3 -m venv venv
./venv/bin/pip install --upgrade pip
./venv/bin/pip install flask flask-login flask-sqlalchemy flask-socketio docker gunicorn eventlet psutil requests

echo "=== [5/6] Deploying SKVM Systemd Service ==="
cat << 'EOF' > /etc/systemd/system/skvm.service
[Unit]
Description=SKVM Cloud Orchestrator Daemon
After=network.target docker.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/skvm
ExecStart=/opt/skvm/venv/bin/gunicorn --worker-class eventlet -w 1 --bind 0.0.0.0:3000 skvm:app
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now skvm

echo "=== [6/6] SKVM Installed Successfully! ==="
SERVER_IP=$(curl -s ifconfig.me || hostname -I | awk '{print $1}')
echo "--------------------------------------------------------"
echo " Access your panel at: http://$SERVER_IP:3000"
echo " Default Admin: admin / Password: admin"
echo "--------------------------------------------------------"`;

  const nodeAgentCommand = `# Run on remote node to connect to SKVM Master:
python3 node.py --panel-url http://YOUR_PANEL_IP:3000 --token YOUR_NODE_TOKEN`;

  const copyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-3xl rounded-2xl glass-card border border-white/10 shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-bold">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Production VPS Deployment</h3>
              <p className="text-xs text-slate-400">Deploy SKVM on any Ubuntu/Debian Linux Server</p>
            </div>
          </div>
          <button
            onClick={() => setIsInstallModalOpen(false)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-white/5 bg-black/30 px-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('installer')}
            className={`py-2.5 px-3 border-b-2 transition-all ${
              activeTab === 'installer' ? 'border-cyan-400 text-cyan-300 font-bold' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            One-Line Installer (install.sh)
          </button>
          <button
            onClick={() => setActiveTab('node')}
            className={`py-2.5 px-3 border-b-2 transition-all ${
              activeTab === 'node' ? 'border-cyan-400 text-cyan-300 font-bold' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Remote Node Agent (node.py)
          </button>
          <button
            onClick={() => setActiveTab('instructions')}
            className={`py-2.5 px-3 border-b-2 transition-all ${
              activeTab === 'instructions' ? 'border-cyan-400 text-cyan-300 font-bold' : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Requirements & Architecture
          </button>
        </div>

        {/* Content Area */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4 text-xs">
          {activeTab === 'installer' && (
            <div className="space-y-4">
              <div>
                <span className="text-slate-300 font-bold block mb-1.5">Single Line Quick Install</span>
                <div className="p-3 rounded-xl bg-black/60 border border-cyan-500/30 font-mono text-cyan-300 flex items-center justify-between select-all">
                  <span>{installCommand}</span>
                  <button
                    onClick={() => copyText(installCommand)}
                    className="p-1 text-slate-400 hover:text-white"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-slate-300 font-bold">Raw install.sh Script</span>
                  <button
                    onClick={() => copyText(installScriptContent)}
                    className="text-xs text-cyan-400 hover:underline flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" /> Copy Script
                  </button>
                </div>
                <pre className="p-4 rounded-xl bg-[#090d14] border border-white/5 font-mono text-[11px] text-slate-300 overflow-x-auto max-h-64 leading-relaxed">
                  {installScriptContent}
                </pre>
              </div>
            </div>
          )}

          {activeTab === 'node' && (
            <div className="space-y-3">
              <p className="text-slate-300 leading-relaxed">
                Connect multiple VPS nodes to your central SKVM master. The <strong className="text-cyan-400">node.py</strong> agent communicates with the panel over HTTPS with token authentication and reports live container metrics.
              </p>
              <div className="p-3 rounded-xl bg-black/60 border border-white/10 font-mono text-slate-300 flex items-center justify-between select-all">
                <span>{nodeAgentCommand}</span>
                <button
                  onClick={() => copyText(nodeAgentCommand)}
                  className="p-1 text-slate-400 hover:text-white"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          {activeTab === 'instructions' && (
            <div className="space-y-4 text-slate-300 leading-relaxed">
              <div>
                <h4 className="text-white font-bold mb-1">Fixing Docker Daemon Offline on your VPS:</h4>
                <p className="text-slate-400 mb-2">If your Docker daemon was reported offline after running <code className="text-cyan-300 font-mono">install.sh</code>, run these 3 quick commands on your server:</p>
                <div className="p-3 rounded-xl bg-black/60 border border-amber-500/30 font-mono text-[11px] text-amber-300 space-y-1">
                  <div>sudo systemctl unmask docker.service docker.socket</div>
                  <div>sudo systemctl daemon-reload</div>
                  <div>sudo systemctl restart docker &amp;&amp; sudo chmod 666 /var/run/docker.sock</div>
                  <div>sudo docker ps</div>
                </div>
              </div>

              <div>
                <h4 className="text-white font-bold mb-1">System Prerequisites:</h4>
                <ul className="list-disc pl-5 space-y-1 text-slate-400">
                  <li>Linux Server (Ubuntu 20.04+, 22.04+, 24.04+, Debian 11/12, or CentOS/Rocky 9)</li>
                  <li>Minimum 1 GB RAM (2 GB+ recommended for multi-container nodes)</li>
                  <li>Docker Engine installed and running with socket privileges</li>
                  <li>Node.js 20+ &amp; Python 3.9+</li>
                  <li>Port 3000 open in firewall (<code className="text-cyan-300 font-mono">sudo ufw allow 3000/tcp</code>)</li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/5 flex items-center justify-between bg-black/20">
          <span className="text-[11px] text-slate-500 font-mono">Real Linux VPS Deployment Ready</span>
          <button
            onClick={() => setIsInstallModalOpen(false)}
            className="px-4 py-1.5 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
