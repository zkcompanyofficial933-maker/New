import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { 
  UserCheck, Shield, Key, Lock, Mail, Clock, 
  Cpu, HardDrive, Zap, Check, Copy, Trash2, Plus, 
  Terminal, AlertCircle, CheckCircle2, ShieldCheck
} from 'lucide-react';

export const ProfilePage: React.FC = () => {
  const { currentUser, vms, switchRole } = useSKVM();
  const isAdmin = currentUser?.role === 'ADMIN';

  // User-specific VM allocations
  const userVMs = vms.filter(v => v.userId === currentUser?.id);
  const totalRam = userVMs.reduce((a, b) => a + b.ramMb, 0);
  const totalCpu = userVMs.reduce((a, b) => a + b.cpuCores, 0);
  const totalDisk = userVMs.reduce((a, b) => a + b.diskGb, 0);

  // SSH Keys state
  const [sshKeys, setSshKeys] = useState<{ id: number; name: string; fingerprint: string; key: string; date: string }[]>([
    {
      id: 1,
      name: 'Default Workstation ED25519',
      fingerprint: 'SHA256:7mK9+sP0L8wX21nQ9B41k8yZ1',
      key: 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIK71e8Q0pW9nL... user@workstation',
      date: '2026-02-15'
    }
  ]);
  const [showAddKeyModal, setShowAddKeyModal] = useState(false);
  const [keyName, setKeyName] = useState('');
  const [keyContent, setKeyContent] = useState('');

  // API Tokens state
  const [apiTokens, setApiTokens] = useState<{ id: number; name: string; token: string; createdAt: string }[]>([
    {
      id: 1,
      name: 'Terraform & CI/CD Runner',
      token: 'skvm_usr_tok_98f12a4b88910cd',
      createdAt: '2026-03-01'
    }
  ]);
  const [showTokenModal, setShowTokenModal] = useState(false);
  const [tokenName, setTokenName] = useState('');
  const [copiedToken, setCopiedToken] = useState<string | null>(null);

  const handleAddKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyName.trim() || !keyContent.trim()) return;
    const newKey = {
      id: Date.now(),
      name: keyName.trim(),
      fingerprint: `SHA256:${Math.random().toString(36).substring(2, 12).toUpperCase()}`,
      key: keyContent.trim(),
      date: new Date().toISOString().split('T')[0]
    };
    setSshKeys([...sshKeys, newKey]);
    setShowAddKeyModal(false);
    setKeyName('');
    setKeyContent('');
  };

  const handleDeleteKey = (id: number) => {
    setSshKeys(sshKeys.filter(k => k.id !== id));
  };

  const handleCreateToken = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tokenName.trim()) return;
    const newToken = {
      id: Date.now(),
      name: tokenName.trim(),
      token: `skvm_usr_tok_${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 10)}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setApiTokens([...apiTokens, newToken]);
    setShowTokenModal(false);
    setTokenName('');
  };

  const handleDeleteToken = (id: number) => {
    setApiTokens(apiTokens.filter(t => t.id !== id));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedToken(text);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto">
      {/* Profile Header Card */}
      <div className="p-6 rounded-2xl glass-card border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative overflow-hidden">
        <div className="flex items-center gap-4 relative z-10">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white font-extrabold text-2xl shadow-xl shadow-cyan-500/20">
            {currentUser?.username.substring(0, 2).toUpperCase() || 'US'}
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-2xl font-extrabold text-white tracking-tight">
                {currentUser?.username}
              </h2>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full font-mono uppercase ${
                isAdmin ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
              }`}>
                {currentUser?.role}
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                <CheckCircle2 className="w-3 h-3" /> Active
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 flex items-center gap-2 font-mono">
              <Mail className="w-3.5 h-3.5 text-slate-500" />
              {currentUser?.email}
              <span>&bull;</span>
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              Member since {currentUser?.createdAt ? new Date(currentUser.createdAt).toLocaleDateString() : '2026-01-01'}
            </p>
          </div>
        </div>

        <div className="relative z-10 flex gap-2">
          <button
            onClick={() => switchRole(isAdmin ? 'USER' : 'ADMIN')}
            className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-200 border border-white/10 text-xs font-semibold transition-all flex items-center gap-1.5"
          >
            <Shield className="w-3.5 h-3.5 text-cyan-400" />
            Switch to {isAdmin ? 'Client' : 'Admin'} View
          </button>
        </div>

        {/* Ambient Glow */}
        <div className="absolute right-0 top-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none"></div>
      </div>

      {/* Quotas & Assigned Hardware */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <span className="text-[11px] text-slate-400 font-medium">Assigned Virtual Machines</span>
          <div className="text-xl font-bold text-white font-mono flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            {userVMs.length} <span className="text-xs font-normal text-slate-400">Containers</span>
          </div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <span className="text-[11px] text-slate-400 font-medium">Total Memory Quota</span>
          <div className="text-xl font-bold text-white font-mono flex items-center gap-2">
            <Zap className="w-4 h-4 text-purple-400" />
            {(totalRam / 1024).toFixed(1)} <span className="text-xs font-normal text-slate-400">GB RAM</span>
          </div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <span className="text-[11px] text-slate-400 font-medium">Allocated Compute Cores</span>
          <div className="text-xl font-bold text-white font-mono flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-400" />
            {totalCpu.toFixed(1)} <span className="text-xs font-normal text-slate-400">vCPUs</span>
          </div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <span className="text-[11px] text-slate-400 font-medium">Assigned Storage</span>
          <div className="text-xl font-bold text-white font-mono flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-blue-400" />
            {totalDisk} <span className="text-xs font-normal text-slate-400">GB NVMe</span>
          </div>
        </div>
      </div>

      {/* SSH Public Keys Management */}
      <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Key className="w-4 h-4 text-cyan-400" /> Authorized SSH Keys
            </h3>
            <p className="text-xs text-slate-400">
              SSH public keys automatically injected into authorized_keys on newly created VPS instances
            </p>
          </div>
          <button
            onClick={() => setShowAddKeyModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-md shadow-cyan-500/10 flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" /> Add SSH Key
          </button>
        </div>

        {sshKeys.length === 0 ? (
          <div className="text-center py-8 border border-dashed border-white/10 rounded-xl text-xs text-slate-500">
            No SSH keys added yet. Add your public key for passwordless root console access.
          </div>
        ) : (
          <div className="space-y-2.5">
            {sshKeys.map(k => (
              <div key={k.id} className="p-3.5 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between text-xs">
                <div className="space-y-1">
                  <div className="font-semibold text-white flex items-center gap-2">
                    {k.name}
                    <span className="text-[10px] text-slate-400 font-mono">Added {k.date}</span>
                  </div>
                  <div className="text-[11px] font-mono text-cyan-400 truncate max-w-md">
                    {k.fingerprint}
                  </div>
                </div>
                <button
                  onClick={() => handleDeleteKey(k.id)}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
                  title="Remove Key"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* API Access Tokens */}
      <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-purple-400" /> Personal API Tokens
            </h3>
            <p className="text-xs text-slate-400">
              API tokens for authenticating with the SKVM REST API (/api/v1) and automating deployment pipelines
            </p>
          </div>
          <button
            onClick={() => setShowTokenModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 font-bold text-xs border border-purple-500/30 transition-all flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" /> Generate Token
          </button>
        </div>

        {apiTokens.length === 0 ? (
          <div className="text-center py-8 border border-dashed border-white/10 rounded-xl text-xs text-slate-500">
            No active API tokens. Generate a token to automate container deployments.
          </div>
        ) : (
          <div className="space-y-2.5">
            {apiTokens.map(tok => (
              <div key={tok.id} className="p-3.5 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between text-xs">
                <div className="space-y-1">
                  <div className="font-semibold text-white">{tok.name}</div>
                  <div className="text-[11px] font-mono text-slate-400 flex items-center gap-2">
                    <span>{tok.token.substring(0, 15)}••••••••••••</span>
                    <button
                      onClick={() => copyToClipboard(tok.token)}
                      className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 text-[10px]"
                    >
                      {copiedToken === tok.token ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      {copiedToken === tok.token ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                </div>
                <button
                  onClick={() => handleDeleteToken(tok.id)}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
                  title="Revoke Token"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add SSH Key Modal */}
      {showAddKeyModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl glass-card border border-white/10 p-6 space-y-4">
            <h3 className="text-base font-bold text-white">Add SSH Public Key</h3>
            <form onSubmit={handleAddKey} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-300 block mb-1 font-medium">Key Name</label>
                <input
                  type="text"
                  placeholder="e.g. MacBook Pro, Workstation Key"
                  value={keyName}
                  onChange={(e) => setKeyName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-cyan-500/50"
                  required
                />
              </div>
              <div>
                <label className="text-slate-300 block mb-1 font-medium">Public Key (ssh-rsa, ssh-ed25519, etc.)</label>
                <textarea
                  rows={4}
                  placeholder="Paste your public key starting with ssh-..."
                  value={keyContent}
                  onChange={(e) => setKeyContent(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white font-mono text-[11px] focus:outline-none focus:border-cyan-500/50"
                  required
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddKeyModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 hover:bg-white/10"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400"
                >
                  Save Key
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create Token Modal */}
      {showTokenModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl glass-card border border-white/10 p-6 space-y-4">
            <h3 className="text-base font-bold text-white">Generate API Access Token</h3>
            <form onSubmit={handleCreateToken} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-300 block mb-1 font-medium">Token Name / Description</label>
                <input
                  type="text"
                  placeholder="e.g. GitHub Actions, Backup Script"
                  value={tokenName}
                  onChange={(e) => setTokenName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-purple-500/50"
                  required
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowTokenModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 hover:bg-white/10"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-purple-500 text-white font-bold hover:bg-purple-400"
                >
                  Generate
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
