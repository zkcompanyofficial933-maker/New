import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { 
  Network, Plus, Trash2, Globe, Server, 
  ArrowRight, Check, Copy, AlertTriangle, ShieldCheck
} from 'lucide-react';

export const PortForwarding: React.FC = () => {
  const { 
    vms, 
    nodes, 
    portMappings, 
    addPortMapping, 
    deletePortMapping, 
    currentUser 
  } = useSKVM();
  const isAdmin = currentUser?.role === 'ADMIN';

  // Available VMs
  const availableVMs = isAdmin ? vms : vms.filter(v => v.userId === currentUser?.id);

  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedVmId, setSelectedVmId] = useState<number>(availableVMs[0]?.id || 0);
  const [internalPort, setInternalPort] = useState<number>(80);
  const [externalPort, setExternalPort] = useState<number>(10080);
  const [protocol, setProtocol] = useState<'TCP' | 'UDP'>('TCP');
  const [description, setDescription] = useState<string>('HTTP Web Traffic');
  const [copiedPort, setCopiedPort] = useState<number | null>(null);

  // Filter port mappings belonging to accessible VMs
  const visibleMappings = portMappings.filter(p => {
    const targetVm = vms.find(v => v.id === p.vmId);
    if (!targetVm) return false;
    if (isAdmin) return true;
    return targetVm.userId === currentUser?.id;
  });

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVmId) return;
    addPortMapping(Number(selectedVmId), Number(internalPort), Number(externalPort), protocol, description);
    setShowAddModal(false);
    setDescription('');
  };

  const copyCommand = (cmd: string, portId: number) => {
    navigator.clipboard.writeText(cmd);
    setCopiedPort(portId);
    setTimeout(() => setCopiedPort(null), 2000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Network className="w-6 h-6 text-cyan-400" />
            Port Forwarding & NAT Rules
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Map external hypervisor node ports to private container internal ports using Docker iptables DNAT routing
          </p>
        </div>

        {availableVMs.length > 0 && (
          <button
            onClick={() => {
              if (availableVMs.length > 0 && !selectedVmId) {
                setSelectedVmId(availableVMs[0].id);
              }
              setShowAddModal(true);
            }}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" /> Add Port Rule
          </button>
        )}
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <span className="text-[11px] text-slate-400 font-medium">Active NAT Port Mappings</span>
          <div className="text-2xl font-bold text-white font-mono text-cyan-400">
            {visibleMappings.length}
          </div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <span className="text-[11px] text-slate-400 font-medium">TCP Routing Status</span>
          <div className="text-2xl font-bold text-emerald-400 font-mono flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            Active
          </div>
        </div>

        <div className="p-4 rounded-xl glass-card border border-white/5 space-y-1">
          <span className="text-[11px] text-slate-400 font-medium">DNAT Security Engine</span>
          <div className="text-2xl font-bold text-white font-mono text-purple-400">
            iptables / nft
          </div>
        </div>
      </div>

      {/* Port Rules Table */}
      {visibleMappings.length === 0 ? (
        <div className="text-center py-16 rounded-2xl glass-card border border-white/5 space-y-3">
          <Network className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-sm font-bold text-white">No Port Mappings Configured</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            {availableVMs.length === 0
              ? 'You must have at least one active virtual machine to forward external ports.'
              : 'Create a port forwarding rule to expose web servers, SSH, databases, or custom game ports to the public internet.'}
          </p>
          {availableVMs.length > 0 && (
            <button
              onClick={() => {
                setSelectedVmId(availableVMs[0].id);
                setShowAddModal(true);
              }}
              className="mt-2 px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 text-xs font-bold hover:bg-cyan-400 inline-flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Forward New Port
            </button>
          )}
        </div>
      ) : (
        <div className="rounded-2xl glass-card border border-white/5 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/[0.02] border-b border-white/5 text-[11px] text-slate-400 font-mono uppercase">
                <tr>
                  <th className="px-5 py-3.5">Target VM</th>
                  <th className="px-5 py-3.5">Internal Port</th>
                  <th className="px-5 py-3.5">External Node Port</th>
                  <th className="px-5 py-3.5">Protocol</th>
                  <th className="px-5 py-3.5">Description</th>
                  <th className="px-5 py-3.5">Public Endpoint</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {visibleMappings.map((p) => {
                  const targetVm = vms.find(v => v.id === p.vmId);
                  const targetNode = nodes.find(n => n.id === targetVm?.nodeId);
                  const hostIp = targetNode?.hostname || 'node.skvm.internal';
                  const curlCmd = `curl http://${hostIp}:${p.externalPort}`;

                  return (
                    <tr key={p.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="px-5 py-4 font-semibold text-white">
                        {targetVm?.name || `VM #${p.vmId}`}
                      </td>
                      <td className="px-5 py-4 font-mono text-slate-300">
                        {p.internalPort}
                      </td>
                      <td className="px-5 py-4 font-mono text-cyan-400 font-bold">
                        {p.externalPort}
                      </td>
                      <td className="px-5 py-4">
                        <span className="px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 font-mono text-[10px] border border-cyan-500/20">
                          {p.protocol}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-slate-400">
                        {p.description || 'Custom Port Forward'}
                      </td>
                      <td className="px-5 py-4 font-mono text-[11px] text-slate-300">
                        <div className="flex items-center gap-2">
                          <span className="truncate max-w-[180px]">{hostIp}:{p.externalPort}</span>
                          <button
                            onClick={() => copyCommand(curlCmd, p.id)}
                            className="text-slate-500 hover:text-cyan-400 transition-colors"
                            title="Copy curl command"
                          >
                            {copiedPort === p.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </td>
                      <td className="px-5 py-4 text-right">
                        <button
                          onClick={() => deletePortMapping(p.id)}
                          className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
                          title="Delete Rule"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Port Mapping Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl glass-card border border-white/10 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/5">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Network className="w-4 h-4 text-cyan-400" /> Add Port Forwarding Rule
              </h3>
            </div>

            <form onSubmit={handleAdd} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-300 block mb-1 font-medium">Target Container Instance</label>
                <select
                  value={selectedVmId}
                  onChange={(e) => setSelectedVmId(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl bg-black/50 border border-white/10 text-white focus:outline-none focus:border-cyan-500/50"
                  required
                >
                  {availableVMs.map(v => (
                    <option key={v.id} value={v.id} className="bg-slate-900 text-white">
                      {v.name} ({v.ipAddress})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-medium">Internal Port</label>
                  <input
                    type="number"
                    min={1}
                    max={65535}
                    value={internalPort}
                    onChange={(e) => setInternalPort(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-black/50 border border-white/10 text-white font-mono focus:outline-none focus:border-cyan-500/50"
                    placeholder="e.g. 80"
                    required
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-medium">External Host Port</label>
                  <input
                    type="number"
                    min={1024}
                    max={65535}
                    value={externalPort}
                    onChange={(e) => setExternalPort(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl bg-black/50 border border-white/10 text-white font-mono focus:outline-none focus:border-cyan-500/50"
                    placeholder="e.g. 10080"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-medium">Protocol</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['TCP', 'UDP'] as const).map(p => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setProtocol(p)}
                      className={`py-2 rounded-xl font-bold font-mono text-xs border transition-all ${
                        protocol === p
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                          : 'bg-black/40 text-slate-400 border-white/10'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-medium">Description</label>
                <input
                  type="text"
                  placeholder="e.g. Web HTTP, MariaDB, OpenVPN"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-black/50 border border-white/10 text-white focus:outline-none focus:border-cyan-500/50"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-white/5">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 text-slate-300 hover:bg-white/10"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400"
                >
                  Apply NAT Rule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
