import React, { useState, useEffect } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { TerminalConsole } from './TerminalConsole';
import { OSLogo } from './OSLogo';
import { LiveMetricsChart } from './telemetry/LiveMetricsChart';
import { 
  Play, Square, RotateCw, Trash2, ArrowLeft, 
  Terminal, ShieldCheck, Copy, Check, ExternalLink, 
  Server, HardDrive, Cpu, Zap, Network, Folder, 
  Archive, Camera, RefreshCw, AlertTriangle, Globe, FileText,
  Key, Download, Eye, EyeOff, Sparkles
} from 'lucide-react';

export const VMDetail: React.FC = () => {
  const { 
    vms, 
    activeVmId, 
    setCurrentView, 
    startVM, 
    stopVM, 
    restartVM, 
    deleteVM, 
    reinstallVM,
    getLiveMetricsForVM,
    portMappings,
    addPortMapping,
    deletePortMapping,
    backups,
    createBackup,
    deleteBackup,
    snapshots,
    createSnapshot,
    deleteSnapshot,
    osImages,
    generateSSHKeyForVM,
    generateTmateSessionForVM,
    downloadPrivateKey
  } = useSKVM();

  const [activeTab, setActiveTab] = useState<'overview' | 'console' | 'files' | 'ports' | 'backups' | 'snapshots' | 'network'>('overview');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [confirmReinstall, setConfirmReinstall] = useState(false);
  const [selectedReinstallOs, setSelectedReinstallOs] = useState<number>(1);
  const [isGeneratingSSH, setIsGeneratingSSH] = useState(false);
  const [isSpawningTmate, setIsSpawningTmate] = useState(false);
  const [showPublicKeyModal, setShowPublicKeyModal] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Port modal state
  const [showPortModal, setShowPortModal] = useState(false);
  const [portInternal, setPortInternal] = useState(80);
  const [portExternal, setPortExternal] = useState(8080);
  const [portDesc, setPortDesc] = useState('');

  // Backup modal
  const [showBackupModal, setShowBackupModal] = useState(false);
  const [backupName, setBackupName] = useState('');

  // Snapshot modal
  const [showSnapshotModal, setShowSnapshotModal] = useState(false);
  const [snapshotName, setSnapshotName] = useState('');

  // Live tick effect to update statistics in real-time
  const [metricsTick, setMetricsTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setMetricsTick(t => t + 1), 2000);
    return () => clearInterval(timer);
  }, []);

  const vm = vms.find(v => v.id === activeVmId) || vms[0];

  if (!vm) {
    return (
      <div className="p-8 text-center space-y-4">
        <p className="text-slate-400">VM not found or has been deleted.</p>
        <button
          onClick={() => setCurrentView('vms')}
          className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs"
        >
          Return to VM List
        </button>
      </div>
    );
  }

  const liveStats = getLiveMetricsForVM(vm);
  const vmPorts = portMappings.filter(p => p.vmId === vm.id);
  const vmBackups = backups.filter(b => b.vmId === vm.id);
  const vmSnapshots = snapshots.filter(s => s.vmId === vm.id);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleCreatePort = (e: React.FormEvent) => {
    e.preventDefault();
    addPortMapping(vm.id, Number(portInternal), Number(portExternal), 'TCP', portDesc || 'Service Port');
    setShowPortModal(false);
  };

  const handleCreateBackup = (e: React.FormEvent) => {
    e.preventDefault();
    createBackup(vm.id, backupName || `${vm.name}-backup-${Date.now()}`);
    setBackupName('');
    setShowBackupModal(false);
  };

  const handleCreateSnapshot = (e: React.FormEvent) => {
    e.preventDefault();
    createSnapshot(vm.id, snapshotName || `snap-${Date.now()}`);
    setSnapshotName('');
    setShowSnapshotModal(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Breadcrumb & Control Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('vms')}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors border border-white/5"
            title="Back to VM list"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <OSLogo slug={vm.osIcon || vm.osName} name={vm.osName} size="md" />
          <div>
            <div className="flex items-center gap-2.5">
              <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">{vm.name}</h2>
              <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono uppercase ${
                vm.status === 'RUNNING'
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  : 'bg-slate-800 text-slate-400 border border-white/5'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${vm.status === 'RUNNING' ? 'bg-emerald-400 animate-pulse' : 'bg-slate-400'}`}></span>
                {vm.status}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              Container ID: <span className="text-cyan-400">{vm.containerId}</span> &bull; Node: {vm.nodeName} &bull; OS: {vm.osName}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {vm.status === 'RUNNING' ? (
            <>
              <button
                onClick={() => restartVM(vm.id)}
                className="px-3.5 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500 text-amber-300 hover:text-slate-950 font-bold text-xs transition-all border border-amber-500/20 flex items-center gap-1.5"
              >
                <RotateCw className="w-3.5 h-3.5" /> Restart
              </button>
              <button
                onClick={() => stopVM(vm.id)}
                className="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500 text-rose-300 hover:text-slate-950 font-bold text-xs transition-all border border-rose-500/20 flex items-center gap-1.5"
              >
                <Square className="w-3.5 h-3.5" /> Stop
              </button>
            </>
          ) : (
            <button
              onClick={() => startVM(vm.id)}
              className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-emerald-500/20 flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5" /> Start Instance
            </button>
          )}

          <button
            onClick={() => setConfirmReinstall(true)}
            className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white font-semibold text-xs border border-white/5 transition-all flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Reinstall OS
          </button>

          <button
            onClick={() => setConfirmDelete(true)}
            className="p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-white/5 transition-all"
            title="Delete VM"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Confirmation Modals for Reinstall & Delete */}
      {confirmDelete && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-rose-300 text-xs">
            <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
            <span>Are you sure you want to permanently delete <strong>{vm.name}</strong> and remove its Docker volume?</span>
          </div>
          <div className="flex gap-2 flex-shrink-0">
            <button
              onClick={() => setConfirmDelete(false)}
              className="px-3 py-1 rounded-lg bg-black/40 text-xs text-slate-300 hover:bg-black/60"
            >
              Cancel
            </button>
            <button
              onClick={() => { deleteVM(vm.id); setConfirmDelete(false); }}
              className="px-3 py-1 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs"
            >
              Confirm Delete
            </button>
          </div>
        </div>
      )}

      {confirmReinstall && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 space-y-3">
          <div className="flex items-center gap-2 text-amber-300 text-xs font-semibold">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Reinstall OS image template. All container filesystem changes will be reset.</span>
          </div>
          <div className="flex items-center gap-3">
            <select
              value={selectedReinstallOs}
              onChange={(e) => setSelectedReinstallOs(Number(e.target.value))}
              className="px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs text-white"
            >
              {osImages.map(img => (
                <option key={img.id} value={img.id}>{img.name} ({img.dockerImage})</option>
              ))}
            </select>
            <button
              onClick={() => { reinstallVM(vm.id, selectedReinstallOs); setConfirmReinstall(false); }}
              className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
            >
              Execute Reinstallation
            </button>
            <button
              onClick={() => setConfirmReinstall(false)}
              className="px-3 py-1.5 rounded-lg bg-black/40 text-xs text-slate-300"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Tabs Navigation Bar */}
      <div className="flex items-center gap-1.5 p-1 rounded-xl bg-black/30 border border-white/5 overflow-x-auto text-xs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'overview' ? 'bg-cyan-500 text-slate-950 shadow-md font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Server className="w-3.5 h-3.5" /> Overview & Live Stats
        </button>
        <button
          onClick={() => setActiveTab('console')}
          className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'console' ? 'bg-cyan-500 text-slate-950 shadow-md font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Terminal className="w-3.5 h-3.5" /> Web Console (PTY)
        </button>
        <button
          onClick={() => setActiveTab('ports')}
          className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'ports' ? 'bg-cyan-500 text-slate-950 shadow-md font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Globe className="w-3.5 h-3.5" /> Ports ({vmPorts.length})
        </button>
        <button
          onClick={() => setActiveTab('files')}
          className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'files' ? 'bg-cyan-500 text-slate-950 shadow-md font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Folder className="w-3.5 h-3.5" /> File Manager
        </button>
        <button
          onClick={() => setActiveTab('backups')}
          className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'backups' ? 'bg-cyan-500 text-slate-950 shadow-md font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Archive className="w-3.5 h-3.5" /> Backups ({vmBackups.length})
        </button>
        <button
          onClick={() => setActiveTab('snapshots')}
          className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'snapshots' ? 'bg-cyan-500 text-slate-950 shadow-md font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Camera className="w-3.5 h-3.5" /> Snapshots ({vmSnapshots.length})
        </button>
        <button
          onClick={() => setActiveTab('network')}
          className={`px-3.5 py-2 rounded-lg font-semibold transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'network' ? 'bg-cyan-500 text-slate-950 shadow-md font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Network className="w-3.5 h-3.5" /> IP & Networking
        </button>
      </div>

      {/* TAB CONTENT: OVERVIEW & REAL-TIME STATS */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* SSH & TMATE CREDENTIAL ACCESS CARDS */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Direct OpenSSH Access with Cryptographic Keypair */}
            <div className="p-5 rounded-2xl glass-card border border-white/5 space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
                    <Key className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider">OpenSSH Keypair & Shell</h4>
                      {vm.isRealDockerContainer && (
                        <span className="text-[9px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded">
                          Docker Engine
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-emerald-400 font-mono">
                      {vm.sshFingerprint ? `${vm.sshFingerprint.substring(0, 24)}...` : 'Status: Ready'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono bg-white/5 px-2 py-0.5 rounded text-slate-400">
                    Port {vm.sshPort}
                  </span>
                </div>
              </div>

              <div className="space-y-2.5 text-xs">
                {/* SSH Command */}
                <div>
                  <label className="text-[10px] text-slate-400 font-mono mb-1 block">Quick SSH Login (PEM Key):</label>
                  <div className="bg-black/60 p-2.5 rounded-xl border border-white/5 flex items-center justify-between">
                    <div className="font-mono text-slate-300 select-all text-[11px] truncate mr-2">
                      ssh -i {vm.name.toLowerCase()}-id_rsa.pem {vm.sshUser}@{vm.ipAddress} -p {vm.sshPort}
                    </div>
                    <button
                      onClick={() => copyToClipboard(`ssh -i ${vm.name.toLowerCase()}-id_rsa.pem ${vm.sshUser}@${vm.ipAddress} -p ${vm.sshPort}`, 'ssh_key_cmd')}
                      className="p-1 rounded text-slate-400 hover:text-white flex-shrink-0"
                      title="Copy command"
                    >
                      {copiedKey === 'ssh_key_cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {/* Password and User Grid */}
                <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                  <div className="bg-black/30 p-2 rounded-lg border border-white/5">
                    <span className="text-slate-500">User:</span> <span className="text-white font-bold">{vm.sshUser}</span>
                  </div>
                  <div className="bg-black/30 p-2 rounded-lg border border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 truncate">
                      <span className="text-slate-500">Pass:</span> 
                      <span className="text-cyan-300 font-bold">
                        {showPassword ? vm.sshPassword : '••••••••••••'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button
                        onClick={() => setShowPassword(!showPassword)}
                        className="text-slate-500 hover:text-slate-300 p-0.5"
                        title={showPassword ? 'Hide password' : 'Show password'}
                      >
                        {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      </button>
                      <button
                        onClick={() => copyToClipboard(vm.sshPassword, 'ssh_pwd')}
                        className="text-slate-400 hover:text-white p-0.5"
                        title="Copy password"
                      >
                        {copiedKey === 'ssh_pwd' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Key Management Actions */}
                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    onClick={() => downloadPrivateKey(vm)}
                    disabled={!vm.sshPrivateKey}
                    className="flex-1 py-1.5 px-2.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 font-medium text-[11px] flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
                  >
                    <Download className="w-3 h-3" /> Download .PEM Key
                  </button>

                  <button
                    onClick={() => setShowPublicKeyModal(true)}
                    className="py-1.5 px-2.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 font-medium text-[11px] flex items-center gap-1.5 transition-colors"
                  >
                    <Key className="w-3 h-3" /> Public Key
                  </button>

                  <button
                    onClick={async () => {
                      setIsGeneratingSSH(true);
                      await generateSSHKeyForVM(vm.id);
                      setIsGeneratingSSH(false);
                    }}
                    disabled={isGeneratingSSH}
                    className="py-1.5 px-2.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-white text-[11px] flex items-center gap-1 transition-colors disabled:opacity-50"
                    title="Rotate and inject fresh 2048-bit RSA keypair"
                  >
                    <RefreshCw className={`w-3 h-3 ${isGeneratingSSH ? 'animate-spin text-cyan-400' : ''}`} />
                    <span>Rotate</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Instant TMATE Session Access */}
            <div className="p-5 rounded-2xl glass-card border border-white/5 space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider">TMATE Terminal Tunnel</h4>
                      <span className="flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                        Live
                      </span>
                    </div>
                    <p className="text-[11px] text-purple-400 font-mono">Instant NAT-Bypassing Web Shell</p>
                  </div>
                </div>
                <button
                  onClick={async () => {
                    setIsSpawningTmate(true);
                    await generateTmateSessionForVM(vm.id);
                    setIsSpawningTmate(false);
                  }}
                  disabled={isSpawningTmate}
                  className="text-[10px] text-slate-400 hover:text-purple-300 flex items-center gap-1 bg-white/5 px-2 py-0.5 rounded border border-white/5"
                  title="Generate new TMATE session tunnel"
                >
                  <RefreshCw className={`w-2.5 h-2.5 ${isSpawningTmate ? 'animate-spin text-purple-400' : ''}`} />
                  Re-spawn
                </button>
              </div>

              <div className="space-y-2.5 text-xs">
                {/* TMATE SSH Command */}
                <div>
                  <label className="text-[10px] text-slate-400 font-mono mb-1 block">Encrypted SSH Tunnel:</label>
                  <div className="bg-black/60 p-2.5 rounded-xl border border-white/5 flex items-center justify-between">
                    <div className="font-mono text-slate-300 select-all text-[11px] truncate mr-2">
                      {vm.tmateCommand}
                    </div>
                    <button
                      onClick={() => copyToClipboard(vm.tmateCommand, 'tmate_cmd')}
                      className="p-1 rounded text-slate-400 hover:text-white flex-shrink-0"
                      title="Copy command"
                    >
                      {copiedKey === 'tmate_cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {/* TMATE Web Console URL & Direct Button */}
                <div className="bg-black/30 p-2 rounded-lg border border-white/5 flex items-center justify-between gap-2 text-[11px] font-mono">
                  <div className="truncate text-slate-400">
                    Web URL: <span className="text-cyan-400 select-all">{vm.tmateWeb}</span>
                  </div>
                  <button
                    onClick={() => copyToClipboard(vm.tmateWeb, 'tmate_web')}
                    className="p-1 rounded text-slate-400 hover:text-white flex-shrink-0"
                    title="Copy web link"
                  >
                    {copiedKey === 'tmate_web' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>

                {/* Live Web Console Button */}
                <div className="pt-1 flex flex-col sm:flex-row gap-2">
                  <button
                    onClick={() => setActiveTab('console')}
                    className="flex-1 py-2 px-3 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-lg shadow-cyan-500/20"
                  >
                    <Terminal className="w-3.5 h-3.5" /> Open Real-Time Terminal
                  </button>
                  <a
                    href={vm.tmateWeb}
                    target="_blank"
                    rel="noreferrer"
                    className="py-2 px-3 rounded-lg bg-white/5 hover:bg-white/10 text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors border border-white/10"
                    title="Open in new window"
                  >
                    <ExternalLink className="w-3.5 h-3.5" /> New Tab
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* REAL-TIME DOCKER STATS METERS */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {/* CPU */}
            <div className="p-5 rounded-2xl glass-card border border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-purple-400" /> CPU Usage
                </span>
                <span className="text-xs font-mono font-bold text-purple-400">{liveStats.cpuPercent}%</span>
              </div>
              <div className="text-2xl font-bold text-white font-mono">{liveStats.cpuPercent}%</div>
              <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-purple-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(100, liveStats.cpuPercent)}%` }}
                ></div>
              </div>
              <p className="text-[10px] text-slate-500 font-mono">Limit: {vm.cpuCores} Cores cgroup</p>
            </div>

            {/* RAM */}
            <div className="p-5 rounded-2xl glass-card border border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-cyan-400" /> RAM Memory
                </span>
                <span className="text-xs font-mono font-bold text-cyan-400">{liveStats.ramPercent}%</span>
              </div>
              <div className="text-2xl font-bold text-white font-mono">
                {liveStats.ramUsedMb} <span className="text-xs font-normal text-slate-400">/ {vm.ramMb} MB</span>
              </div>
              <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-cyan-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(100, liveStats.ramPercent)}%` }}
                ></div>
              </div>
              <p className="text-[10px] text-slate-500 font-mono">Enforced: Docker -m {vm.ramMb}m</p>
            </div>

            {/* DISK */}
            <div className="p-5 rounded-2xl glass-card border border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-emerald-400" /> Disk Quota
                </span>
                <span className="text-xs font-mono font-bold text-emerald-400">{liveStats.diskPercent}%</span>
              </div>
              <div className="text-2xl font-bold text-white font-mono">
                {liveStats.diskUsedGb} <span className="text-xs font-normal text-slate-400">/ {vm.diskGb} GB</span>
              </div>
              <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden">
                <div 
                  className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(100, liveStats.diskPercent)}%` }}
                ></div>
              </div>
              <p className="text-[10px] text-slate-500 font-mono">Volume: /var/lib/docker/overlay2</p>
            </div>

            {/* NETWORK */}
            <div className="p-5 rounded-2xl glass-card border border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Network className="w-3.5 h-3.5 text-amber-400" /> Network I/O
                </span>
                <span className="text-xs font-mono font-bold text-amber-400">Active</span>
              </div>
              <div className="text-sm font-bold text-white font-mono space-y-1">
                <div>RX: <span className="text-cyan-400">{liveStats.netRxKbps} KB/s</span></div>
                <div>TX: <span className="text-emerald-400">{liveStats.netTxKbps} KB/s</span></div>
              </div>
              <p className="text-[10px] text-slate-500 font-mono">Bridge: docker0</p>
            </div>
          </div>

          {/* Recharts Live Metrics Graph */}
          <LiveMetricsChart
            title={`Real-Time Telemetry: ${vm.name}`}
            subtitle={`Live monitoring for container ${vm.containerName} (${vm.ipAddress}) on ${vm.nodeName}`}
            targetType="user_vms"
            targetOptions={[{ id: vm.id, label: vm.name, sublabel: vm.status }]}
            selectedTargetId={vm.id}
            onSelectTarget={() => {}}
            baseCpu={liveStats.cpuPercent}
            baseRamMb={liveStats.ramUsedMb}
            totalRamMb={vm.ramMb}
            isRunning={vm.status === 'RUNNING'}
          />

          {/* VM SPECIFICATIONS GRID */}
          <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
            <h3 className="text-sm font-bold text-white">Container Instance Metadata</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
              <div className="bg-black/30 p-3 rounded-xl border border-white/5 flex items-center gap-2.5">
                <OSLogo slug={vm.osIcon || vm.osName} name={vm.osName} size="sm" />
                <div>
                  <span className="text-slate-500 block text-[10px]">OS Template</span>
                  <span className="text-white font-semibold">{vm.osName}</span>
                </div>
              </div>
              <div className="bg-black/30 p-3 rounded-xl border border-white/5">
                <span className="text-slate-500 block text-[10px]">Docker Image</span>
                <span className="text-cyan-300 truncate block">{vm.osImage}</span>
              </div>
              <div className="bg-black/30 p-3 rounded-xl border border-white/5">
                <span className="text-slate-500 block text-[10px]">Private IPv4</span>
                <span className="text-white font-semibold">{vm.ipAddress}</span>
              </div>
              <div className="bg-black/30 p-3 rounded-xl border border-white/5">
                <span className="text-slate-500 block text-[10px]">Gateway</span>
                <span className="text-white font-semibold">{vm.gateway}</span>
              </div>
              <div className="bg-black/30 p-3 rounded-xl border border-white/5">
                <span className="text-slate-500 block text-[10px]">Container UUID</span>
                <span className="text-slate-300 text-[11px] truncate block">{vm.uuid}</span>
              </div>
              <div className="bg-black/30 p-3 rounded-xl border border-white/5">
                <span className="text-slate-500 block text-[10px]">Host Hypervisor Node</span>
                <span className="text-white font-semibold">{vm.nodeName}</span>
              </div>
              <div className="bg-black/30 p-3 rounded-xl border border-white/5">
                <span className="text-slate-500 block text-[10px]">Provisioned Date</span>
                <span className="text-white font-semibold">{new Date(vm.createdAt).toLocaleDateString()}</span>
              </div>
              <div className="bg-black/30 p-3 rounded-xl border border-white/5">
                <span className="text-slate-500 block text-[10px]">Isolation Engine</span>
                <span className="text-emerald-400 font-semibold">cgroups v2 + LXCFS</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: TERMINAL CONSOLE */}
      {activeTab === 'console' && (
        <div className="space-y-3">
          <TerminalConsole vm={vm} />
        </div>
      )}

      {/* TAB CONTENT: PORTS */}
      {activeTab === 'ports' && (
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Container Port Forwarding</h3>
              <p className="text-xs text-slate-400">Map internal container ports to host network interfaces</p>
            </div>
            <button
              onClick={() => setShowPortModal(true)}
              className="px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400"
            >
              + Add Port Mapping
            </button>
          </div>

          {showPortModal && (
            <form onSubmit={handleCreatePort} className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-400 mb-1 block">Internal Port</label>
                  <input
                    type="number"
                    value={portInternal}
                    onChange={(e) => setPortInternal(Number(e.target.value))}
                    className="w-full px-3 py-1.5 rounded bg-black border border-white/10 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-slate-400 mb-1 block">External Host Port</label>
                  <input
                    type="number"
                    value={portExternal}
                    onChange={(e) => setPortExternal(Number(e.target.value))}
                    className="w-full px-3 py-1.5 rounded bg-black border border-white/10 text-white"
                    required
                  />
                </div>
                <div>
                  <label className="text-slate-400 mb-1 block">Description</label>
                  <input
                    type="text"
                    placeholder="e.g. Web server"
                    value={portDesc}
                    onChange={(e) => setPortDesc(e.target.value)}
                    className="w-full px-3 py-1.5 rounded bg-black border border-white/10 text-white"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPortModal(false)}
                  className="px-3 py-1 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1 rounded bg-cyan-500 text-slate-950 font-bold"
                >
                  Save Mapping
                </button>
              </div>
            </form>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="text-[11px] text-slate-400 border-b border-white/5 uppercase">
                <tr>
                  <th className="py-2.5">Internal Port</th>
                  <th className="py-2.5">External Host Port</th>
                  <th className="py-2.5">Protocol</th>
                  <th className="py-2.5">Description</th>
                  <th className="py-2.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {vmPorts.map(p => (
                  <tr key={p.id}>
                    <td className="py-3 text-cyan-300 font-bold">{p.internalPort}</td>
                    <td className="py-3 text-white font-bold">{p.externalPort}</td>
                    <td className="py-3 text-slate-400">{p.protocol}</td>
                    <td className="py-3 text-slate-300">{p.description}</td>
                    <td className="py-3 text-right">
                      <button
                        onClick={() => deletePortMapping(p.id)}
                        className="text-rose-400 hover:text-rose-300 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB CONTENT: FILE MANAGER */}
      {activeTab === 'files' && (
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Container File Explorer</h3>
              <p className="text-xs text-slate-400">Browse filesystem roots inside {vm.containerName}</p>
            </div>
            <span className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-lg border border-cyan-500/20">
              Path: /var/www/
            </span>
          </div>

          <div className="p-4 rounded-xl bg-black/40 border border-white/5 space-y-2 font-mono text-xs">
            <div className="flex items-center justify-between p-2 hover:bg-white/5 rounded transition-colors text-slate-300">
              <span className="flex items-center gap-2"><Folder className="w-4 h-4 text-cyan-400" /> html/</span>
              <span className="text-slate-500 text-[11px]">drwxr-xr-x &bull; 4.0 KB</span>
            </div>
            <div className="flex items-center justify-between p-2 hover:bg-white/5 rounded transition-colors text-slate-300">
              <span className="flex items-center gap-2"><Folder className="w-4 h-4 text-cyan-400" /> logs/</span>
              <span className="text-slate-500 text-[11px]">drwxr-xr-x &bull; 4.0 KB</span>
            </div>
            <div className="flex items-center justify-between p-2 hover:bg-white/5 rounded transition-colors text-slate-300">
              <span className="flex items-center gap-2"><FileText className="w-4 h-4 text-emerald-400" /> index.html</span>
              <span className="text-slate-500 text-[11px]">-rw-r--r-- &bull; 2.4 KB</span>
            </div>
            <div className="flex items-center justify-between p-2 hover:bg-white/5 rounded transition-colors text-slate-300">
              <span className="flex items-center gap-2"><FileText className="w-4 h-4 text-emerald-400" /> app.py</span>
              <span className="text-slate-500 text-[11px]">-rw-r--r-- &bull; 1.8 KB</span>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: BACKUPS */}
      {activeTab === 'backups' && (
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Container Backups</h3>
              <p className="text-xs text-slate-400">Compressed tarballs of container persistent storage</p>
            </div>
            <button
              onClick={() => setShowBackupModal(true)}
              className="px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400"
            >
              + Create Backup
            </button>
          </div>

          {showBackupModal && (
            <form onSubmit={handleCreateBackup} className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3 text-xs">
              <div>
                <label className="text-slate-400 mb-1 block">Backup Label</label>
                <input
                  type="text"
                  placeholder="e.g. pre-migration-state"
                  value={backupName}
                  onChange={(e) => setBackupName(e.target.value)}
                  className="w-full px-3 py-1.5 rounded bg-black border border-white/10 text-white"
                  required
                />
              </div>
              <div className="flex justify-end gap-2">
                <button type="button" onClick={() => setShowBackupModal(false)} className="px-3 py-1 text-slate-400">Cancel</button>
                <button type="submit" className="px-3 py-1 rounded bg-cyan-500 text-slate-950 font-bold">Generate Backup</button>
              </div>
            </form>
          )}

          <div className="space-y-2">
            {vmBackups.map(b => (
              <div key={b.id} className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-between text-xs font-mono">
                <div>
                  <div className="font-semibold text-white">{b.name}</div>
                  <div className="text-[10px] text-slate-400">Size: {b.sizeMb} MB &bull; {new Date(b.createdAt).toLocaleString()}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-bold">
                    {b.status}
                  </span>
                  <button onClick={() => deleteBackup(b.id)} className="text-slate-500 hover:text-rose-400">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: SNAPSHOTS */}
      {activeTab === 'snapshots' && (
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Storage Snapshots</h3>
              <p className="text-xs text-slate-400">Docker image commits captured at specific moments</p>
            </div>
            <button
              onClick={() => setShowSnapshotModal(true)}
              className="px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400"
            >
              + Create Snapshot
            </button>
          </div>

          {showSnapshotModal && (
            <form onSubmit={handleCreateSnapshot} className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3 text-xs">
              <div>
                <label className="text-slate-400 mb-1 block">Snapshot Tag Name</label>
                <input
                  type="text"
                  placeholder="e.g. checkpoint-v1"
                  value={snapshotName}
                  onChange={(e) => setSnapshotName(e.target.value)}
                  className="w-full px-3 py-1.5 rounded bg-black border border-white/10 text-white"
                  required
                />
              </div>
              <div className="flex justify-end gap-2">
                <button type="button" onClick={() => setShowSnapshotModal(false)} className="px-3 py-1 text-slate-400">Cancel</button>
                <button type="submit" className="px-3 py-1 rounded bg-cyan-500 text-slate-950 font-bold">Save Snapshot</button>
              </div>
            </form>
          )}

          <div className="space-y-2">
            {vmSnapshots.map(s => (
              <div key={s.id} className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-between text-xs font-mono">
                <div>
                  <div className="font-semibold text-white">{s.name}</div>
                  <div className="text-[10px] text-cyan-400">{s.imageTag}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="px-2 py-0.5 rounded bg-purple-500/10 text-purple-400 text-[10px] font-bold">
                    {s.status}
                  </span>
                  <button onClick={() => deleteSnapshot(s.id)} className="text-slate-500 hover:text-rose-400">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT: NETWORKING */}
      {activeTab === 'network' && (
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
          <h3 className="text-base font-bold text-white">Network & Gateway Topology</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
            <div className="bg-black/30 p-4 rounded-xl border border-white/5 space-y-1">
              <span className="text-slate-400 text-[11px]">Primary IP Address</span>
              <p className="text-lg text-cyan-400 font-bold">{vm.ipAddress}</p>
              <p className="text-[10px] text-slate-500">Subnet Mask: 255.255.0.0 (/16)</p>
            </div>
            <div className="bg-black/30 p-4 rounded-xl border border-white/5 space-y-1">
              <span className="text-slate-400 text-[11px]">Default Gateway</span>
              <p className="text-lg text-white font-bold">{vm.gateway}</p>
              <p className="text-[10px] text-slate-500">Bridge Interface: docker0</p>
            </div>
            <div className="bg-black/30 p-4 rounded-xl border border-white/5 space-y-1">
              <span className="text-slate-400 text-[11px]">Primary DNS Server</span>
              <p className="text-base text-white font-semibold">1.1.1.1 (Cloudflare)</p>
              <p className="text-[10px] text-slate-500">Secondary: 8.8.8.8 (Google)</p>
            </div>
            <div className="bg-black/30 p-4 rounded-xl border border-white/5 space-y-1">
              <span className="text-slate-400 text-[11px]">Node FQDN Routing</span>
              <p className="text-base text-white font-semibold">{vm.hostname}</p>
              <p className="text-[10px] text-slate-500">Internal cluster resolve active</p>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: OpenSSH Public Key Viewer */}
      {showPublicKeyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#0f1422] border border-white/10 rounded-2xl p-6 max-w-xl w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">OpenSSH Public Key</h3>
                  <p className="text-xs text-slate-400">Configured in ~/.ssh/authorized_keys for root</p>
                </div>
              </div>
              <button
                onClick={() => setShowPublicKeyModal(false)}
                className="text-slate-400 hover:text-white text-sm p-1"
              >
                ✕
              </button>
            </div>

            {vm.sshFingerprint && (
              <div className="p-2.5 rounded-lg bg-black/40 border border-white/5 text-xs font-mono">
                <span className="text-slate-500 block text-[10px]">SHA-256 Fingerprint:</span>
                <span className="text-emerald-400">{vm.sshFingerprint}</span>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs text-slate-400 block">Public Key (OpenSSH Format):</label>
              <div className="relative">
                <textarea
                  readOnly
                  rows={4}
                  value={vm.sshPublicKey || 'Generating OpenSSH public key...'}
                  className="w-full p-3 rounded-xl bg-black/60 border border-white/10 text-slate-300 font-mono text-xs focus:outline-none resize-none select-all"
                />
              </div>
            </div>

            <div className="p-3 rounded-xl bg-cyan-500/5 border border-cyan-500/10 text-[11px] text-slate-300 space-y-1">
              <span className="font-semibold text-cyan-400 block">How to connect with OpenSSH:</span>
              <p className="font-mono text-slate-400">
                1. Download the private key ({vm.name.toLowerCase()}-id_rsa.pem)<br />
                2. Run: chmod 600 {vm.name.toLowerCase()}-id_rsa.pem<br />
                3. Run: ssh -i {vm.name.toLowerCase()}-id_rsa.pem {vm.sshUser}@{vm.ipAddress} -p {vm.sshPort}
              </p>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => downloadPrivateKey(vm)}
                className="px-3.5 py-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" /> Download .PEM
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    if (vm.sshPublicKey) copyToClipboard(vm.sshPublicKey, 'modal_pub_key');
                  }}
                  className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400 flex items-center gap-1.5 transition-colors"
                >
                  {copiedKey === 'modal_pub_key' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedKey === 'modal_pub_key' ? 'Copied to Clipboard!' : 'Copy Public Key'}
                </button>
                <button
                  onClick={() => setShowPublicKeyModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-medium"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
