import React from 'react';
import { useSKVM } from '../context/SKVMContext';
import { ShieldAlert, FileQuestion, ServerCrash, ArrowLeft, RefreshCw } from 'lucide-react';

export const Error403: React.FC = () => {
  const { setCurrentView } = useSKVM();
  return (
    <div className="min-h-[70vh] flex items-center justify-center p-4">
      <div className="w-full max-w-md text-center p-8 rounded-3xl glass-card border border-rose-500/20 space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <div className="space-y-1">
          <span className="text-xs font-mono font-bold text-rose-400">HTTP 403 FORBIDDEN</span>
          <h2 className="text-xl font-extrabold text-white">Access Denied</h2>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            You do not possess the required administrator privileges or instance ownership to access this resource.
          </p>
        </div>
        <button
          onClick={() => setCurrentView('dashboard')}
          className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold inline-flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" /> Return to Dashboard
        </button>
      </div>
    </div>
  );
};

export const Error404: React.FC = () => {
  const { setCurrentView } = useSKVM();
  return (
    <div className="min-h-[70vh] flex items-center justify-center p-4">
      <div className="w-full max-w-md text-center p-8 rounded-3xl glass-card border border-white/10 space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mx-auto">
          <FileQuestion className="w-8 h-8" />
        </div>
        <div className="space-y-1">
          <span className="text-xs font-mono font-bold text-cyan-400">HTTP 404 NOT FOUND</span>
          <h2 className="text-xl font-extrabold text-white">Page or Instance Not Found</h2>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            The requested container, node ID, or route does not exist or has been decommissioned.
          </p>
        </div>
        <button
          onClick={() => setCurrentView('dashboard')}
          className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold inline-flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" /> Return to Dashboard
        </button>
      </div>
    </div>
  );
};

export const Error500: React.FC = () => {
  const { setCurrentView } = useSKVM();
  return (
    <div className="min-h-[70vh] flex items-center justify-center p-4">
      <div className="w-full max-w-md text-center p-8 rounded-3xl glass-card border border-amber-500/20 space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto">
          <ServerCrash className="w-8 h-8" />
        </div>
        <div className="space-y-1">
          <span className="text-xs font-mono font-bold text-amber-400">HTTP 500 INTERNAL SERVER ERROR</span>
          <h2 className="text-xl font-extrabold text-white">Daemon Communication Fault</h2>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            The SKVM backend encountered an unexpected condition while talking to the Docker socket or remote node agent.
          </p>
        </div>
        <button
          onClick={() => window.location.reload()}
          className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold inline-flex items-center gap-2"
        >
          <RefreshCw className="w-4 h-4" /> Refresh Connection
        </button>
      </div>
    </div>
  );
};
