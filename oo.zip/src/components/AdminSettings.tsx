import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { Settings, Save, ShieldAlert, CheckCircle, Globe, Palette, RotateCcw, AlertTriangle, Terminal, Copy, Check } from 'lucide-react';
import { ResourceThresholdsPanel } from './telemetry/ResourceThresholdsPanel';

export const AdminSettings: React.FC = () => {
  const { settings, updateSettings, resetToCleanState } = useSKVM();

  const [panelName, setPanelName] = useState(settings.panelName);
  const [discordLink, setDiscordLink] = useState(settings.discordLink);
  const [websiteLink, setWebsiteLink] = useState(settings.websiteLink);
  const [maintenanceMode, setMaintenanceMode] = useState(settings.maintenanceMode);
  const [saved, setSaved] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [copiedCurlCmd, setCopiedCurlCmd] = useState(false);

  const curlInstallCmd = `curl -fsSL ${typeof window !== 'undefined' ? window.location.origin : ''}/install.sh | bash`;

  const copyCurlCmd = () => {
    navigator.clipboard.writeText(curlInstallCmd);
    setCopiedCurlCmd(true);
    setTimeout(() => setCopiedCurlCmd(false), 2000);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      panelName,
      discordLink,
      websiteLink,
      maintenanceMode
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handleResetCluster = () => {
    resetToCleanState();
    setConfirmReset(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Settings className="w-6 h-6 text-cyan-400" />
            Cluster & Panel Settings
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure system branding, community links, and maintenance windows.
          </p>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* General Branding */}
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4 text-xs">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Globe className="w-4 h-4 text-cyan-400" /> Global Panel Branding
          </h3>
          <div>
            <label className="text-slate-300 block mb-1 font-medium">Panel Title Name</label>
            <input
              type="text"
              value={panelName}
              onChange={(e) => setPanelName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white font-semibold"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-slate-300 block mb-1 font-medium">Discord Community Invite</label>
              <input
                type="text"
                value={discordLink}
                onChange={(e) => setDiscordLink(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white"
              />
            </div>
            <div>
              <label className="text-slate-300 block mb-1 font-medium">Official Website Link</label>
              <input
                type="text"
                value={websiteLink}
                onChange={(e) => setWebsiteLink(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white"
              />
            </div>
          </div>
        </div>

        {/* Maintenance Mode */}
        <div className="p-6 rounded-2xl glass-card border border-white/5 space-y-4 text-xs">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-400" /> System Maintenance Mode
              </h3>
              <p className="text-slate-400 mt-0.5">
                When active, non-administrator users will see the maintenance landing screen.
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={maintenanceMode}
                onChange={(e) => setMaintenanceMode(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
            </label>
          </div>
        </div>

        {/* Submit */}
        <div className="flex items-center justify-end gap-3">
          {saved && (
            <span className="text-xs text-emerald-400 flex items-center gap-1 font-semibold">
              <CheckCircle className="w-4 h-4" /> Changes applied
            </span>
          )}
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center gap-2"
          >
            <Save className="w-4 h-4" /> Save Configuration
          </button>
        </div>
      </form>

      {/* Resource Saturation Thresholds & Incident Alerts Engine */}
      <ResourceThresholdsPanel />

      {/* Remote Server Quick Deploy Command */}
      <div className="p-6 rounded-2xl glass-card border border-cyan-500/20 space-y-4 text-xs">
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400" /> Remote Server Universal Installer
          </h3>
          <p className="text-slate-400 max-w-xl leading-relaxed">
            Run this command on any fresh Linux server or VPS to install dependencies, configure Docker & TMATE, and start the SKVM panel service automatically.
          </p>
        </div>

        <div className="bg-black/50 border border-cyan-500/20 rounded-xl p-3 flex items-center justify-between gap-3 font-mono text-xs">
          <code className="text-cyan-300 truncate select-all">{curlInstallCmd}</code>
          <button
            type="button"
            onClick={copyCurlCmd}
            className="p-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 hover:text-white transition-colors shrink-0"
            title="Copy 1-line install command"
          >
            {copiedCurlCmd ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Reset to Clean Baseline */}
      <div className="p-6 rounded-2xl glass-card border border-rose-500/20 space-y-4 text-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-rose-400 flex items-center gap-2">
              <RotateCcw className="w-4 h-4" /> Reset Cluster to Clean Baseline
            </h3>
            <p className="text-slate-400 mt-1 max-w-xl">
              Permanently purge all registered nodes, container instances, port mappings, and snapshots, resetting the database and storage to a clean, empty state.
            </p>
          </div>
          {confirmReset ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleResetCluster}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-1.5 shadow-lg shadow-rose-600/20"
              >
                <AlertTriangle className="w-3.5 h-3.5" /> Confirm Purge
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmReset(true)}
              className="px-4 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reset Cluster Data
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
