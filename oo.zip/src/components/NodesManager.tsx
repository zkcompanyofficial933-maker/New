import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { 
  Server, PlusCircle, RefreshCw, Trash2, Key, 
  CheckCircle2, AlertCircle, Copy, Check, Terminal, ExternalLink 
} from 'lucide-react';

export const NodesManager: React.FC = () => {
  const { 
    nodes, 
    vms, 
    createNode, 
    regenerateNodeToken, 
    deleteNode, 
    triggerNodeHeartbeat,
    generatedTokenModal,
    closeTokenModal 
  } = useSKVM();

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [hostname, setHostname] = useState('');
  const [port, setPort] = useState(3000);
  const [ramGb, setRamGb] = useState(32);
  const [cpuCores, setCpuCores] = useState(16);
  const [diskGb, setDiskGb] = useState(1000);
  const [maxVms, setMaxVms] = useState(30);

  const [copiedToken, setCopiedToken] = useState(false);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    createNode({
      name,
      location,
      hostname,
      port: Number(port),
      status: 'ONLINE',
      totalRamMb: ramGb * 1024,
      totalCpuCores: Number(cpuCores),
      totalDiskGb: Number(diskGb),
      maxVms: Number(maxVms),
      dockerVersion: '26.1.3'
    });
    setShowCreateModal(false);
    setName('');
    setLocation('');
    setHostname('');
  };

  const copyToken = (tok: string) => {
    navigator.clipboard.writeText(tok);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Server className="w-6 h-6 text-purple-400" />
            Cluster Node Hypervisors
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Registered Docker host runners communicating via secure HMAC node agent tokens.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" /> Add Hypervisor Node
        </button>
      </div>

      {/* Nodes List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {nodes.map((node) => {
          const nodeVMs = vms.filter(v => v.nodeId === node.id);
          const allocatedRamMb = nodeVMs.reduce((a, b) => a + b.ramMb, 0);
          const allocatedCpu = nodeVMs.reduce((a, b) => a + b.cpuCores, 0);
          const allocatedDisk = nodeVMs.reduce((a, b) => a + b.diskGb, 0);

          return (
            <div key={node.id} className="p-6 rounded-2xl glass-card border border-white/5 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <h3 className="text-base font-bold text-white">{node.name}</h3>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-white/5 font-mono text-cyan-400 border border-white/5">
                      {node.location}
                    </span>
                  </div>
                  <p className="text-xs font-mono text-slate-400 mt-1">
                    {node.hostname}:{node.port} &bull; Docker {node.dockerVersion}
                  </p>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => triggerNodeHeartbeat(node.id)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-emerald-400 text-xs"
                    title="Ping Heartbeat"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => regenerateNodeToken(node.id)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-cyan-400 text-xs"
                    title="Regenerate Token"
                  >
                    <Key className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => deleteNode(node.id)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 text-xs"
                    title="Remove Node"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Node Stats Metrics */}
              <div className="grid grid-cols-3 gap-3 p-3.5 rounded-xl bg-black/40 border border-white/5 text-xs font-mono">
                <div>
                  <span className="text-[10px] text-slate-500 block">RAM Usage</span>
                  <span className="text-white font-bold">{(allocatedRamMb / 1024).toFixed(1)} / {(node.totalRamMb / 1024).toFixed(0)} GB</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">CPU Quota</span>
                  <span className="text-white font-bold">{allocatedCpu.toFixed(1)} / {node.totalCpuCores} Cores</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Containers</span>
                  <span className="text-cyan-400 font-bold">{nodeVMs.length} / {node.maxVms} VMs</span>
                </div>
              </div>

              {/* Token Secret Snippet */}
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-black/30 border border-white/5 text-[11px] font-mono text-slate-400">
                <span className="truncate mr-2">Token: {node.tokenSecret || `${node.tokenPrefix}••••••••••••`}</span>
                <button
                  onClick={() => copyToken(node.tokenSecret || `${node.tokenPrefix}_secret_key`)}
                  className="text-cyan-400 hover:text-cyan-300 flex-shrink-0"
                >
                  {copiedToken ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Node Registration Token Modal */}
      {generatedTokenModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl glass-card border border-white/10 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/5">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-cyan-400" /> Node Authentication Token
              </h3>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                One-Time View
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Copy this token and provide it when running <strong className="text-cyan-400">python3 node.py</strong> on <strong>{generatedTokenModal.nodeName}</strong>.
            </p>
            <div className="p-3 bg-black/60 rounded-xl border border-cyan-500/30 flex items-center justify-between font-mono text-xs text-cyan-300 select-all">
              <span className="truncate mr-2">{generatedTokenModal.token}</span>
              <button
                onClick={() => copyToken(generatedTokenModal.token)}
                className="p-1 text-slate-400 hover:text-white"
              >
                {copiedToken ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
            <div className="p-3 bg-white/[0.02] rounded-xl border border-white/5 font-mono text-[11px] text-slate-400">
              $ python3 node.py --panel-url https://skvm.cloud --token {generatedTokenModal.token}
            </div>
            <div className="flex justify-end">
              <button
                onClick={closeTokenModal}
                className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400"
              >
                I Have Saved This Token
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Node Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <form onSubmit={handleCreate} className="w-full max-w-md rounded-2xl glass-card border border-white/10 p-6 space-y-4 text-xs">
            <h3 className="text-base font-bold text-white">Add Hypervisor Host Node</h3>
            <div>
              <label className="text-slate-400 block mb-1">Node Identifier Name</label>
              <input
                type="text"
                placeholder="e.g. Node-03-US-East"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                required
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Datacenter Location</label>
              <input
                type="text"
                placeholder="e.g. Ashburn, Virginia, USA"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Hostname or IP</label>
                <input
                  type="text"
                  placeholder="us1.skvm.cloud"
                  value={hostname}
                  onChange={(e) => setHostname(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                  required
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Agent Port</label>
                <input
                  type="number"
                  value={port}
                  onChange={(e) => setPort(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-slate-400 block mb-1">RAM (GB)</label>
                <input
                  type="number"
                  value={ramGb}
                  onChange={(e) => setRamGb(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">CPU Cores</label>
                <input
                  type="number"
                  value={cpuCores}
                  onChange={(e) => setCpuCores(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">NVMe (GB)</label>
                <input
                  type="number"
                  value={diskGb}
                  onChange={(e) => setDiskGb(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2 text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400"
              >
                Register & Generate Token
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
