import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { Disc, PlusCircle, CheckCircle2, Trash2, PowerOff, Shield, Globe, Database } from 'lucide-react';
import { OSLogo } from './OSLogo';

export const OSManager: React.FC = () => {
  const { osImages, addOSImage, toggleOSImage, deleteOSImage } = useSKVM();
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [dockerImage, setDockerImage] = useState('');
  const [family, setFamily] = useState<'ubuntu' | 'debian' | 'alpine' | 'centos' | 'rocky' | 'fedora' | 'arch' | 'kali' | 'other'>('ubuntu');
  const [version, setVersion] = useState('');
  const [minRamMb, setMinRamMb] = useState(1024);
  const [minDiskGb, setMinDiskGb] = useState(10);
  const [imageSource, setImageSource] = useState<'dockerhub' | 'local'>('dockerhub');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    addOSImage({
      name,
      dockerImage,
      family,
      version,
      minRamMb: Number(minRamMb),
      minDiskGb: Number(minDiskGb),
      isEnabled: true,
      iconSlug: family,
      imageSource,
      localImagePath: imageSource === 'local' ? dockerImage : undefined
    });
    setName('');
    setDockerImage('');
    setVersion('');
    setImageSource('dockerhub');
    setShowAddModal(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <Disc className="w-6 h-6 text-cyan-400" />
            Operating System Templates
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Docker base images used to instantiate new VPS containers with systemd and OpenSSH. Pulled dynamically from Docker Hub or loaded from local node host cache.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all shadow-lg shadow-cyan-500/20 flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" /> Add Custom OS
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {osImages.map((os) => (
          <div key={os.id} className="p-5 rounded-2xl glass-card border border-white/5 space-y-4 hover:border-white/10 transition-all">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <OSLogo slug={os.iconSlug || os.family} name={os.name} size="md" />
                <span className="text-xs font-mono uppercase font-bold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded">
                  {os.family}
                </span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded flex items-center gap-1 font-semibold ${
                  os.imageSource === 'local' ? 'bg-purple-500/10 text-purple-400' : 'bg-blue-500/10 text-blue-400'
                }`}>
                  {os.imageSource === 'local' ? (
                    <><Database className="w-3 h-3" /> Local Cache</>
                  ) : (
                    <><Globe className="w-3 h-3" /> Docker Hub</>
                  )}
                </span>
              </div>
              <button
                onClick={() => toggleOSImage(os.id)}
                className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                  os.isEnabled ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {os.isEnabled ? 'ENABLED' : 'DISABLED'}
              </button>
            </div>

            <div>
              <h3 className="text-sm font-bold text-white">{os.name}</h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">{os.dockerImage}</p>
            </div>

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 pt-2 border-t border-white/5">
              <span>Min RAM: {os.minRamMb} MB</span>
              <span>Min Disk: {os.minDiskGb} GB</span>
              <button
                onClick={() => deleteOSImage(os.id)}
                className="text-slate-500 hover:text-rose-400"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <form onSubmit={handleAdd} className="w-full max-w-md rounded-2xl glass-card border border-white/10 p-6 space-y-4 text-xs">
            <h3 className="text-base font-bold text-white">Register Docker OS Image</h3>

            {/* Source selector */}
            <div>
              <label className="text-slate-400 block mb-1.5 font-medium">Image Source Location</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setImageSource('dockerhub')}
                  className={`p-2 rounded-lg border text-center flex items-center justify-center gap-1.5 font-medium ${
                    imageSource === 'dockerhub'
                      ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                      : 'bg-white/5 border-white/10 text-slate-300'
                  }`}
                >
                  <Globe className="w-3.5 h-3.5" /> Docker Hub
                </button>
                <button
                  type="button"
                  onClick={() => setImageSource('local')}
                  className={`p-2 rounded-lg border text-center flex items-center justify-center gap-1.5 font-medium ${
                    imageSource === 'local'
                      ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                      : 'bg-white/5 border-white/10 text-slate-300'
                  }`}
                >
                  <Database className="w-3.5 h-3.5" /> Local Image
                </button>
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1 font-medium">Display Name</label>
              <input
                type="text"
                placeholder="e.g. AlmaLinux 9.4 (Minimal)"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                required
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1 font-medium">
                {imageSource === 'dockerhub' ? 'Docker Hub Image Reference' : 'Local Image Tag / RootFS Name'}
              </label>
              <input
                type="text"
                placeholder={imageSource === 'dockerhub' ? 'e.g. almalinux:9, archlinux:latest' : 'e.g. localhost/my-image:latest, custom-base:v1'}
                value={dockerImage}
                onChange={(e) => setDockerImage(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white font-mono"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1 font-medium">Family</label>
                <select
                  value={family}
                  onChange={(e) => setFamily(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                >
                  <option value="ubuntu">Ubuntu</option>
                  <option value="debian">Debian</option>
                  <option value="alpine">Alpine</option>
                  <option value="centos">CentOS</option>
                  <option value="rocky">Rocky Linux</option>
                  <option value="fedora">Fedora</option>
                  <option value="arch">Arch Linux</option>
                  <option value="kali">Kali Linux</option>
                  <option value="other">Other / Custom</option>
                </select>
              </div>
              <div>
                <label className="text-slate-400 block mb-1 font-medium">Version</label>
                <input
                  type="text"
                  placeholder="24.04 / 9.0"
                  value={version}
                  onChange={(e) => setVersion(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1 font-medium">Min RAM (MB)</label>
                <input
                  type="number"
                  value={minRamMb}
                  onChange={(e) => setMinRamMb(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white font-mono"
                  min={128}
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1 font-medium">Min Storage (GB)</label>
                <input
                  type="number"
                  value={minDiskGb}
                  onChange={(e) => setMinDiskGb(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg bg-black border border-white/10 text-white font-mono"
                  min={1}
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
              <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 text-slate-400 hover:text-white">Cancel</button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold">Register Template</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
