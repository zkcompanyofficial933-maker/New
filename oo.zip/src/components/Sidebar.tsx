import React from 'react';
import { useSKVM } from '../context/SKVMContext';
import { 
  LayoutDashboard, Server, PlusCircle, Users, 
  Settings, Disc, Cpu, UserCheck, 
  FileText, HeartPulse, Network, X,
  Shield, LogOut, ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  category?: string;
}

export const Sidebar: React.FC = () => {
  const { 
    currentUser, 
    currentView, 
    setCurrentView, 
    isSidebarOpen, 
    setIsSidebarOpen, 
    switchRole, 
    logout,
    vms,
    nodes
  } = useSKVM();

  const isAdmin = currentUser?.role === 'ADMIN';

  const userNav: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'vms', label: 'My VMs', icon: Cpu, badge: vms.length > 0 ? `${vms.length}` : undefined },
    { id: 'ports', label: 'Port Forwarding', icon: Network },
    { id: 'settings', label: 'User Settings', icon: Settings },
    { id: 'profile', label: 'Profile', icon: UserCheck },
  ];

  const adminNav: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'create_vm', label: 'Create VM', icon: PlusCircle, badge: 'Wizard' },
    { id: 'nodes', label: 'Hypervisor Nodes', icon: Server, badge: nodes.length > 0 ? `${nodes.length}` : undefined },
    { id: 'users', label: 'Users & Quotas', icon: Users },
    { id: 'os', label: 'OS Management', icon: Disc },
    { id: 'ports', label: 'Port Forwarding', icon: Network },
    { id: 'profile', label: 'Profile & SSH Keys', icon: UserCheck },
    { id: 'settings', label: 'Admin Settings', icon: Settings },
  ];

  const secondaryNav: NavItem[] = [
    { id: 'health', label: 'System Health', icon: HeartPulse },
    { id: 'logs', label: 'Activity Logs', icon: FileText },
  ];

  const navItems = isAdmin ? adminNav : userNav;

  const handleNavClick = (viewId: string) => {
    setCurrentView(viewId);
    // On mobile, auto-close sidebar after selection
    if (window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  };

  const renderNavContent = (isMobile: boolean = false) => (
    <div className="flex flex-col h-full justify-between p-4 overflow-y-auto">
      <div className="space-y-6">
        {/* Mobile Header with Close Button */}
        {isMobile && (
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl overflow-hidden bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-white shadow-lg shadow-cyan-500/20">
                <img src="/logo.png" alt="SKVM" className="w-full h-full object-cover" onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }} />
              </div>
              <div>
                <span className="font-extrabold text-white text-sm tracking-tight">SKVM Panel</span>
                <p className="text-[10px] text-slate-400 font-mono">Docker Cloud VPS</p>
              </div>
            </div>
            <button 
              id="btn-close-mobile-sidemenu"
              onClick={() => setIsSidebarOpen(false)}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all"
              aria-label="Close menu"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Category Header */}
        <div>
          <div className="flex items-center justify-between px-3 mb-2.5">
            <span className="text-[10px] font-bold tracking-widest text-slate-400 uppercase font-mono">
              {isAdmin ? 'ADMIN CLUSTER PANEL' : 'USER VPS PORTAL'}
            </span>
            <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase ${
              isAdmin ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
            }`}>
              {isAdmin ? 'Admin' : 'Client'}
            </span>
          </div>

          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  id={`sidemenu-item-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shadow-sm shadow-cyan-500/10'
                      : 'text-slate-400 hover:text-slate-100 hover:bg-white/[0.04]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono ${
                      isActive ? 'bg-cyan-500/30 text-cyan-200' : 'bg-white/5 text-slate-400'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Diagnostics & Observability */}
        <div>
          <div className="px-3 mb-2">
            <span className="text-[10px] font-bold tracking-widest text-slate-400 uppercase font-mono">
              OBSERVABILITY
            </span>
          </div>
          <nav className="space-y-1">
            {secondaryNav.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  id={`sidemenu-item-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-slate-100 hover:bg-white/[0.04]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 opacity-30" />
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Footer Info Box */}
      <div className="space-y-3 pt-4 border-t border-white/5">
        <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1.5">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400">Docker Daemon</span>
            <span className="text-emerald-400 font-mono font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Healthy
            </span>
          </div>
          <div className="text-[10px] text-slate-400 font-mono flex justify-between">
            <span>Isolation:</span>
            <span className="text-slate-300">cgroups v2 & LXCFS</span>
          </div>
        </div>

        {/* Quick Role Switcher for Testing */}
        <div className="flex items-center justify-between text-xs text-slate-400 px-1">
          <button
            id="sidemenu-btn-switch-role"
            onClick={() => switchRole(isAdmin ? 'USER' : 'ADMIN')}
            className="hover:text-cyan-400 transition-colors flex items-center gap-1 text-[11px]"
          >
            <Shield className="w-3.5 h-3.5" />
            Switch to {isAdmin ? 'User' : 'Admin'}
          </button>
          <button
            id="sidemenu-btn-logout"
            onClick={logout}
            className="hover:text-rose-400 transition-colors flex items-center gap-1 text-[11px]"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Permanent Desktop Sidemenu */}
      <aside className="w-64 glass-sidebar flex-shrink-0 hidden md:flex flex-col z-20">
        {renderNavContent(false)}
      </aside>

      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            />

            {/* Sliding Drawer */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 280 }}
              className="relative w-72 max-w-[85vw] h-full bg-[#0d131f] border-r border-white/10 shadow-2xl z-10"
            >
              {renderNavContent(true)}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
