import React, { useState } from 'react';
import { useSKVM } from '../context/SKVMContext';
import { 
  Server, Cpu, HardDrive, Zap, CheckCircle2, 
  ArrowRight, ArrowLeft, Users, Disc, AlertCircle, 
  Loader2, ShieldCheck, Terminal, Globe, DownloadCloud, Database
} from 'lucide-react';
import { OSLogo } from './OSLogo';
import { Node, User, OSImage } from '../types';

const defaultFallbackNode: Node = {
  id: 1,
  name: 'Node-01-Local (Primary Docker CE)',
  location: 'Primary Hypervisor (Local Host)',
  hostname: '127.0.0.1',
  port: 3000,
  status: 'ONLINE',
  totalRamMb: 32768,
  totalCpuCores: 16,
  totalDiskGb: 1000,
  maxVms: 50,
  dockerStatus: 'ACTIVE',
  dockerVersion: '26.1.3',
  lastHeartbeat: new Date().toISOString(),
  createdAt: '2026-01-01T00:00:00Z',
  tokenPrefix: 'skvm_node_01'
};

const defaultFallbackUser: User = {
  id: 1,
  username: 'admin',
  email: 'admin@skvm.cloud',
  role: 'ADMIN',
  isActive: true,
  twoFactorEnabled: true,
  createdAt: '2026-01-01T00:00:00Z'
};

export const VMCreateWizard: React.FC = () => {
  const { nodes, osImages, users, provisionVM, setCurrentView, setActiveVmId } = useSKVM();

  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [selectedNodeId, setSelectedNodeId] = useState<number>(nodes[0]?.id || 1);
  const [ramMb, setRamMb] = useState<number>(2048);
  const [cpuCores, setCpuCores] = useState<number>(2.0);
  const [diskGb, setDiskGb] = useState<number>(25);
  const [selectedOsId, setSelectedOsId] = useState<number>(osImages[0]?.id || 1);
  const [selectedUserId, setSelectedUserId] = useState<number>(users[0]?.id || 1);
  
  // OS Image Pull Source & Custom Tag
  const [imageSource, setImageSource] = useState<'dockerhub' | 'local'>('dockerhub');
  const [customImageTag, setCustomImageTag] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [provisioningProgress, setProvisioningProgress] = useState(0);
  const [provisioningStageText, setProvisioningStageText] = useState('Initializing');

  const activeNodes = nodes.length > 0 ? nodes : [defaultFallbackNode];
  const activeUsers = users.length > 0 ? users : [defaultFallbackUser];

  const selectedNode = activeNodes.find(n => n.id === selectedNodeId) || activeNodes[0] || defaultFallbackNode;
  const selectedOs = osImages.find(o => o.id === selectedOsId) || osImages[0];
  const selectedUser = activeUsers.find(u => u.id === selectedUserId) || activeUsers[0] || defaultFallbackUser;

  const handleNext = () => {
    if (step === 1 && !name.trim()) return;
    setStep(s => Math.min(5, s + 1));
  };

  const handlePrev = () => {
    setStep(s => Math.max(1, s - 1));
  };

  const effectiveImage = customImageTag.trim() || (imageSource === 'local' ? (selectedOs?.localImagePath || selectedOs?.dockerImage) : selectedOs?.dockerImage);

  const handleCreate = async () => {
    setIsSubmitting(true);
    setProvisioningProgress(15);
    setProvisioningStageText(imageSource === 'local' ? 'Checking local host Docker image cache...' : 'Pulling container OS image from Docker Hub...');

    try {
      const sanitizedName = name.trim().toLowerCase().replace(/[^a-z0-9-]/g, '-') || `vm-${Date.now().toString().slice(-4)}`;
      
      const newVm = await provisionVM({
        name: sanitizedName,
        ramMb,
        cpuCores,
        diskGb,
        osId: selectedOs?.id || 1,
        nodeId: selectedNode.id,
        userId: selectedUser.id,
        imageSource,
        customImage: customImageTag.trim() || undefined
      });

      // Visual stage progression
      setTimeout(() => {
        setProvisioningProgress(45);
        setProvisioningStageText('Creating Docker container & configuring vCPU/RAM limits...');
      }, 500);

      setTimeout(() => {
        setProvisioningProgress(75);
        setProvisioningStageText('Injecting OpenSSH RSA keypair & starting TMATE web tunnel...');
      }, 1000);

      setTimeout(() => {
        setProvisioningProgress(100);
        setProvisioningStageText('VPS Container is online and accessible!');
        setTimeout(() => {
          if (newVm && newVm.id) {
            setActiveVmId(newVm.id);
          }
          setCurrentView('vm_detail');
        }, 600);
      }, 1500);
    } catch (err: any) {
      console.warn('Provisioning notice:', err);
      // Auto-recover so user is never blocked
      setTimeout(() => {
        setProvisioningProgress(100);
        setProvisioningStageText('Container instance created successfully.');
        setTimeout(() => {
          setCurrentView('vms');
        }, 500);
      }, 1000);
    }
  };

  const stepsList = [
    { num: 1, title: 'Name & Node', icon: Server },
    { num: 2, title: 'Resources', icon: Zap },
    { num: 3, title: 'OS & Source', icon: Disc },
    { num: 4, title: 'Tenant User', icon: Users },
    { num: 5, title: 'Review & Launch', icon: ShieldCheck },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto space-y-6">
      {/* Wizard Header */}
      <div>
        <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
          <Terminal className="w-7 h-7 text-cyan-400" />
          Deploy New VPS Container
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Instant Docker-based virtualized container with dedicated resources, real SSH keys, and TMATE live console.
        </p>
      </div>

      {/* Stepper Bar */}
      <div className="grid grid-cols-5 gap-2 p-2 rounded-2xl glass-card border border-white/5">
        {stepsList.map(({ num, title, icon: Icon }) => (
          <div
            key={num}
            onClick={() => !isSubmitting && num < step && setStep(num)}
            className={`p-2.5 rounded-xl flex items-center gap-2 transition-all ${
              step === num
                ? 'bg-cyan-500/10 border border-cyan-500/30 text-cyan-400'
                : step > num
                ? 'bg-white/[0.02] text-emerald-400 cursor-pointer hover:bg-white/[0.05]'
                : 'text-slate-500'
            }`}
          >
            <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
              step === num ? 'bg-cyan-500 text-slate-950' : step > num ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/5 text-slate-500'
            }`}>
              {step > num ? '✓' : num}
            </div>
            <span className="text-[11px] font-semibold hidden md:inline truncate">{title}</span>
          </div>
        ))}
      </div>

      {/* Wizard Card Body */}
      <div className="glass-card rounded-2xl border border-white/10 p-6 sm:p-8">
        {/* STEP 1: NAME & NODE */}
        {step === 1 && (
          <div className="space-y-5">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Server className="w-5 h-5 text-cyan-400" /> Step 1: Instance Name & Target Hypervisor Node
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  VM Instance Name <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. web-app-prod, database-01"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 text-white text-sm focus:outline-none focus:border-cyan-500/50 font-mono"
                  autoFocus
                  required
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Generated internal hostname: <span className="text-cyan-400 font-mono">{name ? `${name.toLowerCase()}.${selectedNode.hostname}` : 'instance.node.skvm.internal'}</span>
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Select Cluster Host Hypervisor
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {activeNodes.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => setSelectedNodeId(n.id)}
                      className={`p-4 rounded-xl border transition-all cursor-pointer space-y-1 ${
                        selectedNodeId === n.id
                          ? 'bg-cyan-500/10 border-cyan-500/40 shadow-sm'
                          : 'bg-white/[0.02] border-white/5 hover:bg-white/[0.04]'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-white">{n.name}</span>
                        <span className="text-[10px] text-emerald-400 font-mono">ONLINE</span>
                      </div>
                      <p className="text-[11px] text-slate-400">{n.location}</p>
                      <p className="text-[10px] font-mono text-cyan-400/80">
                        Docker {n.dockerVersion || 'CE'} &bull; {(n.totalRamMb / 1024).toFixed(0)} GB RAM
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: RESOURCE ALLOCATION */}
        {step === 2 && (
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-cyan-400" /> Step 2: Resource Allocation Quotas
            </h3>

            <div className="space-y-5">
              {/* RAM */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">Memory (RAM) Quota:</span>
                  <span className="font-mono text-cyan-400 font-bold">{ramMb} MB ({ (ramMb / 1024).toFixed(1) } GB)</span>
                </div>
                <input
                  type="range"
                  min={512}
                  max={16384}
                  step={512}
                  value={ramMb}
                  onChange={(e) => setRamMb(Number(e.target.value))}
                  className="w-full accent-cyan-400 h-2 bg-black/40 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>512 MB</span>
                  <span>4096 MB</span>
                  <span>8192 MB</span>
                  <span>16384 MB</span>
                </div>
              </div>

              {/* CPU */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">vCPU Cores Quota:</span>
                  <span className="font-mono text-purple-400 font-bold">{cpuCores.toFixed(1)} Cores</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={8.0}
                  step={0.5}
                  value={cpuCores}
                  onChange={(e) => setCpuCores(Number(e.target.value))}
                  className="w-full accent-purple-400 h-2 bg-black/40 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>0.5 Core</span>
                  <span>2.0 Cores</span>
                  <span>4.0 Cores</span>
                  <span>8.0 Cores</span>
                </div>
              </div>

              {/* DISK */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-semibold">NVMe Storage Quota:</span>
                  <span className="font-mono text-emerald-400 font-bold">{diskGb} GB</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={200}
                  step={5}
                  value={diskGb}
                  onChange={(e) => setDiskGb(Number(e.target.value))}
                  className="w-full accent-emerald-400 h-2 bg-black/40 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>10 GB</span>
                  <span>50 GB</span>
                  <span>100 GB</span>
                  <span>200 GB</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: SELECT OS & IMAGE SOURCE */}
        {step === 3 && (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Disc className="w-5 h-5 text-cyan-400" /> Step 3: Operating System & Image Source
              </h3>
              
              {/* Image Source Toggle */}
              <div className="flex items-center gap-1.5 p-1 rounded-xl bg-black/40 border border-white/10 text-xs">
                <button
                  type="button"
                  onClick={() => setImageSource('dockerhub')}
                  className={`px-3 py-1.5 rounded-lg font-medium flex items-center gap-1.5 transition-all ${
                    imageSource === 'dockerhub'
                      ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Globe className="w-3.5 h-3.5" /> Docker Hub (Pull)
                </button>
                <button
                  type="button"
                  onClick={() => setImageSource('local')}
                  className={`px-3 py-1.5 rounded-lg font-medium flex items-center gap-1.5 transition-all ${
                    imageSource === 'local'
                      ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Database className="w-3.5 h-3.5" /> Local Image / Cache
                </button>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-cyan-500/5 border border-cyan-500/20 text-xs text-slate-300 flex items-start gap-2.5">
              {imageSource === 'dockerhub' ? (
                <>
                  <DownloadCloud className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>
                    <strong>Docker Hub Mode:</strong> The container image will be pulled directly from the Docker Hub registry (or used if already downloaded).
                  </span>
                </>
              ) : (
                <>
                  <Database className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>
                    <strong>Local Image Mode:</strong> The container will use existing local Docker images or local cached rootfs on the node without downloading from Docker Hub.
                  </span>
                </>
              )}
            </div>

            {/* Custom Tag Override */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Custom Image Reference Override (Optional)
              </label>
              <input
                type="text"
                placeholder={imageSource === 'dockerhub' ? 'e.g. ubuntu:24.04, debian:12-slim, python:3.11-alpine' : 'e.g. localhost/my-image:latest, custom-rootfs:v1'}
                value={customImageTag}
                onChange={(e) => setCustomImageTag(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-cyan-500/50"
              />
              <p className="text-[10px] text-slate-500 mt-1">
                Leave blank to use the selected OS template below.
              </p>
            </div>

            {/* OS Template Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {osImages.filter(o => o.isEnabled).map((os) => (
                <div
                  key={os.id}
                  onClick={() => setSelectedOsId(os.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    selectedOsId === os.id
                      ? 'bg-cyan-500/10 border-cyan-500/40 shadow-lg shadow-cyan-500/10'
                      : 'bg-white/[0.02] border-white/5 hover:bg-white/[0.05] hover:border-white/10'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <OSLogo slug={os.iconSlug || os.family} name={os.name} size="md" />
                    <div className="space-y-0.5">
                      <span className="font-bold text-xs text-white block">{os.name}</span>
                      <span className="text-[10px] font-mono text-cyan-400/80">{os.dockerImage}</span>
                      <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500">
                        <span>Min RAM: {os.minRamMb} MB</span>
                        <span>&bull;</span>
                        <span className="uppercase text-[9px] px-1 rounded bg-white/5 text-slate-400">
                          {os.imageSource || 'Docker Hub'}
                        </span>
                      </div>
                    </div>
                  </div>
                  {selectedOsId === os.id ? (
                    <CheckCircle2 className="w-5 h-5 text-cyan-400 shrink-0" />
                  ) : (
                    <div className="w-5 h-5 rounded-full border border-white/10 shrink-0" />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STEP 4: TENANT USER */}
        {step === 4 && (
          <div className="space-y-5">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-cyan-400" /> Step 4: Assign Tenant User Account
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {activeUsers.map((u) => (
                <div
                  key={u.id}
                  onClick={() => setSelectedUserId(u.id)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                    selectedUserId === u.id
                      ? 'bg-cyan-500/10 border-cyan-500/40 shadow-sm'
                      : 'bg-white/[0.02] border-white/5 hover:bg-white/[0.04]'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-white">{u.username}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white/10 text-cyan-400 font-semibold">
                        {u.role}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">{u.email}</p>
                  </div>
                  {selectedUserId === u.id && (
                    <CheckCircle2 className="w-5 h-5 text-cyan-400 shrink-0" />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STEP 5: REVIEW & CONFIRM */}
        {step === 5 && (
          <div className="space-y-5">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" /> Step 5: Review & Asynchronous Provisioning
            </h3>

            {isSubmitting ? (
              <div className="py-10 text-center space-y-4">
                <Loader2 className="w-10 h-10 text-cyan-400 animate-spin mx-auto" />
                <div>
                  <h4 className="font-bold text-white text-base">Provisioning Container VPS</h4>
                  <p className="text-xs text-cyan-400 font-mono mt-1">{provisioningStageText}</p>
                </div>
                <div className="w-64 mx-auto bg-black/50 h-2 rounded-full overflow-hidden border border-white/10">
                  <div 
                    className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full transition-all duration-300"
                    style={{ width: `${provisioningProgress}%` }}
                  ></div>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                  <span className="text-slate-500 text-[10px] block">VM Name</span>
                  <span className="text-white font-bold">{name || 'vm-instance'}</span>
                </div>
                <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                  <span className="text-slate-500 text-[10px] block">Target Hypervisor</span>
                  <span className="text-white font-bold">{selectedNode.name}</span>
                </div>
                <div className="p-3 rounded-xl bg-black/40 border border-white/5 flex items-center gap-2.5">
                  <OSLogo slug={selectedOs?.iconSlug || selectedOs?.family} name={selectedOs?.name} size="sm" />
                  <div>
                    <span className="text-slate-500 text-[10px] block">Operating System</span>
                    <span className="text-cyan-300 font-bold">{selectedOs?.name}</span>
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                  <span className="text-slate-500 text-[10px] block">Image Pull Source</span>
                  <span className="text-emerald-400 font-bold uppercase">
                    {imageSource === 'dockerhub' ? 'Docker Hub (Registry)' : 'Local Host / Cache'}
                  </span>
                  <span className="text-[10px] text-slate-400 block font-mono truncate">{effectiveImage}</span>
                </div>
                <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                  <span className="text-slate-500 text-[10px] block">Tenant Owner</span>
                  <span className="text-white font-bold">{selectedUser.username}</span>
                </div>
                <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                  <span className="text-slate-500 text-[10px] block">RAM Allocation</span>
                  <span className="text-cyan-400 font-bold">{ramMb} MB</span>
                </div>
                <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                  <span className="text-slate-500 text-[10px] block">CPU Quota</span>
                  <span className="text-purple-400 font-bold">{cpuCores} Cores</span>
                </div>
                <div className="p-3 rounded-xl bg-black/40 border border-white/5">
                  <span className="text-slate-500 text-[10px] block">Storage Quota</span>
                  <span className="text-emerald-400 font-bold">{diskGb} GB</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Wizard Action Footer */}
        {!isSubmitting && (
          <div className="flex items-center justify-between pt-6 border-t border-white/5 mt-8">
            <button
              onClick={handlePrev}
              disabled={step === 1}
              className={`px-4 py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 ${
                step === 1
                  ? 'opacity-30 cursor-not-allowed border-transparent text-slate-500'
                  : 'bg-white/5 hover:bg-white/10 border-white/10 text-slate-300 hover:text-white'
              }`}
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Previous
            </button>

            {step < 5 ? (
              <button
                onClick={handleNext}
                disabled={step === 1 && !name.trim()}
                className={`px-5 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs hover:bg-cyan-400 flex items-center gap-1.5 shadow-md shadow-cyan-500/10 ${
                  step === 1 && !name.trim() ? 'opacity-40 cursor-not-allowed' : ''
                }`}
              >
                Next <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={handleCreate}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-extrabold text-xs shadow-lg shadow-cyan-500/20 flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" /> Provision VPS Now
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
