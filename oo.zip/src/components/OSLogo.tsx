import React from 'react';
import { Disc } from 'lucide-react';

interface OSLogoProps {
  slug?: string;
  name?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const OSLogo: React.FC<OSLogoProps> = ({ 
  slug = 'ubuntu', 
  name = '', 
  size = 'md',
  className = '' 
}) => {
  // Normalize slug
  const normalized = (slug || '').toLowerCase();
  const lowerName = (name || '').toLowerCase();

  let resolvedSlug = 'ubuntu';
  if (normalized.includes('deb') || lowerName.includes('deb')) resolvedSlug = 'debian';
  else if (normalized.includes('alp') || lowerName.includes('alp')) resolvedSlug = 'alpine';
  else if (normalized.includes('cent') || lowerName.includes('cent')) resolvedSlug = 'centos';
  else if (normalized.includes('rocky') || lowerName.includes('rocky')) resolvedSlug = 'rocky';
  else if (normalized.includes('fedora') || lowerName.includes('fedora')) resolvedSlug = 'fedora';
  else if (normalized.includes('arch') || lowerName.includes('arch')) resolvedSlug = 'arch';
  else if (normalized.includes('kali') || lowerName.includes('kali')) resolvedSlug = 'kali';
  else if (normalized.includes('alma') || lowerName.includes('alma')) resolvedSlug = 'almalinux';
  else if (normalized.includes('suse') || lowerName.includes('suse')) resolvedSlug = 'opensuse';
  else if (normalized.includes('redhat') || lowerName.includes('redhat') || normalized.includes('rhel') || lowerName.includes('rhel')) resolvedSlug = 'redhat';
  else if (normalized.includes('win') || lowerName.includes('win')) resolvedSlug = 'windows';
  else if (normalized.includes('dock') || lowerName.includes('dock')) resolvedSlug = 'docker';
  else if (normalized.includes('tux') || lowerName.includes('tux') || normalized.includes('linux') || lowerName.includes('linux')) resolvedSlug = 'linux';
  else if (normalized.includes('ubun') || lowerName.includes('ubun')) resolvedSlug = 'ubuntu';

  const sizeClasses = {
    xs: 'w-4 h-4',
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
  };

  const containerSizes = {
    xs: 'w-5 h-5 rounded',
    sm: 'w-7 h-7 rounded-lg',
    md: 'w-10 h-10 rounded-xl',
    lg: 'w-14 h-14 rounded-2xl',
    xl: 'w-20 h-20 rounded-2xl',
  };

  return (
    <div className={`relative flex items-center justify-center shrink-0 overflow-hidden shadow-sm bg-black/40 border border-white/10 ${containerSizes[size]} ${className}`}>
      <img
        src={`/assets/os/${resolvedSlug}.svg`}
        alt={`${resolvedSlug} logo`}
        className={`${sizeClasses[size]} object-contain`}
        onError={(e) => {
          const target = e.currentTarget;
          if (target.src.includes('/assets/os/') && target.src.endsWith('.svg')) {
            target.src = `/os/${resolvedSlug}.svg`;
          } else if (target.src.endsWith('.svg')) {
            target.src = `/os/${resolvedSlug}.png`;
          } else {
            target.style.display = 'none';
            const fallbackDisc = target.parentElement?.querySelector('.os-fallback-disc');
            if (fallbackDisc) {
              fallbackDisc.classList.remove('hidden');
            }
          }
        }}
      />
      <Disc className={`os-fallback-disc ${sizeClasses[size]} text-slate-500 hidden`} />
    </div>
  );
};
