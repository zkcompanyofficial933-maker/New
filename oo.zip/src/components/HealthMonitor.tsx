import React from 'react';
import { useSKVM } from '../context/SKVMContext';
import { HeartPulse, CheckCircle2, Server, Database, Activity, ShieldCheck, HardDrive } from 'lucide-react';

export const HealthMonitor: React.FC = () => {
  const { nodes, vms } = useSKVM();

  const services = [
    { name: 'SKVM Control Plane (Flask Core)', status: 'HEALTHY', latency: '2.1 ms', desc: 'Accepting REST API requests & WebSockets' },
    { name: 'Database Storage Engine (SQLite)', status: 'HEALTHY', latency: '0.4 ms', desc: 'ACID transactional integrity verified' },
    { name: 'Node.py Remote Agent Daemon', status: 'HEALTHY', latency: '8.5 ms', desc: 'Secure token HMAC heartbeat streaming' },
    { name: 'Docker Engine UNIX Socket', status: 'HEALTHY', latency: '1.2 ms', desc: 'v26.1.3 unix:///var/run/docker.sock' },
    { name: 'TMATE Web Relay Proxy Bridge', status: 'HEALTHY', latency: '19.4 ms', desc: 'Encrypted browser terminal tunnel' },
    { name: 'Container cgroups v2 Controller', status: 'HEALTHY', latency: '0.8 ms', desc: 'Memory limits and nano-cpus enforcement' },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-5xl mx-auto">
      <div>
        <h2 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          <HeartPulse className="w-6 h-6 text-emerald-400" />
          Cluster Diagnostic Health
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          End-to-end service status, socket responsiveness, and daemon heartbeat monitors.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {services.map((s, idx) => (
          <div key={idx} className="p-5 rounded-2xl glass-card border border-white/5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-white">{s.name}</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/20 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                {s.status}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">{s.desc}</p>
            <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 pt-2 border-t border-white/5">
              <span>Latency: <strong className="text-cyan-400">{s.latency}</strong></span>
              <span>Checked: Just now</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
