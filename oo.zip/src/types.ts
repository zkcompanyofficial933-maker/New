/**
 * SKVM System Types & Interfaces
 */

export type UserRole = 'ADMIN' | 'USER';

export interface User {
  id: number;
  username: string;
  email: string;
  role: UserRole;
  isActive: boolean;
  twoFactorEnabled: boolean;
  createdAt: string;
  lastLogin?: string;
}

export type VMStatus = 
  | 'CREATING' 
  | 'INSTALLING' 
  | 'RUNNING' 
  | 'STOPPED' 
  | 'ERROR' 
  | 'SUSPENDED' 
  | 'DELETING' 
  | 'READY';

export type ProvisioningStage =
  | 'INIT'
  | 'PULLING_IMAGE'
  | 'CREATING_CONTAINER'
  | 'CONFIGURING_RESOURCES'
  | 'CONFIGURING_NETWORK'
  | 'INSTALLING_SSH'
  | 'STARTING_TMATE'
  | 'VERIFYING_VM'
  | 'READY'
  | 'FAILED';

export interface VM {
  id: number;
  uuid: string;
  name: string;
  hostname: string;
  ipAddress: string;
  gateway: string;
  status: VMStatus;
  provisioningStage: ProvisioningStage;
  provisioningProgress: number; // 0 - 100
  provisioningError?: string;
  
  // Resources
  ramMb: number;
  cpuCores: number;
  diskGb: number;

  // Docker Container details
  containerId: string;
  containerName: string;
  imageSource?: 'dockerhub' | 'local';
  localImagePath?: string;

  // Access Credentials
  sshPort: number;
  sshUser: string;
  sshPassword: string;
  sshPrivateKey?: string;
  sshPublicKey?: string;
  sshFingerprint?: string;
  tmateCommand: string;
  tmateWeb: string;
  tmateSessionId?: string;
  tmateActive?: boolean;
  isRealDockerContainer?: boolean;

  // Associations
  userId: number;
  userName: string;
  nodeId: number;
  nodeName: string;
  osId: number;
  osName: string;
  osImage: string;
  osIcon: string;

  createdAt: string;
  updatedAt: string;
}

export interface Node {
  id: number;
  name: string;
  location: string;
  hostname: string;
  port: number;
  status: 'ONLINE' | 'OFFLINE' | 'MAINTENANCE';
  
  // Capacities
  totalRamMb: number;
  totalCpuCores: number;
  totalDiskGb: number;
  maxVms: number;

  dockerStatus: 'READY' | 'ACTIVE' | 'ERROR' | 'OFFLINE';
  dockerVersion: string;
  lastHeartbeat: string;
  createdAt: string;

  // Secret token for node.py agent
  tokenPrefix: string;
  tokenSecret?: string;
}

export interface OSImage {
  id: number;
  name: string;
  dockerImage: string;
  family: 'ubuntu' | 'debian' | 'alpine' | 'centos' | 'rocky' | 'fedora' | 'arch' | 'kali' | 'other';
  version: string;
  minRamMb: number;
  minDiskGb: number;
  isEnabled: boolean;
  iconSlug: string;
  imageSource?: 'dockerhub' | 'local';
  localImagePath?: string;
}

export interface ProvisionVMParams {
  name: string;
  ramMb: number;
  cpuCores: number;
  diskGb: number;
  osId: number;
  nodeId: number;
  userId: number;
  imageSource?: 'dockerhub' | 'local';
  customImage?: string;
}

export interface PortMapping {
  id: number;
  vmId: number;
  internalPort: number;
  externalPort: number;
  protocol: 'TCP' | 'UDP';
  description: string;
}

export interface BackupRecord {
  id: number;
  vmId: number;
  name: string;
  sizeMb: number;
  status: 'COMPLETED' | 'IN_PROGRESS' | 'FAILED';
  createdAt: string;
}

export interface SnapshotRecord {
  id: number;
  vmId: number;
  name: string;
  imageTag: string;
  status: 'READY' | 'CREATING';
  createdAt: string;
}

export interface ActivityLog {
  id: number;
  username: string;
  action: string;
  details: string;
  ipAddress: string;
  createdAt: string;
}

export interface NotificationItem {
  id: number;
  userId: number;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'danger';
  isRead: boolean;
  createdAt: string;
}

export interface LiveMetrics {
  cpuPercent: number;
  ramUsedMb: number;
  ramTotalMb: number;
  ramPercent: number;
  diskUsedGb: number;
  diskTotalGb: number;
  diskPercent: number;
  netRxKbps: number;
  netTxKbps: number;
  uptimeSeconds: number;
}

export interface SystemSettings {
  panelName: string;
  logoUrl: string;
  faviconUrl: string;
  theme: 'dark' | 'system' | 'light';
  accentColor: string;
  discordLink: string;
  websiteLink: string;
  maintenanceMode: boolean;
}

export interface AlertHistoryItem {
  id: number;
  timestamp: string;
  metric: 'CPU' | 'RAM';
  value: number;
  threshold: number;
  target: string;
  channel: 'EMAIL' | 'SYSTEM' | 'BOTH';
  status: 'TRIGGERED' | 'RESOLVED';
  message: string;
}

export interface ResourceThresholdConfig {
  cpuThresholdPercent: number;
  ramThresholdPercent: number;
  enableEmailAlerts: boolean;
  alertEmail: string;
  enableSystemAlerts: boolean;
  notifyOnClusterSpike: boolean;
  notifyOnNodeSpike: boolean;
  notifyOnVmSpike: boolean;
  cooldownMinutes: number;
  autoResolveNotification: boolean;
  lastCpuAlertAt?: string;
  lastRamAlertAt?: string;
  alertHistory: AlertHistoryItem[];
}
