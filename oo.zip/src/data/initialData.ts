import { User, Node, OSImage, VM, PortMapping, BackupRecord, SnapshotRecord, ActivityLog, NotificationItem, SystemSettings, ResourceThresholdConfig } from '../types';

export const initialUsers: User[] = [
  {
    id: 1,
    username: 'admin',
    email: 'admin@skvm.cloud',
    role: 'ADMIN',
    isActive: true,
    twoFactorEnabled: true,
    createdAt: '2026-01-01T00:00:00Z',
    lastLogin: '2026-09-22T08:00:00Z',
  }
];

// Primary Local Host Hypervisor (Docker CE Engine)
export const initialNodes: Node[] = [
  {
    id: 1,
    name: 'Node-01-Local (Primary Docker CE)',
    location: 'Primary Hypervisor (Local Host)',
    hostname: '127.0.0.1',
    port: 3000,
    status: 'ONLINE',
    totalRamMb: 32768,
    totalCpuCores: 16,
    totalDiskGb: 1000,
    maxVms: 50,
    dockerStatus: 'ACTIVE',
    dockerVersion: '26.1.3',
    lastHeartbeat: new Date().toISOString(),
    createdAt: '2026-01-01T00:00:00Z',
    tokenPrefix: 'skvm_node_01'
  }
];

// Preloaded OS base images with dedicated SVG logos
export const initialOSImages: OSImage[] = [
  {
    id: 1,
    name: 'Ubuntu 24.04 LTS (Noble)',
    dockerImage: 'ubuntu:24.04',
    family: 'ubuntu',
    version: '24.04',
    minRamMb: 1024,
    minDiskGb: 10,
    isEnabled: true,
    iconSlug: 'ubuntu'
  },
  {
    id: 2,
    name: 'Ubuntu 22.04 LTS (Jammy)',
    dockerImage: 'ubuntu:22.04',
    family: 'ubuntu',
    version: '22.04',
    minRamMb: 1024,
    minDiskGb: 10,
    isEnabled: true,
    iconSlug: 'ubuntu'
  },
  {
    id: 3,
    name: 'Debian 12 (Bookworm)',
    dockerImage: 'debian:12',
    family: 'debian',
    version: '12',
    minRamMb: 512,
    minDiskGb: 8,
    isEnabled: true,
    iconSlug: 'debian'
  },
  {
    id: 4,
    name: 'Debian 11 (Bullseye)',
    dockerImage: 'debian:11',
    family: 'debian',
    version: '11',
    minRamMb: 512,
    minDiskGb: 8,
    isEnabled: true,
    iconSlug: 'debian'
  },
  {
    id: 5,
    name: 'Alpine Linux 3.20 (Minimal)',
    dockerImage: 'alpine:3.20',
    family: 'alpine',
    version: '3.20',
    minRamMb: 256,
    minDiskGb: 4,
    isEnabled: true,
    iconSlug: 'alpine'
  },
  {
    id: 6,
    name: 'Rocky Linux 9 (Enterprise RHEL)',
    dockerImage: 'rockylinux:9',
    family: 'rocky',
    version: '9.3',
    minRamMb: 1024,
    minDiskGb: 10,
    isEnabled: true,
    iconSlug: 'rocky'
  },
  {
    id: 7,
    name: 'Arch Linux (Rolling Release)',
    dockerImage: 'archlinux:latest',
    family: 'arch',
    version: 'Rolling',
    minRamMb: 1024,
    minDiskGb: 12,
    isEnabled: true,
    iconSlug: 'arch'
  },
  {
    id: 8,
    name: 'Kali Linux (Security / PenTesting)',
    dockerImage: 'kalilinux/kali-rolling:latest',
    family: 'kali',
    version: 'Rolling',
    minRamMb: 2048,
    minDiskGb: 15,
    isEnabled: true,
    iconSlug: 'kali'
  },
  {
    id: 9,
    name: 'Fedora 40 (Workstation Cloud)',
    dockerImage: 'fedora:40',
    family: 'fedora',
    version: '40',
    minRamMb: 1024,
    minDiskGb: 10,
    isEnabled: true,
    iconSlug: 'fedora'
  },
  {
    id: 10,
    name: 'Local Container Image (Host Cache)',
    dockerImage: 'localhost/custom-os:latest',
    family: 'other',
    version: 'Local',
    minRamMb: 512,
    minDiskGb: 5,
    isEnabled: true,
    iconSlug: 'other',
    imageSource: 'local',
    localImagePath: 'localhost/custom-os:latest'
  }
];

// Clean state: No mock demo VMs
export const initialVMs: VM[] = [];

// Clean state: No mock port mappings
export const initialPortMappings: PortMapping[] = [];

// Clean state: No mock backups
export const initialBackups: BackupRecord[] = [];

// Clean state: No mock snapshots
export const initialSnapshots: SnapshotRecord[] = [];

export const initialActivityLogs: ActivityLog[] = [
  { 
    id: 1, 
    username: 'admin', 
    action: 'SYSTEM_INITIALIZED', 
    details: 'SKVM Control Plane initialized. Docker cgroups v2 & LXCFS ready for node connectivity.', 
    ipAddress: '127.0.0.1', 
    createdAt: '2026-09-22T08:00:00Z' 
  },
];

export const initialNotifications: NotificationItem[] = [
  { 
    id: 1, 
    userId: 1, 
    title: 'SKVM Ready', 
    message: 'Welcome to SKVM. Configure your hypervisor nodes to begin provisioning Docker VPS instances.', 
    type: 'info', 
    isRead: false, 
    createdAt: '2026-09-22T08:00:00Z' 
  },
];

export const initialSettings: SystemSettings = {
  panelName: 'SKVM',
  logoUrl: '',
  faviconUrl: '',
  theme: 'dark',
  accentColor: 'cyan',
  discordLink: 'https://discord.gg/skvm',
  websiteLink: 'https://skvm.cloud',
  maintenanceMode: false,
};

export const initialThresholdConfig: ResourceThresholdConfig = {
  cpuThresholdPercent: 80,
  ramThresholdPercent: 85,
  enableEmailAlerts: true,
  alertEmail: 'admin@skvm.cloud',
  enableSystemAlerts: true,
  notifyOnClusterSpike: true,
  notifyOnNodeSpike: true,
  notifyOnVmSpike: true,
  cooldownMinutes: 5,
  autoResolveNotification: true,
  alertHistory: [
    {
      id: 1,
      timestamp: '2026-09-23T06:12:00Z',
      metric: 'CPU',
      value: 86.4,
      threshold: 80,
      target: 'US-East Hypervisor-01',
      channel: 'BOTH',
      status: 'RESOLVED',
      message: 'Node CPU spike normalized back to 42.1%'
    }
  ]
};

