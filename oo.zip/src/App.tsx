import React from 'react';
import { SKVMProvider, useSKVM } from './context/SKVMContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { UserDashboard } from './components/UserDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { VMList } from './components/VMList';
import { VMDetail } from './components/VMDetail';
import { VMCreateWizard } from './components/VMCreateWizard';
import { NodesManager } from './components/NodesManager';
import { UsersManager } from './components/UsersManager';
import { OSManager } from './components/OSManager';
import { PortForwarding } from './components/PortForwarding';
import { ProfilePage } from './components/ProfilePage';
import { AdminSettings } from './components/AdminSettings';
import { UserSettings } from './components/UserSettings';
import { HealthMonitor } from './components/HealthMonitor';
import { ActivityLogs } from './components/ActivityLogs';
import { LoginScreen } from './components/LoginScreen';
import { RegisterScreen } from './components/RegisterScreen';
import { StarterPage } from './components/StarterPage';
import { MaintenanceScreen } from './components/MaintenanceScreen';
import { Error403, Error404, Error500 } from './components/ErrorPages';

const MainLayout: React.FC = () => {
  const { currentUser, currentView, settings } = useSKVM();
  const isAdmin = currentUser?.role === 'ADMIN';

  // If not logged in, route between Starter, Register, and Login
  if (!currentUser) {
    if (currentView === 'starter') {
      return <StarterPage />;
    }
    return (
      <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-white">
        <Navbar />
        <main className="flex-1 flex items-center justify-center p-4">
          {currentView === 'register' ? <RegisterScreen /> : <LoginScreen />}
        </main>
      </div>
    );
  }

  // If in maintenance mode and user is not admin
  if (settings.maintenanceMode && !isAdmin) {
    return (
      <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col font-sans">
        <Navbar />
        <main className="flex-1 flex items-center justify-center p-4">
          <MaintenanceScreen />
        </main>
      </div>
    );
  }

  // Render view router
  const renderCurrentView = () => {
    switch (currentView) {
      case 'starter':
        return <StarterPage />;
      case 'dashboard':
        return isAdmin ? <AdminDashboard /> : <UserDashboard />;
      case 'vms':
        return <VMList />;
      case 'vm_detail':
        return <VMDetail />;
      case 'create_vm':
        return <VMCreateWizard />;
      case 'nodes':
        return <NodesManager />;
      case 'users':
        return <UsersManager />;
      case 'os':
        return <OSManager />;
      case 'ports':
        return <PortForwarding />;
      case 'settings':
        return isAdmin ? <AdminSettings /> : <UserSettings />;
      case 'profile':
        return <ProfilePage />;
      case 'health':
        return <HealthMonitor />;
      case 'logs':
        return <ActivityLogs />;
      case 'error_403':
        return <Error403 />;
      case 'error_404':
        return <Error404 />;
      case 'error_500':
        return <Error500 />;
      default:
        return isAdmin ? <AdminDashboard /> : <UserDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-white">
      <Navbar />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar />

        <main className="flex-1 overflow-y-auto relative">
          {/* Subtle background glow effect */}
          <div className="absolute top-0 right-1/4 w-96 h-96 bg-cyan-500/[0.03] rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute bottom-10 left-1/3 w-96 h-96 bg-purple-500/[0.02] rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 pb-16">
            {renderCurrentView()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <SKVMProvider>
      <MainLayout />
    </SKVMProvider>
  );
}
