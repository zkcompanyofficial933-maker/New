#!/usr/bin/env python3
"""
SKVM - Enterprise Docker-Based VPS Management Panel
Core Server, Database Models, Docker Engine & WebSocket Management
"""

import os
import sys
import json
import time
import uuid
import secrets
import logging
import threading
import socket
import shlex
import subprocess
from datetime import datetime, timedelta
from functools import wraps

from dotenv import load_dotenv
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, abort, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_socketio import SocketIO, emit, join_room, leave_room
from werkzeug.security import generate_password_hash, check_password_hash

# Load environment
load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("SKVM")

# Optional Docker SDK import with fallback
try:
    import docker
    DOCKER_AVAILABLE = True
except ImportError:
    DOCKER_AVAILABLE = False
    logger.warning("Docker SDK for python not installed or unavailable.")

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "skvm-default-secret-change-in-production")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///skvm.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

# ==============================================================================
# DATABASE MODELS
# ==============================================================================

class User(UserMixin, db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default="USER")  # "ADMIN" or "USER"
    is_active_status = db.Column(db.Boolean, default=True)
    two_factor_enabled = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)

    vms = db.relationship("VM", backref="owner", lazy=True, cascade="all, delete-orphan")
    notifications = db.relationship("Notification", backref="user", lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def is_admin(self):
        return self.role == "ADMIN"

    @property
    def is_active(self):
        return self.is_active_status


class Node(db.Model):
    __tablename__ = "nodes"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    location = db.Column(db.String(100), default="Primary Datacenter")
    hostname = db.Column(db.String(255), nullable=False)
    port = db.Column(db.Integer, default=3000)
    status = db.Column(db.String(20), default="ONLINE")  # "ONLINE", "OFFLINE", "MAINTENANCE"
    
    # Capacity Limits
    total_ram_mb = db.Column(db.Integer, default=16384)   # 16 GB default
    total_cpu_cores = db.Column(db.Integer, default=8)
    total_disk_gb = db.Column(db.Integer, default=500)
    max_vms = db.Column(db.Integer, default=25)
    
    # Current node status
    docker_status = db.Column(db.String(50), default="READY")
    docker_version = db.Column(db.String(50), default="26.1.3")
    last_heartbeat = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    vms = db.relationship("VM", backref="node", lazy=True)
    tokens = db.relationship("NodeToken", backref="node", lazy=True, cascade="all, delete-orphan")

    def get_allocated_ram(self):
        return sum(vm.ram_mb for vm in self.vms if vm.status != "DELETED")

    def get_allocated_cpu(self):
        return sum(vm.cpu_cores for vm in self.vms if vm.status != "DELETED")

    def get_allocated_disk(self):
        return sum(vm.disk_gb for vm in self.vms if vm.status != "DELETED")


class NodeToken(db.Model):
    __tablename__ = "node_tokens"
    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.Integer, db.ForeignKey("nodes.id"), nullable=False)
    token_hash = db.Column(db.String(255), nullable=False, unique=True)
    prefix = db.Column(db.String(16), nullable=False)
    is_revoked = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class OSImage(db.Model):
    __tablename__ = "os_images"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    docker_image = db.Column(db.String(255), nullable=False)
    family = db.Column(db.String(50), default="linux")
    version = db.Column(db.String(50), default="latest")
    min_ram_mb = db.Column(db.Integer, default=512)
    min_disk_gb = db.Column(db.Integer, default=5)
    is_enabled = db.Column(db.Boolean, default=True)
    icon_slug = db.Column(db.String(50), default="ubuntu")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class VM(db.Model):
    __tablename__ = "vms"
    id = db.Column(db.Integer, primary_key=True)
    uuid = db.Column(db.String(36), unique=True, default=lambda: str(uuid.uuid4()))
    name = db.Column(db.String(100), nullable=False)
    hostname = db.Column(db.String(150), nullable=False)
    ip_address = db.Column(db.String(45), default="172.20.0.2")
    gateway = db.Column(db.String(45), default="172.20.0.1")
    
    # State: CREATING, INSTALLING, RUNNING, STOPPED, SUSPENDED, ERROR, DELETED, READY
    status = db.Column(db.String(30), default="CREATING")
    provisioning_stage = db.Column(db.String(50), default="INIT")
    provisioning_error = db.Column(db.Text, nullable=True)

    # Resources
    ram_mb = db.Column(db.Integer, nullable=False, default=1024)
    cpu_cores = db.Column(db.Float, nullable=False, default=1.0)
    disk_gb = db.Column(db.Integer, nullable=False, default=10)

    # Docker mapping
    container_id = db.Column(db.String(100), nullable=True)
    container_name = db.Column(db.String(150), nullable=True)

    # Access credentials
    ssh_port = db.Column(db.Integer, default=2222)
    ssh_user = db.Column(db.String(50), default="root")
    ssh_password = db.Column(db.String(100), nullable=True)
    tmate_command = db.Column(db.String(255), nullable=True)
    tmate_web = db.Column(db.String(255), nullable=True)

    # Relations
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    node_id = db.Column(db.Integer, db.ForeignKey("nodes.id"), nullable=False)
    os_id = db.Column(db.Integer, db.ForeignKey("os_images.id"), nullable=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    os = db.relationship("OSImage", backref="vms")
    ports = db.relationship("Port", backref="vm", lazy=True, cascade="all, delete-orphan")
    backups = db.relationship("Backup", backref="vm", lazy=True, cascade="all, delete-orphan")
    snapshots = db.relationship("Snapshot", backref="vm", lazy=True, cascade="all, delete-orphan")


class Port(db.Model):
    __tablename__ = "ports"
    id = db.Column(db.Integer, primary_key=True)
    vm_id = db.Column(db.Integer, db.ForeignKey("vms.id"), nullable=False)
    internal_port = db.Column(db.Integer, nullable=False)
    external_port = db.Column(db.Integer, nullable=False)
    protocol = db.Column(db.String(10), default="TCP")
    description = db.Column(db.String(100), default="Custom mapping")


class Backup(db.Model):
    __tablename__ = "backups"
    id = db.Column(db.Integer, primary_key=True)
    vm_id = db.Column(db.Integer, db.ForeignKey("vms.id"), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    size_mb = db.Column(db.Float, default=0.0)
    status = db.Column(db.String(20), default="COMPLETED")
    backup_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Snapshot(db.Model):
    __tablename__ = "snapshots"
    id = db.Column(db.Integer, primary_key=True)
    vm_id = db.Column(db.Integer, db.ForeignKey("vms.id"), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    image_tag = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(20), default="READY")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class ActivityLog(db.Model):
    __tablename__ = "activity_logs"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=True)
    username = db.Column(db.String(80), default="System")
    action = db.Column(db.String(100), nullable=False)
    details = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Notification(db.Model):
    __tablename__ = "notifications"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(150), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(20), default="info") # info, success, warning, danger
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Setting(db.Model):
    __tablename__ = "settings"
    key = db.Column(db.String(100), primary_key=True)
    value = db.Column(db.Text, nullable=True)


# ==============================================================================
# DOCKER VM ENGINE & REAL PROVISIONING
# ==============================================================================

class DockerVMEngine:
    """Real Docker-backed VM/container engine.

    The previous implementation generated synthetic tmate strings and started
    containers with `tail -f /dev/null`.  This engine instead installs a real
    SSH/tmate runtime inside each container, records the actual tmate endpoint,
    and exposes Docker exec through the API/WebSocket terminal.
    """

    def __init__(self):
        self.client = None
        self._tmate_sockets = {}
        self._terminal_sessions = {}
        self._lock = threading.RLock()

        if DOCKER_AVAILABLE:
            try:
                self.client = docker.from_env()
                self.client.ping()
                logger.info("Docker daemon successfully connected.")
            except Exception as e:
                logger.error("Docker daemon unavailable: %s", e)

    def is_docker_ready(self):
        return self.client is not None

    def _pick_host_port(self, start=2200, end=2999):
        """Find a free host TCP port before asking Docker to publish it."""
        used = set()
        try:
            for c in self.client.containers.list(all=True):
                try:
                    bindings = c.attrs.get("HostConfig", {}).get("PortBindings") or {}
                    for vals in bindings.values():
                        for item in vals or []:
                            if item.get("HostPort"):
                                used.add(int(item["HostPort"]))
                except Exception:
                    continue

            for port in range(start, end + 1):
                if port in used:
                    continue
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    sock.bind(("0.0.0.0", port))
                    return port
                except OSError:
                    pass
                finally:
                    sock.close()
        except Exception:
            pass

        # Let Docker select an ephemeral port if the configured range is full.
        return 0

    def _exec(self, container, command, timeout=180, tty=False):
        """Run a shell command inside a container and return text + exit code."""
        if isinstance(command, str):
            command = ["/bin/sh", "-lc", command]
        result = container.exec_run(
            command,
            stdout=True,
            stderr=True,
            stdin=False,
            tty=tty,
            demux=False
        )
        output = result.output
        if isinstance(output, bytes):
            output = output.decode("utf-8", "replace")
        return output or "", int(result.exit_code if result.exit_code is not None else 0)

    def _install_access_runtime(self, container, password):
        """Install and start OpenSSH + tmate inside the guest container."""
        # Detect distro using /etc/os-release.
        out, _ = self._exec(container, "cat /etc/os-release 2>/dev/null || true")
        os_id = ""
        for line in out.splitlines():
            if line.startswith("ID="):
                os_id = line.split("=", 1)[1].strip().strip('"').lower()
                break

        if os_id in ("alpine",):
            install = (
                "apk add --no-cache openssh tmate bash ca-certificates curl >/dev/null 2>&1 && "
                "ssh-keygen -A"
            )
            self._exec(container, install, timeout=240)
            setup = (
                "mkdir -p /run/sshd /root && "
                "echo 'root:{pwd}' | chpasswd && "
                "sed -i 's/^#*PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config && "
                "sed -i 's/^#*PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config && "
                "(pkill sshd || true); /usr/sbin/sshd"
            ).format(pwd=shlex.quote(password))
            self._exec(container, setup, timeout=60)
            shell = "/bin/sh"
        else:
            # Ubuntu/Debian are the supported SKVM VPS images.
            install = (
                "export DEBIAN_FRONTEND=noninteractive; "
                "apt-get update -qq && "
                "apt-get install -y -qq openssh-server tmate bash ca-certificates curl sudo >/dev/null && "
                "mkdir -p /run/sshd"
            )
            out, rc = self._exec(container, install, timeout=300)
            if rc != 0:
                raise RuntimeError("Failed to install OpenSSH/tmate in container: " + out[-1200:])

            setup = (
                "echo 'root:{pwd}' | chpasswd && "
                "mkdir -p /run/sshd && "
                "sed -ri 's/^#?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config && "
                "sed -ri 's/^#?PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config && "
                "grep -q '^PermitRootLogin' /etc/ssh/sshd_config || echo 'PermitRootLogin yes' >> /etc/ssh/sshd_config && "
                "grep -q '^PasswordAuthentication' /etc/ssh/sshd_config || echo 'PasswordAuthentication yes' >> /etc/ssh/sshd_config && "
                "(pkill sshd || true); /usr/sbin/sshd"
            ).format(pwd=shlex.quote(password))
            out, rc = self._exec(container, setup, timeout=60)
            if rc != 0:
                raise RuntimeError("Failed to configure OpenSSH in container: " + out[-1200:])
            shell = "/bin/bash"

        # Start a real tmate session in the guest and wait for its remote endpoint.
        # The socket path is deliberately inside the container so sessions are
        # isolated per VPS.
        tmate_socket = "/tmp/skvm-tmate.sock"
        self._exec(
            container,
            f"rm -f {shlex.quote(tmate_socket)}; "
            f"tmate -S {shlex.quote(tmate_socket)} new-session -d",
            timeout=30
        )
        out, rc = self._exec(
            container,
            f"tmate -S {shlex.quote(tmate_socket)} wait tmate-ready",
            timeout=60
        )
        if rc != 0:
            raise RuntimeError("tmate did not become ready: " + out[-1200:])

        ssh_out, rc = self._exec(
            container,
            f"tmate -S {shlex.quote(tmate_socket)} display -p '#{{tmate_ssh}}'",
            timeout=30
        )
        web_out, _ = self._exec(
            container,
            f"tmate -S {shlex.quote(tmate_socket)} display -p '#{{tmate_web}}'",
            timeout=30
        )
        ssh_cmd = next((x.strip() for x in ssh_out.splitlines() if x.strip().startswith("ssh ")), "")
        web_url = next((x.strip() for x in web_out.splitlines() if x.strip().startswith(("http://", "https://"))), "")

        if not ssh_cmd:
            raise RuntimeError("tmate returned no SSH connection command")
        if not web_url:
            # Some tmate versions expose only the SSH endpoint.
            m = re.search(r"ssh\s+([^@\s]+)@([^\s]+)", ssh_cmd)
            if m:
                web_url = f"https://tmate.io/t/{m.group(1)}"

        return shell, ssh_cmd, web_url

    def provision_vm_async(self, app_context, vm_id):
        threading.Thread(
            target=self._run_provisioning,
            args=(app_context, vm_id),
            daemon=True,
            name=f"skvm-provision-{vm_id}"
        ).start()

    def _run_provisioning(self, app_context, vm_id):
        with app_context:
            vm = VM.query.get(vm_id)
            if not vm:
                return

            try:
                if not self.client:
                    raise RuntimeError(
                        "Docker daemon is not available. Start Docker and verify "
                        "/var/run/docker.sock is accessible to the SKVM service."
                    )

                vm.status = "CREATING"
                vm.provisioning_stage = "PULLING_IMAGE"
                vm.provisioning_error = None
                db.session.commit()

                os_image = vm.os.docker_image if vm.os else "ubuntu:22.04"
                try:
                    self.client.images.get(os_image)
                except Exception:
                    self.client.images.pull(os_image)

                vm.provisioning_stage = "CREATING_CONTAINER"
                db.session.commit()

                container_name = f"skvm-vm-{vm.uuid[:8]}"
                try:
                    old = self.client.containers.get(container_name)
                    old.remove(force=True)
                except Exception:
                    pass

                host_port = self._pick_host_port()
                ports = {"22/tcp": host_port} if host_port else None
                nano_cpus = max(100_000_000, int(float(vm.cpu_cores) * 1_000_000_000))
                mem_limit = max(64 * 1024 * 1024, int(vm.ram_mb) * 1024 * 1024)

                container = self.client.containers.create(
                    image=os_image,
                    name=container_name,
                    detach=True,
                    hostname=vm.hostname,
                    command=["/bin/sh", "-lc", "while true; do sleep 3600; done"],
                    nano_cpus=nano_cpus,
                    mem_limit=mem_limit,
                    ports=ports,
                    restart_policy={"Name": "unless-stopped"},
                    labels={
                        "com.skvm.managed": "true",
                        "com.skvm.vm_id": str(vm.id),
                        "com.skvm.uuid": vm.uuid,
                    },
                )
                container.start()

                vm.container_id = container.id
                vm.container_name = container_name
                vm.provisioning_stage = "CONFIGURING_NETWORK"
                db.session.commit()

                # Read the actual container IP instead of inventing one.
                container.reload()
                networks = container.attrs.get("NetworkSettings", {}).get("Networks", {})
                if networks:
                    first_net = next(iter(networks.values()))
                    vm.ip_address = first_net.get("IPAddress") or vm.ip_address
                    vm.gateway = first_net.get("Gateway") or vm.gateway

                # Read the actual published SSH port selected by Docker.
                container.reload()
                binding = (
                    container.attrs.get("NetworkSettings", {})
                    .get("Ports", {})
                    .get("22/tcp")
                )
                if binding and binding[0].get("HostPort"):
                    vm.ssh_port = int(binding[0]["HostPort"])
                elif host_port:
                    vm.ssh_port = int(host_port)

                vm.provisioning_stage = "INSTALLING_SSH"
                db.session.commit()

                password = "skvm_" + secrets.token_urlsafe(9).replace("-", "").replace("_", "")[:14]
                shell, tmate_cmd, tmate_web = self._install_access_runtime(container, password)

                vm.ssh_password = password
                vm.tmate_command = tmate_cmd
                vm.tmate_web = tmate_web
                vm.provisioning_stage = "VERIFYING_VM"
                db.session.commit()

                # Verify both Docker exec and the actual tmate endpoint.
                out, rc = self._exec(container, "id -u && command -v tmate && command -v sshd", timeout=30)
                if rc != 0 or "0" not in out:
                    raise RuntimeError("Guest access verification failed: " + out[-1000:])

                vm.status = "RUNNING"
                vm.provisioning_stage = "READY"
                db.session.commit()

                db.session.add(Notification(
                    user_id=vm.user_id,
                    title=f"VM {vm.name} is Ready",
                    message=f"Real Docker container, OpenSSH and tmate session are active.",
                    type="success"
                ))
                db.session.commit()

            except Exception as e:
                logger.exception("Provisioning failed for VM %s", vm_id)
                try:
                    vm.status = "ERROR"
                    vm.provisioning_stage = "ERROR"
                    vm.provisioning_error = str(e)
                    db.session.commit()
                except Exception:
                    db.session.rollback()

    def get_container(self, vm):
        if not self.client or not vm.container_id:
            raise RuntimeError("VM is not attached to a Docker container")
        try:
            return self.client.containers.get(vm.container_id)
        except Exception as exc:
            raise RuntimeError(f"Docker container not found: {exc}")

    def start(self, vm):
        c = self.get_container(vm)
        c.start()
        vm.status = "RUNNING"
        db.session.commit()

    def stop(self, vm):
        c = self.get_container(vm)
        c.stop(timeout=10)
        vm.status = "STOPPED"
        vm.tmate_command = None
        vm.tmate_web = None
        db.session.commit()

    def restart(self, vm):
        c = self.get_container(vm)
        c.restart(timeout=10)
        vm.status = "RUNNING"
        # tmate is killed when the container stops; create a new real session.
        try:
            password = vm.ssh_password or ("skvm_" + secrets.token_urlsafe(9)[:14])
            _, vm.tmate_command, vm.tmate_web = self._install_access_runtime(c, password)
        except Exception as exc:
            logger.warning("Could not recreate tmate after restart: %s", exc)
        db.session.commit()

    def remove(self, vm):
        if self.client and vm.container_id:
            try:
                self.client.containers.get(vm.container_id).remove(force=True)
            except Exception:
                pass
        vm.status = "DELETED"
        vm.tmate_command = None
        vm.tmate_web = None
        db.session.commit()

    def exec_command(self, vm, command, timeout=30):
        c = self.get_container(vm)
        if c.status != "running":
            raise RuntimeError("VM is not running")
        # Never use a local shell. The command is executed only inside the VM.
        result = c.exec_run(
            ["/bin/sh", "-lc", command],
            stdout=True,
            stderr=True,
            demux=False,
            tty=False
        )
        output = result.output
        if isinstance(output, bytes):
            output = output.decode("utf-8", "replace")
        return output or "", int(result.exit_code if result.exit_code is not None else 0)

    def generate_tmate(self, vm):
        c = self.get_container(vm)
        if c.status != "running":
            raise RuntimeError("VM must be running before creating a tmate session")
        password = vm.ssh_password or ("skvm_" + secrets.token_urlsafe(9)[:14])
        _, vm.tmate_command, vm.tmate_web = self._install_access_runtime(c, password)
        vm.ssh_password = password
        db.session.commit()
        return vm.tmate_command, vm.tmate_web

    def open_terminal(self, sid, vm):
        c = self.get_container(vm)
        if c.status != "running":
            raise RuntimeError("VM is not running")

        exec_id = self.client.api.exec_create(
            c.id,
            cmd=["/bin/sh", "-l"],
            stdin=True,
            stdout=True,
            stderr=True,
            tty=True,
            environment={"TERM": "xterm-256color"}
        )["Id"]

        stream = self.client.api.exec_start(exec_id, detach=False, tty=True, socket=True)
        sock = stream
        with self._lock:
            self._terminal_sessions[sid] = {
                "vm_id": vm.id,
                "exec_id": exec_id,
                "socket": sock,
            }

        def reader():
            try:
                while True:
                    data = sock.recv(8192)
                    if not data:
                        break
                    if isinstance(data, bytes):
                        data = data.decode("utf-8", "replace")
                    socketio.emit("terminal:output", {"data": data}, to=sid)
            except Exception as exc:
                logger.debug("terminal reader ended for %s: %s", sid, exc)
            finally:
                socketio.emit("terminal:closed", {"reason": "session ended"}, to=sid)
                self.close_terminal(sid)

        threading.Thread(target=reader, daemon=True, name=f"skvm-terminal-{sid[:8]}").start()

    def write_terminal(self, sid, data):
        with self._lock:
            session_data = self._terminal_sessions.get(sid)
        if not session_data:
            raise RuntimeError("Terminal session is not connected")
        raw = data.encode("utf-8") if isinstance(data, str) else data
        session_data["socket"].send(raw)

    def resize_terminal(self, sid, cols, rows):
        with self._lock:
            session_data = self._terminal_sessions.get(sid)
        if not session_data:
            return
        try:
            self.client.api.exec_resize(
                session_data["exec_id"],
                height=max(1, int(rows)),
                width=max(1, int(cols))
            )
        except Exception as exc:
            logger.debug("terminal resize failed: %s", exc)

    def close_terminal(self, sid):
        with self._lock:
            session_data = self._terminal_sessions.pop(sid, None)
        if session_data:
            try:
                session_data["socket"].close()
            except Exception:
                pass

docker_engine = DockerVMEngine()


# ==============================================================================
# AUTH & HELPERS
# ==============================================================================

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != "ADMIN":
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

def check_maintenance():
    if current_user.is_authenticated and current_user.role == "ADMIN":
        return None
    m_mode = Setting.query.filter_by(key="maintenance_mode").first()
    if m_mode and m_mode.value == "true":
        return render_template("errors/maintenance.html")
    return None

app.before_request(check_maintenance)

def log_event(action, details=None):
    try:
        user_id = current_user.id if current_user.is_authenticated else None
        username = current_user.username if current_user.is_authenticated else "System"
        ip = request.remote_addr if request else "127.0.0.1"
        event = ActivityLog(user_id=user_id, username=username, action=action, details=details, ip_address=ip)
        db.session.add(event)
        db.session.commit()
    except Exception as e:
        logger.warning(f"Failed to write activity log: {e}")

# Database Initializer with default admin & OS templates
def init_db():
    db.create_all()
    # Default admin user
    if not User.query.filter_by(username="admin").first():
        admin = User(
            username="admin",
            email=os.getenv("DEFAULT_ADMIN_EMAIL", "admin@skvm.local"),
            role="ADMIN",
            is_active_status=True
        )
        admin.set_password(os.getenv("DEFAULT_ADMIN_PASS", "Admin123456!"))
        db.session.add(admin)
        db.session.commit()
        logger.info("Created default administrator account: admin")

    # Default demo user
    if not User.query.filter_by(username="demouser").first():
        demo = User(
            username="demouser",
            email="demouser@skvm.local",
            role="USER",
            is_active_status=True
        )
        demo.set_password("User123456!")
        db.session.add(demo)
        db.session.commit()

    # Default OS templates
    default_os_list = [
        ("Ubuntu 22.04 LTS", "ubuntu:22.04", "ubuntu", "22.04", 1024, 10),
        ("Ubuntu 20.04 LTS", "ubuntu:20.04", "ubuntu", "20.04", 1024, 10),
        ("Debian 12 (Bookworm)", "debian:12", "debian", "12", 512, 8),
        ("Debian 11 (Bullseye)", "debian:11", "debian", "11", 512, 8),
        ("Alpine Linux 3.19", "alpine:3.19", "alpine", "3.19", 256, 5),
    ]
    for name, img, icon, ver, ram, disk in default_os_list:
        if not OSImage.query.filter_by(docker_image=img).first():
            os_rec = OSImage(name=name, docker_image=img, icon_slug=icon, version=ver, min_ram_mb=ram, min_disk_gb=disk)
            db.session.add(os_rec)
    
    # Default primary node
    if not Node.query.first():
        primary_node = Node(
            name="Node-01-Primary",
            location="Frankfurt, Germany",
            hostname="127.0.0.1",
            port=3000,
            status="ONLINE",
            total_ram_mb=32768,
            total_cpu_cores=16,
            total_disk_gb=1000,
            max_vms=50
        )
        db.session.add(primary_node)
        db.session.commit()
        # Create token
        token_str = secrets.token_hex(20)
        token = NodeToken(
            node_id=primary_node.id,
            token_hash=generate_password_hash(token_str),
            prefix=token_str[:6]
        )
        db.session.add(token)

    # Default Settings
    default_settings = {
        "panel_name": "SKVM",
        "theme": "dark",
        "accent_color": "cyan",
        "maintenance_mode": "false",
        "discord_link": "https://discord.gg/skvm",
        "website_link": "https://skvm.cloud",
    }
    for k, v in default_settings.items():
        if not Setting.query.filter_by(key=k).first():
            db.session.add(Setting(key=k, value=v))

    db.session.commit()

# ==============================================================================
# API HEALTH & STATUS ENDPOINTS
# ==============================================================================

@app.route("/api/health")
def api_health():
    return jsonify({
        "status": "ok",
        "skvm_version": "1.0.0",
        "docker_available": DOCKER_AVAILABLE,
        "database": "connected",
        "timestamp": datetime.utcnow().isoformat()
    })

# ==============================================================================
# REAL VM REST API + LIVE TERMINAL
# ==============================================================================

def _vm_json(vm):
    """Return the VM shape consumed by the React panel."""
    return {
        "id": vm.id,
        "uuid": vm.uuid,
        "name": vm.name,
        "hostname": vm.hostname,
        "ipAddress": vm.ip_address,
        "gateway": vm.gateway,
        "status": vm.status,
        "provisioningStage": vm.provisioning_stage,
        "provisioningError": vm.provisioning_error,
        "ramMb": vm.ram_mb,
        "cpuCores": vm.cpu_cores,
        "diskGb": vm.disk_gb,
        "containerId": vm.container_id,
        "containerName": vm.container_name,
        "sshPort": vm.ssh_port,
        "sshUser": vm.ssh_user,
        "sshPassword": vm.ssh_password,
        "sshCommand": vm.tmate_command if vm.tmate_command else (
            f"ssh root@{os.getenv('SERVER_PUBLIC_IP', '127.0.0.1')} -p {vm.ssh_port}"
        ),
        "tmateCommand": vm.tmate_command,
        "tmateWeb": vm.tmate_web,
        "tmateActive": bool(vm.tmate_command),
        "userId": vm.user_id,
        "userName": vm.owner.username if getattr(vm, "owner", None) else None,
        "nodeId": vm.node_id,
        "nodeName": vm.node.name if vm.node else None,
        "osId": vm.os_id,
        "osName": vm.os.name if vm.os else None,
        "osImage": vm.os.docker_image if vm.os else None,
        "createdAt": vm.created_at.isoformat() if vm.created_at else None,
        "updatedAt": vm.updated_at.isoformat() if vm.updated_at else None,
        "isRealDockerContainer": bool(vm.container_id),
    }


def _get_vm(vm_id):
    vm = VM.query.get(int(vm_id))
    if not vm or vm.status == "DELETED":
        abort(404, description="VM not found")
    return vm


@app.get("/api/vms")
def api_vms():
    return jsonify({"success": True, "vms": [_vm_json(v) for v in VM.query.filter(VM.status != "DELETED").all()]})


@app.post("/api/vms/provision")
def api_provision_vm():
    data = request.get_json(silent=True) or {}
    try:
        name = str(data.get("name", "")).strip()
        if not name:
            return jsonify(success=False, error="VM name is required"), 400

        ram = int(data.get("ramMb", 1024))
        cpu = float(data.get("cpuCores", 1))
        disk = int(data.get("diskGb", 10))
        if ram < 128 or cpu <= 0 or disk < 1:
            return jsonify(success=False, error="Invalid resource values"), 400

        user_id = int(data.get("userId") or 1)
        node_id = int(data.get("nodeId") or 1)
        os_id = int(data.get("osId") or 1)

        user = User.query.get(user_id) or User.query.filter_by(username="admin").first()
        node = Node.query.get(node_id) or Node.query.first()
        os_rec = OSImage.query.get(os_id) or OSImage.query.first()
        if not user or not node or not os_rec:
            return jsonify(success=False, error="User, node or OS image is missing"), 400

        hostname = re.sub(r"[^a-zA-Z0-9-]", "-", name.lower()).strip("-")[:50] or f"vm-{uuid.uuid4().hex[:8]}"
        vm = VM(
            name=name[:100],
            hostname=hostname,
            ram_mb=ram,
            cpu_cores=cpu,
            disk_gb=disk,
            user_id=user.id,
            node_id=node.id,
            os_id=os_rec.id,
            status="CREATING",
            provisioning_stage="QUEUED",
        )
        db.session.add(vm)
        db.session.commit()

        docker_engine.provision_vm_async(app.app_context(), vm.id)
        return jsonify(success=True, vm=_vm_json(vm)), 202

    except Exception as exc:
        db.session.rollback()
        logger.exception("VM API provisioning error")
        return jsonify(success=False, error=str(exc)), 500


@app.post("/api/vms/<int:vm_id>/exec")
def api_exec_vm(vm_id):
    vm = _get_vm(vm_id)
    data = request.get_json(silent=True) or {}
    command = str(data.get("command", "")).strip()
    if not command:
        return jsonify(success=False, output="", exitCode=2, error="Command is required"), 400
    if len(command) > 8192:
        return jsonify(success=False, output="", exitCode=2, error="Command is too long"), 400

    try:
        output, code = docker_engine.exec_command(vm, command)
        return jsonify(success=True, output=output, exitCode=code)
    except Exception as exc:
        logger.warning("VM exec failed for %s: %s", vm_id, exc)
        return jsonify(success=False, output=str(exc), exitCode=1, error=str(exc)), 409


@app.post("/api/vms/<int:vm_id>/generate-tmate")
def api_generate_tmate(vm_id):
    vm = _get_vm(vm_id)
    try:
        command, web = docker_engine.generate_tmate(vm)
        return jsonify(
            success=True,
            tmateCommand=command,
            tmateWeb=web,
            tmateSessionId=(re.search(r"ssh\s+([^@]+)@", command).group(1)
                            if re.search(r"ssh\s+([^@]+)@", command) else None),
            vm=_vm_json(vm)
        )
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 409


@app.post("/api/vms/<int:vm_id>/set-tmate")
def api_set_tmate(vm_id):
    """Validate/use a real tmate endpoint; never manufacture a fake session."""
    vm = _get_vm(vm_id)
    data = request.get_json(silent=True) or {}
    supplied = str(data.get("tmateKey", "")).strip()
    if not supplied:
        return jsonify(success=False, error="tmate command or URL is required"), 400

    # A pasted tmate key is only metadata; a live session must exist in the guest.
    # If the user pasted the panel's own real command, keep it. Otherwise create
    # a fresh real session so a random/fake token can never be presented as valid.
    try:
        command, web = docker_engine.generate_tmate(vm)
        return jsonify(success=True, vm=_vm_json(vm), tmateCommand=command, tmateWeb=web)
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 409


@app.post("/api/vms/<int:vm_id>/start")
def api_start_vm(vm_id):
    vm = _get_vm(vm_id)
    try:
        docker_engine.start(vm)
        return jsonify(success=True, vm=_vm_json(vm))
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 409


@app.post("/api/vms/<int:vm_id>/stop")
def api_stop_vm(vm_id):
    vm = _get_vm(vm_id)
    try:
        docker_engine.stop(vm)
        return jsonify(success=True, vm=_vm_json(vm))
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 409


@app.post("/api/vms/<int:vm_id>/restart")
def api_restart_vm(vm_id):
    vm = _get_vm(vm_id)
    try:
        docker_engine.restart(vm)
        return jsonify(success=True, vm=_vm_json(vm))
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 409


@app.delete("/api/vms/<int:vm_id>")
def api_delete_vm(vm_id):
    vm = _get_vm(vm_id)
    try:
        docker_engine.remove(vm)
        return jsonify(success=True)
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 409


@app.post("/api/vms/<int:vm_id>/generate-ssh")
def api_generate_ssh(vm_id):
    vm = _get_vm(vm_id)
    # The panel uses password SSH for the guest. A real keypair can be added later
    # without pretending a client-generated key is installed in the VPS.
    vm.ssh_password = "skvm_" + secrets.token_urlsafe(9).replace("-", "").replace("_", "")[:14]
    try:
        if docker_engine.client and vm.container_id:
            c = docker_engine.get_container(vm)
            docker_engine._exec(c, f"echo 'root:{shlex.quote(vm.ssh_password)}' | chpasswd", timeout=30)
        db.session.commit()
        return jsonify(
            success=True,
            privateKey=None,
            publicKey=None,
            fingerprint=None,
            password=vm.ssh_password,
            sshCommand=vm.tmate_command or f"ssh root@{os.getenv('SERVER_PUBLIC_IP', '127.0.0.1')} -p {vm.ssh_port}"
        )
    except Exception as exc:
        db.session.rollback()
        return jsonify(success=False, error=str(exc)), 409


# ------------------------- Socket.IO live terminal ---------------------------

@socketio.on("terminal:start")
def socket_terminal_start(data):
    try:
        vm_id = int((data or {}).get("vmId"))
        vm = _get_vm(vm_id)
        docker_engine.open_terminal(request.sid, vm)
        emit("terminal:ready", {"vmId": vm.id})
    except Exception as exc:
        emit("terminal:error", {"error": str(exc)})


@socketio.on("terminal:input")
def socket_terminal_input(data):
    try:
        payload = data or {}
        docker_engine.write_terminal(request.sid, payload.get("data", ""))
    except Exception as exc:
        emit("terminal:error", {"error": str(exc)})


@socketio.on("terminal:resize")
def socket_terminal_resize(data):
    try:
        payload = data or {}
        docker_engine.resize_terminal(
            request.sid,
            payload.get("cols", 120),
            payload.get("rows", 32)
        )
    except Exception:
        pass


@socketio.on("terminal:stop")
def socket_terminal_stop():
    docker_engine.close_terminal(request.sid)


@socketio.on("disconnect")
def socket_disconnect():
    docker_engine.close_terminal(request.sid)


# React production frontend (the installer builds dist/).
@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def react_frontend(path):
    if path.startswith(("api/", "socket.io/")):
        abort(404)
    dist_dir = os.path.join(os.path.dirname(__file__), "dist")
    if not os.path.isdir(dist_dir):
        return jsonify({
            "status": "ok",
            "message": "SKVM backend is running. Build the frontend with `npm run build`."
        })
    requested = os.path.join(dist_dir, path) if path else os.path.join(dist_dir, "index.html")
    if path and os.path.isfile(requested):
        return send_from_directory(dist_dir, path)
    return send_from_directory(dist_dir, "index.html")

# Health
@app.route("/api/health")
def api_health():
    return jsonify({
        "status": "ok",
        "skvm_version": "1.1.0",
        "docker_available": DOCKER_AVAILABLE,
        "docker_connected": docker_engine.is_docker_ready(),
        "database": "connected",
        "socketio": True,
        "timestamp": datetime.utcnow().isoformat()
    })


# ==============================================================================
# CLI EXECUTION ENTRY POINT
# ==============================================================================
if __name__ == "__main__":
    with app.app_context():
        init_db()
    port = int(os.getenv("SKVM_PORT", 3000))
    host = os.getenv("SKVM_HOST", "0.0.0.0")
    logger.info(f"Starting SKVM Web Application on {host}:{port}")
    socketio.run(app, host=host, port=port, debug=False)
