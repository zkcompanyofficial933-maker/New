#!/usr/bin/env python3
"""
SKVM REST API Blueprint & Node Agent Communication Engine
Provides authenticated endpoints for nodes, VMs, and cluster management
"""

import hmac
import hashlib
from datetime import datetime
from flask import Blueprint, request, jsonify
from werkzeug.security import check_password_hash

api_bp = Blueprint("api_v1", __name__, url_prefix="/api/v1")

# Dummy reference to pass to skvm or standalone import
def register_api_routes(app, db, models):
    Node = models["Node"]
    NodeToken = models["NodeToken"]
    VM = models["VM"]
    OSImage = models["OSImage"]
    ActivityLog = models["ActivityLog"]

    @app.route("/api/v1/node/register", methods=["POST"])
    def node_register():
        """Node agent initial handshake using registration token"""
        data = request.get_json() or {}
        token_str = data.get("token")
        hostname = data.get("hostname")
        node_name = data.get("name")

        if not token_str:
            return jsonify({"success": False, "error": "Node registration token is required"}), 400

        # Verify token against existing active tokens
        tokens = NodeToken.query.filter_by(is_revoked=False).all()
        matched_node = None
        for tok in tokens:
            if check_password_hash(tok.token_hash, token_str):
                matched_node = Node.query.get(tok.node_id)
                break

        if not matched_node:
            return jsonify({"success": False, "error": "Invalid or revoked node token"}), 401

        matched_node.status = "ONLINE"
        matched_node.last_heartbeat = datetime.utcnow()
        if hostname:
            matched_node.hostname = hostname
        db.session.commit()

        return jsonify({
            "success": True,
            "node_id": matched_node.id,
            "node_name": matched_node.name,
            "message": f"Successfully authenticated node '{matched_node.name}' with SKVM controller."
        })

    @app.route("/api/v1/node/heartbeat", methods=["POST"])
    def node_heartbeat():
        """Periodic metrics beacon sent by node.py"""
        data = request.get_json() or {}
        node_id = data.get("node_id")
        token_str = data.get("token")

        if not node_id or not token_str:
            return jsonify({"success": False, "error": "Node ID and token required"}), 400

        node = Node.query.get(node_id)
        if not node:
            return jsonify({"success": False, "error": "Node not found"}), 404

        tokens = NodeToken.query.filter_by(node_id=node.id, is_revoked=False).all()
        valid = any(check_password_hash(t.token_hash, token_str) for t in tokens)
        if not valid:
            return jsonify({"success": False, "error": "Unauthorized"}), 401

        node.status = "ONLINE"
        node.last_heartbeat = datetime.utcnow()
        if "docker_version" in data:
            node.docker_version = data["docker_version"]
        if "docker_status" in data:
            node.docker_status = data["docker_status"]
        db.session.commit()

        return jsonify({"success": True, "timestamp": datetime.utcnow().isoformat()})

    @app.route("/api/v1/vms", methods=["GET"])
    def api_get_vms():
        vms = VM.query.filter(VM.status != "DELETED").all()
        return jsonify({
            "success": True,
            "total": len(vms),
            "vms": [
                {
                    "id": v.id,
                    "uuid": v.uuid,
                    "name": v.name,
                    "status": v.status,
                    "ram_mb": v.ram_mb,
                    "cpu_cores": v.cpu_cores,
                    "disk_gb": v.disk_gb,
                    "node": v.node.name if v.node else "None",
                    "ip": v.ip_address,
                    "os": v.os.name if v.os else "Unknown"
                }
                for v in vms
            ]
        })

    @app.route("/api/v1/os", methods=["GET"])
    def api_get_os():
        images = OSImage.query.filter_by(is_enabled=True).all()
        return jsonify({
            "success": True,
            "images": [
                {
                    "id": img.id,
                    "name": img.name,
                    "docker_image": img.docker_image,
                    "family": img.family,
                    "version": img.version,
                    "min_ram_mb": img.min_ram_mb,
                    "min_disk_gb": img.min_disk_gb
                }
                for img in images
            ]
        })
