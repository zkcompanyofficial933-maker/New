#!/usr/bin/env python3
"""
SKVM Node Agent (node.py)
Run on external VPS hosts to join the SKVM cluster and report Docker stats & heartbeats.
"""

import os
import sys
import time
import socket
import logging
import requests

try:
    import psutil
except ImportError:
    psutil = None

try:
    import docker
except ImportError:
    docker = None

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] [SKVM-AGENT]: %(message)s")
logger = logging.getLogger("SKVM-Node")

def main():
    print("=" * 60)
    print("         SKVM CLUSTER NODE AGENT v1.0.0")
    print("=" * 60)

    api_url = os.getenv("SKVM_NODE_API_URL")
    if not api_url:
        api_url = input("Enter SKVM Controller URL (e.g. http://YOUR_SERVER_IP:3000): ").strip()
    
    token = os.getenv("SKVM_NODE_TOKEN")
    if not token:
        token = input("Enter Node Registration Token: ").strip()

    if not api_url or not token:
        logger.error("Both Controller URL and Registration Token are required to initialize node.")
        sys.exit(1)

    api_url = api_url.rstrip("/")

    # Detect Host Info
    hostname = socket.gethostname()
    try:
        host_ip = socket.gethostbyname(hostname)
    except Exception:
        host_ip = "127.0.0.1"

    # Check Docker Daemon
    docker_status = "NOT_INSTALLED"
    docker_version = "N/A"
    docker_client = None
    if docker:
        try:
            docker_client = docker.from_env()
            docker_client.ping()
            docker_status = "ACTIVE"
            docker_version = docker_client.version().get("Version", "Unknown")
            logger.info(f"Docker engine verified: version {docker_version}")
        except Exception as e:
            docker_status = f"ERROR: {str(e)[:30]}"
            logger.warning(f"Docker daemon not running: {e}")
    else:
        logger.warning("Python docker library not installed. Install via: pip install docker")

    # 1. Register with controller
    logger.info(f"Registering node '{hostname}' with SKVM controller at {api_url}...")
    reg_endpoint = f"{api_url}/api/v1/node/register"
    try:
        resp = requests.post(reg_endpoint, json={
            "token": token,
            "hostname": host_ip,
            "name": hostname,
            "docker_status": docker_status,
            "docker_version": docker_version
        }, timeout=10)
        
        data = resp.json()
        if resp.status_code != 200 or not data.get("success"):
            logger.error(f"Node registration failed: {data.get('error', 'Unknown response')}")
            sys.exit(1)

        node_id = data.get("node_id")
        node_name = data.get("node_name")
        logger.info(f"Authentication successful! Node ID: {node_id} ({node_name}) is now ONLINE.")
    except Exception as e:
        logger.error(f"Failed to connect to SKVM Controller at {reg_endpoint}: {e}")
        sys.exit(1)

    # 2. Enter Heartbeat Loop
    logger.info("Entering periodic heartbeat cycle (every 10s). Press Ctrl+C to terminate.")
    hb_endpoint = f"{api_url}/api/v1/node/heartbeat"
    while True:
        try:
            cpu_pct = psutil.cpu_percent() if psutil else 0.0
            ram_info = psutil.virtual_memory() if psutil else None
            disk_info = psutil.disk_usage("/") if psutil else None

            payload = {
                "node_id": node_id,
                "token": token,
                "docker_status": docker_status,
                "docker_version": docker_version,
                "cpu_percent": cpu_pct,
                "ram_used_mb": ram_info.used // (1024 * 1024) if ram_info else 0,
                "ram_total_mb": ram_info.total // (1024 * 1024) if ram_info else 0,
                "disk_used_gb": disk_info.used // (1024 * 1024 * 1024) if disk_info else 0,
                "disk_total_gb": disk_info.total // (1024 * 1024 * 1024) if disk_info else 0,
                "running_containers": len(docker_client.containers.list()) if docker_client else 0
            }

            hb_resp = requests.post(hb_endpoint, json=payload, timeout=5)
            if hb_resp.status_code == 200:
                logger.debug("Heartbeat beacon acknowledged by controller.")
            else:
                logger.warning(f"Heartbeat rejected: {hb_resp.text}")

        except Exception as e:
            logger.warning(f"Failed to transmit heartbeat: {e}")

        time.sleep(10)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Node agent stopped by user.")
        sys.exit(0)
