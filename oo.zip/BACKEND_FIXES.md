# SKVM backend repair

This build repairs the Docker/tmate backend without replacing the existing UI.

## Fixed
- VM provisioning now fails loudly when Docker is unavailable instead of silently creating a fake VM.
- Ubuntu/Debian containers get real OpenSSH + tmate installed.
- The tmate SSH command and web URL are read from the actual running tmate session; random/fake tokens are no longer generated.
- SSH is published through a real Docker host port.
- `/api/vms/<id>/exec` executes commands inside the real container.
- Socket.IO terminal events are available for a real interactive PTY:
  - `terminal:start`
  - `terminal:input`
  - `terminal:resize`
  - `terminal:stop`
  - `terminal:output`
  - `terminal:ready`
  - `terminal:error`
  - `terminal:closed`
- VM start/stop/restart/delete and tmate regeneration endpoints are implemented.
- Vite development proxy forwards `/api` and `/socket.io` to Flask.
- Production `start.sh` starts the Flask/Socket.IO backend instead of trying to run a missing `server.ts`.
- Removed the unused eventlet dependency because SKVM runs Socket.IO in threading mode.

## Important
The generated tmate command is a real command such as:

    ssh <real-session-token>@<real-tmate-host>

It is not a password/key that can be invented by the panel. The session must be created inside the VPS container first.

Direct SSH uses the published Docker host port shown by the VM API.

