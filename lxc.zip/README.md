# LXC VPS Discord Bot V4

This is a native-LXC rebuild based on the uploaded reference bot's Discord UI/database ideas, but the infrastructure layer is rewritten for the actual LXC environment tested on Rigbox.

## Important compatibility change

The reference bot uses the `lxc` command as an LXD client (`lxc init`, `lxc config set`, remote-node API). Your Rigbox workspace has native LXC 5.x (`lxc-create`, `lxc-start`, `lxc-attach`, etc.), so V4 uses native LXC directly.

## Fixed

- Removes unavailable Debian 12 package `lxc-utils`.
- Does not depend on `lxc-net.service`.
- Creates `lxcbr0` itself.
- Configures dnsmasq DHCP and NAT.
- Starts LXCFS without systemd/systemctl.
- Tests CAP_NET_ADMIN before proceeding.
- Tests a real loop-backed LXC container during install.
- Uses real RAM/CPU cgroup2 limits.
- Uses loop-backed root storage for an actual disk filesystem size.
- Installs SSH automatically inside each VPS and sets a root password.
- Preinstalls tmate when Ubuntu has the package; the tmate SSH string is generated only on request.
- SSHX is installed/run only when requested using `curl -sSf https://sshx.io/get | sh`.
- Start/stop/restart/reinstall/delete operate on real LXC containers.
- Native SQLite save helper checks the column/value count before INSERT, eliminating the 13/14 binding mismatch path.
- Interactive admin VPS creation includes an actual Discord user picker.
- Modern embed/button management UI based on the reference bot.

## Install

```bash
chmod +x install.sh
sudo ./install.sh
```

Set in `config.js`:

```js
DISCORD_TOKEN: "YOUR_BOT_TOKEN",
MAIN_ADMIN_ID: "YOUR_DISCORD_ID",
```

Start:

```bash
sudo ./run.sh
```

## VPS creation

Direct form:

```text
Screatevps <name> <ram> <disk> <cpu> <os> <@user>
```

Example:

```text
Screatevps test 2 10 2 ubuntu22 @User
```

Interactive user picker:

```text
Screatevps
```

The admin first selects the Discord user, then enters the VPS specification.

## User commands

```text
Smyvps
Smanage
Smanage <vps-id>
Snew ssh <vps-id>
Snew sshx <vps-id>
SPanel
Sping
Shelp
```

## Admin commands

```text
Screatevps ...
Sdeletevps <vps-id>
Smanagevps
Saddadmin @user
Saddpanel <url>
Screate embed <title> | <description>
Senable antinuke
Sdisable antinuke
Sban @user [reason]
Skick @user [reason]
Sreset CONFIRM
```

## Manage UI

```text
🔄 REINSTALL   ▶️ START   ⏸️ STOP
🔄 RESTART     🗑️ DELETE
🔑 SSH         🌐 SSHX    📊 STATS
```

`SSH` creates a fresh tmate SSH string. `SSHX` creates a fresh sshx link. They are not created automatically as an access tunnel during VPS provisioning.

## Network

Containers use private NAT networking on `10.0.3.0/24` with gateway `10.0.3.1`. This gives outbound Internet but does not assign a public IP directly to each container. tmate/sshx provide external access.
