import asyncio
import json
import logging
import os
import re
import secrets
import shlex
import sqlite3
import string
import subprocess
import time
from datetime import datetime, timedelta
from pathlib import Path

import discord
from discord.ext import commands

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "config.js"

OS_OPTIONS = {
    "ubuntu20": ("focal", "Ubuntu 20.04 LTS"),
    "ubuntu22": ("jammy", "Ubuntu 22.04 LTS"),
    "ubuntu24": ("noble", "Ubuntu 24.04 LTS"),
    "ubuntu26": ("resolute", "Ubuntu 26.04 LTS"),
}

# ----------------------------- Configuration -----------------------------
def read_config():
    raw = CONFIG_FILE.read_text(encoding="utf-8")

    def get_str(key, default=""):
        m = re.search(rf'\b{re.escape(key)}\s*:\s*"([^"]*)"', raw)
        return m.group(1) if m else default

    def get_int(key, default=0):
        m = re.search(rf'\b{re.escape(key)}\s*:\s*(\d+)', raw)
        return int(m.group(1)) if m else default

    return {
        "token": get_str("DISCORD_TOKEN"),
        "prefix": get_str("PREFIX", "S"),
        "main_admin": get_int("MAIN_ADMIN_ID", 0),
        "bot_name": get_str("BOT_NAME", "LXC VPS Bot"),
        "panel_url": get_str("PANEL_URL", ""),
        "storage": get_str("LXC_STORAGE", "/var/lib/lxc"),
        "bridge": get_str("LXC_BRIDGE", "lxcbr0"),
        "subnet": get_str("LXC_SUBNET", "10.0.3.0/24"),
        "gateway": get_str("LXC_GATEWAY", "10.0.3.1"),
        "dhcp_start": get_str("LXC_DHCP_START", "10.0.3.10"),
        "dhcp_end": get_str("LXC_DHCP_END", "10.0.3.250"),
        "expiry": get_int("VPS_DEFAULT_EXPIRY_DAYS", 30),
        "max_ram": get_int("VPS_MAX_RAM_GB", 128),
        "max_cpu": get_int("VPS_MAX_CPU", 64),
        "max_disk": get_int("VPS_MAX_DISK_GB", 5000),
        "disk_backing": get_str("DISK_BACKING", "loop"),
        "timeout": get_int("COMMAND_TIMEOUT", 600),
    }

CFG = read_config()
PREFIX = CFG["prefix"]
DB_FILE = BASE_DIR / "vps.db"
LOG_FILE = BASE_DIR / "bot.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[logging.FileHandler(LOG_FILE, encoding="utf-8"), logging.StreamHandler()],
)
logger = logging.getLogger("lxc-vps-bot")

# ----------------------------- SQLite -----------------------------
def get_db():
    conn = sqlite3.connect(DB_FILE, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=30000")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=FULL")
    return conn


def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS admins (
                user_id TEXT PRIMARY KEY,
                added_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS vps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id TEXT NOT NULL,
                owner_name TEXT NOT NULL,
                container_name TEXT UNIQUE NOT NULL,
                ram_gb INTEGER NOT NULL,
                disk_gb INTEGER NOT NULL,
                cpu INTEGER NOT NULL,
                os_key TEXT NOT NULL,
                os_label TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'stopped',
                ip TEXT,
                root_password TEXT,
                expires_at TEXT,
                shared_with TEXT NOT NULL DEFAULT '[]',
                created_at TEXT NOT NULL,
                last_error TEXT
            )
        """)
        if CFG["main_admin"]:
            conn.execute(
                "INSERT OR IGNORE INTO admins (user_id, added_at) VALUES (?, ?)",
                (str(CFG["main_admin"]), datetime.now().isoformat()),
            )
        conn.commit()


def is_admin_id(user_id):
    if int(user_id) == int(CFG["main_admin"]):
        return True
    with get_db() as conn:
        return conn.execute("SELECT 1 FROM admins WHERE user_id=?", (str(user_id),)).fetchone() is not None


def set_setting(key, value):
    with get_db() as conn:
        conn.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )


def get_setting(key, default=None):
    with get_db() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row[0] if row else default


def save_vps(row):
    """Single authoritative VPS INSERT. Columns and bindings are built together."""
    values = (
        str(row["owner_id"]),
        str(row["owner_name"]),
        str(row["container_name"]),
        int(row["ram_gb"]),
        int(row["disk_gb"]),
        int(row["cpu"]),
        str(row["os_key"]),
        str(row["os_label"]),
        str(row.get("status", "stopped")),
        row.get("ip"),
        row.get("root_password"),
        row.get("expires_at"),
        json.dumps(row.get("shared_with", [])),
        str(row["created_at"]),
        row.get("last_error"),
    )
    columns = (
        "owner_id", "owner_name", "container_name", "ram_gb", "disk_gb", "cpu",
        "os_key", "os_label", "status", "ip", "root_password", "expires_at",
        "shared_with", "created_at", "last_error"
    )
    placeholders = ",".join("?" for _ in columns)
    if len(values) != len(columns):
        raise RuntimeError(f"Database binding guard failed: {len(columns)} columns, {len(values)} values")
    sql = f"INSERT INTO vps ({','.join(columns)}) VALUES ({placeholders})"
    with get_db() as conn:
        cur = conn.execute(sql, values)
        conn.commit()
        return cur.lastrowid


def update_vps(vps_id, **fields):
    allowed = {"status", "ip", "root_password", "expires_at", "last_error", "os_key", "os_label", "created_at"}
    fields = {k: v for k, v in fields.items() if k in allowed}
    if not fields:
        return
    assignments = ", ".join(f"{k}=?" for k in fields)
    with get_db() as conn:
        conn.execute(f"UPDATE vps SET {assignments} WHERE id=?", (*fields.values(), int(vps_id)))
        conn.commit()


def get_vps(vps_id):
    with get_db() as conn:
        row = conn.execute("SELECT * FROM vps WHERE id=?", (int(vps_id),)).fetchone()
    if not row:
        return None
    d = dict(row)
    try:
        d["shared_with"] = json.loads(d.get("shared_with") or "[]")
    except Exception:
        d["shared_with"] = []
    return d


def get_user_vps(user_id):
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM vps WHERE owner_id=? ORDER BY id DESC", (str(user_id),)).fetchall()
    return [dict(r) for r in rows]


def get_all_vps():
    with get_db() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM vps ORDER BY id DESC").fetchall()]


def delete_vps_db(vps_id):
    with get_db() as conn:
        conn.execute("DELETE FROM vps WHERE id=?", (int(vps_id),))
        conn.commit()

# ----------------------------- LXC engine -----------------------------
def run_cmd(cmd, timeout=120, check=True, cwd=None):
    if isinstance(cmd, str):
        cmd = shlex.split(cmd)
    p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, cwd=cwd)
    if check and p.returncode != 0:
        detail = (p.stderr or p.stdout or "command failed").strip()
        raise RuntimeError(f"{' '.join(cmd)}\n{detail}")
    return p.stdout.strip()


def lxc_exists(name):
    p = subprocess.run(["lxc-info", "-n", name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return p.returncode == 0


def lxc_running(name):
    if not lxc_exists(name):
        return False
    out = run_cmd(["lxc-info", "-n", name], check=False)
    return bool(re.search(r"State:\s+RUNNING", out, re.I))


def lxc_destroy(name):
    if lxc_running(name):
        run_cmd(["lxc-stop", "-n", name], timeout=120, check=False)
        time.sleep(1)
    run_cmd(["lxc-destroy", "-n", name, "-f"], timeout=180, check=False)


def sanitize_name(value):
    value = re.sub(r"[^a-zA-Z0-9-]+", "-", value.lower()).strip("-")
    return value[:30] or "vps"


def next_vps_id():
    with get_db() as conn:
        row = conn.execute("SELECT COALESCE(MAX(id),0)+1 FROM vps").fetchone()
        return int(row[0])


def make_container_name(member):
    return f"{sanitize_name(member.display_name)}-vps-{next_vps_id()}"


def configure_container_file(name, ram_gb, cpu):
    config_path = Path(CFG["storage"]) / name / "config"
    if not config_path.exists():
        raise RuntimeError(f"LXC config not found: {config_path}")
    text = config_path.read_text(errors="replace")
    lines = [
        line for line in text.splitlines()
        if not line.startswith(("lxc.net.0.type", "lxc.net.0.flags", "lxc.net.0.link", "lxc.net.0.name", "lxc.cgroup2.memory.max", "lxc.cgroup2.cpu.max"))
    ]
    lines.extend([
        "lxc.net.0.type = veth",
        "lxc.net.0.flags = up",
        f"lxc.net.0.link = {CFG['bridge']}",
        "lxc.net.0.name = eth0",
        f"lxc.cgroup2.memory.max = {int(ram_gb)}G",
        f"lxc.cgroup2.cpu.max = {int(cpu) * 100000} 100000",
    ])
    hook = Path("/usr/share/lxcfs/lxcfs-mount-hook")
    if hook.exists() and not any(line.startswith("lxc.hook.mount") for line in lines):
        lines.append(f"lxc.hook.mount = {hook}")
    config_path.write_text("\n".join(lines) + "\n")


def create_container(name, os_key, ram_gb, disk_gb, cpu):
    if lxc_exists(name):
        raise RuntimeError(f"Container `{name}` already exists.")
    if os_key not in OS_OPTIONS:
        raise RuntimeError(f"Unsupported OS: {os_key}")
    release, _ = OS_OPTIONS[os_key]
    if CFG["disk_backing"].lower() != "loop":
        raise RuntimeError("This bot requires DISK_BACKING=loop so disk GB is a real filesystem size.")
    if subprocess.run(["losetup", "-f"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode != 0:
        raise RuntimeError("No usable loop device is available; a real disk limit cannot be created on this host.")
    try:
        run_cmd([
            "lxc-create", "-n", name, "-t", "download", "-B", "loop",
            "--fstype", "ext4", "--fssize", f"{int(disk_gb)}G",
            "--", "--dist", "ubuntu", "--release", release, "--arch", "amd64"
        ], timeout=CFG["timeout"])
        configure_container_file(name, ram_gb, cpu)
    except Exception:
        if lxc_exists(name):
            lxc_destroy(name)
        raise


def start_container(name):
    if lxc_running(name):
        return
    log = Path(f"/tmp/{name}-lxc-start.log")
    run_cmd(["lxc-start", "-n", name, "-d", "-l", "ERROR", "-o", str(log)], timeout=120)
    for _ in range(45):
        if lxc_running(name):
            return
        time.sleep(1)
    detail = log.read_text(errors="replace")[-6000:] if log.exists() else "No LXC start log was created."
    raise RuntimeError(f"Container did not reach RUNNING state.\n{detail}")


def stop_container(name):
    if lxc_running(name):
        run_cmd(["lxc-stop", "-n", name], timeout=120)


def attach(name, command, timeout=180, check=True):
    return run_cmd(["lxc-attach", "-n", name, "--", "bash", "-lc", command], timeout=timeout, check=check)


def get_ip(name):
    out = run_cmd(["lxc-info", "-n", name, "-iH"], timeout=30, check=False)
    ips = [x.strip() for x in out.splitlines() if re.match(r"^10\.0\.3\.\d+$", x.strip())]
    if ips:
        return ips[0]
    try:
        out = attach(name, "ip -4 -o addr show dev eth0 2>/dev/null || true", timeout=30, check=False)
        m = re.search(r"inet\s+(\d+\.\d+\.\d+\.\d+)/", out)
        if m:
            return m.group(1)
    except Exception:
        pass
    return None


def configure_guest_ssh(name, password):
    # Network first, then package installation. Retry for transient DHCP/DNS startup.
    script = r'''set -e
for n in 1 2 3 4 5; do
  if getent hosts archive.ubuntu.com >/dev/null 2>&1 || ping -c1 -W1 1.1.1.1 >/dev/null 2>&1; then break; fi
  sleep 2
done
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq openssh-server curl ca-certificates passwd iproute2
apt-get install -y -qq tmate || true
mkdir -p /run/sshd
cat >/etc/ssh/sshd_config <<'SSHEOF'
Port 22
AddressFamily any
ListenAddress 0.0.0.0
ListenAddress ::
PasswordAuthentication yes
PubkeyAuthentication yes
PermitRootLogin yes
PermitEmptyPasswords no
ChallengeResponseAuthentication no
UsePAM yes
MaxAuthTries 6
MaxSessions 20
PrintMotd no
PrintLastLog yes
TCPKeepAlive yes
Subsystem sftp /usr/lib/openssh/sftp-server
SSHEOF
printf 'root:%s\n' "$ROOT_PASS" | chpasswd
service ssh restart 2>/dev/null || service ssh start 2>/dev/null || /etc/init.d/ssh restart 2>/dev/null || true
'''
    # Pass password through an environment variable instead of shell interpolation.
    quoted = shlex.quote(password)
    command = f"ROOT_PASS={quoted}; export ROOT_PASS; {script}"
    attach(name, command, timeout=360)
    ip = None
    for _ in range(30):
        ip = get_ip(name)
        if ip:
            break
        time.sleep(2)
    return ip


def generate_password():
    chars = string.ascii_letters + string.digits + "!@#$%^&*-_"
    return "Vps@" + "".join(secrets.choice(chars) for _ in range(16))


def generate_tmate(name):
    if not lxc_running(name):
        start_container(name)
    # tmate was installed during provisioning when available; install on demand otherwise.
    attach(name, "command -v tmate >/dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq tmate)", timeout=240)
    attach(name, "rm -f /tmp/vpsbot-tmate.sock; tmate -S /tmp/vpsbot-tmate.sock new-session -d", timeout=60)
    attach(name, "tmate -S /tmp/vpsbot-tmate.sock wait tmate-ready", timeout=90)
    link = attach(name, "tmate -S /tmp/vpsbot-tmate.sock display -p '#{tmate_ssh}'", timeout=60).strip()
    if not link.startswith("ssh "):
        raise RuntimeError("tmate started but did not return an SSH string.")
    return link


def generate_sshx(name):
    if not lxc_running(name):
        start_container(name)
    attach(name, "command -v curl >/dev/null 2>&1 || (apt-get update -qq && apt-get install -y -qq curl ca-certificates)", timeout=180)
    install = "command -v sshx >/dev/null 2>&1 || (curl -sSf https://sshx.io/get | sh)"
    attach(name, install, timeout=240)
    command = r'''set -e
export PATH=/root/.local/bin:/usr/local/bin:$PATH
if [ -f /tmp/vpsbot-sshx.pid ]; then kill $(cat /tmp/vpsbot-sshx.pid) 2>/dev/null || true; fi
rm -f /tmp/vpsbot-sshx.log /tmp/vpsbot-sshx.pid
nohup sshx </dev/null >/tmp/vpsbot-sshx.log 2>&1 &
echo $! >/tmp/vpsbot-sshx.pid
for i in $(seq 1 30); do
  link=$(grep -oE 'https://sshx\.io/s/[A-Za-z0-9#?=&_.-]+' /tmp/vpsbot-sshx.log | head -1 || true)
  if [ -n "$link" ]; then echo "$link"; exit 0; fi
  sleep 1
done
cat /tmp/vpsbot-sshx.log 2>/dev/null || true
exit 1
'''
    out = attach(name, command, timeout=60)
    m = re.search(r"https://sshx\.io/s/[^\s\r\n`]+", out)
    if not m:
        raise RuntimeError(f"sshx did not return a link. Output:\n{out[-3000:]}")
    return m.group(0).rstrip(".,)")

# ----------------------------- Embed/UI helpers -----------------------------
COLOR_PRIMARY = 0x2C3E50
COLOR_SUCCESS = 0x27AE60
COLOR_ERROR = 0xE74C3C
COLOR_WARNING = 0xF39C12
COLOR_INFO = 0x3498DB


def truncate(text, limit=1024):
    text = str(text or "")
    return text if len(text) <= limit else text[:limit - 3] + "..."


def embed(title, description="", color=COLOR_PRIMARY):
    e = discord.Embed(title=f"🌟 {title}", description=truncate(description, 4096), color=color, timestamp=datetime.now())
    e.set_footer(text=f"{CFG['bot_name']} • LXC VPS Manager")
    return e


def field(e, name, value, inline=False):
    e.add_field(name=f"➤ {name}", value=truncate(value), inline=inline)


def is_owner_or_admin(interaction, row):
    return is_admin_id(interaction.user.id) or int(row["owner_id"]) == int(interaction.user.id) or str(interaction.user.id) in row.get("shared_with", [])


async def sync_status(row):
    name = row["container_name"]
    status = "running" if await asyncio.to_thread(lxc_running, name) else "stopped"
    ip = await asyncio.to_thread(get_ip, name) if status == "running" else None
    if status != row.get("status") or (ip and ip != row.get("ip")):
        update_vps(row["id"], status=status, ip=ip)
        row["status"] = status
        row["ip"] = ip
    return row

# ----------------------------- Discord bot -----------------------------
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)


def admin_check():
    async def predicate(ctx):
        if is_admin_id(ctx.author.id):
            return True
        raise commands.CheckFailure("Administrator permission required.")
    return commands.check(predicate)


class ManageView(discord.ui.View):
    def __init__(self, vps_id):
        super().__init__(timeout=900)
        self.vps_id = int(vps_id)

    async def get_row(self):
        row = get_vps(self.vps_id)
        if not row:
            raise RuntimeError("VPS no longer exists in the database.")
        return await sync_status(row)

    async def allowed(self, interaction):
        row = await self.get_row()
        return is_owner_or_admin(interaction, row), row

    @discord.ui.button(label="REINSTALL", emoji="🔄", style=discord.ButtonStyle.primary, row=0)
    async def reinstall(self, interaction, button):
        ok, row = await self.allowed(interaction)
        if not ok or (not is_admin_id(interaction.user.id) and int(row["owner_id"]) != int(interaction.user.id)):
            return await interaction.response.send_message("❌ Only the VPS owner/admin can reinstall.", ephemeral=True)
        await interaction.response.send_message(embed=embed("Select OS", f"Choose the new OS for VPS **#{self.vps_id}**."), view=ReinstallView(self.vps_id), ephemeral=True)

    @discord.ui.button(label="START", emoji="▶️", style=discord.ButtonStyle.success, row=0)
    async def start(self, interaction, button):
        ok, row = await self.allowed(interaction)
        if not ok:
            return await interaction.response.send_message("❌ Access denied.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            await asyncio.to_thread(start_container, row["container_name"])
            ip = await asyncio.to_thread(get_ip, row["container_name"])
            update_vps(self.vps_id, status="running", ip=ip, last_error=None)
            await interaction.followup.send(embed=embed("VPS Started", f"`{row['container_name']}` is running.\nIP: `{ip or 'pending'}`", COLOR_SUCCESS), ephemeral=True)
        except Exception as e:
            update_vps(self.vps_id, status="error", last_error=str(e))
            await interaction.followup.send(embed=embed("Start Failed", str(e), COLOR_ERROR), ephemeral=True)

    @discord.ui.button(label="STOP", emoji="⏸️", style=discord.ButtonStyle.secondary, row=0)
    async def stop(self, interaction, button):
        ok, row = await self.allowed(interaction)
        if not ok:
            return await interaction.response.send_message("❌ Access denied.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            await asyncio.to_thread(stop_container, row["container_name"])
            update_vps(self.vps_id, status="stopped", ip=None, last_error=None)
            await interaction.followup.send(embed=embed("VPS Stopped", f"`{row['container_name']}` is stopped.", COLOR_INFO), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=embed("Stop Failed", str(e), COLOR_ERROR), ephemeral=True)

    @discord.ui.button(label="RESTART", emoji="🔄", style=discord.ButtonStyle.primary, row=0)
    async def restart(self, interaction, button):
        ok, row = await self.allowed(interaction)
        if not ok:
            return await interaction.response.send_message("❌ Access denied.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            await asyncio.to_thread(stop_container, row["container_name"])
            await asyncio.to_thread(start_container, row["container_name"])
            ip = await asyncio.to_thread(get_ip, row["container_name"])
            update_vps(self.vps_id, status="running", ip=ip, last_error=None)
            await interaction.followup.send(embed=embed("VPS Restarted", f"`{row['container_name']}` is running again.\nIP: `{ip or 'pending'}`", COLOR_SUCCESS), ephemeral=True)
        except Exception as e:
            update_vps(self.vps_id, status="error", last_error=str(e))
            await interaction.followup.send(embed=embed("Restart Failed", str(e), COLOR_ERROR), ephemeral=True)

    @discord.ui.button(label="DELETE", emoji="🗑️", style=discord.ButtonStyle.danger, row=1)
    async def delete(self, interaction, button):
        ok, row = await self.allowed(interaction)
        if not ok:
            return await interaction.response.send_message("❌ Access denied.", ephemeral=True)
        if not is_admin_id(interaction.user.id) and int(row["owner_id"]) != int(interaction.user.id):
            return await interaction.response.send_message("❌ Only the VPS owner/admin can delete.", ephemeral=True)
        await interaction.response.send_message(embed=embed("Delete Confirmation", f"Delete **VPS #{self.vps_id}** and all its data?"), view=DeleteConfirmView(self.vps_id), ephemeral=True)

    @discord.ui.button(label="SSH", emoji="🔑", style=discord.ButtonStyle.success, row=1)
    async def ssh(self, interaction, button):
        await new_ssh(interaction, self.vps_id)

    @discord.ui.button(label="SSHX", emoji="🌐", style=discord.ButtonStyle.success, row=1)
    async def sshx(self, interaction, button):
        await new_sshx(interaction, self.vps_id)

    @discord.ui.button(label="STATS", emoji="📊", style=discord.ButtonStyle.secondary, row=1)
    async def stats(self, interaction, button):
        ok, row = await self.allowed(interaction)
        if not ok:
            return await interaction.response.send_message("❌ Access denied.", ephemeral=True)
        row = await self.get_row()
        details = (
            f"Status: **{row['status'].upper()}**\n"
            f"IP: `{row.get('ip') or 'N/A'}`\n"
            f"RAM: `{row['ram_gb']} GB`\n"
            f"CPU: `{row['cpu']}`\n"
            f"Disk: `{row['disk_gb']} GB` (loop-backed)\n"
            f"OS: `{row['os_label']}`"
        )
        await interaction.response.send_message(embed=embed(f"VPS #{self.vps_id} Stats", details, COLOR_INFO), ephemeral=True)


class VPSSelectView(discord.ui.View):
    def __init__(self, ctx):
        super().__init__(timeout=300)
        self.ctx = ctx
        rows = get_user_vps(ctx.author.id)
        if not rows:
            self.add_item(discord.ui.Select(placeholder="No VPS found", disabled=True))
            return
        options = []
        for row in rows[:25]:
            options.append(discord.SelectOption(label=f"#{row['id']} {row['container_name'][:80]}", value=str(row['id']), description=f"{row['ram_gb']}GB RAM • {row['disk_gb']}GB Disk"))
        self.select = discord.ui.Select(placeholder="Select a VPS to manage", options=options)
        self.select.callback = self.select_vps
        self.add_item(self.select)

    async def select_vps(self, interaction):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("❌ This selector belongs to another user.", ephemeral=True)
        vps_id = int(self.select.values[0])
        row = get_vps(vps_id)
        if not row:
            return await interaction.response.send_message("❌ VPS not found.", ephemeral=True)
        row = await sync_status(row)
        e = vps_embed(row)
        await interaction.response.send_message(embed=e, view=ManageView(vps_id), ephemeral=True)


class CreateUserView(discord.ui.View):
    def __init__(self, ctx):
        super().__init__(timeout=300)
        self.ctx = ctx
        select = discord.ui.UserSelect(placeholder="Select the Discord user who will receive the VPS", min_values=1, max_values=1)
        select.callback = self.selected
        self.add_item(select)

    async def selected(self, interaction):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("❌ Only the admin who started the command can choose the user.", ephemeral=True)
        await interaction.response.send_modal(CreateSpecModal(interaction.data["resolved"]["users"] if False else interaction.user))
        # Modal cannot receive the selected object after Discord serializes it; store it on the view instead.


class CreateSpecModal(discord.ui.Modal, title="Create LXC VPS"):
    def __init__(self, selected_user):
        super().__init__(timeout=300)
        self.selected_user = selected_user
        self.vps_name = discord.ui.TextInput(label="VPS name", placeholder="my-vps", required=True, max_length=30)
        self.ram = discord.ui.TextInput(label="RAM (GB)", placeholder="2", required=True, max_length=4)
        self.disk = discord.ui.TextInput(label="Disk (GB)", placeholder="10", required=True, max_length=6)
        self.cpu = discord.ui.TextInput(label="CPU cores", placeholder="2", required=True, max_length=3)
        self.os = discord.ui.TextInput(label="OS: ubuntu20 / ubuntu22 / ubuntu24 / ubuntu26", placeholder="ubuntu22", required=True, max_length=10)
        for item in (self.vps_name, self.ram, self.disk, self.cpu, self.os):
            self.add_item(item)

    async def on_submit(self, interaction):
        # This modal path is reserved for direct construction; see create_user_select below.
        await interaction.response.send_message("❌ User selection expired. Run `Screatevps` again.", ephemeral=True)


class RealCreateUserView(discord.ui.View):
    def __init__(self, ctx):
        super().__init__(timeout=300)
        self.ctx = ctx
        select = discord.ui.UserSelect(placeholder="Select the Discord user who will receive this VPS", min_values=1, max_values=1)
        select.callback = self.selected
        self.add_item(select)

    async def selected(self, interaction):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("❌ Only the admin who started this can select the user.", ephemeral=True)
        selected_user_id = int(interaction.data["values"][0])
        try:
            member = self.ctx.guild.get_member(selected_user_id) if self.ctx.guild else None
            member = member or await self.ctx.bot.fetch_user(selected_user_id)
        except Exception:
            return await interaction.response.send_message("❌ Could not resolve the selected user.", ephemeral=True)
        await interaction.response.send_modal(SpecModalForUser(member))


class SpecModalForUser(discord.ui.Modal, title="VPS Specification"):
    name = discord.ui.TextInput(label="VPS name", placeholder="my-vps", max_length=30)
    ram = discord.ui.TextInput(label="RAM in GB", placeholder="2")
    disk = discord.ui.TextInput(label="Disk in GB", placeholder="10")
    cpu = discord.ui.TextInput(label="CPU cores", placeholder="2")
    os = discord.ui.TextInput(label="OS", placeholder="ubuntu22")

    def __init__(self, member):
        super().__init__(timeout=300)
        self.member = member

    async def on_submit(self, interaction):
        try:
            await interaction.response.defer(ephemeral=True)
            await provision_and_report(interaction, self.member, str(self.name.value), int(self.ram.value), int(self.disk.value), int(self.cpu.value), str(self.os.value).lower(), CFG["expiry"])
        except ValueError:
            await interaction.followup.send("❌ RAM, disk and CPU must be numbers.", ephemeral=True)


class OSView(discord.ui.View):
    def __init__(self, vps_id):
        super().__init__(timeout=300)
        self.vps_id = int(vps_id)
        select = discord.ui.Select(
            placeholder="Choose OS",
            options=[discord.SelectOption(label=label, value=key) for key, (_, label) in OS_OPTIONS.items()],
        )
        select.callback = self.choose
        self.add_item(select)

    async def choose(self, interaction):
        row = get_vps(self.vps_id)
        if not row or not (is_admin_id(interaction.user.id) or int(row["owner_id"]) == int(interaction.user.id)):
            return await interaction.response.send_message("❌ Access denied.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            await reinstall_vps(self.vps_id, select_os=interaction.data["values"][0])
            await interaction.followup.send(embed=embed("Reinstall Complete", f"VPS #{self.vps_id} is back online with {OS_OPTIONS[interaction.data['values'][0]][1]}.", COLOR_SUCCESS), ephemeral=True)
        except Exception as e:
            update_vps(self.vps_id, status="error", last_error=str(e))
            await interaction.followup.send(embed=embed("Reinstall Failed", str(e), COLOR_ERROR), ephemeral=True)


class ReinstallView(OSView):
    pass


class DeleteConfirmView(discord.ui.View):
    def __init__(self, vps_id):
        super().__init__(timeout=90)
        self.vps_id = int(vps_id)

    @discord.ui.button(label="DELETE", emoji="🗑️", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction, button):
        row = get_vps(self.vps_id)
        if not row or not (is_admin_id(interaction.user.id) or int(row["owner_id"]) == int(interaction.user.id)):
            return await interaction.response.send_message("❌ Access denied.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            await asyncio.to_thread(lxc_destroy, row["container_name"])
            delete_vps_db(self.vps_id)
            await interaction.followup.send(embed=embed("VPS Deleted", f"VPS #{self.vps_id} was completely removed.", COLOR_SUCCESS), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=embed("Delete Failed", str(e), COLOR_ERROR), ephemeral=True)

    @discord.ui.button(label="CANCEL", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, button):
        await interaction.response.edit_message(content="Cancelled.", embed=None, view=None)


def vps_embed(row):
    status = row.get("status", "stopped").upper()
    color = COLOR_SUCCESS if status == "RUNNING" else COLOR_WARNING if status == "ERROR" else COLOR_INFO
    e = embed(f"VPS #{row['id']} • {row['container_name']}", "Manage your real LXC VPS below.", color)
    field(e, "Owner", f"<@{row['owner_id']}>", True)
    field(e, "Status", f"{status}", True)
    field(e, "IP", f"`{row.get('ip') or 'N/A'}`", True)
    field(e, "Resources", f"RAM: `{row['ram_gb']}GB`\nCPU: `{row['cpu']}`\nDisk: `{row['disk_gb']}GB`", True)
    field(e, "OS", row["os_label"], True)
    if row.get("expires_at"):
        field(e, "Expires", f"`{row['expires_at']}`", True)
    if row.get("last_error"):
        field(e, "Last Error", f"`{row['last_error'][:900]}`", False)
    return e


async def provision_and_report(ctx_or_interaction, member, name, ram, disk, cpu, os_key, expiry_days):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{2,29}", name or ""):
        raise ValueError("VPS name must be 3-30 characters using letters, numbers, `_` or `-`.")
    if os_key not in OS_OPTIONS:
        raise ValueError("OS must be ubuntu20, ubuntu22, ubuntu24, or ubuntu26.")
    if not (1 <= ram <= CFG["max_ram"] and 1 <= disk <= CFG["max_disk"] and 1 <= cpu <= CFG["max_cpu"]):
        raise ValueError(f"Limits: RAM 1-{CFG['max_ram']}GB, CPU 1-{CFG['max_cpu']}, Disk 1-{CFG['max_disk']}GB.")
    container_name = f"{sanitize_name(name)}-{next_vps_id()}"
    password = generate_password()
    await send_progress(ctx_or_interaction, f"⏳ Creating `{container_name}` for {member.mention}...")
    created = False
    try:
        await asyncio.to_thread(create_container, container_name, os_key, ram, disk, cpu)
        created = True
        await asyncio.to_thread(start_container, container_name)
        ip = await asyncio.to_thread(configure_guest_ssh, container_name, password)
        if not ip:
            raise RuntimeError("Container is running but did not receive an IPv4 address. Check lxcbr0/dnsmasq/NAT.")
        release, label = OS_OPTIONS[os_key]
        row = {
            "owner_id": str(member.id),
            "owner_name": str(member),
            "container_name": container_name,
            "ram_gb": ram,
            "disk_gb": disk,
            "cpu": cpu,
            "os_key": os_key,
            "os_label": label,
            "status": "running",
            "ip": ip,
            "root_password": password,
            "expires_at": (datetime.now() + timedelta(days=int(expiry_days))).isoformat(timespec="seconds"),
            "shared_with": [],
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "last_error": None,
        }
        vps_id = save_vps(row)
        e = embed("✅ VPS Created Successfully", f"Your LXC VPS for {member.mention} is ready.", COLOR_SUCCESS)
        field(e, "VPS ID", f"`#{vps_id}`", True)
        field(e, "Container", f"`{container_name}`", True)
        field(e, "IP", f"`{ip}`", True)
        field(e, "Resources", f"RAM `{ram}GB` • CPU `{cpu}` • Disk `{disk}GB`", False)
        field(e, "OS", label, True)
        field(e, "Login", "`root`", True)
        field(e, "Password", f"||{password}||", True)
        field(e, "Access", f"Use `{PREFIX}manage {vps_id}` then **SSH** for tmate or **SSHX** for sshx.", False)
        target = ctx_or_interaction.followup if isinstance(ctx_or_interaction, discord.Interaction) else ctx_or_interaction
        if isinstance(ctx_or_interaction, discord.Interaction):
            await ctx_or_interaction.followup.send(embed=e, ephemeral=True, view=ManageView(vps_id))
        else:
            await ctx_or_interaction.send(embed=e, view=ManageView(vps_id))
        try:
            await member.send(embed=e)
        except discord.Forbidden:
            pass
    except Exception as exc:
        if created:
            await asyncio.to_thread(lxc_destroy, container_name)
        raise


async def send_progress(ctx_or_interaction, content):
    if isinstance(ctx_or_interaction, discord.Interaction):
        await ctx_or_interaction.followup.send(content, ephemeral=True)
    else:
        await ctx_or_interaction.send(content)


async def check_access(user_id, vps_id):
    row = get_vps(vps_id)
    if not row:
        return None
    row["shared_with"] = json.loads(row.get("shared_with") or "[]") if isinstance(row.get("shared_with"), str) else row.get("shared_with", [])
    if is_admin_id(user_id) or int(row["owner_id"]) == int(user_id) or str(user_id) in row["shared_with"]:
        return row
    return None


async def new_ssh(interaction_or_ctx, vps_id):
    user_id = interaction_or_ctx.user.id if isinstance(interaction_or_ctx, discord.Interaction) else interaction_or_ctx.author.id
    row = await check_access(user_id, vps_id)
    if not row:
        if isinstance(interaction_or_ctx, discord.Interaction):
            return await interaction_or_ctx.response.send_message("❌ VPS not found or access denied.", ephemeral=True)
        return await interaction_or_ctx.send("❌ VPS not found or access denied.")
    if isinstance(interaction_or_ctx, discord.Interaction):
        await interaction_or_ctx.response.defer(ephemeral=True)
    else:
        msg = await interaction_or_ctx.send("⏳ Generating a new tmate SSH string...")
    try:
        link = await asyncio.to_thread(generate_tmate, row["container_name"])
        user = await bot.fetch_user(int(row["owner_id"]))
        try:
            await user.send(f"🔑 **VPS #{vps_id} tmate SSH**\n```text\n{link}\n```")
            message = "✅ A new tmate SSH string was sent to your DMs."
        except discord.Forbidden:
            message = f"✅ tmate SSH:\n```text\n{link}\n```"
        if isinstance(interaction_or_ctx, discord.Interaction):
            await interaction_or_ctx.followup.send(message, ephemeral=True)
        else:
            await msg.edit(content=message)
    except Exception as e:
        message = f"❌ tmate failed: `{str(e)[:1800]}`"
        if isinstance(interaction_or_ctx, discord.Interaction):
            await interaction_or_ctx.followup.send(message, ephemeral=True)
        else:
            await msg.edit(content=message)


async def new_sshx(interaction_or_ctx, vps_id):
    user_id = interaction_or_ctx.user.id if isinstance(interaction_or_ctx, discord.Interaction) else interaction_or_ctx.author.id
    row = await check_access(user_id, vps_id)
    if not row:
        if isinstance(interaction_or_ctx, discord.Interaction):
            return await interaction_or_ctx.response.send_message("❌ VPS not found or access denied.", ephemeral=True)
        return await interaction_or_ctx.send("❌ VPS not found or access denied.")
    if isinstance(interaction_or_ctx, discord.Interaction):
        await interaction_or_ctx.response.defer(ephemeral=True)
    else:
        msg = await interaction_or_ctx.send("⏳ Generating a new SSHX link...")
    try:
        link = await asyncio.to_thread(generate_sshx, row["container_name"])
        user = await bot.fetch_user(int(row["owner_id"]))
        try:
            await user.send(f"🌐 **VPS #{vps_id} SSHX**\n```text\n{link}\n```")
            message = "✅ A new SSHX link was sent to your DMs."
        except discord.Forbidden:
            message = f"✅ SSHX link:\n```text\n{link}\n```"
        if isinstance(interaction_or_ctx, discord.Interaction):
            await interaction_or_ctx.followup.send(message, ephemeral=True)
        else:
            await msg.edit(content=message)
    except Exception as e:
        message = f"❌ SSHX failed: `{str(e)[:1800]}`"
        if isinstance(interaction_or_ctx, discord.Interaction):
            await interaction_or_ctx.followup.send(message, ephemeral=True)
        else:
            await msg.edit(content=message)


def reinstall_vps_sync(vps_id, os_key):
    row = get_vps(vps_id)
    if not row:
        raise RuntimeError("VPS not found")
    old_name = row["container_name"]
    new_password = generate_password()
    lxc_destroy(old_name)
    create_container(old_name, os_key, row["ram_gb"], row["disk_gb"], row["cpu"])
    start_container(old_name)
    ip = configure_guest_ssh(old_name, new_password)
    if not ip:
        raise RuntimeError("Reinstalled container has no IPv4 address.")
    _, label = OS_OPTIONS[os_key]
    update_vps(vps_id, os_key=os_key, os_label=label, status="running", ip=ip, root_password=new_password, created_at=datetime.now().isoformat(timespec="seconds"), last_error=None)


async def reinstall_vps(vps_id, select_os):
    await asyncio.to_thread(reinstall_vps_sync, vps_id, select_os)

# ----------------------------- Commands -----------------------------
@bot.event
async def on_ready():
    logger.info("Logged in as %s | prefix=%s", bot.user, PREFIX)
    logger.info("Native LXC VPS bot ready")


@bot.command(name="help")
async def help_command(ctx):
    e = embed("LXC VPS Bot Help", "Real LXC management from Discord.", COLOR_INFO)
    field(e, "User", f"`{PREFIX}myvps`\n`{PREFIX}manage [id]`\n`{PREFIX}new ssh <id>`\n`{PREFIX}new sshx <id>`\n`{PREFIX}panel`\n`{PREFIX}ping", False)
    field(e, "Admin", f"`{PREFIX}createvps <name> <ram> <disk> <cpu> <os> <@user>`\n`{PREFIX}createvps` → interactive user picker\n`{PREFIX}deletevps <id>`\n`{PREFIX}managevps`\n`{PREFIX}addadmin @user`\n`{PREFIX}addpanel <url>`\n`{PREFIX}create embed <title> | <description>`\n`{PREFIX}enable antinuke` / `{PREFIX}disable antinuke`\n`{PREFIX}ban @user [reason]`\n`{PREFIX}kick @user [reason]`\n`{PREFIX}reset CONFIRM`", False)
    field(e, "OS", "`ubuntu20` • `ubuntu22` • `ubuntu24` • `ubuntu26`", False)
    field(e, "Manage Buttons", "🔄 Reinstall • ▶️ Start • ⏸️ Stop • 🔄 Restart • 🗑️ Delete • 🔑 SSH/tmate • 🌐 SSHX • 📊 Stats", False)
    await ctx.send(embed=e)


@bot.command(name="ping")
async def ping(ctx):
    await ctx.send(embed=embed("🏓 Pong", f"Latency: `{round(bot.latency * 1000)}ms`", COLOR_SUCCESS))


@bot.command(name="myvps")
async def myvps(ctx):
    rows = get_user_vps(ctx.author.id)
    if not rows:
        return await ctx.send(embed=embed("No VPS", "You do not have a VPS yet.", COLOR_WARNING))
    parts = []
    for row in rows:
        status = "RUNNING" if lxc_running(row["container_name"]) else "STOPPED"
        parts.append(f"**#{row['id']}** `{row['container_name']}` — {status}\nRAM `{row['ram_gb']}GB` • CPU `{row['cpu']}` • Disk `{row['disk_gb']}GB` • {row['os_label']}")
    e = embed("🖥️ My VPS", "Your VPS overview", COLOR_INFO)
    field(e, "Deployments", "\n\n".join(parts), False)
    field(e, "Quick Access", f"Use `{PREFIX}manage` to open the management panel.", False)
    await ctx.send(embed=e)


@bot.command(name="manage")
async def manage(ctx, vps_id: int = None):
    if vps_id is None:
        return await ctx.send(embed=embed("Manage VPS", "Select one of your VPSes."), view=VPSSelectView(ctx))
    row = await check_access(ctx.author.id, vps_id)
    if not row:
        return await ctx.send("❌ VPS not found or access denied.")
    row = await sync_status(row)
    await ctx.send(embed=vps_embed(row), view=ManageView(vps_id))


@bot.command(name="new")
async def new_group(ctx):
    await ctx.send(f"Use `{PREFIX}new ssh <vps-id>` or `{PREFIX}new sshx <vps-id>`." )

@new_group.command(name="ssh")
async def new_ssh_cmd(ctx, vps_id: int):
    await new_ssh(ctx, vps_id)

@new_group.command(name="sshx")
async def new_sshx_cmd(ctx, vps_id: int):
    await new_sshx(ctx, vps_id)


@bot.command(name="createvps", aliases=["create-vps"])
@admin_check()
async def createvps(ctx, name: str = None, ram: int = None, disk: int = None, cpu: int = None, os_key: str = None, user: discord.Member = None):
    if name is None:
        return await ctx.send(embed=embed("Create VPS", "First select the Discord user who should receive the VPS, then enter the VPS specification.", COLOR_INFO), view=RealCreateUserView(ctx))
    if None in (ram, disk, cpu, os_key, user):
        return await ctx.send(f"Usage: `{PREFIX}createvps <name> <ram> <disk> <cpu> <os> <@user>`\nExample: `{PREFIX}createvps test 2 10 2 ubuntu22 @User`")
    try:
        await provision_and_report(ctx, user, name, ram, disk, cpu, os_key.lower(), CFG["expiry"])
    except Exception as e:
        await ctx.send(embed=embed("❌ VPS creation failed", str(e), COLOR_ERROR))


@bot.command(name="deletevps")
@admin_check()
async def deletevps(ctx, vps_id: int):
    row = get_vps(vps_id)
    if not row:
        return await ctx.send("❌ VPS not found.")
    try:
        await asyncio.to_thread(lxc_destroy, row["container_name"])
        delete_vps_db(vps_id)
        await ctx.send(embed=embed("VPS Deleted", f"Deleted VPS #{vps_id} and container `{row['container_name']}`.", COLOR_SUCCESS))
    except Exception as e:
        await ctx.send(embed=embed("Delete Failed", str(e), COLOR_ERROR))


@bot.command(name="managevps")
@admin_check()
async def managevps(ctx):
    rows = get_all_vps()
    if not rows:
        return await ctx.send(embed=embed("VPS Inventory", "No VPS have been created yet.", COLOR_INFO))
    text = []
    for row in rows:
        real = "RUNNING" if lxc_running(row["container_name"]) else "STOPPED"
        text.append(f"**#{row['id']}** `{row['container_name']}` → <@{row['owner_id']}> → {real} → {row['ram_gb']}GB/{row['cpu']}CPU/{row['disk_gb']}GB")
    e = embed("🛡️ VPS Management", "All tracked VPSes with real LXC state.", COLOR_INFO)
    field(e, "Deployments", "\n".join(text), False)
    await ctx.send(embed=e)


@bot.command(name="addadmin")
@admin_check()
async def addadmin(ctx, user: discord.Member):
    with get_db() as conn:
        conn.execute("INSERT OR IGNORE INTO admins(user_id, added_at) VALUES(?, ?)", (str(user.id), datetime.now().isoformat()))
        conn.commit()
    await ctx.send(embed=embed("Admin Added", f"{user.mention} can now use admin commands.", COLOR_SUCCESS))


@bot.command(name="addpanel")
@admin_check()
async def addpanel(ctx, *, url: str):
    url = url.strip()
    if not re.match(r"^https?://", url):
        return await ctx.send("❌ Panel URL must start with http:// or https://")
    set_setting("panel_url", url)
    await ctx.send(embed=embed("Panel Updated", f"Panel URL set to `{url}`.", COLOR_SUCCESS))


@bot.command(name="panel")
async def panel(ctx):
    url = get_setting("panel_url", CFG["panel_url"])
    if not url:
        return await ctx.send(embed=embed("Panel", "No panel URL has been configured.", COLOR_WARNING))
    await ctx.send(embed=embed("Control Panel", f"[Open panel]({url})", COLOR_INFO))


@bot.group(name="create", invoke_without_command=True)
@admin_check()
async def create_group(ctx):
    await ctx.send(f"Use `{PREFIX}create embed <title> | <description>` for an embed or `{PREFIX}createvps` for VPS creation.")

@create_group.command(name="embed")
@admin_check()
async def create_embed_cmd(ctx, *, payload: str):
    if "|" in payload:
        title, desc = payload.split("|", 1)
    else:
        title, desc = payload, ""
    await ctx.send(embed=embed(title.strip(), desc.strip(), COLOR_PRIMARY))


@bot.group(name="enable", invoke_without_command=True)
@admin_check()
async def enable_group(ctx):
    await ctx.send("Use `Senable antinuke`.")

@enable_group.command(name="antinuke")
@admin_check()
async def enable_antinuke(ctx):
    set_setting("antinuke", "1")
    await ctx.send(embed=embed("Anti-Nuke Enabled", "The setting is now enabled.", COLOR_SUCCESS))


@bot.group(name="disable", invoke_without_command=True)
@admin_check()
async def disable_group(ctx):
    await ctx.send("Use `Sdisable antinuke`.")

@disable_group.command(name="antinuke")
@admin_check()
async def disable_antinuke(ctx):
    set_setting("antinuke", "0")
    await ctx.send(embed=embed("Anti-Nuke Disabled", "The setting is now disabled.", COLOR_WARNING))


@bot.command(name="ban")
@admin_check()
async def ban(ctx, user: discord.Member, *, reason: str = "No reason provided"):
    await user.ban(reason=reason)
    await ctx.send(embed=embed("User Banned", f"{user.mention}\nReason: `{reason}`", COLOR_SUCCESS))


@bot.command(name="kick")
@admin_check()
async def kick(ctx, user: discord.Member, *, reason: str = "No reason provided"):
    await user.kick(reason=reason)
    await ctx.send(embed=embed("User Kicked", f"{user.mention}\nReason: `{reason}`", COLOR_SUCCESS))


@bot.command(name="reset")
@admin_check()
async def reset(ctx, confirm: str = ""):
    if confirm.upper() != "CONFIRM":
        return await ctx.send(f"⚠️ This removes every tracked VPS and container. Run `{PREFIX}reset CONFIRM`.")
    rows = get_all_vps()
    for row in rows:
        await asyncio.to_thread(lxc_destroy, row["container_name"])
    with get_db() as conn:
        conn.execute("DELETE FROM vps")
        conn.commit()
    await ctx.send(embed=embed("System Reset Complete", f"Removed `{len(rows)}` VPS records and containers.", COLOR_SUCCESS))


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.CheckFailure):
        return await ctx.send(embed=embed("Access Denied", str(error) or "Administrator permission required.", COLOR_ERROR))
    if isinstance(error, commands.MissingRequiredArgument):
        return await ctx.send(embed=embed("Missing Argument", f"Use `{PREFIX}help` for command usage.", COLOR_WARNING))
    if isinstance(error, commands.BadArgument):
        return await ctx.send(embed=embed("Invalid Argument", f"Use `{PREFIX}help` for command usage.", COLOR_WARNING))
    logger.exception("Unhandled command error", exc_info=error)
    await ctx.send(embed=embed("System Error", f"`{str(error)[:1500]}`", COLOR_ERROR))


if __name__ == "__main__":
    init_db()
    if not CFG["token"] or CFG["token"].startswith("PUT_YOUR"):
        raise SystemExit("Set DISCORD_TOKEN in config.js before starting the bot.")
    bot.run(CFG["token"])
