#!/usr/bin/env bash
set -Eeuo pipefail

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'
step=0
log(){ echo -e "${GREEN}[STEP $step]${NC} $*"; }
warn(){ echo -e "${YELLOW}[WARN]${NC} $*"; }
die(){ echo -e "${RED}[ERROR]${NC} $*"; exit 1; }
[[ $EUID -eq 0 ]] || die "Run: sudo ./install.sh"
export DEBIAN_FRONTEND=noninteractive
BASE_DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"

step=1; log "Updating Debian package index"
apt-get update

step=2; log "Installing host utilities"
apt-get install -y --no-install-recommends \
  ca-certificates curl wget gnupg2 lsb-release iproute2 iptables \
  dnsmasq-base bridge-utils util-linux fuse3 procps psmisc \
  python3 python3-venv python3-pip python3-dev build-essential

step=3; log "Installing native LXC + LXCFS packages"
# Debian 12 does NOT provide lxc-utils; do not install it.
apt-get install -y lxc lxc-templates lxcfs uidmap

for c in lxc-create lxc-start lxc-stop lxc-info lxc-destroy lxc-attach losetup dnsmasq; do
  command -v "$c" >/dev/null 2>&1 || die "Required command missing after install: $c"
done

step=4; log "Checking that this workspace can create Linux bridges"
ip link add __vpsbot_cap_test type dummy 2>/tmp/vpsbot-cap.err || { cat /tmp/vpsbot-cap.err; die "Rigbox did not grant CAP_NET_ADMIN. Real LXC networking cannot work in this workspace."; }
ip link del __vpsbot_cap_test

step=5; log "Writing native LXC default network configuration"
mkdir -p /etc/lxc /etc/lxc/dnsmasq.d /var/lib/lxc
cat >/etc/lxc/default.conf <<'EOF'
lxc.net.0.type = veth
lxc.net.0.flags = up
lxc.net.0.link = lxcbr0
lxc.net.0.name = eth0
EOF

step=6; log "Creating lxcbr0"
if ! ip link show lxcbr0 >/dev/null 2>&1; then ip link add lxcbr0 type bridge; fi
ip addr replace 10.0.3.1/24 dev lxcbr0
ip link set lxcbr0 up

step=7; log "Configuring DHCP and DNS on lxcbr0"
cat >/etc/dnsmasq.d/vpsbot-lxc.conf <<'EOF'
interface=lxcbr0
bind-interfaces
dhcp-range=10.0.3.10,10.0.3.250,255.255.255.0,12h
dhcp-option=3,10.0.3.1
dhcp-option=6,1.1.1.1,8.8.8.8
no-resolv
server=1.1.1.1
server=8.8.8.8
EOF
if [[ -f /run/vpsbot-dnsmasq.pid ]]; then kill "$(cat /run/vpsbot-dnsmasq.pid)" 2>/dev/null || true; fi
rm -f /run/vpsbot-dnsmasq.pid
dnsmasq --conf-file=/etc/dnsmasq.d/vpsbot-lxc.conf --pid-file=/run/vpsbot-dnsmasq.pid

step=8; log "Configuring IPv4 forwarding and NAT"
sysctl -w net.ipv4.ip_forward=1 >/dev/null
cat >/etc/sysctl.d/99-vpsbot.conf <<'EOF'
net.ipv4.ip_forward=1
EOF
OUT_IFACE="$(ip route show default | awk '/default/ {print $5; exit}')"
[[ -n "$OUT_IFACE" ]] || die "Could not find the host default route interface."
iptables -t nat -C POSTROUTING -s 10.0.3.0/24 ! -o lxcbr0 -j MASQUERADE 2>/dev/null || iptables -t nat -A POSTROUTING -s 10.0.3.0/24 ! -o lxcbr0 -j MASQUERADE
iptables -C FORWARD -i lxcbr0 -j ACCEPT 2>/dev/null || iptables -A FORWARD -i lxcbr0 -j ACCEPT
iptables -C FORWARD -o lxcbr0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || iptables -A FORWARD -o lxcbr0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT

after_network='/usr/local/sbin/vpsbot-host-network.sh'
cat >"$after_network" <<EOF
#!/usr/bin/env bash
set -e
ip link show lxcbr0 >/dev/null 2>&1 || ip link add lxcbr0 type bridge
ip addr replace 10.0.3.1/24 dev lxcbr0
ip link set lxcbr0 up
sysctl -w net.ipv4.ip_forward=1 >/dev/null
iptables -t nat -C POSTROUTING -s 10.0.3.0/24 ! -o lxcbr0 -j MASQUERADE 2>/dev/null || iptables -t nat -A POSTROUTING -s 10.0.3.0/24 ! -o lxcbr0 -j MASQUERADE
iptables -C FORWARD -i lxcbr0 -j ACCEPT 2>/dev/null || iptables -A FORWARD -i lxcbr0 -j ACCEPT
iptables -C FORWARD -o lxcbr0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || iptables -A FORWARD -o lxcbr0 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
if [[ -f /run/vpsbot-dnsmasq.pid ]] && kill -0 "$(cat /run/vpsbot-dnsmasq.pid)" 2>/dev/null; then :; else dnsmasq --conf-file=/etc/dnsmasq.d/vpsbot-lxc.conf --pid-file=/run/vpsbot-dnsmasq.pid; fi
EOF
chmod +x "$after_network"

step=9; log "Starting LXCFS without systemd/systemctl"
mkdir -p /var/lib/lxcfs
if ! mountpoint -q /var/lib/lxcfs; then
  nohup lxcfs -f /var/lib/lxcfs >/var/log/vpsbot-lxcfs.log 2>&1 &
  sleep 2
fi
if ! mountpoint -q /var/lib/lxcfs; then warn "LXCFS mount could not be confirmed; cgroup limits still work, but proc resource virtualization may be unavailable."; else echo "LXCFS mounted at /var/lib/lxcfs"; fi

step=10; log "Creating Python virtual environment and installing bot modules"
cd "$BASE_DIR"
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt

step=11; log "Checking bot syntax and database"
.venv/bin/python -m py_compile bot.py
.venv/bin/python - <<'PY'
import bot
bot.init_db()
print("Bot import: OK")
print("SQLite initialization: OK")
PY

step=12; log "Testing real LXC creation with loop-backed disk"
TEST_NAME="vpsbot-install-test"
lxc-destroy -n "$TEST_NAME" -f 2>/dev/null || true
lxc-create -n "$TEST_NAME" -t download -B loop --fstype ext4 --fssize 1G -- --dist ubuntu --release jammy --arch amd64
python3 - <<'PY'
from pathlib import Path
p=Path('/var/lib/lxc/vpsbot-install-test/config')
assert p.exists(), 'test container config missing'
t=p.read_text()
assert 'lxc.net.0.link = lxcbr0' in t, 'test container did not inherit lxcbr0'
print('LXC create + loop disk + lxcbr0 config: OK')
PY
lxc-destroy -n "$TEST_NAME" -f

step=13; log "Installing reboot helpers without systemd"
cat >/usr/local/sbin/vpsbot-startup.sh <<EOF
#!/usr/bin/env bash
set -e
$after_network
if ! mountpoint -q /var/lib/lxcfs; then nohup lxcfs -f /var/lib/lxcfs >/var/log/vpsbot-lxcfs.log 2>&1 & fi
EOF
chmod +x /usr/local/sbin/vpsbot-startup.sh
apt-get install -y cron >/dev/null
service cron start >/dev/null 2>&1 || true
( crontab -l 2>/dev/null | grep -v '/usr/local/sbin/vpsbot-startup.sh' || true; echo '@reboot /usr/local/sbin/vpsbot-startup.sh >/var/log/vpsbot-startup.log 2>&1' ) | crontab -

step=14; log "Writing run helper"
cat >"$BASE_DIR/run.sh" <<EOF
#!/usr/bin/env bash
set -e
cd "$BASE_DIR"
exec .venv/bin/python bot.py
EOF
chmod +x "$BASE_DIR/run.sh"

cat >"$BASE_DIR/test-lxc.sh" <<'EOF'
#!/usr/bin/env bash
set -e
NAME="vpsbot-runtime-test"
lxc-destroy -n "$NAME" -f 2>/dev/null || true
lxc-create -n "$NAME" -t download -B loop --fstype ext4 --fssize 1G -- --dist ubuntu --release jammy --arch amd64
lxc-start -n "$NAME" -d
for i in $(seq 1 30); do lxc-info -n "$NAME" | grep -q 'State:.*RUNNING' && break; sleep 1; done
lxc-info -n "$NAME"
echo '--- IP ---'
lxc-info -n "$NAME" -iH || true
echo '--- eth0 ---'
lxc-attach -n "$NAME" -- ip -4 addr show eth0 || true
lxc-stop -n "$NAME" || true
lxc-destroy -n "$NAME" -f || true
EOF
chmod +x "$BASE_DIR/test-lxc.sh"

step=15; log "Installation finished"
echo
printf '%s\n' '============================================================'
printf '%s\n' ' LXC VPS Discord Bot V4 — native LXC build'
printf '%s\n' '============================================================'
echo '1. Edit config.js and set DISCORD_TOKEN + MAIN_ADMIN_ID.'
echo '2. Start: sudo ./run.sh'
echo '3. Test LXC: sudo ./test-lxc.sh'
echo '4. No lxc-utils package and no lxc-net.service dependency.'
echo '5. Disk backing is loop, so requested disk size is a real filesystem size.'
