#!/usr/bin/env bash
#
# SKVM universal installer.
#
# Works on:
#   - A real VPS / bare-metal Linux host with systemd      -> installs+starts a systemd service
#   - GitHub Codespaces / CodeSandbox / Gitpod / any devcontainer without systemd
#                                                             -> starts SKVM directly in the background
#
# This revision specifically hardens the GitHub Codespaces path against the
# two failure modes reported in practice:
#   1. "errors running python" -- usually pip failing to build a C extension
#      (argon2-cffi / psutil / cffi) because build-essential/python3-dev/
#      libffi-dev weren't installed. This script now installs those first
#      and never silently swallows a pip failure.
#   2. "it's running but the port doesn't open" -- the old script only
#      checked whether the process PID was still alive 2 seconds after
#      launch, which is not the same as the HTTP server actually accepting
#      connections. This script now polls the real /api/health endpoint in
#      a retry loop and only reports success once it gets a real response,
#      and prints the actual Codespaces forwarded URL when it can detect one.
#
# Re-run-safe: never deletes the database, VMs/containers, or settings.
#
set -uo pipefail

INSTALL_DIR_DEFAULT="/opt/skvm"
SERVICE_NAME="skvm"
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log()  { echo -e "\033[1;34m[skvm]\033[0m $*"; }
warn() { echo -e "\033[1;33m[skvm][warn]\033[0m $*"; }
err()  { echo -e "\033[1;31m[skvm][error]\033[0m $*" >&2; }
die()  { err "$*"; exit 1; }

# --------------------------------------------------------- environment kind
ENVIRONMENT_KIND="vps_or_local_linux"
HAS_SYSTEMD="no"
if command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; then
  HAS_SYSTEMD="yes"
fi

if [[ -n "${CODESPACES:-}" ]]; then
  ENVIRONMENT_KIND="github_codespaces"
elif [[ -n "${CODESANDBOX_SSE:-}" || -f /.codesandbox || -n "${CODESANDBOX_HOST:-}" ]]; then
  ENVIRONMENT_KIND="codesandbox"
elif [[ -n "${GITPOD_WORKSPACE_ID:-}" ]]; then
  ENVIRONMENT_KIND="gitpod"
elif [[ "${HAS_SYSTEMD}" == "no" && -f /.dockerenv ]]; then
  ENVIRONMENT_KIND="restricted_container"
fi

IS_ROOT="no"
[[ "${EUID}" -eq 0 ]] && IS_ROOT="yes"

log "Environment: ${ENVIRONMENT_KIND}  |  systemd available: ${HAS_SYSTEMD}  |  running as root: ${IS_ROOT}"

if [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" && "${IS_ROOT}" == "no" ]]; then
  die "On a VPS/bare-metal host, please run this as root: sudo ./install.sh"
fi

# ----------------------------------------------------- choose install path
if [[ "${HAS_SYSTEMD}" == "yes" && "${IS_ROOT}" == "yes" ]]; then
  INSTALL_DIR="${INSTALL_DIR_DEFAULT}"
  USE_SYSTEMD="yes"
else
  INSTALL_DIR="${REPO_DIR}"
  USE_SYSTEMD="no"
  if [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" ]]; then
    warn "systemd not detected -- falling back to a direct background process instead of a service."
  fi
fi
log "Install directory: ${INSTALL_DIR}"
log "Startup method: $( [[ ${USE_SYSTEMD} == yes ]] && echo 'systemd service' || echo 'background process (nohup)' )"

DISTRO="unknown"
if [[ -f /etc/os-release ]]; then
  . /etc/os-release
  DISTRO="${ID:-unknown} ${VERSION_ID:-}"
fi
log "Distro: ${DISTRO}  Arch: $(uname -m)"

# ------------------------------------------------------------- dependencies
# build-essential/python3-dev/libffi-dev/pkg-config are required whenever pip
# has to compile a C extension (argon2-cffi's cffi backend, psutil) and no
# prebuilt wheel exists for the installed Python version -- this is the #1
# real-world cause of "errors running python" on a fresh Codespace/VPS.
if [[ "${IS_ROOT}" == "yes" ]]; then
  APT_PKGS="python3 python3-venv python3-pip python3-dev build-essential libffi-dev pkg-config curl git ca-certificates gnupg lsb-release"
  log "Installing system dependencies (apt-get)..."
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -y || warn "apt-get update failed; continuing with what's already installed."
    apt-get install -y ${APT_PKGS} || warn "Some base packages failed to install -- see errors above."
    if [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" ]]; then
      apt-get install -y lxc lxc-templates bridge-utils uidmap || \
        warn "LXC packages failed to install; the LXC engine won't be usable until you install them manually."
    fi
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y python3 python3-pip python3-devel gcc gcc-c++ libffi-devel curl git || \
      warn "Some base packages failed to install."
    [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" ]] && \
      (dnf install -y lxc lxc-templates bridge-utils || warn "LXC packages failed to install.")
  else
    warn "Unknown package manager -- ensure python3, python3-dev/venv, build-essential and libffi-dev are installed."
  fi
else
  log "Not running as root -- skipping system package installation (normal for GitHub Codespaces)."
  log "Codespaces images ship build-essential/python3-dev already; if pip still fails to"
  log "compile a package below, run: sudo apt-get install -y python3-dev build-essential libffi-dev"
  if ! command -v python3 >/dev/null 2>&1; then
    die "python3 was not found. Switch to a Python-capable devcontainer/image, then re-run this script."
  fi
fi

PY_VERSION="$(python3 -c 'import sys; print("%d.%d.%d" % sys.version_info[:3])' 2>/dev/null || echo unknown)"
log "System python3 version: ${PY_VERSION}"

# ------------------------------------------------------------------- Docker
if [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" && "${IS_ROOT}" == "yes" ]]; then
  if ! command -v docker >/dev/null 2>&1; then
    log "Docker not found. Attempting install via get.docker.com ..."
    if curl -fsSL https://get.docker.com -o /tmp/get-docker.sh 2>/dev/null; then
      sh /tmp/get-docker.sh || warn "Docker installation script failed; install Docker manually if you plan to use the Docker engine."
      systemctl enable --now docker 2>/dev/null || true
    else
      warn "Could not reach get.docker.com (no network egress?). Skipping Docker auto-install."
    fi
  else
    log "Docker already installed."
  fi
fi

DOCKER_OK="no"; command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1 && DOCKER_OK="yes"
LXC_OK="no"; command -v lxc-create >/dev/null 2>&1 && LXC_OK="yes"
if [[ "${DOCKER_OK}" == "no" && "${LXC_OK}" == "no" ]]; then
  warn "Neither a reachable Docker daemon nor LXC tooling was detected on this host."
  warn "SKVM will install and run, but real VM provisioning will fail with a real,"
  warn "honest error until this runs somewhere with Docker or LXC available."
fi
if [[ "${ENVIRONMENT_KIND}" == "github_codespaces" ]]; then
  log "GitHub Codespaces detected: Docker-in-Codespaces is usually available (Docker_OK=${DOCKER_OK})"
  log "but real container provisioning is still restricted in many Codespaces images -- expect"
  log "VM creation to surface an honest provisioning error there rather than a fake success."
fi

# ---------------------------------------------------------------- app files
if [[ "${INSTALL_DIR}" != "${REPO_DIR}" ]]; then
  log "Copying application into ${INSTALL_DIR} ..."
  mkdir -p "${INSTALL_DIR}" || die "Could not create ${INSTALL_DIR}"
  if command -v rsync >/dev/null 2>&1; then
    rsync -a --exclude 'data' --exclude 'logs' --exclude '.git' --exclude 'venv' \
      "${REPO_DIR}/" "${INSTALL_DIR}/" || die "Failed to copy application files."
  else
    cp -r "${REPO_DIR}/." "${INSTALL_DIR}/" || die "Failed to copy application files."
  fi
fi

mkdir -p "${INSTALL_DIR}/data" "${INSTALL_DIR}/logs" || die "Could not create data/logs directories."
chmod 0777 "${INSTALL_DIR}/data" "${INSTALL_DIR}/logs" 2>/dev/null || true
cd "${INSTALL_DIR}" || die "Could not cd into ${INSTALL_DIR}"

# --------------------------------------------------------------- virtualenv
if [[ ! -d venv ]]; then
  log "Creating Python virtual environment..."
  python3 -m venv venv || die "python3 -m venv failed. Install python3-venv (apt-get install -y python3-venv) and re-run."
fi

log "Virtualenv python: $(./venv/bin/python -c 'import sys; print(sys.version.split()[0])' 2>/dev/null || echo unknown)"

log "Upgrading pip/setuptools/wheel..."
./venv/bin/pip install --upgrade pip setuptools wheel || warn "Could not upgrade pip; continuing with existing version."

log "Installing Python dependencies (this can take a minute)..."
if ! ./venv/bin/pip install -r requirements.txt; then
  err "pip failed to install requirements.txt. Full pip output is above -- common fixes:"
  err "  - missing build tools: sudo apt-get install -y python3-dev build-essential libffi-dev"
  err "  - a package has no wheel for python ${PY_VERSION} yet: try a different python3"
  err "    (e.g. 'sudo apt-get install -y python3.12 python3.12-venv' then re-run with that binary)"
  die "Dependency installation failed -- see errors above."
fi

# ------------------------------------------------------------- environment
# DATABASE_URL is always pinned to an ABSOLUTE path. A relative
# "sqlite:///data/skvm.db" only works if the process is later launched from
# exactly this directory -- not guaranteed across shells / sudo su / restarts.
ABS_DB_PATH="${INSTALL_DIR}/data/skvm.db"
ABS_DATABASE_URL="sqlite:///${ABS_DB_PATH}"

if [[ ! -f .env ]]; then
  log "Creating .env from .env.example (first install)..."
  cp .env.example .env
  SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
  sed -i.bak "s#SECRET_KEY=.*#SECRET_KEY=${SECRET}#" .env && rm -f .env.bak
  if grep -qE '^[#[:space:]]*DATABASE_URL=' .env; then
    sed -i.bak "s#^[#[:space:]]*DATABASE_URL=.*#DATABASE_URL=${ABS_DATABASE_URL}#" .env && rm -f .env.bak
  else
    echo "DATABASE_URL=${ABS_DATABASE_URL}" >> .env
  fi
else
  log ".env already exists -- leaving your existing configuration untouched, except:"
  if grep -qE '^DATABASE_URL=sqlite:///[^/]' .env 2>/dev/null; then
    warn "  .env has a relative sqlite:// DATABASE_URL -- rewriting it to an absolute path"
    warn "  (${ABS_DATABASE_URL}) to prevent 'unable to open database file' errors."
    sed -i.bak "s#^DATABASE_URL=sqlite:///.*#DATABASE_URL=${ABS_DATABASE_URL}#" .env && rm -f .env.bak
  fi
fi

if [[ ! -w "${INSTALL_DIR}/data" ]]; then
  die "The data directory (${INSTALL_DIR}/data) is not writable by the current user. Fix with: chmod 0777 '${INSTALL_DIR}/data'"
fi

# ------------------------------------------------------- database & bootstrap
log "Initializing database (idempotent; existing data is preserved)..."
DB_INIT_LOG="$(mktemp)"
if ! ./venv/bin/python -c "
from app import create_app
app = create_app()
print('Database ready. Local node synced. Bootstrap admin ensured if none existed.')
" > "${DB_INIT_LOG}" 2>&1; then
  err "Database initialization failed. Full traceback:"
  cat "${DB_INIT_LOG}" >&2
  err ""
  err "Common causes:"
  err "  - the 'data' directory isn't writable by this user"
  err "  - a dependency listed above failed to install correctly"
  err "  - current DATABASE_URL:"
  grep '^DATABASE_URL=' .env || true
  rm -f "${DB_INIT_LOG}"
  die "Aborting -- fix the error above and re-run ./install.sh (it is safe to re-run)."
fi
cat "${DB_INIT_LOG}"
rm -f "${DB_INIT_LOG}"

PORT=$(grep -E '^APP_PORT=' .env | cut -d= -f2)
PORT="${PORT:-8000}"

# ------------------------------------------------------------------- start
if [[ "${USE_SYSTEMD}" == "yes" ]]; then
  log "Installing systemd service..."
  sed "s#/opt/skvm#${INSTALL_DIR}#g" "${INSTALL_DIR}/scripts/skvm.service" > /etc/systemd/system/${SERVICE_NAME}.service
  systemctl daemon-reload
  systemctl enable ${SERVICE_NAME}
  systemctl restart ${SERVICE_NAME}
else
  log "Starting SKVM as a background process (no systemd available/permitted here)..."
  if [[ -f skvm.pid ]] && kill -0 "$(cat skvm.pid)" 2>/dev/null; then
    log "An existing SKVM process is already running (pid $(cat skvm.pid)); restarting it."
    kill "$(cat skvm.pid)" 2>/dev/null || true
    sleep 1
  fi
  nohup ./venv/bin/python run.py > logs/skvm.out 2>&1 &
  echo $! > skvm.pid
fi

# ------------------------------------------------- real HTTP health-check
# Checking that the PID is alive is NOT the same as the port actually being
# open -- Flask can be mid-import, or bound to the wrong interface, or the
# process can die a few seconds after this check runs. Poll the real
# /api/health endpoint instead, and only declare success once it responds.
log "Waiting for SKVM to actually accept connections on port ${PORT}..."
HEALTH_OK="no"
for i in $(seq 1 30); do
  if curl -fsS -m 2 "http://127.0.0.1:${PORT}/api/health" >/tmp/skvm_health.json 2>/dev/null; then
    HEALTH_OK="yes"
    break
  fi
  if [[ "${USE_SYSTEMD}" == "no" ]] && ! kill -0 "$(cat skvm.pid 2>/dev/null)" 2>/dev/null; then
    err "The SKVM process exited before it started serving. Last 60 log lines:"
    tail -n 60 logs/skvm.out 2>/dev/null || true
    die "Startup failed -- see traceback above. Fix it and re-run ./install.sh."
  fi
  sleep 1
done

if [[ "${HEALTH_OK}" == "yes" ]]; then
  log "Confirmed: SKVM is responding on port ${PORT}."
  log "Health check response: $(cat /tmp/skvm_health.json 2>/dev/null)"
else
  err "SKVM did not start responding on port ${PORT} within 30 seconds."
  if [[ "${USE_SYSTEMD}" == "yes" ]]; then
    err "Recent service logs:"
    journalctl -u ${SERVICE_NAME} --no-pager -n 60 || true
  else
    err "Last 60 log lines:"
    tail -n 60 logs/skvm.out 2>/dev/null || true
  fi
  die "Installation did not finish cleanly -- fix the error above, then re-run ./install.sh (safe to re-run)."
fi

# ----------------------------------------------------------------- summary
echo
log "SKVM installation complete."

if [[ "${ENVIRONMENT_KIND}" == "vps_or_local_linux" ]]; then
  IP=$(hostname -I 2>/dev/null | awk '{print $1}')
  IP="${IP:-127.0.0.1}"
  log "Panel URL: http://${IP}:${PORT}"
elif [[ "${ENVIRONMENT_KIND}" == "github_codespaces" ]]; then
  log "Local URL inside the Codespace: http://localhost:${PORT}"
  if [[ -n "${CODESPACE_NAME:-}" && -n "${GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN:-}" ]]; then
    FORWARDED_URL="https://${CODESPACE_NAME}-${PORT}.${GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN}"
    log "Public forwarded URL: ${FORWARDED_URL}"
    log "If that link doesn't load: open the 'PORTS' tab, find port ${PORT}, right-click it ->"
    log "'Port Visibility' -> 'Public', then click the globe/open-in-browser icon next to it."
  else
    log "Open the 'PORTS' tab in this Codespace, find port ${PORT} (add it manually if it's not"
    log "listed yet), set its visibility to Public if needed, then click the globe icon to open it."
  fi
elif [[ "${ENVIRONMENT_KIND}" == "codesandbox" ]]; then
  log "Local URL: http://localhost:${PORT} -- open the 'Ports' tab in CodeSandbox and click port ${PORT}."
else
  log "Local URL: http://localhost:${PORT}"
fi

log "Database file: ${ABS_DB_PATH}"
log "Bootstrap admin login: admin@gmail.com / admin123  (change this immediately after first login -- it is never shown anywhere in the panel UI itself)"
if [[ "${DOCKER_OK}" == "no" && "${LXC_OK}" == "no" ]]; then
  warn "Reminder: real container provisioning is not available in this environment."
fi
echo
if [[ "${USE_SYSTEMD}" == "yes" ]]; then
  log "Manage the service with: systemctl {status|start|stop|restart} ${SERVICE_NAME}"
  log "Logs: journalctl -u ${SERVICE_NAME} -f"
else
  log "Manage the process manually (no systemctl here):"
  log "  Stop:    kill \$(cat ${INSTALL_DIR}/skvm.pid)"
  log "  Restart: ./install.sh   (re-run-safe, keeps existing data)"
  log "  Logs:    tail -f ${INSTALL_DIR}/logs/skvm.out"
fi
