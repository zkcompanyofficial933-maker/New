import pytest

from app.services.validation import (
    ValidationError,
    validate_vm_name,
    validate_username,
    validate_os_key,
    validate_engine,
    validate_int_range,
)


def test_validate_vm_name_accepts_valid():
    assert validate_vm_name("my-ubuntu-1") == "my-ubuntu-1"


def test_validate_vm_name_rejects_shell_metacharacters():
    with pytest.raises(ValidationError):
        validate_vm_name("evil; rm -rf /")


def test_validate_vm_name_rejects_path_traversal():
    with pytest.raises(ValidationError):
        validate_vm_name("../../etc/passwd")


def test_validate_username_rejects_root():
    with pytest.raises(ValidationError):
        validate_username("root")


def test_validate_os_key_rejects_unsupported_os():
    with pytest.raises(ValidationError):
        validate_os_key("centos-7")


def test_validate_os_key_accepts_all_four_supported():
    for key in ("ubuntu-20.04", "ubuntu-22.04", "debian-11", "debian-12"):
        assert validate_os_key(key) == key


def test_validate_engine_rejects_unknown():
    with pytest.raises(ValidationError):
        validate_engine("kvm")


def test_validate_int_range_rejects_non_integer():
    with pytest.raises(ValidationError):
        validate_int_range("not-a-number", 1, 10, "CPU")


def test_validate_int_range_enforces_bounds():
    with pytest.raises(ValidationError):
        validate_int_range(9999, 1, 64, "CPU")
