import os
import tempfile

import pytest


@pytest.fixture
def app():
    os.environ["DATABASE_URL"] = "sqlite:///:memory:"
    os.environ["BOOTSTRAP_ADMIN_EMAIL"] = "admin@gmail.com"
    os.environ["BOOTSTRAP_ADMIN_PASSWORD"] = "admin123"
    os.environ["SECRET_KEY"] = "test-secret"

    from app import create_app
    from app.config import Config

    class TestConfig(Config):
        SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
        TESTING = True
        WTF_CSRF_ENABLED = False
        RATELIMIT_ENABLED = False

    flask_app = create_app(TestConfig)
    flask_app.config.update(TESTING=True)
    yield flask_app


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def admin_client(client):
    client.post("/auth/login", data={"email": "admin@gmail.com", "password": "admin123"})
    return client


@pytest.fixture
def regular_user(app):
    with app.app_context():
        from app.extensions import db
        from app.models import User
        from app.auth.utils import hash_password

        user = User(email="user@example.com", password_hash=hash_password("password123"), role="user")
        db.session.add(user)
        db.session.commit()
        return user.id


@pytest.fixture
def user_client(client, regular_user):
    client.post("/auth/login", data={"email": "user@example.com", "password": "password123"})
    return client
