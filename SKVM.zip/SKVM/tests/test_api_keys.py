def test_create_and_use_api_key(app, admin_client):
    resp = admin_client.post("/api/api-keys", json={"name": "ci"})
    assert resp.status_code == 201
    raw_key = resp.get_json()["key"]
    assert raw_key.startswith("skvm_")

    with app.app_context():
        from app.models import ApiKey

        stored = ApiKey.query.filter_by(name="ci").first()
        assert stored.key_hash != raw_key  # never stored in plaintext

    fresh_client = app.test_client()
    resp = fresh_client.get("/api/vms", headers={"Authorization": f"Bearer {raw_key}"})
    assert resp.status_code == 200


def test_revoked_key_denied(app, admin_client):
    resp = admin_client.post("/api/api-keys", json={"name": "temp"})
    key_id = resp.get_json()["id"]
    raw_key = resp.get_json()["key"]

    admin_client.delete(f"/api/api-keys/{key_id}")

    fresh_client = app.test_client()
    resp = fresh_client.get("/api/vms", headers={"Authorization": f"Bearer {raw_key}"})
    assert resp.status_code == 401


def test_regular_user_cannot_create_api_key(user_client):
    resp = user_client.post("/api/api-keys", json={"name": "x"})
    assert resp.status_code == 403
