"""
Validates a requested VM's CPU/RAM/disk against the REAL local node capacity
(spec section 6). The UI may present the node as "unlimited" for product
simplicity, but this module is what actually protects the host from
over-commitment.
"""
from app.models import LocalNode
from app.services.system import allocated_resources_for_running_vms

# Small safety margin left for the host OS itself.
RESERVED_RAM_MB = 512
RESERVED_DISK_GB = 5


class ResourceError(Exception):
    pass


def validate_request(cpu: int, ram_mb: int, disk_gb: int):
    node = LocalNode.query.first()
    if node is None:
        raise ResourceError("Local node has not been initialized yet.")

    if cpu < 1 or cpu > max(node.cpu_total, 1):
        raise ResourceError(
            f"Requested {cpu} vCPU(s) exceeds host capacity ({node.cpu_total} vCPUs available)."
        )
    if ram_mb < 128:
        raise ResourceError("RAM must be at least 128 MB.")
    if disk_gb < 1:
        raise ResourceError("Disk must be at least 1 GB.")

    used = allocated_resources_for_running_vms()

    available_ram = node.ram_total_mb - RESERVED_RAM_MB - used["ram_mb"]
    if ram_mb > available_ram:
        raise ResourceError(
            f"Requested {ram_mb} MB RAM exceeds available host capacity "
            f"({max(available_ram, 0)} MB free of {node.ram_total_mb} MB total)."
        )

    available_disk = node.disk_total_gb - RESERVED_DISK_GB - used["disk_gb"]
    if disk_gb > available_disk:
        raise ResourceError(
            f"Requested {disk_gb} GB disk exceeds available host capacity "
            f"({max(available_disk, 0)} GB free of {node.disk_total_gb} GB total)."
        )

    return True
