"""
Synchronizes a VM's DB status with what the actual Docker/LXC backend
reports right now (spec sections 64-65). Called on-demand when a VM detail
page is opened, so the UI never claims "Running" when the real container
was stopped or deleted out-of-band.
"""
from app.extensions import db
from app.models import VM, VMState
from app.services.provisioning import get_provider


def sync_vm_status(vm: VM):
    # Only meaningful once a container actually exists; earlier lifecycle
    # states are owned by the background provisioning job.
    if vm.status not in (VMState.READY, VMState.RUNNING, VMState.STOPPED, VMState.MISSING):
        return vm

    provider = get_provider(vm.engine)
    try:
        real_status = provider.status(vm)
    except Exception:
        return vm

    if real_status == "running" and vm.status != VMState.RUNNING:
        vm.status = VMState.RUNNING
        db.session.commit()
    elif real_status == "stopped" and vm.status != VMState.STOPPED:
        vm.status = VMState.STOPPED
        db.session.commit()
    elif real_status == "missing" and vm.status != VMState.MISSING:
        # The DB row still exists but the backend container is gone --
        # never pretend it's still running.
        vm.status = VMState.MISSING
        vm.last_error = "The underlying container no longer exists on this host."
        db.session.commit()

    return vm
