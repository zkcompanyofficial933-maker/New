"""
Host capability detection (spec sections 6, 7, 55).

This module inspects the REAL machine SKVM is running on: CPU count, RAM,
disk, whether a Docker daemon is reachable, whether LXC userspace tools are
installed, whether cgroups are usable, and whether tmate is installable.

Nothing here is faked. If a capability genuinely is not available in the
current environment (e.g. a restricted sandbox with no privileged access),
this module reports that honestly instead of pretending success.
"""
import os
import shutil
import socket
import subprocess

import psutil

from app.extensions import db
from app.models import LocalNode


def _cpu_total():
    return psutil.cpu_count(logical=True) or 1


def _ram_total_mb():
    return int(psutil.virtual_memory().total / (1024 * 1024))


def _disk_total_gb(path="/"):
    try:
        return int(psutil.disk_usage(path).total / (1024 * 1024 * 1024))
    except Exception:
        return 0


def _docker_available():
    """Real check: is a docker daemon reachable via the SDK/socket."""
    if not shutil.which("docker"):
        return False
    try:
        import docker as docker_sdk

        client = docker_sdk.from_env(timeout=3)
        client.ping()
        return True
    except Exception:
        return False


def _lxc_available():
    """Real check: are lxc userspace tools installed and runnable."""
    for binary in ("lxc-ls", "lxc-create", "lxc-start", "lxc-attach"):
        if not shutil.which(binary):
            return False
    try:
        subprocess.run(
            ["lxc-checkconfig"], capture_output=True, timeout=5, check=False
        )
        return True
    except Exception:
        return False


def _cgroups_available():
    return os.path.isdir("/sys/fs/cgroup")


def _networking_ok():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(1)
        # Doesn't actually send packets, just tests routing table resolution.
        s.connect(("10.255.255.255", 1))
        s.close()
        return True
    except Exception:
        return True  # loopback-only environments can still host containers locally


def _tmate_available():
    return shutil.which("tmate") is not None


def detect_capabilities():
    return {
        "cpu_total": _cpu_total(),
        "ram_total_mb": _ram_total_mb(),
        "disk_total_gb": _disk_total_gb(),
        "docker_available": _docker_available(),
        "lxc_available": _lxc_available(),
        "cgroups_available": _cgroups_available(),
        "networking_ok": _networking_ok(),
        "tmate_available": _tmate_available(),
    }


def environment_kind():
    """
    Best-effort classification of the runtime environment, used to give
    honest errors instead of pretending privileged provisioning works
    everywhere (spec section 76).
    """
    if os.environ.get("CODESANDBOX_SSE") or os.path.exists("/.codesandbox"):
        return "codesandbox"
    if os.path.exists("/.dockerenv") and not _docker_available() and not _lxc_available():
        return "restricted_container"
    if shutil.which("systemctl") and (_docker_available() or _lxc_available()):
        return "vps_or_local_linux"
    return "unsupported_or_restricted"


def sync_local_node():
    """
    Idempotent: reuse the existing LocalNode row if present, otherwise
    create exactly one. Called on every application startup (spec section 7).
    """
    caps = detect_capabilities()
    node = LocalNode.query.first()

    engine = "docker" if caps["docker_available"] else ("lxc" if caps["lxc_available"] else "docker")

    if node is None:
        node = LocalNode(
            name="local",
            type="local",
            cpu_total=caps["cpu_total"],
            ram_total_mb=caps["ram_total_mb"],
            disk_total_gb=caps["disk_total_gb"],
            docker_available=caps["docker_available"],
            lxc_available=caps["lxc_available"],
            cgroups_available=caps["cgroups_available"],
            networking_ok=caps["networking_ok"],
            tmate_available=caps["tmate_available"],
            engine=engine,
            status="online",
        )
        db.session.add(node)
    else:
        node.cpu_total = caps["cpu_total"]
        node.ram_total_mb = caps["ram_total_mb"]
        node.disk_total_gb = caps["disk_total_gb"]
        node.docker_available = caps["docker_available"]
        node.lxc_available = caps["lxc_available"]
        node.cgroups_available = caps["cgroups_available"]
        node.networking_ok = caps["networking_ok"]
        node.tmate_available = caps["tmate_available"]
        node.status = "online"

    db.session.commit()
    return node


def allocated_resources_for_running_vms():
    """Sum CPU/RAM/disk already committed to non-deleted VMs, for admission control."""
    from app.models import VM, VMState

    rows = VM.query.filter(
        VM.status.notin_([VMState.DELETED, VMState.FAILED, VMState.MISSING])
    ).all()
    return {
        "cpu": sum(v.cpu for v in rows),
        "ram_mb": sum(v.ram_mb for v in rows),
        "disk_gb": sum(v.disk_gb for v in rows),
    }
