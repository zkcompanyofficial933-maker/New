"""
Real Google OAuth 2.0 login (spec section 22). Uses Authlib to perform an
actual authorization-code exchange against Google. If the administrator has
not configured client id/secret in Admin Settings, the routes report
"Google authentication is not configured" instead of showing a non-functional
button.
"""
from authlib.integrations.flask_client import OAuth

from app.models import Settings

oauth = OAuth()
_google_registered = False


def google_configured():
    settings = Settings.query.first()
    return bool(
        settings
        and settings.google_auth_enabled
        and settings.google_client_id
        and settings.google_client_secret
        and settings.google_redirect_uri
    )


def register_google_client(app):
    """(Re)register the google client with the OAuth registry using whatever
    is currently stored in Settings. Safe to call multiple times."""
    global _google_registered
    settings = Settings.query.first()
    if not settings or not settings.google_client_id or not settings.google_client_secret:
        return False

    if "google" in oauth._clients:
        del oauth._clients["google"]

    oauth.init_app(app)
    oauth.register(
        name="google",
        client_id=settings.google_client_id,
        client_secret=settings.google_client_secret,
        server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
        client_kwargs={"scope": "openid email profile"},
    )
    _google_registered = True
    return True
