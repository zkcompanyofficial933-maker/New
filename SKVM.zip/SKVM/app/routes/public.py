from flask import Blueprint, render_template
from flask_login import current_user

from app.models import Settings

public_bp = Blueprint("public", __name__)


@public_bp.route("/")
def starter():
    if current_user.is_authenticated:
        from flask import redirect, url_for

        return redirect(url_for("admin.dashboard" if current_user.is_admin else "user.dashboard"))
    settings = Settings.query.first()
    return render_template("starter.html", settings=settings)
