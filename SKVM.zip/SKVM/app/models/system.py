import uuid
from datetime import datetime

from app.extensions import db


def gen_uuid():
    return str(uuid.uuid4())


class LocalNode(db.Model):
    """
    Exactly one row is ever expected to exist. Represents the machine SKVM
    itself is running on. Created/refreshed automatically on startup
    (see app.services.system.sync_local_node). There is intentionally no
    UI for creating additional nodes.
    """

    __tablename__ = "local_node"

    id = db.Column(db.String(36), primary_key=True, default=gen_uuid)
    name = db.Column(db.String(64), nullable=False, default="local")
    type = db.Column(db.String(20), nullable=False, default="local")

    cpu_total = db.Column(db.Integer, nullable=False, default=0)
    ram_total_mb = db.Column(db.Integer, nullable=False, default=0)
    disk_total_gb = db.Column(db.Integer, nullable=False, default=0)

    docker_available = db.Column(db.Boolean, default=False)
    lxc_available = db.Column(db.Boolean, default=False)
    cgroups_available = db.Column(db.Boolean, default=False)
    networking_ok = db.Column(db.Boolean, default=False)
    tmate_available = db.Column(db.Boolean, default=False)

    engine = db.Column(db.String(10), nullable=False, default="docker")
    status = db.Column(db.String(20), nullable=False, default="online")

    last_checked_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Settings(db.Model):
    """Single-row key/value-ish settings table (id=1 always)."""

    __tablename__ = "settings"

    id = db.Column(db.Integer, primary_key=True)
    panel_name = db.Column(db.String(64), nullable=False, default="SKVM")
    logo_path = db.Column(db.String(256), nullable=True)
    favicon_path = db.Column(db.String(256), nullable=True)
    theme = db.Column(db.String(10), nullable=False, default="dark")  # dark/light/system
    discord_url = db.Column(db.String(256), nullable=True)

    container_engine = db.Column(db.String(10), nullable=False, default="docker")

    google_auth_enabled = db.Column(db.Boolean, default=False)
    google_client_id = db.Column(db.String(256), nullable=True)
    google_client_secret = db.Column(db.String(256), nullable=True)
    google_redirect_uri = db.Column(db.String(256), nullable=True)
    firebase_project_id = db.Column(db.String(128), nullable=True)
    firebase_api_key = db.Column(db.String(256), nullable=True)
    firebase_auth_domain = db.Column(db.String(256), nullable=True)
    firebase_app_id = db.Column(db.String(128), nullable=True)

    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_public_dict(self):
        """Safe subset exposed to unauthenticated pages (no secrets)."""
        return {
            "panel_name": self.panel_name,
            "logo_path": self.logo_path,
            "favicon_path": self.favicon_path,
            "theme": self.theme,
            "discord_url": self.discord_url,
            "google_auth_enabled": self.google_auth_enabled
            and bool(self.google_client_id)
            and bool(self.google_client_secret),
        }


class ActivityLog(db.Model):
    __tablename__ = "activity_logs"

    id = db.Column(db.String(36), primary_key=True, default=gen_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id"), nullable=True)
    action = db.Column(db.String(128), nullable=False)
    target = db.Column(db.String(128), nullable=True)
    status = db.Column(db.String(20), nullable=False, default="ok")  # ok/error
    message = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class ApiKey(db.Model):
    __tablename__ = "api_keys"

    id = db.Column(db.String(36), primary_key=True, default=gen_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey("users.id"), nullable=False)
    name = db.Column(db.String(64), nullable=False)
    key_prefix = db.Column(db.String(12), nullable=False)  # shown in UI list, e.g. "skvm_ab12"
    key_hash = db.Column(db.String(255), nullable=False)
    is_admin_key = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_used = db.Column(db.DateTime, nullable=True)
    revoked = db.Column(db.Boolean, default=False)
