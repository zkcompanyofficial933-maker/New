import uuid
from datetime import datetime

from app.extensions import db


def gen_uuid():
    return str(uuid.uuid4())


# Explicit provisioning states (see spec section 37)
class VMState:
    PENDING = "PENDING"
    VALIDATING = "VALIDATING"
    CREATING = "CREATING"
    INSTALLING_OS = "INSTALLING_OS"
    CONFIGURING = "CONFIGURING"
    STARTING = "STARTING"
    INSTALLING_SSH = "INSTALLING_SSH"
    INSTALLING_TMATE = "INSTALLING_TMATE"
    READY = "READY"
    RUNNING = "RUNNING"
    STOPPED = "STOPPED"
    FAILED = "FAILED"
    DELETING = "DELETING"
    DELETED = "DELETED"
    MISSING = "MISSING"  # orphan: DB row exists but backend container does not


OS_CATALOG = {
    "ubuntu-20.04": {
        "label": "Ubuntu 20.04",
        "docker_image": "ubuntu:20.04",
        "lxc_template": "ubuntu",
        "lxc_release": "focal",
        "family": "debian",
        "icon": "ubuntu",
        "icon_color": "#E95420",
    },
    "ubuntu-22.04": {
        "label": "Ubuntu 22.04",
        "docker_image": "ubuntu:22.04",
        "lxc_template": "ubuntu",
        "lxc_release": "jammy",
        "family": "debian",
        "icon": "ubuntu",
        "icon_color": "#E95420",
    },
    "debian-11": {
        "label": "Debian 11",
        "docker_image": "debian:11",
        "lxc_template": "debian",
        "lxc_release": "bullseye",
        "family": "debian",
        "icon": "debian",
        "icon_color": "#A81D33",
    },
    "debian-12": {
        "label": "Debian 12",
        "docker_image": "debian:12",
        "lxc_template": "debian",
        "lxc_release": "bookworm",
        "family": "debian",
        "icon": "debian",
        "icon_color": "#A81D33",
    },
}


class VM(db.Model):
    __tablename__ = "vms"

    id = db.Column(db.String(36), primary_key=True, default=gen_uuid)
    name = db.Column(db.String(64), nullable=False)
    owner_id = db.Column(db.String(36), db.ForeignKey("users.id"), nullable=False)

    engine = db.Column(db.String(10), nullable=False)  # 'docker' or 'lxc'
    os_key = db.Column(db.String(32), nullable=False)  # key into OS_CATALOG

    status = db.Column(db.String(32), nullable=False, default=VMState.PENDING)
    last_error = db.Column(db.Text, nullable=True)

    container_id = db.Column(db.String(128), nullable=True)  # docker container id / lxc name
    hostname = db.Column(db.String(128), nullable=True)
    username = db.Column(db.String(64), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    ssh_port = db.Column(db.Integer, nullable=True)
    ip_address = db.Column(db.String(64), nullable=True)

    tmate_ssh = db.Column(db.Text, nullable=True)
    tmate_status = db.Column(db.String(20), nullable=True)  # active / expired / none
    tmate_socket_path = db.Column(db.String(256), nullable=True)

    cpu = db.Column(db.Integer, nullable=False)  # vCPUs
    ram_mb = db.Column(db.Integer, nullable=False)
    disk_gb = db.Column(db.Integer, nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self, include_owner=False):
        os_def = OS_CATALOG.get(self.os_key, {})
        d = {
            "id": self.id,
            "name": self.name,
            "engine": self.engine,
            "os": os_def.get("label", self.os_key),
            "os_icon": os_def.get("icon", "linux"),
            "os_icon_color": os_def.get("icon_color", "#8b93a3"),
            "status": self.status,
            "last_error": self.last_error,
            "hostname": self.hostname,
            "username": self.username,
            "ssh_port": self.ssh_port,
            "ip_address": self.ip_address,
            "tmate_status": self.tmate_status,
            "cpu": self.cpu,
            "ram_mb": self.ram_mb,
            "disk_gb": self.disk_gb,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
        if include_owner:
            d["owner_id"] = self.owner_id
        return d
