function copyText(elId) {
  const el = document.getElementById(elId);
  if (!el) return;
  const text = el.innerText;
  navigator.clipboard.writeText(text).then(() => {
    const original = event.target.innerText;
    event.target.innerText = "Copied!";
    setTimeout(() => { event.target.innerText = original; }, 1500);
  });
}

// Auto-dismiss flash messages
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".flash").forEach((el) => {
    setTimeout(() => { el.style.display = "none"; }, 6000);
  });
});
