# SKVM

Real Linux container hosting panel. SKVM provisions genuine **Docker** or **LXC**
containers (branded as "VMs" in the UI) with real SSH access and a real
**tmate** session -- there is no simulated provisioning, no fake container
IDs, and no fabricated access credentials anywhere in this codebase.

## Features

- Two real provisioning engines: Docker (via the official `docker` SDK) and
  LXC (via `lxc-create` / `lxc-attach` / `lxc-cgroup` / `lxc-destroy`).
- Admin selects the engine globally in **Admin Settings**; existing VMs keep
  the engine they were created with even after the setting changes.
- Automatic **local node** detection (CPU/RAM/disk/Docker/LXC/cgroups/
  networking/tmate) on every startup -- no manual node setup, no Nodes page.
- Admin-only VM creation, enforced in the API layer, not just hidden in the UI.
- Background provisioning worker with real state transitions
  (`PENDING -> VALIDATING -> CREATING -> INSTALLING_OS -> CONFIGURING ->
  STARTING -> INSTALLING_SSH -> INSTALLING_TMATE -> READY`), polling-friendly.
- Real SSH server installed and started inside every workload; real tmate
  session bootstrapped and its actual `ssh <session>` string retrieved.
- Resource validation against the real host's CPU/RAM/disk before any
  container is created.
- Real port allocator for exposed SSH ports (socket bind test + DB reservation).
- Argon2 password hashing, session auth, real Google OAuth (Authlib), hashed
  API keys with one-time reveal.
- Clean separation between the Admin Panel (Dashboard / Create VM / API Keys
  / Admin Settings) and the User Panel (Dashboard / My VM / User Settings).
- Original, non-trademarked OS badge icons (Ubuntu/Debian, color-coded) shown
  on the Create VM picker, VM lists, VM detail pages, and the starter page.
- On-demand VM status sync against the real Docker/LXC backend (never shows
  "Running" for a container that was stopped or deleted out-of-band; flags
  orphaned DB rows as `MISSING`).

## Supported operating systems

| OS | Docker image | LXC template |
|---|---|---|
| Ubuntu 20.04 | `ubuntu:20.04` | `download` template, `ubuntu`/`focal` |
| Ubuntu 22.04 | `ubuntu:22.04` | `download` template, `ubuntu`/`jammy` |
| Debian 11 | `debian:11` | `download` template, `debian`/`bullseye` |
| Debian 12 | `debian:12` | `download` template, `debian`/`bookworm` |

## Supported engines

- **Docker** -- requires a reachable Docker daemon (`docker.sock`).
- **LXC** -- requires `lxc-create`, `lxc-start`, `lxc-attach`, `lxc-cgroup`,
  `lxc-destroy`, and the `download` LXC template on the host.

## Architecture

```
app/
  config.py              Environment-driven configuration
  extensions.py           Flask extension singletons (db, login, limiter, argon2)
  models/                 User, VM, LocalNode, Settings, ActivityLog, ApiKey
  auth/                   Login/register/logout, Argon2 hashing, Google OAuth
  routes/                 Server-rendered admin & user panels
  api/                    JSON REST API (session or API-key auth)
  services/
    system.py              Real host capability detection + local node sync
    resources.py            Admission control against real host capacity
    networking.py           Real port allocator
    validation.py           Injection-safe input validation
    jobs.py                 Background provisioning worker (in-process queue)
    provisioning/
      base.py                Common provider interface
      docker_provider.py      Real Docker SDK implementation
      lxc_provider.py         Real LXC CLI implementation
      manager.py               Engine -> provider factory
  templates/, static/       Dark-first UI
tests/                     Pytest suite (infra calls mocked)
install.sh                 Re-run-safe VPS installer
scripts/skvm.service       systemd unit
```

## Installation

`install.sh` is a single **universal installer**. Run the exact same command
everywhere -- it detects the environment and does the right thing:

- **VPS / bare-metal Linux with systemd, run as root**: installs Docker and
  LXC tooling, copies the app to `/opt/skvm`, and installs+starts a
  `skvm` systemd service.
- **CodeSandbox / GitHub Codespaces / Gitpod / any devcontainer without
  systemd, or not run as root**: installs Python deps in place, skips
  system package installation it can't perform without root, and starts
  SKVM directly with `nohup`, writing a `skvm.pid` you can use to stop/restart.

```bash
git clone <repository-url> SKVM
cd SKVM
chmod +x install.sh
./install.sh          # VPS: run with sudo ./install.sh
```

Re-running `./install.sh` (with the same privileges) is always safe -- it
never deletes the database, VMs, containers, or settings; it just updates
code/dependencies and restarts SKVM.

**On a VPS**, manage it with:
```bash
sudo systemctl status skvm
sudo systemctl restart skvm
sudo journalctl -u skvm -f
```

**On CodeSandbox/Codespaces/Gitpod** (no systemd), manage it with:
```bash
kill $(cat skvm.pid)     # stop
./install.sh             # restart (re-run-safe)
tail -f logs/skvm.out    # logs
```

### Manual / GitHub installation

If you'd rather not use the installer at all:

```bash
git clone <repository-url>
cd SKVM
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # edit SECRET_KEY, etc.
python run.py
```

### CodeSandbox / GitHub Codespaces / restricted containers

The Flask web application runs fine in these environments -- you can browse
the UI, register, log in, and explore the admin panel via `./install.sh`
exactly as described above. **Real container provisioning will not work**
there: there is no privileged Docker daemon and no LXC/cgroup access
available. SKVM detects this at startup
(`app/services/system.py::environment_kind`) and the `/api/health` endpoint
will report `engine_status` as unavailable rather than pretending a
container was created. Use a VPS or bare-metal Linux host with Docker or
LXC installed for real provisioning.

## Configuration (`.env`)

See `.env.example`. Key variables:

- `SECRET_KEY`, `DATABASE_URL`, `APP_HOST`, `APP_PORT`
- `BOOTSTRAP_ADMIN_EMAIL` / `BOOTSTRAP_ADMIN_PASSWORD` (first-run only)
- `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` / `GOOGLE_REDIRECT_URI`
- `FIREBASE_PROJECT_ID` / `FIREBASE_API_KEY` / `FIREBASE_AUTH_DOMAIN` / `FIREBASE_APP_ID`
- `SSH_PORT_RANGE_START` / `SSH_PORT_RANGE_END`

Google login and Firebase values can also be set from **Admin Settings** in
the UI; the database values take precedence once configured there.

## Default admin bootstrap credentials

On first run, if no admin account exists, SKVM creates:

- Email: `admin@gmail.com`
- Password: `admin123`

These are **never** shown on the starter, login, or register pages, and never
appear in frontend source. **Change the password immediately** after your
first login via Admin Settings -> Admin Account.

## VM creation workflow

Admin Panel -> Create VM -> fill in name / OS / RAM / CPU / disk / username /
password / hostname -> submit. The request:

1. Is validated (server-side, admin-only).
2. Is checked against the real local node's free capacity.
3. Is queued to a background worker (`app/services/jobs.py`), which:
   - creates the real Docker/LXC container using the selected OS image,
   - applies CPU/RAM (and disk quota where the storage backend supports it),
   - starts the container and records its real IP,
   - allocates a real, collision-free host SSH port,
   - installs and starts a real `sshd` with the requested account,
   - installs `tmate`, starts a real session, and retrieves the actual
     `ssh <session>` string via `tmate ... display -p '#{tmate_ssh}'`,
   - marks the VM `READY` only once every step above has genuinely succeeded.

If any step fails, the VM is marked `FAILED` with the real error message and
any partially-created container is cleaned up automatically.

## SSH / tmate access

The VM detail page shows two access blocks once provisioning reaches
`READY`:

- **SSH Access**: `ssh <username>@<container-ip> -p <allocated-port>`
- **tmate Access**: the real tmate SSH connection string retrieved from the
  running session inside the container.

Use **Regenerate Tmate Session** to kill the old tmate process and bootstrap
a fresh one (spec-compliant "temporary" handling -- tmate sessions are never
treated as permanent credentials).

## Testing

```bash
pip install -r requirements.txt
pip install pytest
pytest
```

Tests mock the Docker SDK / `lxc-*` subprocess calls (no real daemon or LXC
tooling required to run the suite) and cover: registration, login,
admin/user authorization, admin-only VM creation, user VM isolation,
input validation, resource-limit validation, the provider factory,
Docker/LXC provider argv construction, the port allocator, and API-key
issuance/revocation.

## Known limitations / honesty notes

- **This repository was authored and syntax-checked in a sandboxed
  environment with no Docker daemon, no LXC tooling, and no network
  egress.** The Docker and LXC provider code makes real SDK/subprocess
  calls and has been unit-tested with mocks, but it has **not** been run
  end-to-end against a live daemon in that environment. Please validate on
  a real VPS before production use, and open an issue if any provider call
  needs adjusting for your distro's exact package/service names.
- Disk quotas are enforced via `--storage-opt size=` (Docker, overlay2+xfs
  only) or are best-effort; if your storage driver doesn't support a real
  quota, SKVM says so rather than pretending it applied one.
- The background job queue is a simple in-process worker thread, not
  Celery/RQ -- sufficient for a single-node panel; swap `app/services/jobs.py`
  for a Celery/RQ-backed implementation if you need multi-process workers.

## Security

- Argon2 password hashing; no plaintext passwords stored anywhere.
- All provisioning commands use argv lists, never shell string concatenation.
- Server-side authorization on every admin-only route and API endpoint.
- API keys are hashed at rest and shown in full exactly once, at creation.
- Uploaded logos are extension-validated and stored outside any executable path.
- Sensitive values (passwords, tmate sessions, API secrets) are never logged.

## Uninstallation

```bash
sudo systemctl stop skvm
sudo systemctl disable skvm
sudo rm /etc/systemd/system/skvm.service
sudo rm -rf /opt/skvm
```

Consider stopping/removing any Docker containers or LXC containers with the
`skvm-` name prefix first if you want to reclaim those resources.
