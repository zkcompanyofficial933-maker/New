import React, { useEffect, useRef, useState } from 'react';
import { Terminal } from 'xterm';
import { FitAddon } from '@xterm/addon-fit';
import 'xterm/css/xterm.css';
import { VM } from '../types';
import { Play, RotateCcw, Trash2, Maximize2, Minimize2, Terminal as TerminalIcon, AlertCircle, Wifi, WifiOff } from 'lucide-react';

interface TerminalConsoleProps {
  vm: VM;
}

export const TerminalConsole: React.FC<TerminalConsoleProps> = ({ vm }) => {
  const terminalRef = useRef<HTMLDivElement>(null);
  const xtermInstance = useRef<Terminal | null>(null);
  const fitAddonRef = useRef<FitAddon | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected' | 'error'>('connecting');
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const connectWebSocket = () => {
    if (!terminalRef.current) return;
    
    // Clean up any existing connection
    if (wsRef.current) {
      try { wsRef.current.close(); } catch {}
      wsRef.current = null;
    }

    setConnectionStatus('connecting');
    setErrorMessage(null);

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/console?vmId=${vm.id}`;

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setConnectionStatus('connected');
      if (xtermInstance.current && fitAddonRef.current) {
        fitAddonRef.current.fit();
        // Send initial resize
        const { cols, rows } = xtermInstance.current;
        ws.send(JSON.stringify({ type: 'resize', cols, rows }));
      }
    };

    ws.onmessage = (event) => {
      if (xtermInstance.current) {
        xtermInstance.current.write(event.data);
      }
    };

    ws.onerror = () => {
      setConnectionStatus('error');
      setErrorMessage('WebSocket connection failure. Dev server might be reloading.');
    };

    ws.onclose = () => {
      setConnectionStatus('disconnected');
    };
  };

  useEffect(() => {
    if (!terminalRef.current) return;

    // Initialize xterm
    const term = new Terminal({
      cursorBlink: true,
      cursorStyle: 'block',
      fontSize: 13,
      fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
      theme: {
        background: '#090d16',
        foreground: '#e2e8f0',
        cursor: '#38bdf8',
        selectionBackground: 'rgba(56, 189, 248, 0.3)',
        black: '#1e293b',
        red: '#f87171',
        green: '#4ade80',
        yellow: '#facc15',
        blue: '#60a5fa',
        magenta: '#c084fc',
        cyan: '#22d3ee',
        white: '#f8fafc',
        brightBlack: '#475569',
        brightRed: '#ef4444',
        brightGreen: '#22c55e',
        brightYellow: '#eab308',
        brightBlue: '#3b82f6',
        brightMagenta: '#a855f7',
        brightCyan: '#06b6d4',
        brightWhite: '#ffffff'
      },
      convertEol: true
    });

    const fitAddon = new FitAddon();
    term.loadAddon(fitAddon);
    term.open(terminalRef.current);
    fitAddon.fit();

    xtermInstance.current = term;
    fitAddonRef.current = fitAddon;

    term.onData((data) => {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(data);
      }
    });

    term.onResize(({ cols, rows }) => {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'resize', cols, rows }));
      }
    });

    connectWebSocket();

    const handleWindowResize = () => {
      try {
        if (fitAddonRef.current) {
          fitAddonRef.current.fit();
        }
      } catch {}
    };

    window.addEventListener('resize', handleWindowResize);

    return () => {
      window.removeEventListener('resize', handleWindowResize);
      if (wsRef.current) {
        try { wsRef.current.close(); } catch {}
      }
      term.dispose();
    };
  }, [vm.id]);

  useEffect(() => {
    // When entering/exiting fullscreen, fit terminal
    const timer = setTimeout(() => {
      try {
        if (fitAddonRef.current) {
          fitAddonRef.current.fit();
        }
      } catch {}
    }, 150);
    return () => clearTimeout(timer);
  }, [isFullScreen]);

  const handleClear = () => {
    if (xtermInstance.current) {
      xtermInstance.current.clear();
    }
  };

  const handleSendCtrlC = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send('\x03');
    }
  };

  return (
    <div className={`flex flex-col rounded-2xl border border-white/10 bg-[#090d16] overflow-hidden shadow-2xl transition-all ${
      isFullScreen ? 'fixed inset-4 z-50' : 'w-full h-[540px]'
    }`}>
      {/* Terminal Title Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/40 border-b border-white/10 text-xs select-none">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block"></span>
            <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block"></span>
            <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
          </div>
          <div className="h-4 w-px bg-white/10 mx-1"></div>
          <div className="flex items-center gap-1.5 text-slate-300 font-mono font-medium">
            <TerminalIcon className="w-3.5 h-3.5 text-cyan-400" />
            <span>root@{vm.hostname || vm.name}</span>
            <span className="text-slate-600">({vm.containerName})</span>
          </div>
        </div>

        {/* Status Indicator & Controls */}
        <div className="flex items-center gap-2">
          {connectionStatus === 'connected' && (
            <span className="flex items-center gap-1 text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Live PTY
            </span>
          )}
          {connectionStatus === 'connecting' && (
            <span className="flex items-center gap-1 text-[11px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping"></span>
              Connecting...
            </span>
          )}
          {(connectionStatus === 'disconnected' || connectionStatus === 'error') && (
            <span className="flex items-center gap-1 text-[11px] font-mono text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
              <WifiOff className="w-3 h-3" />
              Disconnected
            </span>
          )}

          <button
            onClick={handleSendCtrlC}
            className="px-2 py-1 bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white rounded text-[11px] font-mono transition-colors border border-white/5"
            title="Send SIGINT (Ctrl+C)"
          >
            Ctrl+C
          </button>

          <button
            onClick={handleClear}
            className="p-1 text-slate-400 hover:text-white rounded bg-white/5 hover:bg-white/10 transition-colors"
            title="Clear Terminal Screen"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={connectWebSocket}
            className="p-1 text-slate-400 hover:text-white rounded bg-white/5 hover:bg-white/10 transition-colors"
            title="Reconnect WebSocket PTY"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsFullScreen(!isFullScreen)}
            className="p-1 text-slate-400 hover:text-white rounded bg-white/5 hover:bg-white/10 transition-colors"
            title={isFullScreen ? 'Exit Full Screen' : 'Full Screen'}
          >
            {isFullScreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Terminal Viewport */}
      <div className="flex-1 p-2 bg-[#090d16] overflow-hidden" ref={terminalRef}></div>

      {/* Terminal Bottom Helper Bar */}
      <div className="px-4 py-2 bg-black/40 border-t border-white/5 text-[11px] text-slate-400 flex items-center justify-between font-mono">
        <div className="flex items-center gap-3">
          <span>Target: <span className="text-slate-300 font-semibold">{vm.isRealDockerContainer ? 'Docker Container' : 'Native Shell'}</span></span>
          <span>•</span>
          <span>TTY: <span className="text-slate-300 font-semibold">xterm-256color</span></span>
        </div>
        <div className="text-slate-500 text-[10px]">
          Direct PTY stream via WebSocket
        </div>
      </div>
    </div>
  );
};
