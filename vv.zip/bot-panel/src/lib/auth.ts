import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { prisma } from "./prisma";

const JWT_SECRET = process.env.JWT_SECRET || "";
const COOKIE_NAME = "bot_panel_session";

if (!JWT_SECRET && process.env.NODE_ENV === "production") {
  throw new Error("JWT_SECRET must be set in production. See .env.example.");
}

export interface SessionPayload {
  userId: string;
  role: "ADMIN" | "USER";
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 12);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

export function signSession(payload: SessionPayload): string {
  return jwt.sign(payload, JWT_SECRET || "dev-secret-do-not-use-in-prod", { expiresIn: "7d" });
}

export function verifySession(token: string): SessionPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET || "dev-secret-do-not-use-in-prod") as SessionPayload;
  } catch {
    return null;
  }
}

/** Reads and verifies the session cookie for the current request (Route Handlers / Server Components). */
export async function getCurrentUser() {
  const token = cookies().get(COOKIE_NAME)?.value;
  if (!token) return null;
  const session = verifySession(token);
  if (!session) return null;

  const user = await prisma.user.findUnique({ where: { id: session.userId } });
  return user;
}

export function sessionCookieOptions() {
  return {
    name: COOKIE_NAME,
    httpOnly: true,
    // Defaults to false so the panel works out of the box over plain HTTP
    // (the common case for a self-hosted panel on a bare IP/port). If you
    // put the panel behind HTTPS (a reverse proxy with TLS), set
    // COOKIE_SECURE=true in .env so the session cookie is only ever sent
    // over an encrypted connection.
    secure: process.env.COOKIE_SECURE === "true",
    sameSite: "lax" as const,
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  };
}

export { COOKIE_NAME };
